<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * MySQL port of the Next.js/Drizzle PostgreSQL schema in
 * luxury-attractions-hotels-source.zip (src/db/schema.ts).
 *
 * Conversion rules used:
 *   serial              -> bigIncrements (Laravel id())
 *   text                -> varchar(n) where the column is indexed/unique, otherwise TEXT
 *   numeric(p,s)        -> decimal(p,s)
 *   jsonb               -> json
 *   boolean             -> tinyint(1)
 *   date                -> date
 *   timestamptz         -> timestamp (MySQL stores UTC, app timezone Asia/Dubai)
 *   uniqueIndex/index   -> unique()/index() with InnoDB-safe key lengths (<=191 chars)
 *
 * Tables are created in foreign-key dependency order because MySQL, unlike
 * PostgreSQL, cannot reference a table that does not exist yet.
 */
return new class extends Migration
{
    public function up(): void
    {
        // 1 · Private key/value store. Held SESSION_SECRET in the Node version;
        // Laravel keeps its APP_KEY in .env, so this stores app preferences only.
        Schema::create('app_settings', function (Blueprint $t) {
            $t->string('key', 120)->primary();
            $t->text('value');
            $t->timestamp('created_at')->useCurrent();
        });

        // 2 · Company/branding settings written by the installer.
        Schema::create('settings', function (Blueprint $t) {
            $t->id();
            $t->string('group', 60)->index();
            $t->string('key', 120);
            $t->text('value')->nullable();
            $t->timestamps();
            $t->unique(['group', 'key'], 'settings_group_key_unique');
        });

        // 3 · Staff accounts (administrator / contract manager / sales agent / viewer).
        Schema::create('users', function (Blueprint $t) {
            $t->id();
            $t->string('name', 150);
            $t->string('username', 60)->nullable()->unique();
            $t->string('email', 190)->unique();
            $t->string('password_hash', 255);
            $t->string('role', 40)->default('viewer');
            $t->json('permissions')->nullable();
            $t->boolean('active')->default(true);
            $t->unsignedInteger('session_version')->default(1);
            $t->unsignedInteger('failed_attempts')->default(0);
            $t->timestamp('locked_until')->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            $t->rememberToken();
        });

        // 4 · Single-use SHA-256 hashed password recovery links (30 min expiry).
        Schema::create('password_reset_tokens', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $t->string('token_hash', 64)->unique();
            $t->timestamp('expires_at');
            $t->timestamp('consumed_at')->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['user_id', 'created_at'], 'password_reset_user_created_idx');
        });

        // 5 · Lookups referenced by hotels.
        Schema::create('locations', function (Blueprint $t) {
            $t->id();
            $t->string('city', 120);
            $t->string('name', 150);
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->useCurrent();
            $t->unique(['city', 'name'], 'locations_city_name_unique');
        });

        Schema::create('markets', function (Blueprint $t) {
            $t->id();
            $t->string('slug', 60)->unique();
            $t->string('label', 120);
            $t->unsignedInteger('sort_order')->default(100);
            $t->boolean('active')->default(true);
        });

        Schema::create('hotel_groups', function (Blueprint $t) {
            $t->id();
            $t->string('name', 150)->unique();
            $t->string('website', 255)->default('');
            $t->text('notes')->nullable();
            $t->boolean('active')->default(true);
        });

        Schema::create('amenities', function (Blueprint $t) {
            $t->id();
            $t->string('slug', 60)->unique();
            $t->string('label', 120);
            $t->string('icon', 60)->default('check');
            $t->unsignedInteger('sort_order')->default(100);
            $t->boolean('active')->default(true);
        });

        Schema::create('room_categories', function (Blueprint $t) {
            $t->id();
            $t->string('slug', 60)->unique();
            $t->string('label', 120);
            $t->unsignedInteger('sort_order')->default(100);
            $t->boolean('active')->default(true);
        });

        // 6 · Contracted hotels / suppliers.
        Schema::create('hotels', function (Blueprint $t) {
            $t->id();
            $t->string('name', 190);
            $t->string('city', 120);
            $t->foreignId('location_id')->nullable()->constrained('locations')->nullOnDelete();
            $t->string('country', 120)->default('United Arab Emirates');
            $t->string('address', 255)->default('');
            $t->unsignedTinyInteger('star_rating')->default(5);
            $t->string('supplier_code', 60)->unique();
            $t->foreignId('group_id')->nullable()->constrained('hotel_groups')->nullOnDelete();
            $t->string('business_type', 60)->default('Hotel');
            $t->string('website', 255)->default('');
            $t->string('contracts_folder_link', 500)->default('');
            $t->string('media_link', 500)->default('');
            $t->string('contact_email', 190)->default('');
            $t->string('contact_phone', 60)->default('');
            $t->string('currency', 8)->default('AED');
            $t->string('check_in_time', 12)->default('15:00');
            $t->string('check_out_time', 12)->default('12:00');
            $t->decimal('tourism_tax', 10, 2)->default(0);
            $t->string('tourism_tax_basis', 30)->default('room_night');
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->useCurrent();
            $t->index(['city', 'name'], 'hotels_city_name_idx');
        });

        Schema::create('hotel_amenities', function (Blueprint $t) {
            $t->id();
            $t->foreignId('hotel_id')->constrained('hotels')->cascadeOnDelete();
            $t->foreignId('amenity_id')->constrained('amenities')->cascadeOnDelete();
            $t->unique(['hotel_id', 'amenity_id'], 'hotel_amenities_unique');
        });

        // 7 · Hotel contact people, optionally shared across a group.
        Schema::create('hotel_contacts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('hotel_id')->nullable()->constrained('hotels')->nullOnDelete();
            $t->foreignId('group_id')->nullable()->constrained('hotel_groups')->nullOnDelete();
            $t->string('name', 150);
            $t->string('position', 120)->default('');
            $t->string('email', 190)->default('');
            $t->string('phone', 60)->default('');
            $t->string('business_card_link', 500)->default('');
            $t->boolean('whatsapp')->default(false);
            $t->boolean('telegram')->default(false);
            $t->boolean('viber')->default(false);
            $t->string('other_contact', 150)->default('');
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->useCurrent();
        });

        Schema::create('hotel_contact_assignments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('hotel_id')->constrained('hotels')->cascadeOnDelete();
            $t->foreignId('contact_id')->constrained('hotel_contacts')->cascadeOnDelete();
            $t->timestamp('created_at')->useCurrent();
            $t->unique(['hotel_id', 'contact_id'], 'hotel_contact_assignments_unique');
        });

        // 8 · Rooms, occupancy and bedding.
        Schema::create('room_types', function (Blueprint $t) {
            $t->id();
            $t->foreignId('hotel_id')->constrained('hotels')->cascadeOnDelete();
            $t->string('name', 150);
            $t->string('code', 60);
            $t->string('category', 60)->default('deluxe_king');
            $t->text('description')->nullable();
            $t->string('media_link', 500)->default('');
            $t->unsignedTinyInteger('max_adults')->default(2);
            $t->unsignedTinyInteger('max_children')->default(0);
            $t->unsignedTinyInteger('max_infants')->default(0);
            $t->unsignedTinyInteger('included_adults')->default(2);
            $t->unsignedTinyInteger('base_sleeps')->default(2);
            $t->unsignedSmallInteger('default_inventory')->default(1);
            $t->boolean('extra_bed_allowed')->default(false);
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->useCurrent();
            $t->unique(['hotel_id', 'code'], 'room_types_hotel_code_unique');
        });

        Schema::create('occupancy_rules', function (Blueprint $t) {
            $t->id();
            $t->foreignId('room_type_id')->constrained('room_types')->cascadeOnDelete();
            $t->unsignedTinyInteger('adults');
            $t->unsignedTinyInteger('children')->default(0);
            $t->unsignedTinyInteger('infants')->default(0);
            $t->unsignedTinyInteger('extra_beds')->default(0);
            $t->string('label', 150)->default('');
        });

        Schema::create('room_bedding', function (Blueprint $t) {
            $t->id();
            $t->foreignId('room_type_id')->constrained('room_types')->cascadeOnDelete();
            $t->string('kind', 40);
            $t->string('label', 120);
            $t->unsignedTinyInteger('max_per_room')->default(1);
            $t->boolean('free')->default(false);
            $t->decimal('rate_per_night', 10, 2)->default(0);
            $t->boolean('per_stay')->default(false);
            $t->unsignedInteger('sort_order')->default(100);
            $t->unique(['room_type_id', 'kind'], 'room_bedding_unique');
        });

        // 9 · Contracted rate periods (net supplier pricing).
        Schema::create('rate_periods', function (Blueprint $t) {
            $t->id();
            $t->foreignId('hotel_id')->constrained('hotels')->cascadeOnDelete();
            $t->foreignId('room_type_id')->constrained('room_types')->cascadeOnDelete();
            $t->string('name', 150);
            $t->string('board_type', 40)->default('breakfast');
            $t->date('valid_from');
            $t->date('valid_to');
            $t->date('booking_window_start')->nullable();
            $t->date('booking_window_end')->nullable();
            $t->string('market', 60)->default('all');
            $t->string('market_exclusions', 255)->default('');
            $t->string('promo_code', 60)->default('');
            $t->decimal('base_rate', 12, 2);
            $t->string('rate_basis', 30)->default('room_night');
            $t->decimal('board_adult_supplement', 10, 2)->default(0);
            $t->decimal('board_child_supplement', 10, 2)->default(0);
            $t->string('board_supplement_basis', 30)->default('person_night');
            $t->decimal('extra_adult_rate', 10, 2)->default(0);
            $t->decimal('extra_child_rate', 10, 2)->default(0);
            $t->decimal('extra_bed_rate', 10, 2)->default(0);
            $t->string('extra_bed_basis', 30)->default('bed_night');
            $t->unsignedTinyInteger('minimum_nights')->default(1);
            $t->boolean('active')->default(true);
            $t->timestamp('created_at')->useCurrent();
            $t->index(['hotel_id'], 'rate_periods_hotel_idx');
            $t->index(['room_type_id', 'valid_from', 'valid_to'], 'rate_periods_room_dates_idx');
        });

        Schema::create('blackout_dates', function (Blueprint $t) {
            $t->id();
            $t->foreignId('hotel_id')->constrained('hotels')->cascadeOnDelete();
            $t->foreignId('room_type_id')->nullable()->constrained('room_types')->cascadeOnDelete();
            $t->date('start_date');
            $t->date('end_date');
            $t->string('reason', 190)->default('Sold out by hotel');
            $t->timestamp('created_at')->useCurrent();
            $t->index(['hotel_id', 'start_date', 'end_date'], 'blackout_dates_hotel_dates_idx');
        });

        // 10 · Quotations, then bookings (bookings may originate from a quotation).
        Schema::create('quotations', function (Blueprint $t) {
            $t->id();
            $t->string('reference', 40)->unique();
            $t->string('client_name', 150);
            $t->string('client_email', 190)->default('');
            $t->string('client_phone', 60)->default('');
            $t->string('market', 60)->default('all');
            $t->string('status', 30)->default('draft');
            $t->decimal('total_amount', 12, 2)->default(0);
            $t->string('currency', 8)->default('AED');
            $t->date('valid_until')->nullable();
            $t->text('notes')->nullable();
            $t->boolean('include_tourism_tax')->default(true);
            $t->decimal('markup_percent', 8, 2)->default(0);
            $t->decimal('markup_amount', 12, 2)->default(0);
            $t->decimal('proposal_total', 12, 2)->default(0);
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('created_at')->useCurrent();
        });

        Schema::create('bookings', function (Blueprint $t) {
            $t->id();
            $t->string('reference', 40)->unique();
            $t->foreignId('hotel_id')->constrained('hotels')->restrictOnDelete();
            $t->foreignId('room_type_id')->constrained('room_types')->restrictOnDelete();
            $t->foreignId('rate_period_id')->constrained('rate_periods')->restrictOnDelete();
            $t->string('board_type', 40)->default('breakfast');
            $t->string('guest_name', 150);
            $t->string('guest_email', 190);
            $t->string('guest_phone', 60)->default('');
            $t->date('check_in');
            $t->date('check_out');
            $t->unsignedTinyInteger('adults');
            $t->unsignedTinyInteger('children')->default(0);
            $t->unsignedTinyInteger('infants')->default(0);
            $t->unsignedTinyInteger('rooms')->default(1);
            $t->unsignedTinyInteger('extra_beds')->default(0);
            $t->unsignedTinyInteger('sofa_beds')->default(0);
            $t->unsignedTinyInteger('baby_cots')->default(0);
            $t->unsignedSmallInteger('nights');
            $t->decimal('base_amount', 12, 2);
            $t->decimal('board_amount', 12, 2)->default(0);
            $t->decimal('occupancy_amount', 12, 2)->default(0);
            $t->decimal('extra_bed_amount', 12, 2)->default(0);
            $t->decimal('tourism_tax_amount', 12, 2)->default(0);
            $t->decimal('total_amount', 12, 2);
            $t->string('currency', 8)->default('AED');
            $t->string('status', 30)->default('confirmed');
            $t->text('notes')->nullable();
            $t->foreignId('quotation_id')->nullable()->constrained('quotations')->nullOnDelete();
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['check_in', 'check_out'], 'bookings_dates_idx');
        });

        Schema::create('quotation_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('quotation_id')->constrained('quotations')->cascadeOnDelete();
            $t->unsignedInteger('position')->default(1);
            $t->foreignId('hotel_id')->nullable()->constrained('hotels')->nullOnDelete();
            $t->foreignId('room_type_id')->nullable()->constrained('room_types')->nullOnDelete();
            $t->foreignId('rate_period_id')->nullable()->constrained('rate_periods')->nullOnDelete();
            $t->string('board_type', 40)->default('breakfast');
            $t->date('check_in');
            $t->date('check_out');
            $t->unsignedSmallInteger('nights');
            $t->unsignedTinyInteger('adults');
            $t->unsignedTinyInteger('children')->default(0);
            $t->unsignedTinyInteger('infants')->default(0);
            $t->unsignedTinyInteger('rooms')->default(1);
            $t->unsignedTinyInteger('extra_beds')->default(0);
            $t->unsignedTinyInteger('sofa_beds')->default(0);
            $t->unsignedTinyInteger('baby_cots')->default(0);
            $t->decimal('base_amount', 12, 2)->default(0);
            $t->decimal('board_amount', 12, 2)->default(0);
            $t->decimal('occupancy_amount', 12, 2)->default(0);
            $t->decimal('extra_bed_amount', 12, 2)->default(0);
            $t->decimal('tourism_tax_amount', 12, 2)->default(0);
            $t->decimal('total_amount', 12, 2)->default(0);
            $t->string('rate_names', 255)->default('');
            $t->string('promo_codes', 255)->default('');
            // Drizzle stored these as TEXT holding JSON; kept as JSON for MySQL.
            $t->json('allocation_json')->nullable();
            $t->json('nightly_json')->nullable();
            $t->index(['quotation_id'], 'quotation_items_quotation_idx');
        });

        // 11 · Transfers and tours used inside trip packages.
        Schema::create('services', function (Blueprint $t) {
            $t->id();
            $t->string('kind', 30)->default('transfer')->index();
            $t->string('name', 190);
            $t->text('description')->nullable();
            $t->string('city', 120)->default('Dubai');
            $t->string('duration', 90)->default('');
            $t->decimal('shared_oneway_price', 10, 2)->default(0);
            $t->decimal('shared_twoway_price', 10, 2)->default(0);
            $t->decimal('private7_oneway_price', 10, 2)->default(0);
            $t->decimal('private7_twoway_price', 10, 2)->default(0);
            $t->decimal('private12_oneway_price', 10, 2)->default(0);
            $t->decimal('private12_twoway_price', 10, 2)->default(0);
            $t->decimal('ticket_only_adult', 10, 2)->default(0);
            $t->decimal('ticket_only_child', 10, 2)->default(0);
            $t->decimal('shared_adult', 10, 2)->default(0);
            $t->decimal('shared_child', 10, 2)->default(0);
            $t->decimal('private_adult', 10, 2)->default(0);
            $t->decimal('private_child', 10, 2)->default(0);
            $t->boolean('active')->default(true);
            $t->unsignedInteger('sort_order')->default(100);
            $t->timestamp('created_at')->useCurrent();
        });

        Schema::create('trip_packages', function (Blueprint $t) {
            $t->id();
            $t->string('reference', 40)->unique();
            $t->string('client_name', 150);
            $t->string('client_email', 190)->default('');
            $t->string('client_phone', 60)->default('');
            $t->foreignId('quotation_id')->nullable()->constrained('quotations')->nullOnDelete();
            $t->string('market', 60)->default('all');
            $t->string('status', 30)->default('draft');
            $t->unsignedTinyInteger('adults')->default(2);
            $t->unsignedTinyInteger('children')->default(0);
            $t->unsignedTinyInteger('infants')->default(0);
            $t->boolean('include_tourism_tax')->default(true);
            $t->decimal('markup_percent', 8, 2)->default(0);
            $t->decimal('markup_amount', 12, 2)->default(0);
            $t->decimal('hotels_net', 12, 2)->default(0);
            $t->decimal('transfers_net', 12, 2)->default(0);
            $t->decimal('tours_net', 12, 2)->default(0);
            $t->decimal('subtotal_net', 12, 2)->default(0);
            $t->decimal('proposal_total', 12, 2)->default(0);
            $t->string('currency', 8)->default('AED');
            $t->date('valid_until')->nullable();
            $t->text('notes')->nullable();
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('created_at')->useCurrent();
        });

        Schema::create('trip_package_transfers', function (Blueprint $t) {
            $t->id();
            $t->foreignId('package_id')->constrained('trip_packages')->cascadeOnDelete();
            $t->unsignedInteger('position')->default(1);
            $t->foreignId('service_id')->nullable()->constrained('services')->nullOnDelete();
            $t->string('service_name', 190)->default('');
            $t->string('mode', 30)->default('shared');
            $t->string('direction', 30)->default('oneway');
            $t->string('vehicle', 60)->default('');
            $t->date('transfer_date');
            $t->string('transfer_time', 12)->default('');
            $t->string('pickup', 190)->default('');
            $t->string('dropoff', 190)->default('');
            $t->string('flight_no', 30)->default('');
            $t->unsignedTinyInteger('adults')->default(2);
            $t->unsignedTinyInteger('children')->default(0);
            $t->unsignedTinyInteger('vehicles')->default(1);
            $t->decimal('unit_price', 10, 2)->default(0);
            $t->decimal('total_net', 12, 2)->default(0);
            $t->text('notes')->nullable();
            $t->index(['package_id'], 'trip_transfers_package_idx');
        });

        Schema::create('trip_package_tours', function (Blueprint $t) {
            $t->id();
            $t->foreignId('package_id')->constrained('trip_packages')->cascadeOnDelete();
            $t->unsignedInteger('position')->default(1);
            $t->foreignId('service_id')->nullable()->constrained('services')->nullOnDelete();
            $t->string('service_name', 190)->default('');
            $t->string('option_mode', 30)->default('shared');
            $t->date('tour_date');
            $t->string('tour_time', 12)->default('');
            $t->string('meeting_point', 190)->default('');
            $t->unsignedTinyInteger('adults')->default(2);
            $t->unsignedTinyInteger('children')->default(0);
            $t->decimal('price_adult', 10, 2)->default(0);
            $t->decimal('price_child', 10, 2)->default(0);
            $t->decimal('total_net', 12, 2)->default(0);
            $t->text('notes')->nullable();
            $t->index(['package_id'], 'trip_tours_package_idx');
        });

        // 12 · Audit trail (new – the Node version logged nothing server side).
        Schema::create('audit_logs', function (Blueprint $t) {
            $t->id();
            $t->string('entity', 60)->index();
            $t->unsignedBigInteger('entity_id')->nullable();
            $t->string('action', 60);
            $t->json('payload')->nullable();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('ip', 45)->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['entity', 'entity_id'], 'audit_entity_idx');
        });
    }

    public function down(): void
    {
        foreach ([
            'audit_logs', 'trip_package_tours', 'trip_package_transfers', 'trip_packages',
            'services', 'quotation_items', 'bookings', 'quotations', 'blackout_dates',
            'rate_periods', 'room_bedding', 'occupancy_rules', 'room_types',
            'hotel_contact_assignments', 'hotel_contacts', 'hotel_amenities', 'hotels',
            'room_categories', 'amenities', 'hotel_groups', 'markets', 'locations',
            'password_reset_tokens', 'users', 'settings', 'app_settings',
        ] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
