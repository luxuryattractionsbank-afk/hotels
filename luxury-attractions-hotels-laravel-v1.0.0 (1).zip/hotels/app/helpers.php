<?php

use App\Support\Catalog;
use App\Support\Fmt;
use App\Support\Perm;

if (! function_exists('money')) {
    function money($n, ?string $cur = null): string { return Fmt::money($n, $cur ?? 'AED'); }
}
if (! function_exists('lbl')) {
    function lbl(?string $s): string { return Fmt::label($s); }
}
if (! function_exists('board_lbl')) {
    function board_lbl(?string $s): string { return Catalog::boardLabel((string) $s); }
}
if (! function_exists('badge')) {
    function badge(?string $s): string
    {
        $c = match ($s) {
            'confirmed', 'completed', 'sent', 'active' => 'bg-emerald-100 text-emerald-800',
            'draft', 'on_hold', 'pending' => 'bg-amber-100 text-amber-800',
            'cancelled', 'expired' => 'bg-red-100 text-red-700',
            default => 'bg-slate-100 text-slate-700',
        };
        return '<span class="badge '.$c.'">'.e(Fmt::label($s)).'</span>';
    }
}
if (! function_exists('can')) {
    /** Permission check used by every Blade view; the server re-checks in middleware. */
    function can(string $p): bool { return Perm::allows(auth()->user(), $p); }
}
if (! function_exists('setting')) {
    function setting(string $key, $default = '') { return \App\Support\Settings::company($key, $default); }
}
