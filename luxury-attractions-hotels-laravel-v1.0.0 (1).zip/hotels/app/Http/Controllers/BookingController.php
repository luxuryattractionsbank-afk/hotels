<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Support\Audit;
use App\Support\Catalog;
use App\Support\Pricing;
use App\Support\Reference;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Confirmed hotel stays. Replaces api/bookings and the booking side of search-panel.
 * A booking is always priced from a real contract line so the stored amounts match search.
 */
class BookingController extends Controller
{
    public function index(Request $r)
    {
        return view('bookings.index', [
            'bookings' => Booking::with(['hotel', 'roomType'])
                ->when($r->input('q'), function ($q, $term) {
                    $like = '%'.trim($term).'%';
                    $q->where(fn ($w) => $w->where('reference', 'like', $like)->orWhere('guest_name', 'like', $like)->orWhere('guest_email', 'like', $like));
                })
                ->when($r->input('status'), fn ($q, $s) => $q->where('status', $s))
                ->when($r->input('from'), fn ($q, $d) => $q->where('check_in', '>=', $d))
                ->when($r->input('to'), fn ($q, $d) => $q->where('check_out', '<=', $d))
                ->orderByDesc('check_in')->paginate(25)->withQueryString(),
            'statuses' => Catalog::STATUSES,
        ]);
    }

    /** Opened from a search result: everything is already priced by the engine. */
    public function create(Request $r)
    {
        $offer = $r->input('offer') ? json_decode(base64_decode((string) $r->input('offer')), true) : null;

        return view('bookings.form', [
            'offer' => $offer,
            'hotels' => DB::table('hotels')->where('active', 1)->orderBy('name')->get(['id', 'name']),
            'rooms' => DB::table('room_types')->where('active', 1)->orderBy('name')->get(['id', 'name', 'hotel_id']),
            'rates' => DB::table('rate_periods')->where('active', 1)->orderByDesc('valid_from')
                ->get(['id', 'hotel_id', 'room_type_id', 'name', 'board_type', 'valid_from', 'valid_to', 'base_rate']),
            'boards' => Catalog::BOARD_TYPES,
            'statuses' => Catalog::STATUSES,
        ]);
    }

    public function store(Request $r)
    {
        $d = $r->validate([
            'hotel_id' => 'required|integer|exists:hotels,id',
            'room_type_id' => 'required|integer|exists:room_types,id',
            'board_type' => 'required|string|max:40',
            'guest_name' => 'required|string|max:150',
            'guest_email' => 'required|email|max:190',
            'guest_phone' => 'nullable|string|max:60',
            'check_in' => 'required|date',
            'check_out' => 'required|date|after:check_in',
            'adults' => 'required|integer|min:1',
            'children' => 'nullable|integer|min:0',
            'infants' => 'nullable|integer|min:0',
            'rooms' => 'required|integer|min:1',
            'extra_beds' => 'nullable|integer|min:0',
            'sofa_beds' => 'nullable|integer|min:0',
            'baby_cots' => 'nullable|integer|min:0',
            'status' => 'nullable|string|max:30',
            'notes' => 'nullable|string',
            'quotation_id' => 'nullable|integer|exists:quotations,id',
        ]);

        // Re-price server side – never trust amounts posted from the browser.
        $criteria = [
            'checkIn' => $d['check_in'], 'checkOut' => $d['check_out'], 'bookingDate' => Pricing::todayIso(),
            'adults' => (int) $d['adults'], 'children' => (int) ($d['children'] ?? 0), 'infants' => (int) ($d['infants'] ?? 0),
            'rooms' => (int) $d['rooms'], 'extraBeds' => (int) ($d['extra_beds'] ?? 0), 'sofaBeds' => (int) ($d['sofa_beds'] ?? 0),
            'babyCots' => (int) ($d['baby_cots'] ?? 0), 'category' => 'any', 'market' => 'all',
            'hotelId' => (int) $d['hotel_id'], 'roomTypeId' => (int) $d['room_type_id'],
        ];
        $result = Pricing::evaluateAvailability(Pricing::context(), $criteria);
        if ($result['error']) return back()->withInput()->with('error', $result['error']);

        $offer = null;
        foreach ($result['results'] as $res) {
            foreach ($res['offers'] as $o) {
                if ($o['boardType'] === $d['board_type']) { $offer = $o; break 2; }
            }
        }
        // Never store a booking we could not price from a real contract line.
        if (! $offer) {
            return back()->withInput()->with(
                'error',
                $result['excluded'][0]['reason'] ?? "No $d[board_type] contract covers those dates for that room.",
            );
        }

        $row = [
            'reference' => Reference::booking(),
            'hotel_id' => (int) $d['hotel_id'], 'room_type_id' => (int) $d['room_type_id'],
            'rate_period_id' => $offer['primaryRatePeriodId'] ?? DB::table('rate_periods')->where('room_type_id', $d['room_type_id'])->value('id'),
            'board_type' => $d['board_type'], 'guest_name' => $d['guest_name'], 'guest_email' => $d['guest_email'],
            'guest_phone' => $d['guest_phone'] ?? '', 'check_in' => $d['check_in'], 'check_out' => $d['check_out'],
            'adults' => (int) $d['adults'], 'children' => (int) ($d['children'] ?? 0), 'infants' => (int) ($d['infants'] ?? 0),
            'rooms' => (int) $d['rooms'],
            'extra_beds' => $offer['extraBeds'] ?? (int) ($d['extra_beds'] ?? 0),
            'sofa_beds' => $offer['sofaBeds'] ?? (int) ($d['sofa_beds'] ?? 0),
            'baby_cots' => $offer['babyCots'] ?? (int) ($d['baby_cots'] ?? 0),
            'nights' => $offer['nights'] ?? Pricing::daysBetween($d['check_in'], $d['check_out']),
            'base_amount' => $offer['baseAmount'] ?? 0, 'board_amount' => $offer['boardAmount'] ?? 0,
            'occupancy_amount' => $offer['occupancyAmount'] ?? 0, 'extra_bed_amount' => $offer['extraBedAmount'] ?? 0,
            'tourism_tax_amount' => $offer['tourismTaxAmount'] ?? 0, 'total_amount' => $offer['totalAmount'] ?? 0,
            'currency' => DB::table('hotels')->where('id', $d['hotel_id'])->value('currency') ?: 'AED',
            'status' => $d['status'] ?: 'confirmed', 'notes' => $d['notes'] ?? '',
            'quotation_id' => $d['quotation_id'] ?? null, 'created_by' => $r->user()?->id, 'created_at' => now(),
        ];

        $id = DB::table('bookings')->insertGetId($row);
        Audit::log('booking', $id, 'created', ['reference' => $row['reference'], 'total' => $row['total_amount']]);

        return redirect('/bookings/'.$id)->with('ok', 'Booking '.$row['reference'].' confirmed.');
    }

    public function show(int $id)
    {
        return view('bookings.show', [
            'booking' => Booking::with(['hotel', 'roomType', 'ratePeriod', 'quotation', 'creator'])->findOrFail($id),
            'nights' => DB::table('bookings')->where('id', $id)->get(['check_in', 'check_out'])
                ->map(fn ($b) => Pricing::eachNight((string) $b->check_in, (string) $b->check_out))->first() ?? [],
        ]);
    }

    public function status(Request $r, int $id)
    {
        $d = $r->validate(['status' => 'required|string|in:'.implode(',', Catalog::STATUSES)]);
        DB::table('bookings')->where('id', $id)->update(['status' => $d['status']]);
        Audit::log('booking', $id, 'status_changed', ['status' => $d['status']]);

        return back()->with('ok', 'Booking marked '.$d['status'].'.');
    }

    public function destroy(int $id)
    {
        $ref = DB::table('bookings')->where('id', $id)->value('reference');
        DB::table('bookings')->where('id', $id)->delete();
        Audit::log('booking', $id, 'deleted', ['reference' => $ref]);

        return redirect('/bookings')->with('ok', 'Booking '.$ref.' deleted – the allocation is released.');
    }
}
