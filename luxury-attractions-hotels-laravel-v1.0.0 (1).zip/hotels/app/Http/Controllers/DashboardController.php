<?php

namespace App\Http\Controllers;

use App\Support\Catalog;
use App\Support\Perm;
use Illuminate\Support\Facades\DB;

/** Landing page: contract coverage, upcoming arrivals and document counters. */
class DashboardController extends Controller
{
    public function index()
    {
        $today = now()->toDateString();
        $in30 = now()->addDays(30)->toDateString();

        $stats = [
            'hotels' => DB::table('hotels')->where('active', 1)->count(),
            'rooms' => DB::table('room_types')->where('active', 1)->count(),
            'rates' => DB::table('rate_periods')->where('active', 1)->where('valid_to', '>=', $today)->count(),
            'contacts' => DB::table('hotel_contacts')->where('active', 1)->count(),
            'services' => DB::table('services')->where('active', 1)->count(),
            'quotations' => DB::table('quotations')->count(),
            'packages' => DB::table('trip_packages')->count(),
        ];

        return view('dashboard', [
            'stats' => $stats,
            'arrivals' => DB::table('bookings')
                ->join('hotels', 'hotels.id', '=', 'bookings.hotel_id')
                ->join('room_types', 'room_types.id', '=', 'bookings.room_type_id')
                ->where('bookings.check_in', '>=', $today)->where('bookings.check_in', '<=', $in30)
                ->where('bookings.status', '!=', 'cancelled')
                ->orderBy('bookings.check_in')->limit(12)
                ->get(['bookings.*', 'hotels.name as hotel_name', 'hotels.city', 'room_types.name as room_name']),
            'recentQuotations' => DB::table('quotations')->orderByDesc('id')->limit(8)
                ->get(['id', 'reference', 'client_name', 'status', 'proposal_total', 'currency', 'created_at']),
            'expiringRates' => DB::table('rate_periods')
                ->join('hotels', 'hotels.id', '=', 'rate_periods.hotel_id')
                ->where('rate_periods.active', 1)->where('rate_periods.valid_to', '>=', $today)
                ->where('rate_periods.valid_to', '<=', now()->addDays(60)->toDateString())
                ->orderBy('rate_periods.valid_to')->limit(8)
                ->get(['rate_periods.id', 'rate_periods.name', 'rate_periods.valid_to', 'rate_periods.base_rate', 'hotels.name as hotel_name']),
            'blackouts' => DB::table('blackout_dates')
                ->join('hotels', 'hotels.id', '=', 'blackout_dates.hotel_id')
                ->where('blackout_dates.end_date', '>=', $today)->orderBy('blackout_dates.start_date')->limit(6)
                ->get(['blackout_dates.*', 'hotels.name as hotel_name']),
            'boards' => Catalog::BOARD_TYPES,
            'permCount' => count(Perm::ALL),
        ]);
    }
}
