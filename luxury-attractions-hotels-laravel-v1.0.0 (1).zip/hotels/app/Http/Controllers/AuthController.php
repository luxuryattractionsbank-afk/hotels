<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Support\Audit;
use App\Support\Mailer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Sign in with username OR registered email, account lockout after repeated failures,
 * and single-use 30-minute recovery links whose only stored form is a SHA-256 hash.
 * Ported from src/lib/auth.ts + src/app/api/auth/* (iron-session → Laravel sessions).
 */
class AuthController extends Controller
{
    public function show(Request $r)
    {
        if (Auth::check()) return redirect('/dashboard');

        return view('auth.login', [
            // The Node build created the first admin on /login when the users table was empty.
            // The Laravel installer always creates it, so setup mode is only a safety net.
            'needsSetup' => DB::table('users')->count() === 0,
        ]);
    }

    public function login(Request $r)
    {
        $d = $r->validate([
            'identifier' => 'required|string|max:190',
            'password' => 'required|string',
        ], ['identifier.required' => 'Enter your username or registered email.']);

        $user = User::findByIdentifier($d['identifier']);

        if ($user && $user->isLocked()) {
            return back()->withInput()->with('error', 'This account is temporarily locked after repeated failed sign-ins. Try again after '.$user->locked_until->diffForHumans().'.');
        }

        // Setup mode: no accounts exist yet, so the first sign-in creates the administrator.
        if (! $user && DB::table('users')->count() === 0 && strlen($d['password']) >= 8) {
            $user = User::create([
                'name' => $d['identifier'],
                'username' => strtolower(preg_replace('/[^a-zA-Z0-9._-]/', '', $d['identifier'])),
                'email' => filter_var($d['identifier'], FILTER_VALIDATE_EMAIL) ? $d['identifier'] : $d['identifier'].'@hotels.local',
                'password_hash' => Hash::make($d['password']),
                'role' => 'admin',
                'permissions' => json_encode(\App\Support\Perm::defaults('admin')),
                'active' => 1,
                'session_version' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            Audit::log('system', $user->id, 'first_admin_created', ['username' => $user->username]);
        }

        if (! $user || ! $user->active || ! Hash::check($d['password'], $user->password_hash)) {
            if ($user) $user->registerFailedAttempt();
            Audit::log('auth', $user?->id, 'login_failed', ['identifier' => $d['identifier']]);

            return back()->withInput()->with('error', 'Those sign-in details do not match an active account.');
        }

        $user->clearFailedAttempts();
        Auth::login($user, remember: true);
        session()->put('session_version', (int) $user->session_version);
        $r->session()->regenerate();
        Audit::log('auth', $user->id, 'login', ['username' => $user->username]);

        return redirect('/dashboard')->with('ok', 'Welcome back, '.($user->name ?: $user->username).'.');
    }

    public function logout(Request $r)
    {
        Audit::log('auth', $r->user()?->id, 'logout', []);
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return redirect('/login')->with('ok', 'You have been signed out.');
    }

    /** Never reveals whether an account exists – same behaviour as the Node API. */
    public function forgot(Request $r)
    {
        $d = $r->validate(['identifier' => 'required|string|max:190']);
        $user = User::findByIdentifier($d['identifier']);
        $generic = 'If that account exists and is active, a recovery link is on its way to the registered email.';

        if (! $user || ! $user->active) return back()->with('ok', $generic);

        // Rate limits carried over: max 3 per hour, no more than one per minute.
        $recent = DB::table('password_reset_tokens')->where('user_id', $user->id)
            ->where('created_at', '>=', now()->subHour())->count();
        $lastMinute = DB::table('password_reset_tokens')->where('user_id', $user->id)
            ->where('created_at', '>=', now()->subMinute())->count();
        if ($recent >= 3 || $lastMinute >= 1) return back()->with('ok', $generic);

        try {
            $link = Mailer::sendResetLink($user);
        } catch (\Throwable $e) {
            return back()->with('error', Mailer::unavailableMessage());
        }

        Audit::log('auth', $user->id, 'reset_requested', []);

        // Without SMTP an administrator still needs the link; show it once, server side only.
        return back()->with('ok', $generic.(Mailer::configured() ? '' : ' (SMTP is not configured – link logged: '.$link.')'));
    }

    public function showReset(Request $r)
    {
        return view('auth.reset', ['token' => (string) $r->query('token')]);
    }

    public function reset(Request $r)
    {
        $d = $r->validate([
            'token' => 'required|string',
            'password' => 'required|string|min:8|confirmed',
        ], ['password.confirmed' => 'The two passwords do not match.']);

        $row = DB::table('password_reset_tokens')->where('token_hash', hash('sha256', $d['token']))
            ->whereNull('consumed_at')->where('expires_at', '>', now())->first();

        if (! $row) return back()->with('error', 'That recovery link is invalid, already used or older than 30 minutes.');

        $user = User::find($row->user_id);
        if (! $user || ! $user->active) return back()->with('error', 'That account can no longer be recovered.');

        DB::table('password_reset_tokens')->where('user_id', $user->id)->whereNull('consumed_at')
            ->update(['consumed_at' => now()]);
        DB::table('users')->where('id', $user->id)->update([
            'password_hash' => Hash::make($d['password']),
            'session_version' => (int) $user->session_version + 1,
            'failed_attempts' => 0, 'locked_until' => null, 'updated_at' => now(),
        ]);
        Audit::log('auth', $user->id, 'password_reset', []);

        return redirect('/login')->with('ok', 'Password changed. Sign in with your new password – other sessions were signed out.');
    }
}
