<?php

namespace App\Http\Controllers;

use App\Models\RatePeriod;
use App\Models\RoomType;
use App\Support\Audit;
use App\Support\Catalog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Room types, occupancy rules, bedding, contracted rate periods and stop-sales.
 * Replaces api/rooms, api/rooms/[id], api/rooms/[id]/duplicate, api/rates, api/blackouts.
 */
class ContractController extends Controller
{
    public function rooms(Request $r)
    {
        return view('contracts.rooms', [
            'rooms' => RoomType::with('hotel')->when($r->input('hotel_id'), fn ($q, $h) => $q->where('hotel_id', $h))
                ->when($r->input('q'), function ($q, $term) {
                    $like = '%'.trim($term).'%';
                    $q->where(fn ($w) => $w->where('name', 'like', $like)->orWhere('code', 'like', $like));
                })->orderBy('hotel_id')->orderBy('name')->paginate(30)->withQueryString(),
            'hotels' => DB::table('hotels')->orderBy('name')->get(['id', 'name']),
            'categories' => Catalog::ROOM_CATEGORIES,
            'editing' => $r->input('edit') ? RoomType::with(['occupancyRules', 'bedding'])->find($r->input('edit')) : null,
        ]);
    }

    public function saveRoom(Request $r, ?int $id = null)
    {
        $d = $r->validate([
            'hotel_id' => 'required|integer|exists:hotels,id',
            'name' => 'required|string|max:150',
            'code' => 'required|string|max:60',
            'category' => 'required|string|max:60',
            'description' => 'nullable|string',
            'media_link' => 'nullable|string|max:500',
            'max_adults' => 'required|integer|min:1|max:12',
            'max_children' => 'nullable|integer|min:0|max:12',
            'max_infants' => 'nullable|integer|min:0|max:6',
            'included_adults' => 'nullable|integer|min:1|max:12',
            'base_sleeps' => 'nullable|integer|min:1|max:12',
            'default_inventory' => 'required|integer|min:0|max:999',
        ], ['code' => 'Room code is required.']);

        $existing = DB::table('room_types')->where('hotel_id', $d['hotel_id'])->where('code', $d['code'])
            ->when($id, fn ($q) => $q->where('id', '!=', $id))->exists();
        if ($existing) return back()->withInput()->with('error', 'That hotel already has a room with code “'.$d['code'].'”.');

        $d += ['max_children' => (int) ($d['max_children'] ?? 0), 'max_infants' => (int) ($d['max_infants'] ?? 0),
            'included_adults' => (int) ($d['included_adults'] ?? 2), 'base_sleeps' => (int) ($d['base_sleeps'] ?? $d['max_adults']),
            'description' => $d['description'] ?? '', 'media_link' => $d['media_link'] ?? '',
            'extra_bed_allowed' => $r->boolean('extra_bed_allowed') ? 1 : 0, 'active' => $r->boolean('active') ? 1 : 0,
            'created_at' => now()];

        $room = RoomType::updateOrCreate(['id' => $id], $d);

        // Occupancy rules and bedding are replaced wholesale, as in the Node form.
        DB::table('occupancy_rules')->where('room_type_id', $room->id)->delete();
        foreach ((array) $r->input('rule_adults', []) as $i => $adults) {
            if (! (int) $adults) continue;
            DB::table('occupancy_rules')->insert([
                'room_type_id' => $room->id, 'adults' => (int) $adults,
                'children' => (int) ($r->input('rule_children')[$i] ?? 0),
                'infants' => (int) ($r->input('rule_infants')[$i] ?? 0),
                'extra_beds' => (int) ($r->input('rule_extra_beds')[$i] ?? 0),
                'label' => (string) ($r->input('rule_label')[$i] ?? ''),
            ]);
        }
        foreach (array_keys(Catalog::BEDDING_KINDS) as $kind) {
            $max = (int) $r->input("bed_{$kind}_max", 0);
            if ($max <= 0 && $id) { DB::table('room_bedding')->where('room_type_id', $room->id)->where('kind', $kind)->delete(); continue; }
            if ($max <= 0) continue;
            DB::table('room_bedding')->updateOrInsert(
                ['room_type_id' => $room->id, 'kind' => $kind],
                ['label' => Catalog::beddingLabel($kind), 'max_per_room' => $max,
                    'free' => $r->boolean("bed_{$kind}_free") ? 1 : 0,
                    'rate_per_night' => (float) $r->input("bed_{$kind}_rate", 0),
                    'per_stay' => $r->boolean("bed_{$kind}_per_stay") ? 1 : 0,
                    'sort_order' => 10],
            );
        }

        Audit::log('room', $room->id, $id ? 'updated' : 'created', ['name' => $room->name, 'hotel_id' => $room->hotel_id]);

        return redirect('/contracts/rooms')->with('ok', $id ? 'Room updated.' : 'Room added.');
    }

    /** Copies a room with all occupancy rules, bedding and rate periods (api/rooms/[id]/duplicate). */
    public function duplicateRoom(int $id)
    {
        $source = RoomType::with(['occupancyRules', 'bedding', 'rates'])->findOrFail($id);
        $copy = $source->replicate(['id']);
        $copy->code = substr($source->code.'-COPY', 0, 60);
        $copy->name = $source->name.' (copy)';
        $copy->created_at = now();
        $copy->save();

        foreach ($source->occupancyRules as $rule) {
            DB::table('occupancy_rules')->insert(collect($rule->only(['adults', 'children', 'infants', 'extra_beds', 'label']))
                ->put('room_type_id', $copy->id)->all());
        }
        foreach ($source->bedding as $bed) {
            DB::table('room_bedding')->insert(collect($bed->only(['kind', 'label', 'max_per_room', 'free', 'rate_per_night', 'per_stay', 'sort_order']))
                ->put('room_type_id', $copy->id)->all());
        }
        foreach ($source->rates as $rate) {
            $new = $rate->replicate(['id']);
            $new->room_type_id = $copy->id;
            $new->created_at = now();
            $new->save();
        }
        Audit::log('room', $copy->id, 'duplicated', ['from' => $source->id]);

        return redirect('/contracts/rooms')->with('ok', 'Room duplicated with '.$source->rates()->count().' rate period(s).');
    }

    public function rates(Request $r)
    {
        return view('contracts.rates', [
            'rates' => RatePeriod::with(['hotel', 'roomType'])
                ->when($r->input('hotel_id'), fn ($q, $h) => $q->where('hotel_id', $h))
                ->when($r->input('room_type_id'), fn ($q, $rt) => $q->where('room_type_id', $rt))
                ->when($r->input('board'), fn ($q, $b) => $q->where('board_type', $b))
                ->orderByDesc('valid_from')->paginate(30)->withQueryString(),
            'hotels' => DB::table('hotels')->orderBy('name')->get(['id', 'name']),
            'rooms' => DB::table('room_types')->orderBy('name')->get(['id', 'name', 'hotel_id']),
            'boards' => Catalog::BOARD_TYPES,
            'markets' => DB::table('markets')->orderBy('sort_order')->get(),
            'editing' => $r->input('edit') ? RatePeriod::find($r->input('edit')) : null,
        ]);
    }

    public function saveRate(Request $r, ?int $id = null)
    {
        $d = $r->validate([
            'hotel_id' => 'required|integer|exists:hotels,id',
            'room_type_id' => 'required|integer|exists:room_types,id',
            'name' => 'required|string|max:150',
            'board_type' => 'required|string|max:40',
            'valid_from' => 'required|date',
            'valid_to' => 'required|date|after_or_equal:valid_from',
            'booking_window_start' => 'nullable|date',
            'booking_window_end' => 'nullable|date|after_or_equal:booking_window_start',
            'market' => 'nullable|string|max:60',
            'market_exclusions' => 'nullable|string|max:255',
            'promo_code' => 'nullable|string|max:60',
            'base_rate' => 'required|numeric|min:0|max:999999',
            'rate_basis' => 'required|string|max:30',
            'board_adult_supplement' => 'nullable|numeric|min:0',
            'board_child_supplement' => 'nullable|numeric|min:0',
            'board_supplement_basis' => 'nullable|string|max:30',
            'extra_adult_rate' => 'nullable|numeric|min:0',
            'extra_child_rate' => 'nullable|numeric|min:0',
            'extra_bed_rate' => 'nullable|numeric|min:0',
            'minimum_nights' => 'nullable|integer|min:1|max:60',
        ]);

        $room = DB::table('room_types')->where('id', $d['room_type_id'])->first();
        if (! $room || (int) $room->hotel_id !== (int) $d['hotel_id']) {
            return back()->withInput()->with('error', 'That room does not belong to the selected hotel.');
        }

        $d += ['market' => $d['market'] ?: 'all', 'market_exclusions' => $d['market_exclusions'] ?? '', 'promo_code' => $d['promo_code'] ?? '',
            'rate_basis' => $d['rate_basis'] ?: 'room_night', 'board_adult_supplement' => $d['board_adult_supplement'] ?? 0,
            'board_child_supplement' => $d['board_child_supplement'] ?? 0, 'board_supplement_basis' => $d['board_supplement_basis'] ?: 'person_night',
            'extra_adult_rate' => $d['extra_adult_rate'] ?? 0, 'extra_child_rate' => $d['extra_child_rate'] ?? 0,
            'extra_bed_rate' => $d['extra_bed_rate'] ?? 0, 'extra_bed_basis' => 'bed_night',
            'minimum_nights' => (int) ($d['minimum_nights'] ?? 1), 'active' => $r->boolean('active') ? 1 : 0, 'created_at' => now()];

        $rate = RatePeriod::updateOrCreate(['id' => $id], $d);
        Audit::log('rate', $rate->id, $id ? 'updated' : 'created', ['name' => $rate->name, 'base_rate' => $rate->base_rate]);

        return redirect('/contracts/rates')->with('ok', $id ? 'Contract rate updated.' : 'Contract rate added.');
    }

    public function blackouts(Request $r)
    {
        return view('contracts.blackouts', [
            'blackouts' => DB::table('blackout_dates')
                ->join('hotels', 'hotels.id', '=', 'blackout_dates.hotel_id')
                ->leftJoin('room_types', 'room_types.id', '=', 'blackout_dates.room_type_id')
                ->orderByDesc('blackout_dates.start_date')->limit(200)
                ->get(['blackout_dates.*', 'hotels.name as hotel_name', 'room_types.name as room_name']),
            'hotels' => DB::table('hotels')->orderBy('name')->get(['id', 'name']),
            'rooms' => DB::table('room_types')->orderBy('name')->get(['id', 'name', 'hotel_id']),
        ]);
    }

    public function saveBlackout(Request $r)
    {
        $d = $r->validate([
            'hotel_id' => 'required|integer|exists:hotels,id',
            'room_type_id' => 'nullable|integer|exists:room_types,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'nullable|string|max:190',
        ]);
        $d['reason'] = $d['reason'] ?: 'Sold out by hotel';
        $d['created_at'] = now();
        $id = DB::table('blackout_dates')->insertGetId($d);
        Audit::log('blackout', $id, 'created', $d);

        return redirect('/contracts/blackouts')->with('ok', 'Stop-sale added – those dates are now excluded from search.');
    }

    public function deleteBlackout(int $id)
    {
        DB::table('blackout_dates')->where('id', $id)->delete();
        Audit::log('blackout', $id, 'deleted', []);

        return redirect('/contracts/blackouts')->with('ok', 'Stop-sale removed.');
    }
}
