<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Support\Audit;
use App\Support\Mailer;
use App\Support\Perm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Users & permissions. Replaces api/users + users-panel.tsx.
 * Deactivating an account or changing its password/permissions invalidates old sessions.
 */
class UserController extends Controller
{
    public function index()
    {
        return view('users', [
            'users' => User::orderBy('name')->get(),
            'roles' => Perm::ROLES,
            'permissions' => Perm::ALL,
        ]);
    }

    public function edit(?int $id = null)
    {
        return view('users.form', [
            'user' => $id ? User::findOrFail($id) : null,
            'roles' => Perm::ROLES,
            'permissions' => Perm::ALL,
        ]);
    }

    public function save(Request $r, ?int $id = null)
    {
        $d = $r->validate([
            'name' => 'required|string|max:150',
            'username' => ['required', 'string', 'min:3', 'max:60', 'regex:/^[a-zA-Z0-9._-]{3,60}$/', 'unique:users,username'.($id ? ",$id" : '')],
            'email' => 'required|email|max:190|unique:users,email'.($id ? ",$id" : ''),
            'role' => 'required|in:'.implode(',', array_keys(Perm::ROLES)),
            'password' => ($id ? 'nullable' : 'required').'|string|min:8',
        ], [
            'username.regex' => 'Username: 3–60 letters, numbers, dot, dash or underscore.',
            'password.min' => 'Use at least 8 characters.',
        ]);

        $role = $d['role'];
        $permissions = $role === 'admin'
            ? Perm::defaults('admin')
            : Perm::normalize((array) $r->input('permissions', Perm::defaults($role)));

        $row = [
            'name' => $d['name'],
            'username' => strtolower($d['username']),
            'email' => $d['email'],
            'role' => $role,
            'permissions' => json_encode($permissions),
            'active' => $r->boolean('active') || ! $id ? 1 : 0,
            'updated_at' => now(),
        ];
        if ($d['password'] ?? null) $row['password_hash'] = Hash::make($d['password']);

        if ($id) {
            $user = User::findOrFail($id);
            // Never let the last administrator be locked out or demoted.
            $admins = DB::table('users')->where('role', 'admin')->where('active', 1)->count();
            if ($user->role === 'admin' && $admins <= 1 && ($role !== 'admin' || ! $row['active'])) {
                return back()->withInput()->with('error', 'At least one active administrator must remain.');
            }
            if (isset($row['password_hash']) || $permissions !== $user->permissions()) {
                $row['session_version'] = (int) $user->session_version + 1;
            }
            DB::table('users')->where('id', $id)->update($row);
            Audit::log('user', $id, 'updated', ['role' => $role, 'permissions' => $permissions]);

            return redirect('/users')->with('ok', 'Account updated – earlier sessions were signed out.');
        }

        $row += ['password_hash' => Hash::make($d['password']), 'session_version' => 1, 'failed_attempts' => 0, 'created_at' => now()];
        $newId = DB::table('users')->insertGetId($row);
        Audit::log('user', $newId, 'created', ['role' => $role, 'username' => $row['username']]);

        return redirect('/users')->with('ok', 'Account created for '.$row['username'].'.');
    }

    public function toggle(Request $r, int $id)
    {
        $user = User::findOrFail($id);
        $next = ! $user->active;
        if ($user->role === 'admin' && ! $next && DB::table('users')->where('role', 'admin')->where('active', 1)->count() <= 1) {
            return back()->with('error', 'At least one active administrator must remain.');
        }
        DB::table('users')->where('id', $id)->update(['active' => $next ? 1 : 0, 'session_version' => (int) $user->session_version + 1, 'updated_at' => now()]);
        if ($id === $r->user()?->id && ! $next) {
            auth()->logout();
            $r->session()->invalidate();

            return redirect('/login')->with('ok', 'Your account was deactivated.');
        }
        Audit::log('user', $id, $next ? 'activated' : 'deactivated', []);

        return back()->with('ok', $next ? 'Account activated.' : 'Account deactivated and signed out everywhere.');
    }

    /** An administrator can send the recovery email from this screen once SMTP works. */
    public function sendReset(Request $r, int $id)
    {
        $user = User::findOrFail($id);
        try {
            $link = Mailer::sendResetLink($user);
        } catch (\Throwable) {
            return back()->with('error', Mailer::unavailableMessage());
        }
        Audit::log('user', $id, 'reset_email_sent', []);

        return back()->with('ok', 'Recovery link sent to '.$user->email.(Mailer::configured() ? '' : ' (SMTP not configured – link logged).'));
    }

    public function profile(Request $r)
    {
        return view('profile', ['user' => $r->user(), 'permissions' => Perm::ALL]);
    }

    public function saveProfile(Request $r)
    {
        $user = $r->user();
        $d = $r->validate([
            'name' => 'required|string|max:150',
            'username' => ['required', 'string', 'min:3', 'max:60', 'regex:/^[a-zA-Z0-9._-]{3,60}$/', 'unique:users,username,'.$user->id],
            'current_password' => 'nullable|string',
            'password' => 'nullable|string|min:8|confirmed',
        ], ['password.confirmed' => 'The two passwords do not match.']);

        if (! empty($d['password'])) {
            if (! Hash::check((string) $d['current_password'], $user->password_hash)) {
                return back()->withInput()->with('error', 'Your current password is not correct.');
            }
            DB::table('users')->where('id', $user->id)->update([
                'password_hash' => Hash::make($d['password']),
                'session_version' => (int) $user->session_version + 1, 'updated_at' => now(),
            ]);
            Audit::log('user', $user->id, 'own_password_changed', []);

            return redirect('/login')->with('ok', 'Password changed – sign in again.');
        }

        DB::table('users')->where('id', $user->id)->update([
            'name' => $d['name'], 'username' => strtolower($d['username']), 'updated_at' => now(),
        ]);

        return back()->with('ok', 'Profile updated.');
    }
}
