<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Catalog;
use App\Support\Pricing;
use App\Support\Reference;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Trip packages: hotel quotation + transfers + tours, marked up into one client proposal.
 * Replaces api/trip-packages and trip-packages-panel.tsx (src/lib/trip-package.ts maths).
 */
class TripPackageController extends Controller
{
    public function index(Request $r)
    {
        return view('packages.index', [
            'packages' => DB::table('trip_packages')
                ->when($r->input('q'), function ($q, $term) {
                    $like = '%'.trim($term).'%';
                    $q->where(fn ($w) => $w->where('reference', 'like', $like)->orWhere('client_name', 'like', $like));
                })
                ->when($r->input('status'), fn ($q, $s) => $q->where('status', $s))
                ->orderByDesc('id')->paginate(25)->withQueryString(),
            'statuses' => Catalog::STATUSES,
        ]);
    }

    public function edit(Request $r, ?int $id = null)
    {
        $package = $id ? DB::table('trip_packages')->find($id) : null;

        return view('packages.form', [
            'package' => $package,
            'transfers' => $package ? DB::table('trip_package_transfers')->where('package_id', $id)->orderBy('position')->get() : collect(),
            'tours' => $package ? DB::table('trip_package_tours')->where('package_id', $id)->orderBy('position')->get() : collect(),
            'quotations' => DB::table('quotations')->orderByDesc('id')->limit(200)
                ->get(['id', 'reference', 'client_name', 'proposal_total', 'currency']),
            'services' => DB::table('services')->where('active', 1)->orderBy('sort_order')->get(),
            'markets' => DB::table('markets')->orderBy('sort_order')->get(),
            'statuses' => Catalog::STATUSES,
        ]);
    }

    public function save(Request $r, ?int $id = null)
    {
        $d = $r->validate([
            'client_name' => 'required|string|max:150',
            'client_email' => 'nullable|email|max:190',
            'client_phone' => 'nullable|string|max:60',
            'quotation_id' => 'nullable|integer|exists:quotations,id',
            'market' => 'nullable|string|max:60',
            'status' => 'nullable|string|max:30',
            'adults' => 'required|integer|min:1',
            'children' => 'nullable|integer|min:0',
            'infants' => 'nullable|integer|min:0',
            'markup_percent' => 'nullable|numeric|min:0|max:400',
            'valid_until' => 'nullable|date',
            'notes' => 'nullable|string',
            'currency' => 'nullable|string|max:8',
        ]);

        $hotelsNet = $d['quotation_id']
            ? (float) DB::table('quotations')->where('id', $d['quotation_id'])->value('total_amount')
            : 0.0;

        $transfers = [];
        $transfersNet = 0.0;
        foreach ((array) $r->input('transfer', []) as $t) {
            if (empty($t['service_id']) && empty($t['service_name'])) continue;
            if (empty($t['transfer_date'])) continue;
            $service = $t['service_id'] ? DB::table('services')->find((int) $t['service_id']) : null;
            $vehicles = max(1, (int) ($t['vehicles'] ?? 1));
            $adults = max(0, (int) ($t['adults'] ?? $d['adults']));
            $children = max(0, (int) ($t['children'] ?? 0));
            $unit = (float) ($t['unit_price'] ?? 0);
            if ($unit <= 0 && $service) {
                $unit = $service->kind === 'transfer'
                    ? (($t['mode'] ?? 'shared') === 'shared'
                        ? (float) (($t['direction'] ?? 'oneway') === 'twoway' ? $service->shared_twoway_price : $service->shared_oneway_price) * max(1, $adults + $children)
                        : (float) (($t['direction'] ?? 'oneway') === 'twoway'
                            ? (($t['vehicle'] ?? '') === 'private12' ? $service->private12_twoway_price : $service->private7_twoway_price)
                            : (($t['vehicle'] ?? '') === 'private12' ? $service->private12_oneway_price : $service->private7_oneway_price)) * $vehicles)
                    : (float) $service->ticket_only_adult * $adults;
            }
            $total = Pricing::money($unit);
            $transfersNet += $total;
            $transfers[] = [
                'position' => count($transfers) + 1, 'service_id' => $service?->id,
                'service_name' => $service?->name ?: ($t['service_name'] ?? ''), 'mode' => $t['mode'] ?? 'shared',
                'direction' => $t['direction'] ?? 'oneway', 'vehicle' => $t['vehicle'] ?? '',
                'transfer_date' => $t['transfer_date'], 'transfer_time' => $t['transfer_time'] ?? '',
                'pickup' => $t['pickup'] ?? '', 'dropoff' => $t['dropoff'] ?? '', 'flight_no' => $t['flight_no'] ?? '',
                'adults' => $adults, 'children' => $children, 'vehicles' => $vehicles,
                'unit_price' => $total, 'total_net' => $total, 'notes' => $t['notes'] ?? '',
            ];
        }

        $tours = [];
        $toursNet = 0.0;
        foreach ((array) $r->input('tour', []) as $t) {
            if (empty($t['service_id']) || empty($t['tour_date'])) continue;
            $service = DB::table('services')->find((int) $t['service_id']);
            if (! $service) continue;
            $adults = max(0, (int) ($t['adults'] ?? $d['adults']));
            $children = max(0, (int) ($t['children'] ?? 0));
            $mode = $t['option_mode'] ?? 'ticket';
            $priceAdult = (float) match ($mode) { 'shared' => $service->shared_adult, 'private' => $service->private_adult, default => $service->ticket_only_adult };
            $priceChild = (float) match ($mode) { 'shared' => $service->shared_child, 'private' => $service->private_child, default => $service->ticket_only_child };
            $total = Pricing::money($priceAdult * $adults + $priceChild * $children);
            $toursNet += $total;
            $tours[] = [
                'position' => count($tours) + 1, 'service_id' => $service->id, 'service_name' => $service->name,
                'option_mode' => $mode, 'tour_date' => $t['tour_date'], 'tour_time' => $t['tour_time'] ?? '',
                'meeting_point' => $t['meeting_point'] ?? '', 'adults' => $adults, 'children' => $children,
                'price_adult' => $priceAdult, 'price_child' => $priceChild, 'total_net' => $total, 'notes' => $t['notes'] ?? '',
            ];
        }

        $subtotalNet = Pricing::money($hotelsNet + $transfersNet + $toursNet);
        $markupPercent = (float) ($d['markup_percent'] ?? 0);
        $markupAmount = Pricing::money($subtotalNet * $markupPercent / 100);
        $proposalTotal = Pricing::money($subtotalNet + $markupAmount);

        DB::transaction(function () use (&$id, $d, $r, $hotelsNet, $transfers, $transfersNet, $tours, $toursNet, $subtotalNet, $markupPercent, $markupAmount, $proposalTotal) {
            $row = [
                'reference' => $id ? DB::table('trip_packages')->where('id', $id)->value('reference') : Reference::tripPackage(),
                'client_name' => $d['client_name'], 'client_email' => $d['client_email'] ?? '', 'client_phone' => $d['client_phone'] ?? '',
                'quotation_id' => $d['quotation_id'] ?? null, 'market' => $d['market'] ?: 'all', 'status' => $d['status'] ?: 'draft',
                'adults' => (int) $d['adults'], 'children' => (int) ($d['children'] ?? 0), 'infants' => (int) ($d['infants'] ?? 0),
                'include_tourism_tax' => $r->boolean('include_tourism_tax') ? 1 : 0,
                'markup_percent' => $markupPercent, 'markup_amount' => $markupAmount,
                'hotels_net' => $hotelsNet, 'transfers_net' => Pricing::money($transfersNet), 'tours_net' => Pricing::money($toursNet),
                'subtotal_net' => $subtotalNet, 'proposal_total' => $proposalTotal,
                'currency' => $d['currency'] ?: 'AED', 'valid_until' => $d['valid_until'] ?? null,
                'notes' => $d['notes'] ?? '', 'created_by' => $r->user()?->id, 'created_at' => now(),
            ];
            if ($id) DB::table('trip_packages')->where('id', $id)->update($row);
            else $id = DB::table('trip_packages')->insertGetId($row);

            DB::table('trip_package_transfers')->where('package_id', $id)->delete();
            DB::table('trip_package_tours')->where('package_id', $id)->delete();
            foreach ($transfers as $t) DB::table('trip_package_transfers')->insert($t + ['package_id' => $id]);
            foreach ($tours as $t) DB::table('trip_package_tours')->insert($t + ['package_id' => $id]);
        });

        Audit::log('package', $id, $r->input('id') ? 'updated' : 'created', ['total' => $proposalTotal]);

        return redirect('/packages/'.$id)->with('ok', 'Trip package saved – net '.$subtotalNet.' + markup '.$markupAmount.'.');
    }

    public function show(int $id)
    {
        $package = DB::table('trip_packages')->findOrFail($id);

        return view('packages.show', [
            'package' => $package,
            'transfers' => DB::table('trip_package_transfers')->where('package_id', $id)->orderBy('position')->get(),
            'tours' => DB::table('trip_package_tours')->where('package_id', $id)->orderBy('position')->get(),
            'hotels' => $package->quotation_id
                ? DB::table('quotation_items')->join('hotels', 'hotels.id', '=', 'quotation_items.hotel_id')
                    ->join('room_types', 'room_types.id', '=', 'quotation_items.room_type_id')
                    ->where('quotation_items.quotation_id', $package->quotation_id)->orderBy('quotation_items.position')
                    ->get(['quotation_items.*', 'hotels.name as hotel_name', 'room_types.name as room_name'])
                : collect(),
            'itinerary' => $this->itinerary($id, $package),
        ]);
    }

    /** One chronological day-by-day list for the client-facing proposal. */
    private function itinerary(int $id, object $package): array
    {
        $days = [];
        if ($package->quotation_id) {
            foreach (DB::table('quotation_items')->where('quotation_id', $package->quotation_id)->get() as $item) {
                foreach (Pricing::eachNight((string) $item->check_in, (string) $item->check_out) as $night) {
                    $days[$night][] = ['type' => 'stay', 'label' => 'Hotel stay', 'detail' => 'Night '.Catalog::boardShort($item->board_type), 'amount' => null];
                }
                $days[(string) $item->check_in][] = ['type' => 'checkin', 'label' => 'Check-in', 'detail' => $item->check_in, 'amount' => null];
            }
        }
        foreach (DB::table('trip_package_transfers')->where('package_id', $id)->get() as $t) {
            $days[(string) $t->transfer_date][] = ['type' => 'transfer', 'label' => $t->service_name, 'detail' => trim($t->pickup.' → '.$t->dropoff.' '.($t->transfer_time ? 'at '.$t->transfer_time : '')), 'amount' => $t->total_net];
        }
        foreach (DB::table('trip_package_tours')->where('package_id', $id)->get() as $t) {
            $days[(string) $t->tour_date][] = ['type' => 'tour', 'label' => $t->service_name, 'detail' => trim(($t->tour_time ? $t->tour_time.' · ' : '').$t->meeting_point), 'amount' => $t->total_net];
        }
        ksort($days);

        return collect($days)->map(fn ($events, $date) => ['date' => $date, 'events' => $events])->values()->all();
    }

    public function destroy(int $id)
    {
        DB::table('trip_package_transfers')->where('package_id', $id)->delete();
        DB::table('trip_package_tours')->where('package_id', $id)->delete();
        DB::table('trip_packages')->where('id', $id)->delete();
        Audit::log('package', $id, 'deleted', []);

        return redirect('/packages')->with('ok', 'Trip package deleted.');
    }
}
