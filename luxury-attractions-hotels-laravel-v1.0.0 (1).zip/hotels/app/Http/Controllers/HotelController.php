<?php

namespace App\Http\Controllers;

use App\Models\Hotel;
use App\Models\HotelContact;
use App\Support\Audit;
use App\Support\Catalog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Hotels, groups, locations, amenities and contact people.
 * Replaces api/hotels, api/contacts, api/hotel-groups, api/locations, api/amenities,
 * api/hotel-amenities, api/markets and api/room-categories.
 */
class HotelController extends Controller
{
    public function index(Request $r)
    {
        $hotels = Hotel::query()->with(['location', 'group'])
            ->search($r->input('q'))
            ->when($r->input('city'), fn ($q, $city) => $q->where('city', $city))
            ->when($r->filled('group_id'), fn ($q, $g) => $q->where('group_id', $g))
            ->orderBy('name')->paginate(25)->withQueryString();

        return view('hotels.index', [
            'hotels' => $hotels,
            'cities' => DB::table('hotels')->distinct()->orderBy('city')->pluck('city'),
            'groups' => DB::table('hotel_groups')->orderBy('name')->get(['id', 'name']),
            'q' => $r->input('q'),
        ]);
    }

    public function edit(?int $id = null)
    {
        return view('hotels.form', [
            'hotel' => $id ? Hotel::with(['amenities'])->findOrFail($id) : null,
            'groups' => DB::table('hotel_groups')->orderBy('name')->get(['id', 'name']),
            'locations' => DB::table('locations')->orderBy('city')->orderBy('name')->get(),
            'amenities' => DB::table('amenities')->orderBy('sort_order')->get(),
            'markets' => DB::table('markets')->orderBy('sort_order')->get(),
            'taxBases' => Catalog::TAX_BASES,
        ]);
    }

    public function save(Request $r, ?int $id = null)
    {
        $d = $r->validate([
            'name' => 'required|string|max:190',
            'city' => 'required|string|max:120',
            'location_id' => 'nullable|integer|exists:locations,id',
            'country' => 'nullable|string|max:120',
            'address' => 'nullable|string|max:255',
            'star_rating' => 'required|integer|min:1|max:5',
            'supplier_code' => 'required|string|max:60|unique:hotels,supplier_code'.($id ? ",$id" : ''),
            'group_id' => 'nullable|integer|exists:hotel_groups,id',
            'business_type' => 'nullable|string|max:60',
            'website' => 'nullable|string|max:255',
            'contracts_folder_link' => 'nullable|string|max:500',
            'media_link' => 'nullable|string|max:500',
            'contact_email' => 'nullable|string|max:190',
            'contact_phone' => 'nullable|string|max:60',
            'currency' => 'nullable|string|max:8',
            'check_in_time' => 'nullable|string|max:12',
            'check_out_time' => 'nullable|string|max:12',
            'tourism_tax' => 'nullable|numeric|min:0|max:9999',
            'tourism_tax_basis' => 'nullable|string|max:30',
            'active' => 'nullable|boolean',
        ], ['supplier_code.unique' => 'That supplier code is already used by another hotel.']);

        $d += [
            'country' => $d['country'] ?: 'United Arab Emirates', 'business_type' => $d['business_type'] ?: 'Hotel',
            'currency' => $d['currency'] ?: 'AED', 'check_in_time' => $d['check_in_time'] ?: '15:00',
            'check_out_time' => $d['check_out_time'] ?: '12:00', 'tourism_tax' => $d['tourism_tax'] ?? 0,
            'tourism_tax_basis' => $d['tourism_tax_basis'] ?: 'room_night', 'active' => $r->boolean('active') ? 1 : 0,
            'address' => $d['address'] ?? '', 'website' => $d['website'] ?? '',
            'contracts_folder_link' => $d['contracts_folder_link'] ?? '', 'media_link' => $d['media_link'] ?? '',
            'contact_email' => $d['contact_email'] ?? '', 'contact_phone' => $d['contact_phone'] ?? '',
            'created_at' => now(),
        ];

        $hotel = Hotel::updateOrCreate(['id' => $id], $d);
        $hotel->amenities()->sync(array_map('intval', (array) $r->input('amenities', [])));
        Audit::log('hotel', $hotel->id, $id ? 'updated' : 'created', ['name' => $hotel->name]);

        return redirect('/hotels/'.$hotel->id)->with('ok', $id ? 'Hotel updated.' : 'Hotel added.');
    }

    public function show(int $id)
    {
        $hotel = Hotel::with(['location', 'group', 'amenities'])->findOrFail($id);

        return view('hotels.show', [
            'hotel' => $hotel,
            'rooms' => DB::table('room_types')->where('hotel_id', $id)->orderBy('name')->get(),
            'rates' => DB::table('rate_periods')->where('hotel_id', $id)->orderByDesc('valid_from')->limit(60)->get(),
            'blackouts' => DB::table('blackout_dates')->where('hotel_id', $id)->orderBy('start_date')->get(),
            'contacts' => $hotel->contacts()->get(),
            'bookings' => DB::table('bookings')->join('room_types', 'room_types.id', '=', 'bookings.room_type_id')
                ->where('bookings.hotel_id', $id)->orderByDesc('bookings.check_in')->limit(15)
                ->get(['bookings.*', 'room_types.name as room_name']),
        ]);
    }

    // ---- contact people (hotel_contacts + hotel_contact_assignments) ----

    public function contacts(Request $r)
    {
        return view('contacts', [
            'contacts' => HotelContact::query()
                ->when($r->input('q'), function ($q, $term) {
                    $like = '%'.trim($term).'%';
                    $q->where(fn ($w) => $w->where('name', 'like', $like)->orWhere('email', 'like', $like)->orWhere('phone', 'like', $like));
                })
                ->orderBy('name')->paginate(30)->withQueryString(),
            'hotels' => DB::table('hotels')->orderBy('name')->get(['id', 'name']),
            'groups' => DB::table('hotel_groups')->orderBy('name')->get(['id', 'name']),
            'editing' => $r->input('edit') ? HotelContact::with('hotels')->find($r->input('edit')) : null,
        ]);
    }

    public function saveContact(Request $r, ?int $id = null)
    {
        $d = $r->validate([
            'name' => 'required|string|max:150',
            'position' => 'nullable|string|max:120',
            'email' => 'nullable|string|max:190',
            'phone' => 'nullable|string|max:60',
            'business_card_link' => 'nullable|string|max:500',
            'other_contact' => 'nullable|string|max:150',
            'hotel_id' => 'nullable|integer|exists:hotels,id',
            'group_id' => 'nullable|integer|exists:hotel_groups,id',
        ]);
        $d += ['position' => '', 'email' => '', 'phone' => '', 'business_card_link' => '', 'other_contact' => '',
            'whatsapp' => $r->boolean('whatsapp') ? 1 : 0, 'telegram' => $r->boolean('telegram') ? 1 : 0,
            'viber' => $r->boolean('viber') ? 1 : 0, 'active' => $r->boolean('active') ? 1 : 0, 'created_at' => now()];

        $contact = HotelContact::updateOrCreate(['id' => $id], $d);
        // One contact can cover every hotel in a group (hotel_contact_assignments).
        $hotelIds = array_map('intval', (array) $r->input('hotels', []));
        if ($contact->group_id && ! $hotelIds) {
            $hotelIds = DB::table('hotels')->where('group_id', $contact->group_id)->pluck('id')->map(fn ($v) => (int) $v)->all();
        }
        $contact->hotels()->sync($hotelIds);
        Audit::log('contact', $contact->id, $id ? 'updated' : 'created', ['name' => $contact->name]);

        return redirect('/contacts')->with('ok', $id ? 'Contact updated.' : 'Contact added.');
    }

    // ---- simple lookups ----

    public function lookups()
    {
        return view('lookups', [
            'groups' => DB::table('hotel_groups')->orderBy('name')->get(),
            'locations' => DB::table('locations')->orderBy('city')->orderBy('name')->get(),
            'amenities' => DB::table('amenities')->orderBy('sort_order')->get(),
            'markets' => DB::table('markets')->orderBy('sort_order')->get(),
            'categories' => DB::table('room_categories')->orderBy('sort_order')->get(),
        ]);
    }

    public function saveLookup(Request $r, string $kind)
    {
        $tables = [
            'group' => ['hotel_groups', ['name' => 'required|string|max:150|unique:hotel_groups,name', 'website' => 'nullable|string|max:255', 'notes' => 'nullable|string']],
            'location' => ['locations', ['city' => 'required|string|max:120', 'name' => 'required|string|max:150']],
            'amenity' => ['amenities', ['label' => 'required|string|max:120', 'icon' => 'nullable|string|max:60']],
            'market' => ['markets', ['label' => 'required|string|max:120']],
            'category' => ['room_categories', ['label' => 'required|string|max:120']],
        ];
        if (! isset($tables[$kind])) abort(404);
        [$table, $rules] = $tables[$kind];

        $d = $r->validate($rules);
        $id = $r->input('id') ? (int) $r->input('id') : null;

        if (in_array($kind, ['amenity', 'market', 'category'], true)) {
            $d['slug'] = Catalog::slugify($d['label']);
        }
        $d['active'] = $r->boolean('active') ? 1 : 0;
        if ($kind === 'location') $d['created_at'] = now();
        if (in_array($kind, ['group'], true)) { $d['website'] = $d['website'] ?? ''; $d['notes'] = $d['notes'] ?? ''; }

        if ($id) DB::table($table)->where('id', $id)->update($d);
        else DB::table($table)->insert($d);
        Audit::log($kind, $id, $id ? 'updated' : 'created', $d);

        return redirect('/lookups')->with('ok', ucfirst($kind).' saved.');
    }
}
