<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Catalog;
use App\Support\Fmt;
use App\Support\Mailer;
use App\Support\Settings;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Client-facing PDF proposals. Net supplier costs, internal margins and markup
 * percentages are NEVER rendered here – the same rule as src/lib/pdf.ts.
 * Replaces api/proposals/email and the jsPDF browser generation.
 */
class PdfController extends Controller
{
    private function company(): array
    {
        return [
            'name' => Settings::company('name', 'Luxury Attractions'),
            'phone' => Settings::company('phone', ''),
            'email' => Settings::company('email', ''),
            'address' => Settings::company('address', ''),
            'website' => Settings::company('website', ''),
        ];
    }

    private function clientOnly(array $row): array
    {
        // Whitelist – anything net/margin related is dropped before it reaches a template.
        return collect($row)->only([
            'reference', 'client_name', 'client_email', 'client_phone', 'status', 'currency',
            'valid_until', 'notes', 'proposal_total', 'adults', 'children', 'infants', 'created_at',
        ])->all();
    }

    /** Builds the quotation proposal PDF; shared by the download route and the email route. */
    private function buildQuotation(int $id): array
    {
        $q = DB::table('quotations')->findOrFail($id);
        $lines = DB::table('quotation_items')
            ->join('hotels', 'hotels.id', '=', 'quotation_items.hotel_id')
            ->join('room_types', 'room_types.id', '=', 'quotation_items.room_type_id')
            ->where('quotation_items.quotation_id', $id)->orderBy('quotation_items.position')
            ->get(['quotation_items.*', 'hotels.name as hotel_name', 'hotels.city', 'hotels.check_in_time',
                'hotels.check_out_time', 'room_types.name as room_name']);

        $pdf = Pdf::loadView('pdf.quotation', [
            'company' => $this->company(),
            'quotation' => (object) $this->clientOnly((array) $q),
            'lines' => $lines,
            'clientTotal' => (float) $q->proposal_total,
            'currency' => $q->currency,
        ])->setPaper('a4');

        return [$pdf, $q->reference.'-proposal.pdf'];
    }

    public function quotation(int $id)
    {
        [$pdf, $name] = $this->buildQuotation($id);

        return $pdf->download($name);
    }

    private function buildTripPackage(int $id): array
    {
        $p = DB::table('trip_packages')->findOrFail($id);
        $transfers = DB::table('trip_package_transfers')->where('package_id', $id)->orderBy('position')->get();
        $tours = DB::table('trip_package_tours')->where('package_id', $id)->orderBy('position')->get();
        $hotels = $p->quotation_id
            ? DB::table('quotation_items')->join('hotels', 'hotels.id', '=', 'quotation_items.hotel_id')
                ->join('room_types', 'room_types.id', '=', 'quotation_items.room_type_id')
                ->where('quotation_items.quotation_id', $p->quotation_id)->orderBy('quotation_items.position')
                ->get(['quotation_items.board_type', 'quotation_items.check_in', 'quotation_items.check_out',
                    'quotation_items.nights', 'quotation_items.adults', 'quotation_items.children', 'quotation_items.rooms',
                    'quotation_items.total_amount', 'hotels.name as hotel_name', 'hotels.city', 'room_types.name as room_name'])
            : collect();

        $pdf = Pdf::loadView('pdf.package', [
            'company' => $this->company(),
            'package' => (object) $this->clientOnly((array) $p),
            'hotels' => $hotels,
            'transfers' => $transfers,
            'tours' => $tours,
            'clientTotal' => (float) $p->proposal_total,
            'currency' => $p->currency,
        ])->setPaper('a4');

        return [$pdf, $p->reference.'-trip-package.pdf'];
    }

    public function tripPackage(int $id)
    {
        [$pdf, $name] = $this->buildTripPackage($id);

        return $pdf->download($name);
    }

    /** Booking confirmation / voucher for the hotel. */
    private function buildBooking(int $id): array
    {
        $b = DB::table('bookings')->join('hotels', 'hotels.id', '=', 'bookings.hotel_id')
            ->join('room_types', 'room_types.id', '=', 'bookings.room_type_id')
            ->leftJoin('rate_periods', 'rate_periods.id', '=', 'bookings.rate_period_id')
            ->where('bookings.id', $id)
            ->first(['bookings.*', 'hotels.name as hotel_name', 'hotels.address', 'hotels.city', 'hotels.contact_email',
                'hotels.contact_phone', 'hotels.check_in_time', 'hotels.check_out_time',
                'room_types.name as room_name', 'rate_periods.name as rate_name']);
        if (! $b) abort(404);

        $pdf = Pdf::loadView('pdf.booking', [
            'company' => $this->company(),
            'booking' => (object) $b->toArray(),
            'nights' => \App\Support\Pricing::eachNight((string) $b->check_in, (string) $b->check_out),
        ])->setPaper('a4');

        return [$pdf, $b->reference.'-confirmation.pdf'];
    }

    public function booking(int $id)
    {
        [$pdf, $name] = $this->buildBooking($id);

        return $pdf->download($name);
    }

    /** Emails the generated PDF itself as an attachment (api/proposals/email). */
    public function email(Request $r)
    {
        $d = $r->validate([
            'kind' => 'required|in:quotation,package,booking',
            'id' => 'required|integer',
            'to' => 'required|email|max:190',
            'cc' => 'nullable|string|max:500',
            'subject' => 'required|string|max:200',
            'message' => 'nullable|string|max:4000',
        ]);

        // Build the very same PDF the download route serves, then attach it.
        try {
            [$pdf, $name] = match ($d['kind']) {
                'quotation' => $this->buildQuotation((int) $d['id']),
                'package' => $this->buildTripPackage((int) $d['id']),
                default => $this->buildBooking((int) $d['id']),
            };
        } catch (\Throwable $e) {
            return back()->with('error', 'The PDF could not be generated: '.$e->getMessage());
        }

        $path = storage_path('app/proposals');
        if (! is_dir($path)) @mkdir($path, 0775, true);
        $tmp = $path.'/'.time().'-'.preg_replace('/[^A-Za-z0-9._-]/', '-', $name ?: 'proposal.pdf');
        file_put_contents($tmp, $pdf->output());

        try {
            Mailer::sendProposal(
                $d['to'], $d['subject'],
                ($d['message'] ?: 'Please find your proposal attached.')."\n\n".
                    $this->company()['name']."\n".$this->company()['phone']."\n".$this->company()['email'],
                $tmp, $name, array_map('trim', explode(',', (string) ($d['cc'] ?? ''))),
            );
        } catch (\Throwable $e) {
            @unlink($tmp);

            return back()->with('error', $e->getMessage());
        }

        @unlink($tmp);
        Audit::log($d['kind'], (int) $d['id'], 'proposal_emailed', ['to' => $d['to']]);

        return back()->with('ok', 'Proposal PDF emailed to '.$d['to'].'.');
    }
}
