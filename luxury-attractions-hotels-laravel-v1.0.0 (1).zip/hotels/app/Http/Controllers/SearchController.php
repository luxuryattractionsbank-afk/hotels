<?php

namespace App\Http\Controllers;

use App\Support\Catalog;
use App\Support\Pricing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Availability & rate search – replaces src/app/api/search/route.ts and the
 * browser side of src/app/search-panel.tsx. All pricing runs through Pricing.php.
 */
class SearchController extends Controller
{
    public function index(Request $r)
    {
        $criteria = $this->criteria($r);
        $filters = $this->filters($r);

        $response = null;
        $shown = [];
        $excluded = [];
        if ($r->filled('check_in') || $r->filled('check_out')) {
            $response = Pricing::evaluateAvailability(Pricing::context(), $criteria);
            if (! $response['error']) {
                $f = Pricing::applyFilters($response['results'], $filters);
                $shown = $f['results'];
                $response['outsidePriceRange'] = $f['outsidePriceRange'];
            }
            $excluded = $response['excluded'];
        }

        return view('search', [
            'criteria' => $criteria,
            'filters' => $filters,
            'response' => $response,
            'results' => $shown,
            'excluded' => $excluded,
            'hotels' => DB::table('hotels')->where('active', 1)->orderBy('name')->get(['id', 'name', 'city']),
            'locations' => DB::table('locations')->where('active', 1)->orderBy('city')->orderBy('name')->get(),
            'amenities' => DB::table('amenities')->where('active', 1)->orderBy('sort_order')->get(),
            'markets' => DB::table('markets')->where('active', 1)->orderBy('sort_order')->get(),
            'categories' => Catalog::ROOM_CATEGORIES,
            'boards' => Catalog::BOARD_TYPES,
            'sorts' => Catalog::SORT_OPTIONS,
        ]);
    }

    /** JSON endpoint kept for API parity with the Next.js build. */
    public function api(Request $r)
    {
        $response = Pricing::evaluateAvailability(Pricing::context(), $this->criteria($r));
        if ($response['error']) return response()->json(['error' => $response['error']], 422);
        $f = Pricing::applyFilters($response['results'], $this->filters($r));

        return response()->json($response + ['results' => $f['results'], 'outsidePriceRange' => $f['outsidePriceRange']]);
    }

    private function criteria(Request $r): array
    {
        return [
            'checkIn' => $r->input('check_in') ?: Pricing::todayIso(),
            'checkOut' => $r->input('check_out') ?: Pricing::addDays(Pricing::todayIso(), 2),
            'bookingDate' => $r->input('booking_date') ?: Pricing::todayIso(),
            'adults' => max(1, (int) $r->input('adults', 2)),
            'children' => max(0, (int) $r->input('children', 0)),
            'infants' => max(0, (int) $r->input('infants', 0)),
            'rooms' => max(1, (int) $r->input('rooms', 1)),
            'extraBeds' => max(0, (int) $r->input('extra_beds', 0)),
            'sofaBeds' => max(0, (int) $r->input('sofa_beds', 0)),
            'babyCots' => max(0, (int) $r->input('baby_cots', 0)),
            'category' => $r->input('category', 'any'),
            'market' => $r->input('market', 'all'),
            'hotelId' => $r->input('hotel_id') ? (int) $r->input('hotel_id') : null,
            'roomTypeId' => null,
        ];
    }

    private function filters(Request $r): array
    {
        return [
            'query' => (string) $r->input('q', ''),
            'sort' => (string) $r->input('sort', 'price_asc'),
            'rateBasis' => $r->input('rate_basis', 'excl_tax'),
            'boardTypes' => array_values(array_filter((array) $r->input('board_types', []))),
            'cities' => array_values(array_filter((array) $r->input('cities', []))),
            'locations' => array_values(array_filter((array) $r->input('locations', []))),
            'amenities' => array_values(array_filter((array) $r->input('amenities', []))),
            'minStars' => (int) $r->input('min_stars', 0),
            'priceMin' => $r->input('price_min', ''),
            'priceMax' => $r->input('price_max', ''),
        ];
    }
}
