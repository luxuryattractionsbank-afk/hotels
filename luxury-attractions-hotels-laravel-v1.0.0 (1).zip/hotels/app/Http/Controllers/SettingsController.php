<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Catalog;
use App\Support\Mailer;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Company details, SMTP status and the audit trail. */
class SettingsController extends Controller
{
    public function index()
    {
        return view('settings', [
            'company' => Settings::all('company'),
            'mail' => [
                'configured' => Mailer::configured(),
                'driver' => config('mail.default'),
                'host' => config('mail.mailers.smtp.host'),
                'port' => config('mail.mailers.smtp.port'),
                'from' => config('mail.from.address'),
            ],
            'counts' => [
                'hotels' => DB::table('hotels')->count(),
                'rooms' => DB::table('room_types')->count(),
                'rates' => DB::table('rate_periods')->count(),
                'bookings' => DB::table('bookings')->count(),
                'quotations' => DB::table('quotations')->count(),
                'packages' => DB::table('trip_packages')->count(),
                'services' => DB::table('services')->count(),
                'users' => DB::table('users')->count(),
            ],
            'tables' => array_map(fn ($t) => current((array) $t), DB::select('show tables')),
            'installed' => trim((string) @file_get_contents(storage_path('installed.lock'))),
            'version' => trim((string) @file_get_contents(base_path('VERSION'))),
            'currencies' => ['AED', 'USD', 'EUR', 'GBP', 'SAR'],
        ]);
    }

    public function save(Request $r)
    {
        $d = $r->validate([
            'name' => 'required|string|max:150',
            'phone' => 'nullable|string|max:60',
            'email' => 'nullable|email|max:190',
            'address' => 'nullable|string|max:255',
            'website' => 'nullable|string|max:255',
            'default_currency' => 'nullable|string|max:8',
            'default_markup' => 'nullable|numeric|min:0|max:400',
        ]);
        Settings::save('company', $d);
        Audit::log('settings', null, 'company_updated', ['name' => $d['name']]);

        return back()->with('ok', 'Company details saved.');
    }

    public function audit()
    {
        return view('audit', ['rows' => Audit::recent(500)]);
    }
}
