<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Quotation;
use App\Support\Audit;
use App\Support\Catalog;
use App\Support\Pricing;
use App\Support\Reference;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Quotations (multi-hotel itineraries with markup) and confirmed bookings.
 * Replaces api/quotations, api/quotations/convert and api/bookings.
 */
class QuotationController extends Controller
{
    public function index(Request $r)
    {
        return view('quotations.index', [
            'quotations' => Quotation::query()
                ->when($r->input('q'), function ($q, $term) {
                    $like = '%'.trim($term).'%';
                    $q->where(fn ($w) => $w->where('reference', 'like', $like)->orWhere('client_name', 'like', $like)->orWhere('client_email', 'like', $like));
                })
                ->when($r->input('status'), fn ($q, $s) => $q->where('status', $s))
                ->orderByDesc('id')->paginate(25)->withQueryString(),
            'statuses' => Catalog::STATUSES,
            'q' => $r->input('q'),
            'status' => $r->input('status'),
        ]);
    }

    public function create(Request $r)
    {
        return view('quotations.form', [
            'quotation' => null,
            'fromSearch' => $r->input('offer') ? json_decode(base64_decode((string) $r->input('offer')), true) : null,
            'hotels' => DB::table('hotels')->where('active', 1)->orderBy('name')->get(['id', 'name', 'city']),
            'markets' => DB::table('markets')->orderBy('sort_order')->get(),
            'boards' => Catalog::BOARD_TYPES,
            'defaultMarkup' => (float) (\App\Support\Settings::company('default_markup', '15')),
        ]);
    }

    public function edit(int $id)
    {
        return view('quotations.form', [
            'quotation' => Quotation::with('items')->findOrFail($id),
            'fromSearch' => null,
            'hotels' => DB::table('hotels')->where('active', 1)->orderBy('name')->get(['id', 'name', 'city']),
            'markets' => DB::table('markets')->orderBy('sort_order')->get(),
            'boards' => Catalog::BOARD_TYPES,
            'defaultMarkup' => (float) (\App\Support\Settings::company('default_markup', '15')),
        ]);
    }

    /** Saves a quotation and prices every line with the same engine used by search. */
    public function store(Request $r, ?int $id = null)
    {
        $d = $r->validate([
            'client_name' => 'required|string|max:150',
            'client_email' => 'nullable|email|max:190',
            'client_phone' => 'nullable|string|max:60',
            'market' => 'nullable|string|max:60',
            'status' => 'nullable|string|max:30',
            'valid_until' => 'nullable|date',
            'notes' => 'nullable|string',
            'markup_percent' => 'nullable|numeric|min:0|max:400',
            'include_tourism_tax' => 'nullable|boolean',
            'currency' => 'nullable|string|max:8',
        ]);

        $context = Pricing::context();
        $items = [];
        $netTotal = 0.0;

        foreach ((array) $r->input('line', []) as $line) {
            if (empty($line['hotel_id']) || empty($line['room_type_id']) || empty($line['check_in']) || empty($line['check_out'])) continue;
            $criteria = [
                'checkIn' => $line['check_in'], 'checkOut' => $line['check_out'],
                'bookingDate' => $line['booking_date'] ?? Pricing::todayIso(),
                'adults' => max(1, (int) ($line['adults'] ?? 2)), 'children' => max(0, (int) ($line['children'] ?? 0)),
                'infants' => max(0, (int) ($line['infants'] ?? 0)), 'rooms' => max(1, (int) ($line['rooms'] ?? 1)),
                'extraBeds' => (int) ($line['extra_beds'] ?? 0), 'sofaBeds' => (int) ($line['sofa_beds'] ?? 0),
                'babyCots' => (int) ($line['baby_cots'] ?? 0), 'category' => 'any',
                'market' => $d['market'] ?: 'all', 'hotelId' => (int) $line['hotel_id'], 'roomTypeId' => (int) $line['room_type_id'],
            ];
            $board = $line['board_type'] ?? 'breakfast';
            $result = Pricing::evaluateAvailability($context, $criteria);
            if ($result['error']) return back()->withInput()->with('error', $result['error']);

            $match = null;
            foreach ($result['results'] as $res) {
                foreach ($res['offers'] as $offer) {
                    if ($offer['boardType'] === $board) { $match = ['res' => $res, 'offer' => $offer]; break 2; }
                }
            }
            if (! $match) {
                $reason = $result['excluded'][0]['reason'] ?? "No $board contract covers those dates.";
                return back()->withInput()->with('error', 'Line '.(count($items) + 1).': '.$reason);
            }

            $offer = $match['offer'];
            $res = $match['res'];
            $netTotal += (float) $offer['totalAmount'];
            $items[] = [
                'position' => count($items) + 1,
                'hotel_id' => (int) $line['hotel_id'], 'room_type_id' => (int) $line['room_type_id'],
                'rate_period_id' => $offer['primaryRatePeriodId'] ?: null, 'board_type' => $board,
                'check_in' => $criteria['checkIn'], 'check_out' => $criteria['checkOut'],
                'nights' => $offer['nights'], 'adults' => $criteria['adults'], 'children' => $criteria['children'],
                'infants' => $criteria['infants'], 'rooms' => $criteria['rooms'],
                'extra_beds' => $offer['extraBeds'], 'sofa_beds' => $offer['sofaBeds'], 'baby_cots' => $offer['babyCots'],
                'base_amount' => $offer['baseAmount'], 'board_amount' => $offer['boardAmount'],
                'occupancy_amount' => $offer['occupancyAmount'], 'extra_bed_amount' => $offer['extraBedAmount'],
                'tourism_tax_amount' => $d['include_tourism_tax'] ?? true ? $offer['tourismTaxAmount'] : 0,
                'total_amount' => $offer['totalAmount'],
                'rate_names' => implode(', ', $offer['rateNames']),
                'promo_codes' => implode(', ', $offer['promoCodes']),
                'allocation_json' => json_encode($res['allocation']),
                'nightly_json' => json_encode($offer['nightly']),
                'hotel_name' => $res['hotel']['name'], 'room_name' => $res['room']['name'],
            ];
        }

        if ($items === []) return back()->withInput()->with('error', 'Add at least one priced hotel line.');

        $markupPercent = (float) ($d['markup_percent'] ?? 0);
        $markupAmount = Pricing::money($netTotal * $markupPercent / 100);
        $proposalTotal = Pricing::money($netTotal + $markupAmount);

        DB::transaction(function () use (&$id, $d, $items, $netTotal, $markupPercent, $markupAmount, $proposalTotal, $r) {
            $row = [
                'reference' => $id ? Quotation::findOrFail($id)->reference : Reference::quotation(),
                'client_name' => $d['client_name'], 'client_email' => $d['client_email'] ?? '',
                'client_phone' => $d['client_phone'] ?? '', 'market' => $d['market'] ?: 'all',
                'status' => $d['status'] ?: 'draft', 'total_amount' => $netTotal,
                'currency' => $d['currency'] ?: 'AED', 'valid_until' => $d['valid_until'] ?? null,
                'notes' => $d['notes'] ?? '', 'include_tourism_tax' => $r->boolean('include_tourism_tax') ? 1 : 0,
                'markup_percent' => $markupPercent, 'markup_amount' => $markupAmount,
                'proposal_total' => $proposalTotal, 'created_by' => $r->user()?->id, 'created_at' => now(),
            ];
            if ($id) DB::table('quotations')->where('id', $id)->update($row);
            else $id = DB::table('quotations')->insertGetId($row);

            DB::table('quotation_items')->where('quotation_id', $id)->delete();
            foreach ($items as $item) {
                unset($item['hotel_name'], $item['room_name']);
                $item['quotation_id'] = $id;
                DB::table('quotation_items')->insert($item);
            }
        });

        Audit::log('quotation', $id, $r->input('id') ? 'updated' : 'created', ['lines' => count($items), 'total' => $proposalTotal]);

        return redirect('/quotations/'.$id)->with('ok', 'Quotation saved and priced from live contracts.');
    }

    public function show(int $id)
    {
        $q = Quotation::with('items.hotel', 'items.roomType', 'bookings')->findOrFail($id);

        return view('quotations.show', [
            'quotation' => $q,
            'lines' => $q->items->map(function ($item) {
                return $item->only(['id', 'position', 'board_type', 'check_in', 'check_out', 'nights', 'adults', 'children',
                    'infants', 'rooms', 'extra_beds', 'sofa_beds', 'baby_cots', 'base_amount', 'board_amount',
                    'occupancy_amount', 'extra_bed_amount', 'tourism_tax_amount', 'total_amount', 'rate_names', 'promo_codes'])
                    + ['hotel_name' => $item->hotel?->name ?? '—', 'room_name' => $item->roomType?->name ?? '—',
                        'nightly' => $item->nightly_json ?? [], 'allocation' => $item->allocation_json ?? []];
            }),
        ]);
    }

    /** Converts a quotation line into a confirmed booking (api/quotations/convert). */
    public function convert(Request $r, int $id)
    {
        $item = DB::table('quotation_items')->where('quotation_id', $id)->where('id', (int) $r->input('item_id'))->first();
        if (! $item) return back()->with('error', 'Choose a quotation line to convert.');

        $d = $r->validate([
            'guest_name' => 'required|string|max:150',
            'guest_email' => 'required|email|max:190',
            'guest_phone' => 'nullable|string|max:60',
            'notes' => 'nullable|string',
        ]);

        $bookingId = DB::table('bookings')->insertGetId([
            'reference' => Reference::booking(),
            'hotel_id' => $item->hotel_id, 'room_type_id' => $item->room_type_id,
            'rate_period_id' => $item->rate_period_id ?: DB::table('rate_periods')->where('hotel_id', $item->hotel_id)->value('id'),
            'board_type' => $item->board_type, 'guest_name' => $d['guest_name'], 'guest_email' => $d['guest_email'],
            'guest_phone' => $d['guest_phone'] ?? '', 'check_in' => $item->check_in, 'check_out' => $item->check_out,
            'adults' => $item->adults, 'children' => $item->children, 'infants' => $item->infants, 'rooms' => $item->rooms,
            'extra_beds' => $item->extra_beds, 'sofa_beds' => $item->sofa_beds, 'baby_cots' => $item->baby_cots,
            'nights' => $item->nights, 'base_amount' => $item->base_amount, 'board_amount' => $item->board_amount,
            'occupancy_amount' => $item->occupancy_amount, 'extra_bed_amount' => $item->extra_bed_amount,
            'tourism_tax_amount' => $item->tourism_tax_amount, 'total_amount' => $item->total_amount,
            'currency' => DB::table('quotations')->where('id', $id)->value('currency') ?: 'AED',
            'status' => 'confirmed', 'notes' => $d['notes'] ?? '', 'quotation_id' => $id,
            'created_by' => $r->user()?->id, 'created_at' => now(),
        ]);
        DB::table('quotations')->where('id', $id)->update(['status' => 'confirmed']);
        Audit::log('booking', $bookingId, 'converted_from_quotation', ['quotation_id' => $id, 'item_id' => $item->id]);

        return redirect('/bookings/'.$bookingId)->with('ok', 'Booking confirmed from the quotation.');
    }

    public function destroy(int $id)
    {
        DB::table('quotation_items')->where('quotation_id', $id)->delete();
        DB::table('quotations')->where('id', $id)->delete();
        Audit::log('quotation', $id, 'deleted', []);

        return redirect('/quotations')->with('ok', 'Quotation deleted.');
    }
}
