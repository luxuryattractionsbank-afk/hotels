<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Catalog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Internal transfer & tour price list. Replaces api/services and services-panel.tsx. */
class ServiceController extends Controller
{
    public function index(Request $r)
    {
        return view('services', [
            'services' => DB::table('services')
                ->when($r->input('kind'), fn ($q, $k) => $q->where('kind', $k))
                ->when($r->input('q'), function ($q, $term) {
                    $like = '%'.trim($term).'%';
                    $q->where(fn ($w) => $w->where('name', 'like', $like)->orWhere('city', 'like', $like));
                })
                ->orderBy('sort_order')->orderBy('name')->paginate(40)->withQueryString(),
            'editing' => $r->input('edit') ? DB::table('services')->find($r->input('edit')) : null,
            'cities' => DB::table('services')->distinct()->orderBy('city')->pluck('city'),
        ]);
    }

    public function save(Request $r, ?int $id = null)
    {
        $money = 'nullable|numeric|min:0|max:999999';
        $d = $r->validate([
            'kind' => 'required|in:transfer,tour',
            'name' => 'required|string|max:190',
            'description' => 'nullable|string',
            'city' => 'required|string|max:120',
            'duration' => 'nullable|string|max:90',
            'shared_oneway_price' => $money, 'shared_twoway_price' => $money,
            'private7_oneway_price' => $money, 'private7_twoway_price' => $money,
            'private12_oneway_price' => $money, 'private12_twoway_price' => $money,
            'ticket_only_adult' => $money, 'ticket_only_child' => $money,
            'shared_adult' => $money, 'shared_child' => $money,
            'private_adult' => $money, 'private_child' => $money,
            'sort_order' => 'nullable|integer|min:0|max:9999',
        ]);

        foreach (array_keys($d) as $k) {
            if (str_contains($k, 'price') || str_contains($k, 'adult') || str_contains($k, 'child')) $d[$k] = (string) ($d[$k] ?? 0);
        }
        $d += ['description' => $d['description'] ?? '', 'duration' => $d['duration'] ?? '', 'sort_order' => (int) ($d['sort_order'] ?? 100),
            'active' => $r->boolean('active') ? 1 : 0];
        if (! $id) $d['created_at'] = now();

        $row = collect($d)->only(['kind', 'name', 'description', 'city', 'duration', 'shared_oneway_price', 'shared_twoway_price',
            'private7_oneway_price', 'private7_twoway_price', 'private12_oneway_price', 'private12_twoway_price',
            'ticket_only_adult', 'ticket_only_child', 'shared_adult', 'shared_child', 'private_adult', 'private_child',
            'sort_order', 'active', 'created_at'])->all();

        if ($id) DB::table('services')->where('id', $id)->update($row);
        else $id = DB::table('services')->insertGetId($row);
        Audit::log('service', $id, $id ? 'updated' : 'created', ['name' => $row['name']]);

        return redirect('/services')->with('ok', 'Service price saved.');
    }

    public function destroy(int $id)
    {
        DB::table('services')->where('id', $id)->delete();
        Audit::log('service', $id, 'deleted', []);

        return redirect('/services')->with('ok', 'Service deleted.');
    }

    /** Price a transfer or tour line exactly as trip-packages-panel.tsx does. */
    public function price(Request $r)
    {
        $service = DB::table('services')->find((int) $r->input('service_id'));
        if (! $service) return response()->json(['error' => 'Unknown service.'], 404);

        $adults = max(0, (int) $r->input('adults', 2));
        $children = max(0, (int) $r->input('children', 0));

        if ($service->kind === 'transfer') {
            $mode = (string) $r->input('mode', 'shared');
            $direction = (string) $r->input('direction', 'oneway');
            $vehicles = max(1, (int) $r->input('vehicles', 1));
            $unit = $mode === 'shared'
                ? (float) ($direction === 'twoway' ? $service->shared_twoway_price : $service->shared_oneway_price) * max(1, $adults + $children)
                : (float) ($direction === 'twoway'
                    ? ($mode === 'private12' ? $service->private12_twoway_price : $service->private7_twoway_price)
                    : ($mode === 'private12' ? $service->private12_oneway_price : $service->private7_oneway_price)) * $vehicles;

            return response()->json(['kind' => 'transfer', 'unit_price' => round($unit, 2), 'total_net' => round($unit, 2)]);
        }

        $mode = (string) $r->input('option_mode', 'ticket');
        $adult = (float) match ($mode) {
            'shared' => $service->shared_adult,
            'private' => $service->private_adult,
            default => $service->ticket_only_adult,
        };
        $child = (float) match ($mode) {
            'shared' => $service->shared_child,
            'private' => $service->private_child,
            default => $service->ticket_only_child,
        };

        return response()->json([
            'kind' => 'tour', 'price_adult' => round($adult, 2), 'price_child' => round($child, 2),
            'total_net' => round($adult * $adults + $child * $children, 2),
        ]);
    }
}
