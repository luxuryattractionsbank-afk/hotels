<?php

namespace App\Http\Middleware;

use App\Support\Perm;
use Closure;
use Illuminate\Http\Request;

/**
 * Server-side authorization. Hiding a button in Blade is not authorization, so every
 * write route is guarded here – the same rule the Next.js API routes enforced.
 * Usage: ->middleware('perm:manage_rates') or ->middleware('perm:manage_users,manage_hotels')
 */
class Permission
{
    public function handle(Request $request, Closure $next, string ...$permissions)
    {
        $user = $request->user();
        $list = implode(',', $permissions);

        if (! Perm::allowsAny($user, $list)) {
            $message = 'You do not have permission for this action.';
            if ($request->expectsJson()) return response()->json(['error' => $message], 403);
            return back()->with('error', $message);
        }

        return $next($request);
    }
}
