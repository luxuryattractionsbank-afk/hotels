<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** A transfer line inside a trip package. No timestamps. */
class TripPackageTransfer extends Model
{
    protected $table = 'trip_package_transfers';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return ['unit_price' => 'decimal:2', 'total_net' => 'decimal:2'];
    }

    public function package() { return $this->belongsTo(TripPackage::class, 'package_id'); }
    public function service() { return $this->belongsTo(Service::class); }
}
