<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** A tour / ticket line inside a trip package. No timestamps. */
class TripPackageTour extends Model
{
    protected $table = 'trip_package_tours';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return ['price_adult' => 'decimal:2', 'price_child' => 'decimal:2', 'total_net' => 'decimal:2'];
    }

    public function package() { return $this->belongsTo(TripPackage::class, 'package_id'); }
    public function service() { return $this->belongsTo(Service::class); }
}
