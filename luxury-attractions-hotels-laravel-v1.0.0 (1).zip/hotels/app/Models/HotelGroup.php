<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HotelGroup extends Model
{
    protected $table = 'hotel_groups';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function hotels() { return $this->hasMany(Hotel::class, "group_id"); }

}
