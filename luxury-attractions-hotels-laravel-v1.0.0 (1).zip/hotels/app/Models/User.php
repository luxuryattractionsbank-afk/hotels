<?php

namespace App\Models;

use App\Support\Perm;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

/**
 * Staff account. Replaces the iron-session cookie user from src/lib/auth.ts:
 * Laravel sessions hold the user id, and `session_version` still invalidates
 * old sessions after a password or permission change.
 */
class User extends Authenticatable
{
    protected $table = 'users';

    protected $guarded = ['id'];

    protected $hidden = ['password_hash', 'remember_token'];

    protected function casts(): array
    {
        return ['active' => 'boolean', 'locked_until' => 'datetime', 'permissions' => 'array'];
    }

    /** Laravel's auth driver expects a `password` attribute. */
    public function getAuthPassword(): string { return (string) $this->password_hash; }

    public function permissions(): array { return Perm::normalize($this->attributes['permissions'] ?? []); }

    public function can($ability, $arguments = []): bool { return Perm::allows($this, (string) $ability); }

    public function roleName(): string { return Perm::roleName($this->role); }

    /** Sign in with either the username or the registered email. */
    public static function findByIdentifier(string $identifier): ?self
    {
        $identifier = trim($identifier);
        return self::where('username', $identifier)->orWhere('email', $identifier)->first();
    }

    public function isLocked(): bool { return $this->locked_until && $this->locked_until->isFuture(); }

    /** Password/permission changes invalidate every earlier session. */
    public function bumpSessionVersion(): void
    {
        DB::table('users')->where('id', $this->id)->update([
            'session_version' => (int) $this->session_version + 1, 'updated_at' => now(),
        ]);
        $this->session_version = (int) $this->session_version + 1;
    }

    public function registerFailedAttempt(int $max = 6, int $minutes = 15): void
    {
        $attempts = (int) $this->failed_attempts + 1;
        DB::table('users')->where('id', $this->id)->update([
            'failed_attempts' => $attempts,
            'locked_until' => $attempts >= $max ? now()->addMinutes($minutes) : $this->locked_until,
            'updated_at' => now(),
        ]);
    }

    public function clearFailedAttempts(): void
    {
        DB::table('users')->where('id', $this->id)->update(['failed_attempts' => 0, 'locked_until' => null, 'updated_at' => now()]);
    }
}
