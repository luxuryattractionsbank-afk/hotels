<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** One priced hotel line inside a quotation. Table has no timestamps or active flag. */
class QuotationItem extends Model
{
    protected $table = 'quotation_items';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        // The Node build stored these as TEXT holding JSON; MySQL uses native JSON.
        return [
            'allocation_json' => 'array',
            'nightly_json' => 'array',
        ];
    }

    public function quotation() { return $this->belongsTo(Quotation::class); }
    public function hotel() { return $this->belongsTo(Hotel::class); }
    public function roomType() { return $this->belongsTo(RoomType::class); }
    public function ratePeriod() { return $this->belongsTo(RatePeriod::class); }
}
