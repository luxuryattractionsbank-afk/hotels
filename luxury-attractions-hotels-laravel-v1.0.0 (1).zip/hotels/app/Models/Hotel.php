<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hotel extends Model
{
    protected $table = 'hotels';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function location() { return $this->belongsTo(Location::class, "location_id"); }
    public function group() { return $this->belongsTo(HotelGroup::class, "group_id"); }
    public function roomTypes() { return $this->hasMany(RoomType::class); }
    public function rates() { return $this->hasMany(RatePeriod::class); }
    public function blackouts() { return $this->hasMany(BlackoutDate::class); }
    public function bookings() { return $this->hasMany(Booking::class); }
    public function contacts() { return $this->belongsToMany(HotelContact::class, "hotel_contact_assignments", "hotel_id", "contact_id"); }
    public function amenities() { return $this->belongsToMany(Amenity::class, "hotel_amenities", "hotel_id", "amenity_id"); }

    public function scopeSearch($q, ?string $term)
    {
        if (! $term) return $q;
        $like = "%".trim($term)."%";
        return $q->where(fn ($w) => $w->where("name", "like", $like)
            ->orWhere("city", "like", $like)->orWhere("supplier_code", "like", $like)
            ->orWhere("address", "like", $like));
    }

}
