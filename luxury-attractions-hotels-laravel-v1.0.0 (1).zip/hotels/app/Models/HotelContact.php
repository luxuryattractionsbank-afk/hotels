<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HotelContact extends Model
{
    protected $table = 'hotel_contacts';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function hotels() { return $this->belongsToMany(Hotel::class, "hotel_contact_assignments", "contact_id", "hotel_id"); }

}
