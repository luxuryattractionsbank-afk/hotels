<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $table = 'bookings';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function hotel() { return $this->belongsTo(Hotel::class); }
    public function roomType() { return $this->belongsTo(RoomType::class); }
    public function ratePeriod() { return $this->belongsTo(RatePeriod::class); }
    public function quotation() { return $this->belongsTo(Quotation::class); }
    public function creator() { return $this->belongsTo(User::class, "created_by"); }

}
