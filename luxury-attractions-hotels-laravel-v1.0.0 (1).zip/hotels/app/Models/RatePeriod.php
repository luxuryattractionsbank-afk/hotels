<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RatePeriod extends Model
{
    protected $table = 'rate_periods';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function hotel() { return $this->belongsTo(Hotel::class); }
    public function roomType() { return $this->belongsTo(RoomType::class); }

    /** True when this contract covers a given stay date, booking date and market. */
    public function covers(string $date, string $bookingDate, string $market = "all"): bool
    {
        return (bool) $this->active
            && $this->valid_from <= $date && $this->valid_to >= $date
            && \App\Support\Pricing::withinBookingWindow($this->booking_window_start, $this->booking_window_end, $bookingDate)
            && \App\Support\Pricing::rateAppliesToMarket((string) $this->market, (string) $this->market_exclusions, $market);
    }

}
