<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Quotation extends Model
{
    protected $table = 'quotations';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function items() { return $this->hasMany(QuotationItem::class)->orderBy("position"); }
    public function bookings() { return $this->hasMany(Booking::class); }
    public function tripPackages() { return $this->hasMany(TripPackage::class); }
    public function creator() { return $this->belongsTo(User::class, "created_by"); }

}
