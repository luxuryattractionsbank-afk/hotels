<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RoomType extends Model
{
    protected $table = 'room_types';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function hotel() { return $this->belongsTo(Hotel::class); }
    public function occupancyRules() { return $this->hasMany(OccupancyRule::class); }
    public function bedding() { return $this->hasMany(RoomBedding::class)->orderBy("sort_order"); }
    public function rates() { return $this->hasMany(RatePeriod::class); }

}
