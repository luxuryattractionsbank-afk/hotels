<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TripPackage extends Model
{
    protected $table = 'trip_packages';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'created_at' => 'datetime',
        ];
    }

    public function transfers() { return $this->hasMany(TripPackageTransfer::class, "package_id")->orderBy("position"); }
    public function tours() { return $this->hasMany(TripPackageTour::class, "package_id")->orderBy("position"); }
    public function quotation() { return $this->belongsTo(Quotation::class); }
    public function creator() { return $this->belongsTo(User::class, "created_by"); }

}
