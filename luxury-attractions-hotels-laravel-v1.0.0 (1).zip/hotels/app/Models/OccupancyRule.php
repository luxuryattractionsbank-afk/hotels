<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** A permitted adults/children/infants combination for a room type. No timestamps. */
class OccupancyRule extends Model
{
    protected $table = 'occupancy_rules';

    protected $guarded = ['id'];

    public $timestamps = false;

    public function roomType() { return $this->belongsTo(RoomType::class); }
}
