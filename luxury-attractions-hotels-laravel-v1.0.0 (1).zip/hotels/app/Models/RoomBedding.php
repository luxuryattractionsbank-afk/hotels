<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** Bedding a room type can offer (extra bed, sofa bed, baby cot). Table has no timestamps. */
class RoomBedding extends Model
{
    protected $table = 'room_bedding';

    protected $guarded = ['id'];

    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'free' => 'boolean',
            'per_stay' => 'boolean',
            'rate_per_night' => 'decimal:2',
        ];
    }

    public function roomType() { return $this->belongsTo(RoomType::class); }
}
