<?php

namespace App\Providers;

use App\Support\Settings;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Every Blade layout gets the company name and the signed-in user's permissions.
        View::composer('*', function ($view) {
            $view->with('companyName', $this->safe(fn () => Settings::company('name', 'Luxury Attractions')));
        });

        // The auth driver reads users.password_hash through the User model.
        Auth::shouldUse('web');

        // trustProxies(at: '*') in bootstrap/app.php already honours X-Forwarded-Proto, so
        // generated URLs are https behind cPanel's proxy. We deliberately do NOT force the
        // scheme unconditionally: the subdomain is often installed before its SSL certificate
        // exists, and forcing https there would redirect /install into a connection error.
        // Set APP_FORCE_HTTPS=true once AutoSSL has run to hard-force it.
        if (env('APP_FORCE_HTTPS', false) && ! app()->runningInConsole()) {
            \Illuminate\Support\Facades\URL::forceScheme('https');
        }
    }

    /** Settings cannot be read before the installer created the tables. */
    private function safe(callable $fn, $default = '')
    {
        try {
            if (! Schema::hasTable('settings')) return $default;
            return $fn();
        } catch (\Throwable) {
            return $default;
        }
    }
}
