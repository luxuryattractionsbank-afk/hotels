<?php

namespace App\Support;

/** Presentation helpers shared by every Blade view. */
class Fmt
{
    public static function money($n, string $cur = 'AED'): string
    {
        $v = (float) $n;
        $symbol = ['AED' => 'AED ', 'USD' => '$ ', 'EUR' => '€ ', 'GBP' => '£ ', 'SAR' => 'SAR '][$cur] ?? $cur.' ';
        return $symbol.number_format($v, 2);
    }

    /** "deluxe_king" -> "Deluxe king"; keeps known catalogue labels intact. */
    public static function label(?string $s): string
    {
        $known = Catalog::label((string) $s);
        if ($known !== null) return $known;
        return ucfirst(str_replace(['_', '-'], ' ', strtolower(trim((string) $s))));
    }

    public static function date(?string $d, string $fmt = 'd M Y'): string
    {
        if (! $d) return '—';
        try {
            return \Illuminate\Support\Carbon::parse($d)->format($fmt);
        } catch (\Throwable) {
            return $d;
        }
    }

    public static function nights(?string $in, ?string $out): int
    {
        if (! $in || ! $out) return 0;
        return max(0, (int) \Illuminate\Support\Carbon::parse($in)->diffInDays(\Illuminate\Support\Carbon::parse($out)));
    }

    public static function stars(int $n): string
    {
        return str_repeat('★', max(0, min(5, $n)));
    }

    public static function bool(?bool $b, string $yes = 'Yes', string $no = 'No'): string
    {
        return $b ? $yes : $no;
    }
}
