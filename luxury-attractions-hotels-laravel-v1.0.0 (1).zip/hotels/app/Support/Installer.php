<?php

namespace App\Support;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use PDO;

/**
 * WordPress-style browser installer: unzip → open the subdomain → /install.
 * Mirrors the proven flow from luxury-attractions-travel-desk-laravel-v1.0.0.
 */
class Installer
{
    public static function lockPath(): string { return storage_path('installed.lock'); }

    public static function installed(): bool
    {
        if (file_exists(self::lockPath())) return true;
        if (! env('DB_DATABASE')) return false;
        try {
            if (DB::getSchemaBuilder()->hasTable('users') && DB::table('users')->count() > 0) {
                @file_put_contents(self::lockPath(), 'Installed '.now().' (existing database detected)');
                return true;
            }
        } catch (\Throwable) {
        }
        return false;
    }

    /** Server requirements shown on step 1 of /install. */
    public static function requirements(): array
    {
        $ext = fn ($e) => extension_loaded($e);
        return [
            ['PHP 8.2 or newer', version_compare(PHP_VERSION, '8.2.0', '>='), 'Running PHP '.PHP_VERSION],
            ['PDO MySQL extension', $ext('pdo_mysql'), 'pdo_mysql'],
            ['mbstring, openssl, xml, curl, gd extensions', $ext('mbstring') && $ext('openssl') && $ext('dom') && $ext('curl') && $ext('gd'), 'needed for PDF proposals and email'],
            ['.env file writable', is_writable(base_path('.env')) || (! file_exists(base_path('.env')) && is_writable(base_path())), base_path('.env')],
            ['storage/ folder writable', is_writable(storage_path()), storage_path()],
            ['bootstrap/cache writable', is_writable(base_path('bootstrap/cache')), 'bootstrap/cache'],
        ];
    }

    /** Step 2 – try the MySQL credentials before anything is written. */
    public static function testDb(array $c): string
    {
        try {
            $pdo = new PDO(
                "mysql:host={$c['host']};port={$c['port']};dbname={$c['database']};charset=utf8mb4",
                $c['username'],
                $c['password'],
                [PDO::ATTR_TIMEOUT => 8, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION],
            );
            $v = $pdo->query('select version()')->fetchColumn();
            $tables = (int) $pdo->query('select count(*) from information_schema.tables where table_schema = '. $pdo->quote($c['database']))->fetchColumn();
            return "Connected – MySQL/MariaDB $v, database “{$c['database']}” ($tables existing table(s)).";
        } catch (\PDOException $e) {
            $m = $e->getMessage();
            if (str_contains($m, 'Access denied')) throw new \RuntimeException('Wrong database username or password (or the user is not added to this database).');
            if (str_contains($m, 'Unknown database')) throw new \RuntimeException('That database name does not exist – use the full name shown in cPanel (e.g. myuser_hotels).');
            if (str_contains($m, 'Connection refused') || str_contains($m, 'getaddrinfo') || str_contains($m, 'timed out')) throw new \RuntimeException('Cannot reach the database server – on cPanel the host is usually localhost and the port 3306.');
            throw new \RuntimeException($m);
        }
    }

    /** Writes/updates keys in .env without disturbing comments or other values. */
    public static function writeEnv(array $values): void
    {
        $file = base_path('.env');
        $env = file_exists($file) ? file_get_contents($file) : (file_exists(base_path('.env.example')) ? file_get_contents(base_path('.env.example')) : '');
        foreach ($values as $k => $v) {
            $v = preg_match('/[\s#"\']$|[\s#"\'$]/', (string) $v) ? '"'.str_replace(['\\', '"'], ['\\\\', '\\"'], (string) $v).'"' : (string) $v;
            if (preg_match("/^{$k}=.*$/m", $env)) $env = preg_replace("/^{$k}=.*$/m", str_replace(['\\', '$'], ['\\\\', '\\$'], "$k=$v"), $env);
            else $env .= "\n$k=$v";
        }
        file_put_contents($file, trim($env)."\n");
        @chmod($file, 0600);
    }

    /** Step 3 – write .env, create all tables, seed catalogues, create the administrator. */
    public static function install(array $db, array $i): void
    {
        // APP_URL is taken from the current request when the installer runs in a browser,
        // and falls back to the configured value when run from the command line.
        $url = app()->bound('request') && request()->getSchemeAndHttpHost()
            ? rtrim(request()->getSchemeAndHttpHost().request()->getBaseUrl(), '/')
            : rtrim((string) (env('APP_URL') ?: 'http://localhost'), '/');
        self::writeEnv([
            'APP_NAME' => 'Luxury Attractions Hotels',
            'APP_ENV' => 'production',
            'APP_DEBUG' => 'false',
            'APP_URL' => $url,
            'APP_KEY' => env('APP_KEY') ?: 'base64:'.base64_encode(random_bytes(32)),
            'APP_TIMEZONE' => 'Asia/Dubai',
            'DB_CONNECTION' => 'mysql',
            'DB_HOST' => $db['host'],
            'DB_PORT' => $db['port'],
            'DB_DATABASE' => $db['database'],
            'DB_USERNAME' => $db['username'],
            'DB_PASSWORD' => $db['password'],
            'SESSION_DRIVER' => 'file',
            'CACHE_STORE' => 'file',
            'QUEUE_CONNECTION' => 'sync',
            'MAIL_MAILER' => ! empty($i['smtp_host']) ? 'smtp' : 'log',
            'MAIL_HOST' => $i['smtp_host'] ?? '',
            'MAIL_PORT' => $i['smtp_port'] ?? 587,
            'MAIL_USERNAME' => $i['smtp_user'] ?? '',
            'MAIL_PASSWORD' => $i['smtp_password'] ?? '',
            'MAIL_ENCRYPTION' => ((int) ($i['smtp_port'] ?? 587)) === 465 ? 'tls' : 'tls',
            'MAIL_FROM_ADDRESS' => $i['smtp_from'] ?: ($i['company_email'] ?: 'proposals@luxuryattractions.com'),
            'MAIL_FROM_NAME' => $i['company_name'],
        ]);

        config([
            'database.default' => 'mysql',
            'database.connections.mysql' => array_merge(config('database.connections.mysql'), [
                'host' => $db['host'], 'port' => $db['port'], 'database' => $db['database'],
                'username' => $db['username'], 'password' => $db['password'],
            ]),
        ]);
        DB::purge('mysql');
        DB::reconnect('mysql');

        Artisan::call('migrate', ['--force' => true]);

        Seeder::runReferenceData();
        if (! empty($i['example_data'])) Seeder::runExampleHotels();

        Settings::save('company', [
            'name' => $i['company_name'],
            'phone' => $i['company_phone'] ?? '',
            'email' => $i['company_email'] ?? '',
            'address' => $i['company_address'] ?? '',
            'website' => $i['company_website'] ?? '',
            'default_currency' => $i['currency'] ?? 'AED',
            'default_markup' => $i['default_markup'] ?? '15',
        ]);

        $adminId = DB::table('users')->insertGetId([
            'name' => $i['admin_name'],
            'username' => strtolower($i['admin_username']),
            'email' => $i['admin_email'],
            'password_hash' => Hash::make($i['admin_password']),
            'role' => 'admin',
            'permissions' => json_encode(Perm::defaults('admin')),
            'active' => 1,
            'session_version' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        if (! empty($i['demo_agent'])) {
            DB::table('users')->insert([
                'name' => 'Demo Sales Agent', 'username' => 'agent', 'email' => 'agent@hotels.local',
                'password_hash' => Hash::make('agent12345'), 'role' => 'sales',
                'permissions' => json_encode(Perm::defaults('sales')), 'active' => 1,
                'session_version' => 1, 'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        Audit::log('system', null, 'installed', [
            'company' => $i['company_name'],
            'admin' => $i['admin_username'],
            'example_data' => (bool) ($i['example_data'] ?? false),
            'version' => trim((string) @file_get_contents(base_path('VERSION'))),
        ], $adminId);

        file_put_contents(self::lockPath(), 'Installed '.now().' – delete this file only to run the web installer again.');
        foreach (['config:clear', 'route:clear', 'view:clear'] as $c) {
            try { Artisan::call($c); } catch (\Throwable) {}
        }
    }
}
