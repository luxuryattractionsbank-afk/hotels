<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/**
 * Reference data + optional illustrative hotel catalogue.
 * Ported from src/lib/hotel-data.ts (seedHotelData / ensureServiceSeeds).
 *
 * All demo hotels, contacts, rates and service prices remain ILLUSTRATIVE ONLY –
 * replace them with real contracted supplier data before selling.
 */
class Seeder
{
    private const DRIVE = 'https://drive.google.com/drive/folders/EXAMPLE-CONTRACTS-FOLDER';

    /** Per star rating: board supplements and occupancy surcharges (AED). */
    private const BOARD = [
        3 => ['hb' => 65, 'fb' => 115, 'extraAdult' => 90, 'extraChild' => 0, 'extraBed' => 70],
        4 => ['hb' => 105, 'fb' => 175, 'extraAdult' => 140, 'extraChild' => 0, 'extraBed' => 110],
        5 => ['hb' => 195, 'fb' => 340, 'extraAdult' => 280, 'extraChild' => 95, 'extraBed' => 190],
    ];

    private const AMENITIES = [
        ['swimming_pool', 'Swimming pool', 10],
        ['beach', 'Beach', 20],
        ['gym', 'Gym', 30],
        ['metro', 'Metro nearby', 40],
        ['spa', 'Spa & wellness', 50],
        ['kids_club', 'Kids club', 60],
        ['wifi', 'Free Wi-Fi', 70],
        ['parking', 'Free parking', 80],
    ];

    private const CITY_FULL = ['swimming_pool', 'gym', 'metro', 'wifi', 'parking'];
    private const BEACH_RESORT = ['swimming_pool', 'beach', 'gym', 'spa', 'kids_club', 'wifi', 'parking'];
    private const POOL_GYM = ['swimming_pool', 'gym', 'wifi', 'parking'];

    private const LOCATIONS = [
        ['Dubai', 'Deira'], ['Dubai', 'Bur Dubai'], ['Dubai', 'Dubai Marina'], ['Dubai', 'Business Bay'],
        ['Dubai', 'Downtown Dubai'], ['Dubai', 'Al Barsha'], ['Dubai', 'Palm Jumeirah'],
        ['Abu Dhabi', 'Yas Island'], ['Abu Dhabi', 'Corniche'], ['Abu Dhabi', 'Saadiyat Island'],
        ['Ras Al Khaimah', 'Marjan Island'], ['Sharjah', 'Al Majaz'],
    ];

    private const SERVICES = [
        ['transfer', 'Airport Pick-up & Drop-back (DXB)', 'Shared coach per person, or private vehicle per unit. Two-way covers arrival + departure.', 'Dubai', '≈45 min each way',
            ['sharedOneWayPrice' => 45, 'sharedTwoWayPrice' => 80, 'private7OneWayPrice' => 250, 'private7TwoWayPrice' => 500, 'private12OneWayPrice' => 400, 'private12TwowayPrice' => 800], 10],
        ['transfer', 'Airport Pick-up & Drop-back (AUH)', 'Abu Dhabi airport shared or private transfers.', 'Abu Dhabi', '≈40 min each way',
            ['sharedOneWayPrice' => 50, 'sharedTwoWayPrice' => 90, 'private7OneWayPrice' => 280, 'private7TwoWayPrice' => 540, 'private12OneWayPrice' => 450, 'private12TwowayPrice' => 850], 20],
        ['tour', 'Desert Safari with BBQ Dinner', 'Dune bashing, camel ride, BBQ dinner and live shows. Evening tour.', 'Dubai', '6 hours (15:00 – 21:00)',
            ['ticketOnlyAdult' => 120, 'ticketOnlyChild' => 90, 'sharedAdult' => 165, 'sharedChild' => 130, 'privateAdult' => 320, 'privateChild' => 260], 30],
        ['tour', 'Burj Khalifa At The Top (124/125)', 'Entry tickets with optional shared or private transfers.', 'Dubai', '2 hours',
            ['ticketOnlyAdult' => 189, 'ticketOnlyChild' => 149, 'sharedAdult' => 249, 'sharedChild' => 209, 'privateAdult' => 420, 'privateChild' => 380], 40],
        ['tour', 'Dhow Cruise Marina Dinner', '2-hour marina cruise with international buffet dinner.', 'Dubai', '2 hours (20:00 – 22:00)',
            ['ticketOnlyAdult' => 110, 'ticketOnlyChild' => 80, 'sharedAdult' => 150, 'sharedChild' => 115, 'privateAdult' => 300, 'privateChild' => 250], 50],
        ['tour', 'Ferrari World Abu Dhabi', 'Full-day theme park tickets from Dubai or Abu Dhabi.', 'Abu Dhabi', 'Full day',
            ['ticketOnlyAdult' => 345, 'ticketOnlyChild' => 265, 'sharedAdult' => 425, 'sharedChild' => 335, 'privateAdult' => 690, 'privateChild' => 590], 60],
    ];

    /** 14 contracted demo suppliers, same names/codes as the Node seed. */
    private const HOTELS = [
        ['Al Khoory Executive Hotel', 'Dubai', 'Al Barsha 1, Dubai', 4, 'AKE-DXB', 'sales@alkhoory.example', '+971 4 321 7777', '14:00', '12:00', 15, 165, 330, 'Al Khoory Hotels', 'CITY_FULL', 'four', 0],
        ['Al Khoory Sky Garden Hotel', 'Dubai', 'Al Barsha South, Dubai', 4, 'AKS-DXB', 'skygarden@alkhoory.example', '+971 4 321 8888', '14:00', '12:00', 15, 155, 315, 'Al Khoory Hotels', 'CITY_FULL', 'four', 0],
        ['Rove Downtown', 'Dubai', 'Al Mustaqbal Street, Downtown Dubai', 3, 'RDT-DXB', 'groups@rove.example', '+971 4 561 9000', '15:00', '12:00', 10, 135, 265, null, 'CITY_FULL', 'three', 0],
        ['Citymax Hotel Al Barsha', 'Dubai', 'Al Barsha 1, near Mall of the Emirates', 3, 'CMB-DXB', 'sales@citymax.example', '+971 4 409 8000', '14:00', '12:00', 10, 110, 210, null, 'CITY_FULL', 'three', 1],
        ['Premier Inn Dubai Silicon Oasis', 'Dubai', 'Dubai Silicon Oasis', 3, 'PIS-DXB', 'b2b@premierinn.example', '+971 4 372 2222', '14:00', '12:00', 10, 105, 190, null, 'POOL_GYM', 'three', 0],
        ['Hampton by Hilton Marjan Island', 'Ras Al Khaimah', 'Marjan Island Boulevard', 3, 'HMI-RAK', 'reservations@hampton.example', '+971 7 204 7000', '15:00', '12:00', 10, 125, 235, null, 'BEACH_RESORT', 'three', 0],
        ['Novotel Dubai Al Barsha', 'Dubai', 'Sheikh Zayed Road, Al Barsha', 4, 'NAB-DXB', 'contracts@novotel.example', '+971 4 304 9000', '14:00', '12:00', 15, 175, 360, null, 'CITY_FULL', 'four', 0],
        ['Holiday Inn Abu Dhabi Downtown', 'Abu Dhabi', 'Hamdan Bin Mohammed Street', 4, 'HID-AUH', 'sales@holidayinn.example', '+971 2 657 4888', '15:00', '12:00', 15, 150, 285, null, 'POOL_GYM', 'four', 0],
        ['Address Sky View', 'Dubai', 'Sheikh Mohammed bin Rashid Boulevard', 5, 'ASV-DXB', 'reservations@address.example', '+971 4 873 8888', '15:00', '12:00', 20, 690, 1250, 'Emaar Hospitality', 'CITY_FULL', 'five', 0],
        ['Jumeirah Beach Hotel', 'Dubai', 'Jumeirah Beach Road, Umm Suqeim', 5, 'JBH-DXB', 'contracts@jumeirah.example', '+971 4 348 0000', '15:00', '12:00', 20, 780, 1450, 'Jumeirah Group', 'BEACH_RESORT', 'five', 0],
        ['Rixos Premium Saadiyat', 'Abu Dhabi', 'Saadiyat Island', 5, 'RPS-AUH', 'sales@rixos.example', '+971 2 492 2222', '15:00', '12:00', 20, 720, 1180, null, 'BEACH_RESORT', 'five', 0],
        ['Atlantis The Royal', 'Dubai', 'Crescent Road, Palm Jumeirah', 5, 'ATR-DXB', 'trade@atlantis.example', '+971 4 426 3000', '15:00', '11:00', 20, 1650, 2900, 'Kerzner International', 'BEACH_RESORT', 'five', 0],
        ['The Ritz-Carlton Al Wadi Desert', 'Ras Al Khaimah', 'Al Mazraa, Ras Al Khaimah', 5, 'RCW-RAK', 'wholesale@ritz-carlton.example', '+971 7 206 7777', '15:00', '12:00', 20, 1150, 1900, 'Marriott International', 'POOL_GYM', 'five', 1],
        ['Anantara Qasr Al Sarab', 'Abu Dhabi', 'Liwa Desert, Qasr Al Sarab Road', 5, 'QAS-AUH', 'partners@anantara.example', '+971 2 886 2088', '15:00', '12:00', 20, 890, 1350, null, 'POOL_GYM', 'five', 0],
    ];

    /** Lookups always exist – the app cannot price a stay without markets/amenities. */
    public static function runReferenceData(): void
    {
        $order = 0;
        foreach (Catalog::MARKETS as $slug => $label) {
            $order++;
            DB::table('markets')->updateOrInsert(['slug' => $slug], ['label' => $label, 'sort_order' => $order * 10, 'active' => 1]);
        }
        $i = 0;
        foreach (Catalog::ROOM_CATEGORIES as $slug => $label) {
            $i++;
            DB::table('room_categories')->updateOrInsert(['slug' => $slug], ['label' => $label, 'sort_order' => $i * 10, 'active' => 1]);
        }
        foreach (self::AMENITIES as [$slug, $label, $order]) {
            DB::table('amenities')->updateOrInsert(['slug' => $slug], ['label' => $label, 'icon' => 'check', 'sort_order' => $order, 'active' => 1]);
        }
        foreach (self::LOCATIONS as [$city, $name]) {
            DB::table('locations')->updateOrInsert(['city' => $city, 'name' => $name], ['active' => 1, 'created_at' => now()]);
        }
        self::seedServices();
    }

    /** Transfer & tour price list (services table). */
    public static function seedServices(): void
    {
        foreach (self::SERVICES as [$kind, $name, $description, $city, $duration, $prices, $order]) {
            DB::table('services')->updateOrInsert(
                ['name' => $name, 'kind' => $kind],
                array_merge([
                    'description' => $description, 'city' => $city, 'duration' => $duration,
                    'sort_order' => $order, 'active' => 1, 'created_at' => now(),
                ], array_map(fn ($v) => (string) $v, [
                    'shared_oneway_price' => $prices['sharedOneWayPrice'] ?? 0,
                    'shared_twoway_price' => $prices['sharedTwoWayPrice'] ?? 0,
                    'private7_oneway_price' => $prices['private7OneWayPrice'] ?? 0,
                    'private7_twoway_price' => $prices['private7TwoWayPrice'] ?? 0,
                    'private12_oneway_price' => $prices['private12OneWayPrice'] ?? 0,
                    'private12_twoway_price' => $prices['private12TwowayPrice'] ?? 0,
                    'ticket_only_adult' => $prices['ticketOnlyAdult'] ?? 0,
                    'ticket_only_child' => $prices['ticketOnlyChild'] ?? 0,
                    'shared_adult' => $prices['sharedAdult'] ?? 0,
                    'shared_child' => $prices['sharedChild'] ?? 0,
                    'private_adult' => $prices['privateAdult'] ?? 0,
                    'private_child' => $prices['privateChild'] ?? 0,
                ])),
            );
        }
    }

    /** Illustrative hotels, contacts, rooms, contracted rates and stop-sales. */
    public static function runExampleHotels(): void
    {
        if (DB::table('hotels')->count() > 0) return;
        $year = (int) now()->format('Y');

        foreach (self::HOTELS as $row) {
            [$name, $city, $address, $stars, $code, $email, $phone, $checkIn, $checkOut, $tax, $summer, $winter, $group, $amenitySet, $roomSet, $breakfastPerRoom] = $row;

            $groupId = null;
            if ($group) {
                $groupId = DB::table('hotel_groups')->where('name', $group)->value('id');
                if (! $groupId) {
                    $groupId = DB::table('hotel_groups')->insertGetId([
                        'name' => $group, 'website' => '', 'notes' => '', 'active' => 1,
                    ]);
                }
            }
            $locationId = DB::table('locations')->where('city', $city)->value('id');

            $hotelId = DB::table('hotels')->insertGetId([
                'name' => $name, 'city' => $city, 'location_id' => $locationId, 'country' => 'United Arab Emirates',
                'address' => $address, 'star_rating' => $stars, 'supplier_code' => $code, 'group_id' => $groupId,
                'business_type' => $stars >= 5 ? 'Hotel / Resort' : 'Hotel', 'website' => '',
                'contracts_folder_link' => self::DRIVE, 'media_link' => '', 'contact_email' => $email, 'contact_phone' => $phone,
                'currency' => 'AED', 'check_in_time' => $checkIn, 'check_out_time' => $checkOut,
                'tourism_tax' => $tax, 'tourism_tax_basis' => 'room_night', 'active' => 1, 'created_at' => now(),
            ]);

            foreach (self::amenitySet($amenitySet) as $slug) {
                $amenityId = DB::table('amenities')->where('slug', $slug)->value('id');
                if ($amenityId) DB::table('hotel_amenities')->insertOrIgnore(['hotel_id' => $hotelId, 'amenity_id' => $amenityId]);
            }

            $contactId = DB::table('hotel_contacts')->insertGetId([
                'hotel_id' => $hotelId, 'group_id' => $groupId, 'name' => 'Sales Desk – '.$name,
                'position' => 'Director of Sales & Marketing', 'email' => $email, 'phone' => preg_replace('/\s/', '', $phone),
                'business_card_link' => '', 'whatsapp' => 1, 'telegram' => 0, 'viber' => 0, 'active' => 1, 'created_at' => now(),
            ]);
            DB::table('hotel_contact_assignments')->insertOrIgnore(['hotel_id' => $hotelId, 'contact_id' => $contactId, 'created_at' => now()]);

            $board = self::BOARD[$stars];
            foreach (self::roomSet($roomSet) as $room) {
                [$roomName, $roomCode, $category, $factor, $inventory] = $room;
                $maxAdults = $category === 'family' ? 4 : ($category === 'triple' ? 3 : ($category === 'villa' ? 4 : 2));
                $base = round($winter * $factor);

                $roomTypeId = DB::table('room_types')->insertGetId([
                    'hotel_id' => $hotelId, 'name' => $roomName, 'code' => $roomCode, 'category' => $category,
                    'description' => Catalog::categoryLabel($category).' – contracted B2B allocation.',
                    'media_link' => '', 'max_adults' => $maxAdults, 'max_children' => 2, 'max_infants' => 1,
                    'included_adults' => 2, 'base_sleeps' => $maxAdults, 'default_inventory' => $inventory,
                    'extra_bed_allowed' => 1, 'active' => 1, 'created_at' => now(),
                ]);

                DB::table('occupancy_rules')->insert([
                    ['room_type_id' => $roomTypeId, 'adults' => 2, 'children' => 0, 'infants' => 1, 'extra_beds' => 0, 'label' => '2 adults'],
                    ['room_type_id' => $roomTypeId, 'adults' => 2, 'children' => 2, 'infants' => 1, 'extra_beds' => 1, 'label' => '2 adults + 2 children'],
                    ['room_type_id' => $roomTypeId, 'adults' => $maxAdults, 'children' => 1, 'infants' => 1, 'extra_beds' => 1, 'label' => $maxAdults.' adults + 1 child'],
                ]);

                DB::table('room_bedding')->insert([
                    ['room_type_id' => $roomTypeId, 'kind' => 'extra_bed', 'label' => 'Extra bed', 'max_per_room' => 1, 'free' => 0, 'rate_per_night' => $board['extraBed'], 'per_stay' => 0, 'sort_order' => 10],
                    ['room_type_id' => $roomTypeId, 'kind' => 'sofa_bed', 'label' => 'Sofa bed', 'max_per_room' => 1, 'free' => 0, 'rate_per_night' => round($board['extraBed'] * 0.8), 'per_stay' => 0, 'sort_order' => 20],
                    ['room_type_id' => $roomTypeId, 'kind' => 'baby_cot', 'label' => 'Baby cot', 'max_per_room' => 1, 'free' => 1, 'rate_per_night' => 0, 'per_stay' => 0, 'sort_order' => 30],
                ]);

                foreach (self::seasons($year, $summer, $winter) as [$seasonName, $from, $to, $rate]) {
                    foreach (['room_only', 'breakfast', 'half_board', 'full_board'] as $boardType) {
                        $supplement = match ($boardType) {
                            'half_board' => $board['hb'],
                            'full_board' => $board['fb'],
                            default => 0,
                        };
                        DB::table('rate_periods')->insert([
                            'hotel_id' => $hotelId, 'room_type_id' => $roomTypeId,
                            'name' => "$seasonName $year – ".Catalog::categoryLabel($category),
                            'board_type' => $boardType,
                            'valid_from' => $from, 'valid_to' => $to,
                            'market' => 'all', 'market_exclusions' => '', 'promo_code' => '',
                            'base_rate' => round($rate * $factor), 'rate_basis' => 'room_night',
                            'board_adult_supplement' => $supplement, 'board_child_supplement' => $breakfastPerRoom ? 0 : round($supplement * 0.5),
                            'board_supplement_basis' => $breakfastPerRoom ? 'room_night' : 'person_night',
                            'extra_adult_rate' => $board['extraAdult'], 'extra_child_rate' => $board['extraChild'],
                            'extra_bed_rate' => $board['extraBed'], 'extra_bed_basis' => 'bed_night',
                            'minimum_nights' => $seasonName === 'Festive Peak' ? 4 : 1, 'active' => 1, 'created_at' => now(),
                        ]);
                    }
                }
            }
        }

        // One illustrative stop-sale so closures are visible in the search panel.
        $hotelId = DB::table('hotels')->where('supplier_code', 'JBH-DXB')->value('id');
        if ($hotelId) {
            DB::table('blackout_dates')->insert([
                'hotel_id' => $hotelId, 'room_type_id' => null,
                'start_date' => now()->addDays(20)->toDateString(), 'end_date' => now()->addDays(24)->toDateString(),
                'reason' => 'Sold out by hotel – New Year gala period', 'created_at' => now(),
            ]);
        }
    }

    private static function amenitySet(string $key): array
    {
        return match ($key) {
            'BEACH_RESORT' => self::BEACH_RESORT,
            'POOL_GYM' => self::POOL_GYM,
            default => self::CITY_FULL,
        };
    }

    private static function roomSet(string $kind): array
    {
        return match ($kind) {
            'three' => [
                ['Deluxe King Room', 'DLX-KING', 'deluxe_king', 1, 10],
                ['Triple Room', 'TRIPLE', 'triple', 1.18, 6],
                ['Family Room', 'FAMILY', 'family', 1.4, 4],
            ],
            'four' => [
                ['Deluxe King Room', 'DLX-KING', 'deluxe_king', 1, 8],
                ['Triple Room', 'TRIPLE', 'triple', 1.15, 5],
                ['Junior Suite', 'JR-SUITE', 'suite', 1.7, 3],
            ],
            default => [
                ['Deluxe King Room', 'DLX-KING', 'deluxe_king', 1, 6],
                ['Deluxe Twin Room', 'DLX-TWIN', 'deluxe_twin', 1.05, 5],
                ['Family Room', 'FAMILY', 'family', 1.45, 3],
                ['One Bedroom Suite', 'ONE-SUITE', 'suite', 2, 3],
            ],
        };
    }

    /** Low summer, high winter and a short festive peak – the shortest period wins per night. */
    private static function seasons(int $year, float $summer, float $winter): array
    {
        return [
            ['Summer Low', "$year-05-01", "$year-09-30", $summer],
            ['Winter High', "$year-11-01", "$year-12-20", $winter],
            ['Festive Peak', "$year-12-21", "$year-12-31", $winter * 1.45],
            ['Shoulder', "$year-04-01", "$year-04-30", ($summer + $winter) / 2],
            ['Shoulder', "$year-10-01", "$year-10-31", ($summer + $winter) / 2],
            ['Winter High', ($year + 1).'-01-01', ($year + 1).'-03-31', $winter],
        ];
    }
}
