<?php

namespace App\Support;

/**
 * Fixed catalogues ported from src/lib/search-engine.ts (ROOM_CATEGORIES,
 * BOARD_TYPES, MARKETS, BEDDING_KINDS, SORT_OPTIONS).
 */
class Catalog
{
    public const ROOM_CATEGORIES = [
        'deluxe_king' => 'Deluxe King',
        'deluxe_twin' => 'Deluxe Twin',
        'standard' => 'Standard / Superior',
        'triple' => 'Triple Room',
        'family' => 'Family Room',
        'suite' => 'Suite',
        'villa' => 'Villa',
    ];

    /** value => [label, short] */
    public const BOARD_TYPES = [
        'room_only' => ['Room only', 'RO'],
        'breakfast' => ['Bed & breakfast', 'BB'],
        'half_board' => ['Half board', 'HB'],
        'full_board' => ['Full board', 'FB'],
    ];

    public const MARKETS = [
        'all' => 'All markets',
        'uae' => 'UAE (domestic)',
        'gcc' => 'GCC',
        'europe' => 'Europe',
        'uk' => 'United Kingdom',
        'asia' => 'Asia',
        'india' => 'India & subcontinent',
        'africa' => 'Africa',
        'americas' => 'Americas',
        'cis' => 'CIS & Russia',
    ];

    /** value => [label, hint] */
    public const BEDDING_KINDS = [
        'extra_bed' => ['Extra bed', 'Rollaway / additional bed'],
        'sofa_bed' => ['Sofa bed', 'Pull-out sofa bed'],
        'baby_cot' => ['Baby cot', 'Often free of charge'],
    ];

    public const SORT_OPTIONS = [
        'price_asc' => 'Price: lowest first',
        'price_desc' => 'Price: highest first',
        'stars_desc' => 'Star rating',
        'name_asc' => 'Hotel name (A–Z)',
    ];

    public const RATE_BASES = ['room_night' => 'Per room / night', 'person_night' => 'Per person / night'];
    public const TAX_BASES = ['room_night' => 'Per room / night', 'person_night' => 'Per person / night', 'per_stay' => 'Once per stay'];
    public const STATUSES = ['draft', 'sent', 'confirmed', 'cancelled', 'completed', 'on_hold'];

    public static function label(string $value): ?string
    {
        foreach ([self::ROOM_CATEGORIES, self::MARKETS, self::SORT_OPTIONS, self::RATE_BASES, self::TAX_BASES] as $map) {
            if (isset($map[$value])) return $map[$value];
        }
        foreach ([self::BOARD_TYPES, self::BEDDING_KINDS] as $map) {
            if (isset($map[$value])) return $map[$value][0];
        }
        return null;
    }

    public static function boardLabel(string $v): string { return self::BOARD_TYPES[$v][0] ?? Fmt::label($v); }
    public static function boardShort(string $v): string { return self::BOARD_TYPES[$v][1] ?? strtoupper(substr($v, 0, 2)); }
    public static function categoryLabel(string $v): string { return self::ROOM_CATEGORIES[$v] ?? Fmt::label($v); }
    public static function marketLabel(string $v): string { return self::MARKETS[$v] ?? Fmt::label($v); }
    public static function beddingLabel(string $v): string { return self::BEDDING_KINDS[$v][0] ?? Fmt::label($v); }

    public static function slugify(string $value): string
    {
        $s = strtolower(trim($value));
        $s = preg_replace('/[^a-z0-9]+/', '_', $s) ?? '';
        return substr(trim($s, '_'), 0, 48);
    }

    /** wa.me / t.me / viber deep link built from a stored phone number. */
    public static function messagingLink(string $kind, string $phone): string
    {
        $digits = preg_replace('/\D/', '', $phone) ?? '';
        if ($digits === '') return '';
        return match ($kind) {
            'whatsapp' => 'https://wa.me/'.$digits,
            'telegram' => 'https://t.me/+'.$digits,
            'viber' => 'viber://chat?number=%2B'.$digits,
            default => '',
        };
    }
}
