<?php

namespace App\Support;

use App\Models\User;

/**
 * Permission catalogue ported 1:1 from src/lib/auth.ts of the Next.js source.
 * Administrators always pass; other roles need the explicit permission.
 */
class Perm
{
    public const ALL = [
        'manage_hotels' => ['label' => 'Hotels, contacts & groups', 'description' => 'Create or update hotels, locations, amenities and contacts'],
        'manage_rates' => ['label' => 'Contracts, rates & closures', 'description' => 'Room types, seasonal rates, markets and stop-sales'],
        'manage_bookings' => ['label' => 'Bookings', 'description' => 'Confirm hotel stays and convert quotations to bookings'],
        'manage_quotations' => ['label' => 'Quotations', 'description' => 'Create, price, change and delete hotel quotations'],
        'manage_services' => ['label' => 'Services & tours', 'description' => 'Maintain internal transfer and tour price lists'],
        'manage_packages' => ['label' => 'Trip packages', 'description' => 'Create and manage trip itineraries and prices'],
        'send_email' => ['label' => 'Send proposal emails', 'description' => 'Email customer-facing PDFs via the configured SMTP server'],
        'manage_users' => ['label' => 'Users & permissions', 'description' => 'Create, disable and assign permissions to users'],
    ];

    public const ROLES = [
        'admin' => 'Administrator',
        'manager' => 'Contract manager',
        'sales' => 'Sales agent',
        'viewer' => 'Read only',
    ];

    public static function keys(): array { return array_keys(self::ALL); }

    public static function defaults(string $role): array
    {
        return match ($role) {
            'admin' => self::keys(),
            'manager' => array_values(array_diff(self::keys(), ['manage_users'])),
            'sales' => ['manage_bookings', 'manage_quotations', 'manage_packages', 'send_email'],
            default => [],
        };
    }

    /** Drops anything that is not a known permission key (mirrors normalizePermissions). */
    public static function normalize(mixed $value): array
    {
        $list = is_array($value) ? $value : (json_decode((string) $value, true) ?: []);
        return array_values(array_unique(array_filter(array_map('strval', $list), fn ($p) => array_key_exists($p, self::ALL))));
    }

    public static function allows(?User $user, string $permission): bool
    {
        if (! $user || ! $user->active) return false;
        if ($user->role === 'admin') return true;
        return in_array($permission, $user->permissions(), true);
    }

    /** Accepts a comma separated list – passes when the user holds any of them. */
    public static function allowsAny(?User $user, string $permissions): bool
    {
        foreach (array_filter(array_map('trim', explode(',', $permissions))) as $p) {
            if (self::allows($user, $p)) return true;
        }
        return false;
    }

    public static function roleName(?string $role): string { return self::ROLES[$role] ?? ucfirst((string) $role); }
}
