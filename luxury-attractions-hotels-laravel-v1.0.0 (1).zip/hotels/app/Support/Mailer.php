<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

/**
 * Password recovery + proposal emailing.
 * Replaces src/lib/smtp.ts (Nodemailer) with the Laravel mailer configured by the installer.
 */
class Mailer
{
    public static function configured(): bool
    {
        return config('mail.mailers.smtp.host') && config('mail.mailers.smtp.username')
            && config('mail.default') === 'smtp';
    }

    public static function unavailableMessage(): string
    {
        return 'SMTP is not configured on this server yet, so email cannot be sent. '
            .'Add MAIL_HOST / MAIL_PORT / MAIL_USERNAME / MAIL_PASSWORD in .env (or re-run the installer) '
            .'and set MAIL_MAILER=smtp. Download and Share keep working meanwhile.';
    }

    /** Sends a customer-facing PDF proposal as a real attachment (src/lib/share-pdf.ts + proposals/email). */
    public static function sendProposal(string $to, string $subject, string $body, ?string $pdfPath, string $filename, array $cc = []): bool
    {
        if (! self::configured()) throw new \RuntimeException(self::unavailableMessage());
        if (! filter_var($to, FILTER_VALIDATE_EMAIL)) throw new \RuntimeException('That recipient email address is not valid.');

        Mail::raw($body, function ($mail) use ($to, $subject, $pdfPath, $filename, $cc) {
            $mail->to($to)
                ->from(config('mail.from.address'), config('mail.from.name'))
                ->subject($subject);
            foreach (array_filter($cc) as $c) {
                if (filter_var($c, FILTER_VALIDATE_EMAIL)) $mail->cc($c);
            }
            if ($pdfPath && file_exists($pdfPath)) $mail->attach($pdfPath, ['as' => $filename, 'mime' => 'application/pdf']);
        });
        return true;
    }

    /** One-time password recovery link; only the SHA-256 hash is stored (as in the Node build). */
    public static function sendResetLink(\App\Models\User $user): string
    {
        $raw = bin2hex(random_bytes(32));
        DB::table('password_reset_tokens')->where('user_id', $user->id)->whereNull('consumed_at')->delete();
        DB::table('password_reset_tokens')->insert([
            'user_id' => $user->id,
            'token_hash' => hash('sha256', $raw),
            'expires_at' => now()->addMinutes(30),
            'created_at' => now(),
        ]);
        $link = rtrim((string) config('app.url'), '/').'/reset-password?token='.$raw;
        $body = "Hello {$user->name},\n\n"
            ."A password reset was requested for your Luxury Attractions Hotels account.\n"
            ."Open this link within 30 minutes to choose a new password:\n\n$link\n\n"
            ."If you did not ask for this, ignore this email – your password stays the same.\n";
        if (self::configured()) {
            Mail::raw($body, fn ($m) => $m->to($user->email)
                ->from(config('mail.from.address'), config('mail.from.name'))
                ->subject('Reset your Luxury Attractions Hotels password'));
        } else {
            // Without SMTP the link is written to the log so an administrator can pass it on.
            \Illuminate\Support\Facades\Log::warning('Password reset link (SMTP not configured): '.$link);
        }
        return $link;
    }
}
