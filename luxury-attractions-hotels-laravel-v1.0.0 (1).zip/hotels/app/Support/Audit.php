<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/** Append-only audit trail (the Next.js build had none – added for the Laravel port). */
class Audit
{
    public static function log(string $entity, ?int $entityId, string $action, array $payload = [], ?int $userId = null): void
    {
        try {
            DB::table('audit_logs')->insert([
                'entity' => $entity,
                'entity_id' => $entityId,
                'action' => $action,
                'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'user_id' => $userId ?? auth()->id(),
                'ip' => request()?->ip(),
                'created_at' => now(),
            ]);
        } catch (\Throwable) {
            // Auditing must never break a business action.
        }
    }

    public static function recent(int $limit = 200)
    {
        return DB::table('audit_logs')
            ->leftJoin('users', 'users.id', '=', 'audit_logs.user_id')
            ->orderByDesc('audit_logs.id')
            ->limit($limit)
            ->get(['audit_logs.*', 'users.name as user_name', 'users.username']);
    }
}
