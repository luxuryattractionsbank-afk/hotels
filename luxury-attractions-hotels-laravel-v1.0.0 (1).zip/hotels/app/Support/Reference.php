<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/** Human readable document references, e.g. LA-Q-2026-0007 / LA-B-2026-0004 / LA-P-2026-0002. */
class Reference
{
    public static function next(string $table, string $letter): string
    {
        $year = (int) now()->format('Y');
        $prefix = "LA-$letter-$year-";
        $last = DB::table($table)->where('reference', 'like', $prefix.'%')->orderByDesc('reference')->value('reference');
        $n = $last ? ((int) substr($last, strlen($prefix))) + 1 : 1;
        return $prefix.str_pad((string) $n, 4, '0', STR_PAD_LEFT);
    }

    public static function quotation(): string { return self::next('quotations', 'Q'); }
    public static function booking(): string { return self::next('bookings', 'B'); }
    public static function tripPackage(): string { return self::next('trip_packages', 'P'); }
}
