<?php

namespace App\Support;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * Availability & pricing engine – a line-by-line PHP port of
 * src/lib/search-engine.ts from luxury-attractions-hotels-source.zip.
 *
 * Same rules as the Node version:
 *  • a night needs a contract covering it, an open booking window and a sellable market
 *  • the shortest (most specific) rate period wins, ties broken by the newest row
 *  • guests are split across rooms, occupancy rules and bedding capacity are enforced
 *  • blackouts, contracted inventory and minimum stays exclude a room with a reason
 *  • tourism tax is charged per room/night, per person/night or once per stay
 */
class Pricing
{
    public static function money(float $v): float { return round($v + 0.0, 2); }
    public static function num($v): float { return is_numeric($v) ? (float) $v : 0.0; }

    public static function addDays(string $date, int $days): string
    {
        return Carbon::parse($date)->addDays($days)->toDateString();
    }

    public static function daysBetween(string $start, string $end): int
    {
        return (int) Carbon::parse($start)->diffInDays(Carbon::parse($end));
    }

    /** Every night of a stay: check-in inclusive, check-out exclusive. */
    public static function eachNight(string $checkIn, string $checkOut): array
    {
        $out = [];
        $n = self::daysBetween($checkIn, $checkOut);
        for ($i = 0; $i < $n; $i++) {
            $out[] = self::addDays($checkIn, $i);
        }
        return $out;
    }

    public static function todayIso(): string { return now()->toDateString(); }

    public static function rateAppliesToMarket(string $rateMarket, string $exclusions, string $selected): bool
    {
        if ($selected === 'all') return true;
        $excluded = array_filter(array_map(fn ($m) => strtolower(trim($m)), explode(',', (string) $exclusions)));
        if (in_array($selected, $excluded, true)) return false;
        return $rateMarket === 'all' || $rateMarket === $selected;
    }

    public static function withinBookingWindow(?string $start, ?string $end, string $bookingDate): bool
    {
        if ($start && $bookingDate < $start) return false;
        if ($end && $bookingDate > $end) return false;
        return true;
    }

    public static function validateCore(array $c): ?string
    {
        $iso = fn ($v) => is_string($v) && (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $v);
        if (! $iso($c['checkIn'] ?? null) || ! $iso($c['checkOut'] ?? null)) return 'Enter valid check-in and check-out dates.';
        if ($c['checkOut'] <= $c['checkIn']) return 'Check-out must be after check-in.';
        if (($c['adults'] ?? 0) < 1) return 'At least one adult is required.';
        if (($c['rooms'] ?? 1) < 1) return 'At least one room is required.';
        if (self::daysBetween($c['checkIn'], $c['checkOut']) > 60) return 'Stays longer than 60 nights are not supported.';
        return null;
    }

    /** Splits guests across rooms exactly like allocateGuests() in the Node engine. */
    public static function allocateGuests(int $adults, int $children, int $infants, int $rooms): array
    {
        $allocation = array_map(fn () => ['adults' => 0, 'children' => 0, 'infants' => 0], array_fill(0, $rooms, null));
        for ($i = 0; $i < $adults; $i++) { $allocation[$i % $rooms]['adults']++; }
        for ($i = 0; $i < $children; $i++) { $allocation[$rooms - 1 - ($i % $rooms)]['children']++; }
        for ($i = 0; $i < $infants; $i++) { $allocation[$rooms - 1 - ($i % $rooms)]['infants']++; }
        return $allocation;
    }

    public static function describeGuests(array $g): string
    {
        $parts = [$g['adults'].' adult'.($g['adults'] === 1 ? '' : 's')];
        if ($g['children']) $parts[] = $g['children'].' child'.($g['children'] === 1 ? '' : 'ren');
        if ($g['infants']) $parts[] = $g['infants'].' infant'.($g['infants'] === 1 ? '' : 's');
        return implode(' + ', $parts);
    }

    /** @param array $room EngineRoom @param array $rules EngineOccupancy[] */
    public static function matchOccupancy(array $room, array $rules, array $guests): array
    {
        if ($guests['adults'] > $room['maxAdults']) return ['ok' => false, 'reason' => "Max {$room['maxAdults']} adults per room"];
        if ($guests['children'] > $room['maxChildren']) {
            return ['ok' => false, 'reason' => $room['maxChildren'] ? "Max {$room['maxChildren']} children per room" : 'Children not accepted in this room'];
        }
        if ($guests['infants'] > $room['maxInfants']) {
            return ['ok' => false, 'reason' => $room['maxInfants'] ? "Max {$room['maxInfants']} infants per room" : 'Infants not accepted in this room'];
        }

        $roomRules = array_values(array_filter($rules, fn ($r) => (int) $r['roomTypeId'] === (int) $room['id']));
        if ($roomRules === []) return ['ok' => true, 'rule' => self::describeGuests($guests)];

        $matches = array_values(array_filter(
            $roomRules,
            fn ($r) => $guests['adults'] <= (int) $r['adults'] && $guests['children'] <= (int) $r['children'] && $guests['infants'] <= (int) $r['infants'],
        ));
        usort($matches, fn ($a, $b) => ((int) $a['extraBeds'] <=> (int) $b['extraBeds'])
            ?: (($a['adults'] + $a['children']) <=> ($b['adults'] + $b['children'])));

        if ($matches === []) {
            $allowed = implode(', ', array_map(fn ($r) => $r['label'], $roomRules));
            return ['ok' => false, 'reason' => self::describeGuests($guests)." is not a permitted occupancy (allowed: $allowed)"];
        }
        return ['ok' => true, 'rule' => $matches[0]['label'] ?: self::describeGuests($guests)];
    }

    /** Works out bedding needed in one room; auto-adds beds when guests exceed baseSleeps. */
    public static function assignBedding(array $room, array $bedding, array $guests, array $requested): array
    {
        $options = array_values(array_filter($bedding, fn ($b) => (int) $b['roomTypeId'] === (int) $room['id']));
        $option = fn (string $kind) => current(array_filter($options, fn ($b) => $b['kind'] === $kind)) ?: null;
        $capacity = fn (string $kind) => (int) ($option($kind)['maxPerRoom'] ?? 0);

        if ($requested['extraBeds'] > $capacity('extra_bed')) {
            return ['ok' => false, 'reason' => $capacity('extra_bed') === 0 ? 'This room does not allow extra beds' : "Max {$capacity('extra_bed')} extra bed(s) per room"];
        }
        if ($requested['sofaBeds'] > $capacity('sofa_bed')) {
            return ['ok' => false, 'reason' => $capacity('sofa_bed') === 0 ? 'This room has no sofa bed' : "Max {$capacity('sofa_bed')} sofa bed(s) per room"];
        }
        if ($requested['babyCots'] > $capacity('baby_cot')) {
            return ['ok' => false, 'reason' => $capacity('baby_cot') === 0 ? 'This room has no baby cot' : "Max {$capacity('baby_cot')} baby cot(s) per room"];
        }

        $counts = ['extra_bed' => (int) $requested['extraBeds'], 'sofa_bed' => (int) $requested['sofaBeds'], 'baby_cot' => (int) $requested['babyCots']];
        $bedsNeeded = max(0, $guests['adults'] + $guests['children'] - (int) $room['baseSleeps']);
        $bedSlots = $capacity('extra_bed') + $capacity('sofa_bed');

        if ($bedsNeeded > $bedSlots) {
            return ['ok' => false, 'reason' => "Sleeps {$room['baseSleeps']} without extra bedding — $bedsNeeded extra bed(s) needed but only $bedSlots allowed"];
        }

        $deficit = max(0, $bedsNeeded - $counts['extra_bed'] - $counts['sofa_bed']);
        foreach (['extra_bed', 'sofa_bed'] as $kind) {
            if ($deficit <= 0) break;
            $add = min($deficit, $capacity($kind) - $counts[$kind]);
            $counts[$kind] += $add;
            $deficit -= $add;
        }
        if ($deficit > 0) return ['ok' => false, 'reason' => 'Not enough extra bedding for '.($guests['adults'] + $guests['children']).' guests'];

        $used = [];
        foreach (['extra_bed', 'sofa_bed', 'baby_cot'] as $kind) {
            if ($counts[$kind] <= 0) continue;
            $cfg = $option($kind);
            if (! $cfg) continue;
            $used[] = [
                'kind' => $kind,
                'label' => $cfg['label'],
                'count' => $counts[$kind],
                'free' => (bool) $cfg['free'],
                'ratePerNight' => self::num($cfg['ratePerNight']),
                'perStay' => (bool) $cfg['perStay'],
            ];
        }
        return ['ok' => true, 'bedding' => $used];
    }

    /** Extra-bed cost for one night in one room; the seasonal contract rate wins. */
    private static function beddingAmountForNight(array $bedding, float $seasonalExtraBedRate): float
    {
        $total = 0.0;
        foreach ($bedding as $item) {
            if ($item['free']) continue;
            $rate = ($item['kind'] === 'extra_bed' && $seasonalExtraBedRate > 0) ? $seasonalExtraBedRate : $item['ratePerNight'];
            $total += $item['count'] * $rate;
        }
        return $total;
    }

    /** The contract that applies to one night. Shorter (more specific) periods win. */
    public static function pickRate(array $rates, int $roomTypeId, string $boardType, string $date, string $bookingDate, string $market): ?array
    {
        $eligible = array_values(array_filter($rates, fn ($r) => (bool) $r['active']
            && (int) $r['roomTypeId'] === $roomTypeId
            && $r['boardType'] === $boardType
            && $r['validFrom'] <= $date && $r['validTo'] >= $date
            && self::withinBookingWindow($r['bookingWindowStart'] ?? null, $r['bookingWindowEnd'] ?? null, $bookingDate)
            && self::rateAppliesToMarket((string) $r['market'], (string) ($r['marketExclusions'] ?? ''), $market)));

        if ($eligible === []) return null;
        usort($eligible, fn ($a, $b) => (self::daysBetween($a['validFrom'], $a['validTo']) <=> self::daysBetween($b['validFrom'], $b['validTo']))
            ?: ((int) $b['id'] <=> (int) $a['id']));
        return $eligible[0];
    }

    private static function priceOffer(array $hotel, array $room, array $rates, string $boardType, array $nights, array $allocation, string $bookingDate, string $market): array
    {
        $lines = [];
        $rateNames = [];
        $promoCodes = [];
        $primaryRatePeriodId = 0;
        $minimumNights = 1;

        foreach ($nights as $index => $date) {
            $rate = self::pickRate($rates, (int) $room['id'], $boardType, $date, $bookingDate, $market);
            if (! $rate) return ['kind' => 'no_rate', 'reason' => 'No '.strtolower(Catalog::boardLabel($boardType))." contract for $date"];
            if (! $primaryRatePeriodId) $primaryRatePeriodId = (int) $rate['id'];
            if (! in_array($rate['name'], $rateNames, true)) $rateNames[] = $rate['name'];
            if ($rate['promoCode'] && ! in_array($rate['promoCode'], $promoCodes, true)) $promoCodes[] = $rate['promoCode'];
            $minimumNights = max($minimumNights, (int) $rate['minimumNights']);

            $roomAmount = $boardAmount = $supplementAmount = $extraBedAmount = 0.0;
            foreach ($allocation as $guests) {
                $perPerson = $rate['rateBasis'] === 'person_night';
                $base = self::num($rate['baseRate']);
                $roomAmount += $perPerson ? $base * ($guests['adults'] + $guests['children']) : $base;

                $boardAmount += $rate['boardSupplementBasis'] === 'room_night'
                    ? self::num($rate['boardAdultSupplement'])
                    : self::num($rate['boardAdultSupplement']) * $guests['adults'] + self::num($rate['boardChildSupplement']) * $guests['children'];

                if (! $perPerson) {
                    $supplementAmount += max(0, $guests['adults'] - (int) $room['includedAdults']) * self::num($rate['extraAdultRate']);
                    $supplementAmount += $guests['children'] * self::num($rate['extraChildRate']);
                }

                $perNight = array_values(array_filter($guests['bedding'], fn ($b) => ! $b['perStay']));
                $perStay = array_values(array_filter($guests['bedding'], fn ($b) => $b['perStay']));
                $extraBedAmount += self::beddingAmountForNight($perNight, self::num($rate['extraBedRate']));
                if ($index === 0) $extraBedAmount += self::beddingAmountForNight($perStay, self::num($rate['extraBedRate']));
            }

            $lines[] = [
                'date' => $date,
                'rateName' => $rate['name'],
                'roomAmount' => self::money($roomAmount),
                'boardAmount' => self::money($boardAmount),
                'supplementAmount' => self::money($supplementAmount),
                'extraBedAmount' => self::money($extraBedAmount),
                'total' => self::money($roomAmount + $boardAmount + $supplementAmount + $extraBedAmount),
            ];
        }

        if (count($nights) < $minimumNights) {
            return ['kind' => 'min_stay', 'reason' => "Minimum stay of $minimumNights nights applies to these dates"];
        }

        $rooms = count($allocation);
        $payingGuests = array_sum(array_map(fn ($g) => $g['adults'] + $g['children'], $allocation));
        $tax = self::num($hotel['tourismTax']);
        $tourismTaxAmount = match ($hotel['tourismTaxBasis']) {
            'person_night' => $tax * $payingGuests * count($nights),
            'per_stay' => $tax * $rooms,
            default => $tax * $rooms * count($nights),
        };

        $sum = fn (string $key) => self::money(array_sum(array_map(fn ($l) => $l[$key], $lines)));
        $stayExTax = $sum('total');
        $totalAmount = self::money($stayExTax + $tourismTaxAmount);
        $countBed = fn (string $kind) => array_sum(array_map(
            fn ($g) => current(array_filter($g['bedding'], fn ($b) => $b['kind'] === $kind))['count'] ?? 0,
            $allocation,
        ));

        return ['offer' => [
            'boardType' => $boardType,
            'rateNames' => $rateNames,
            'promoCodes' => $promoCodes,
            'primaryRatePeriodId' => $primaryRatePeriodId,
            'minimumNights' => $minimumNights,
            'nights' => count($nights),
            'rooms' => $rooms,
            'extraBeds' => $countBed('extra_bed'),
            'sofaBeds' => $countBed('sofa_bed'),
            'babyCots' => $countBed('baby_cot'),
            'bedding' => array_merge(...array_map(fn ($g) => $g['bedding'], $allocation) ?: [[]]),
            'baseAmount' => $sum('roomAmount'),
            'boardAmount' => $sum('boardAmount'),
            'occupancyAmount' => $sum('supplementAmount'),
            'extraBedAmount' => $sum('extraBedAmount'),
            'tourismTaxAmount' => self::money($tourismTaxAmount),
            'totalAmount' => $totalAmount,
            'avgNightlyPerRoom' => self::money($stayExTax / max(1, count($nights)) / max(1, $rooms)),
            'avgNightlyPerRoomInclTax' => self::money($totalAmount / max(1, count($nights)) / max(1, $rooms)),
            'nightly' => $lines,
        ]];
    }

    /** Loads everything the engine needs in a handful of queries (was 8 queries in Node too). */
    public static function context(): array
    {
        $locations = DB::table('locations')->pluck('name', 'id');
        $hotels = DB::table('hotels')->get()->map(function ($h) use ($locations) {
            return [
                'id' => (int) $h->id, 'name' => $h->name, 'city' => $h->city,
                'location' => $h->location_id ? ($locations[$h->location_id] ?? '') : '',
                'address' => $h->address, 'starRating' => (int) $h->star_rating, 'currency' => $h->currency,
                'checkInTime' => $h->check_in_time, 'checkOutTime' => $h->check_out_time,
                'tourismTax' => $h->tourism_tax, 'tourismTaxBasis' => $h->tourism_tax_basis,
                'amenities' => DB::table('hotel_amenities')->join('amenities', 'amenities.id', '=', 'hotel_amenities.amenity_id')
                    ->where('hotel_amenities.hotel_id', $h->id)->orderBy('amenities.sort_order')->pluck('amenities.label')->all(),
                'active' => (bool) $h->active,
            ];
        })->all();

        $rooms = DB::table('room_types')->get()->map(fn ($r) => [
            'id' => (int) $r->id, 'hotelId' => (int) $r->hotel_id, 'name' => $r->name, 'code' => $r->code,
            'category' => $r->category, 'description' => (string) $r->description, 'mediaLink' => $r->media_link,
            'maxAdults' => (int) $r->max_adults, 'maxChildren' => (int) $r->max_children, 'maxInfants' => (int) $r->max_infants,
            'includedAdults' => (int) $r->included_adults, 'baseSleeps' => (int) $r->base_sleeps,
            'defaultInventory' => (int) $r->default_inventory, 'extraBedAllowed' => (bool) $r->extra_bed_allowed,
            'active' => (bool) $r->active,
        ])->all();

        $rates = DB::table('rate_periods')->get()->map(fn ($r) => [
            'id' => (int) $r->id, 'hotelId' => (int) $r->hotel_id, 'roomTypeId' => (int) $r->room_type_id,
            'name' => $r->name, 'boardType' => $r->board_type,
            'validFrom' => (string) $r->valid_from, 'validTo' => (string) $r->valid_to,
            'bookingWindowStart' => $r->booking_window_start ? (string) $r->booking_window_start : null,
            'bookingWindowEnd' => $r->booking_window_end ? (string) $r->booking_window_end : null,
            'market' => $r->market, 'marketExclusions' => $r->market_exclusions, 'promoCode' => $r->promo_code,
            'baseRate' => $r->base_rate, 'rateBasis' => $r->rate_basis,
            'boardAdultSupplement' => $r->board_adult_supplement, 'boardChildSupplement' => $r->board_child_supplement,
            'boardSupplementBasis' => $r->board_supplement_basis,
            'extraAdultRate' => $r->extra_adult_rate, 'extraChildRate' => $r->extra_child_rate,
            'extraBedRate' => $r->extra_bed_rate, 'extraBedBasis' => $r->extra_bed_basis,
            'minimumNights' => (int) $r->minimum_nights, 'active' => (bool) $r->active,
        ])->all();

        return [
            'hotels' => $hotels,
            'rooms' => $rooms,
            'rates' => $rates,
            'occupancies' => DB::table('occupancy_rules')->get()->map(fn ($o) => [
                'id' => (int) $o->id, 'roomTypeId' => (int) $o->room_type_id, 'adults' => (int) $o->adults,
                'children' => (int) $o->children, 'infants' => (int) $o->infants, 'extraBeds' => (int) $o->extra_beds,
                'label' => $o->label,
            ])->all(),
            'bedding' => DB::table('room_bedding')->get()->map(fn ($b) => [
                'roomTypeId' => (int) $b->room_type_id, 'kind' => $b->kind, 'label' => $b->label,
                'maxPerRoom' => (int) $b->max_per_room, 'free' => (bool) $b->free,
                'ratePerNight' => $b->rate_per_night, 'perStay' => (bool) $b->per_stay,
            ])->all(),
            'blackouts' => DB::table('blackout_dates')->get()->map(fn ($b) => [
                'hotelId' => (int) $b->hotel_id, 'roomTypeId' => $b->room_type_id ? (int) $b->room_type_id : null,
                'startDate' => (string) $b->start_date, 'endDate' => (string) $b->end_date, 'reason' => $b->reason,
            ])->all(),
            'bookings' => DB::table('bookings')->where('status', '!=', 'cancelled')->get()->map(fn ($b) => [
                'roomTypeId' => (int) $b->room_type_id, 'checkIn' => (string) $b->check_in,
                'checkOut' => (string) $b->check_out, 'rooms' => (int) $b->rooms, 'status' => $b->status,
            ])->all(),
        ];
    }

    /** Checks every contracted hotel & room for the requested stay. */
    public static function evaluateAvailability(array $context, array $criteria): array
    {
        $error = self::validateCore($criteria);
        if ($error) return ['error' => $error, 'nights' => 0, 'checkedHotels' => 0, 'checkedRooms' => 0, 'results' => [], 'excluded' => []];

        $nights = self::eachNight($criteria['checkIn'], $criteria['checkOut']);
        $lastNight = $nights[count($nights) - 1];
        $rooms = max(1, (int) $criteria['rooms']);
        $baseAllocation = self::allocateGuests((int) $criteria['adults'], (int) ($criteria['children'] ?? 0), (int) ($criteria['infants'] ?? 0), $rooms);
        $hotelsById = [];
        foreach ($context['hotels'] as $h) { $hotelsById[$h['id']] = $h; }

        $candidates = array_values(array_filter($context['rooms'], function ($room) use ($hotelsById, $criteria) {
            $hotel = $hotelsById[$room['hotelId']] ?? null;
            return $room['active'] && $hotel && $hotel['active']
                && (($criteria['category'] ?? 'any') === 'any' || empty($criteria['category']) || $room['category'] === $criteria['category'])
                && (empty($criteria['hotelId']) || (int) $room['hotelId'] === (int) $criteria['hotelId'])
                && (empty($criteria['roomTypeId']) || (int) $room['id'] === (int) $criteria['roomTypeId']);
        }));

        $results = [];
        $excluded = [];

        foreach ($candidates as $room) {
            $hotel = $hotelsById[$room['hotelId']];
            $key = $hotel['id'].'-'.$room['id'];
            $exclude = function (string $kind, string $reason) use (&$excluded, $key, $hotel, $room) {
                $excluded[] = ['key' => $key, 'hotelId' => $hotel['id'], 'hotelName' => $hotel['name'], 'city' => $hotel['city'],
                    'starRating' => $hotel['starRating'], 'roomName' => $room['name'], 'kind' => $kind, 'reason' => $reason];
            };

            $allocation = [];
            $occupancyError = '';
            foreach ($baseAllocation as $guests) {
                $match = self::matchOccupancy($room, $context['occupancies'], $guests);
                if (! $match['ok']) { $occupancyError = $match['reason']; break; }
                $bedding = self::assignBedding($room, $context['bedding'], $guests, [
                    'extraBeds' => (int) round(((int) ($criteria['extraBeds'] ?? 0)) / $rooms),
                    'sofaBeds' => (int) round(((int) ($criteria['sofaBeds'] ?? 0)) / $rooms),
                    'babyCots' => (int) round(((int) ($criteria['babyCots'] ?? 0)) / $rooms),
                ]);
                if (! $bedding['ok']) { $occupancyError = $bedding['reason']; break; }
                $allocation[] = $guests + ['bedding' => $bedding['bedding'], 'rule' => $match['rule']];
            }
            if ($occupancyError) { $exclude('occupancy', $occupancyError); continue; }

            $closure = null;
            foreach ($context['blackouts'] as $item) {
                if ((int) $item['hotelId'] === (int) $hotel['id']
                    && ($item['roomTypeId'] === null || (int) $item['roomTypeId'] === (int) $room['id'])
                    && $item['startDate'] <= $lastNight && $item['endDate'] >= $criteria['checkIn']) {
                    $closure = $item;
                    break;
                }
            }
            if ($closure) {
                $exclude('blackout', "Fully booked / stop sale {$closure['startDate']} → {$closure['endDate']}: {$closure['reason']}");
                continue;
            }

            $activeBookings = array_values(array_filter($context['bookings'], fn ($b) => (int) $b['roomTypeId'] === (int) $room['id'] && $b['status'] !== 'cancelled'));
            $peakBooked = 0;
            foreach ($nights as $date) {
                $booked = 0;
                foreach ($activeBookings as $b) {
                    if ($b['checkIn'] <= $date && $b['checkOut'] > $date) $booked += $b['rooms'];
                }
                $peakBooked = max($peakBooked, $booked);
            }
            $roomsLeft = (int) $room['defaultInventory'] - $peakBooked;
            if ($roomsLeft < $rooms) {
                $exclude('sold_out', $roomsLeft <= 0 ? 'Contracted allocation fully used for these dates' : "Only $roomsLeft contracted room(s) left");
                continue;
            }

            $boards = array_values(array_filter(
                array_keys(Catalog::BOARD_TYPES),
                fn ($board) => (bool) array_filter($context['rates'], fn ($r) => (int) $r['roomTypeId'] === (int) $room['id'] && $r['boardType'] === $board),
            ));

            $offers = [];
            $failures = [];
            foreach ($boards as $board) {
                $priced = self::priceOffer($hotel, $room, $context['rates'], $board, $nights, $allocation, $criteria['bookingDate'] ?? self::todayIso(), $criteria['market'] ?? 'all');
                if (isset($priced['offer'])) $offers[] = $priced['offer'];
                else $failures[] = $priced;
            }
            if ($offers === []) {
                $minStay = null;
                foreach ($failures as $f) { if ($f['kind'] === 'min_stay') { $minStay = $f; break; } }
                $exclude($minStay ? 'min_stay' : 'no_rate', $minStay['reason'] ?? ($failures[0]['reason'] ?? 'No contracted rate covers every night of this stay'));
                continue;
            }
            usort($offers, fn ($a, $b) => $a['totalAmount'] <=> $b['totalAmount']);

            $results[] = [
                'key' => $key,
                'hotel' => $hotel,
                'room' => $room + ['bedding' => array_values(array_filter($context['bedding'], fn ($b) => (int) $b['roomTypeId'] === (int) $room['id']))],
                'roomsLeft' => $roomsLeft,
                'allocation' => $allocation,
                'offers' => $offers,
                'best' => $offers[0],
            ];
        }

        $hotelIds = array_unique(array_map(fn ($r) => $r['hotelId'], $candidates));

        return [
            'error' => null,
            'nights' => count($nights),
            'checkedHotels' => count($hotelIds),
            'checkedRooms' => count($candidates),
            'results' => $results,
            'excluded' => $excluded,
        ];
    }

    public static function comparableRate(array $offer, string $basis): float
    {
        return $basis === 'incl_tax' ? (float) $offer['avgNightlyPerRoomInclTax'] : (float) $offer['avgNightlyPerRoom'];
    }

    /** Board, price range, location, amenity filtering and sorting (applyFilters port). */
    public static function applyFilters(array $results, array $filters): array
    {
        $query = strtolower(trim((string) ($filters['query'] ?? '')));
        $min = isset($filters['maxPrice']) && $filters['maxPrice'] !== '' ? null : null;
        $priceMin = ($filters['priceMin'] ?? '') !== '' ? (float) $filters['priceMin'] : null;
        $priceMax = ($filters['priceMax'] ?? '') !== '' ? (float) $filters['priceMax'] : null;
        unset($min);
        $basis = $filters['rateBasis'] ?? 'excl_tax';
        $out = [];
        $outsidePriceRange = 0;

        foreach ($results as $r) {
            $best = $r['best'];
            if (! empty($filters['boardTypes']) && ! in_array($best['boardType'], (array) $filters['boardTypes'], true)) continue;
            if (! empty($filters['cities']) && ! in_array($r['hotel']['city'], (array) $filters['cities'], true)) continue;
            if (! empty($filters['locations']) && ! in_array($r['hotel']['location'], (array) $filters['locations'], true)) continue;
            if (! empty($filters['minStars']) && $r['hotel']['starRating'] < (int) $filters['minStars']) continue;
            if (! empty($filters['amenities'])) {
                foreach ((array) $filters['amenities'] as $a) {
                    if (! in_array($a, $r['hotel']['amenities'] ?? [], true)) continue 2;
                }
            }
            $comparable = self::comparableRate($best, $basis);
            if ($priceMin !== null && $comparable < $priceMin) { $outsidePriceRange++; continue; }
            if ($priceMax !== null && $comparable > $priceMax) { $outsidePriceRange++; continue; }
            if ($query !== '') {
                $hay = strtolower($r['hotel']['name'].' '.$r['hotel']['city'].' '.$r['hotel']['location'].' '.$r['room']['name']);
                if (! str_contains($hay, $query)) continue;
            }
            $out[] = $r;
        }

        usort($out, match ($filters['sort'] ?? 'price_asc') {
            'price_desc' => fn ($a, $b) => self::comparableRate($b['best'], $basis) <=> self::comparableRate($a['best'], $basis),
            'stars_desc' => fn ($a, $b) => ($b['hotel']['starRating'] <=> $a['hotel']['starRating']) ?: strcmp($a['hotel']['name'], $b['hotel']['name']),
            'name_asc' => fn ($a, $b) => strcmp($a['hotel']['name'], $b['hotel']['name']),
            default => fn ($a, $b) => self::comparableRate($a['best'], $basis) <=> self::comparableRate($b['best'], $basis),
        });

        return ['results' => $out, 'outsidePriceRange' => $outsidePriceRange];
    }
}
