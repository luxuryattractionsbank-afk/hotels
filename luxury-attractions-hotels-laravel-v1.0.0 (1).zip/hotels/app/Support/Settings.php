<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/** Company & branding settings, stored in MySQL instead of .env so staff can edit them. */
class Settings
{
    private static array $cache = [];

    public static function all(string $group): array
    {
        if (isset(self::$cache[$group])) return self::$cache[$group];
        try {
            $rows = DB::table('settings')->where('group', $group)->get(['key', 'value']);
        } catch (\Throwable) {
            return self::$cache[$group] = [];
        }
        return self::$cache[$group] = $rows->pluck('value', 'key')->all();
    }

    public static function get(string $group, string $key, $default = null)
    {
        return self::all($group)[$key] ?? $default;
    }

    public static function save(string $group, array $values): void
    {
        foreach ($values as $k => $v) {
            DB::table('settings')->updateOrInsert(
                ['group' => $group, 'key' => $k],
                ['value' => is_array($v) ? json_encode($v) : (string) $v, 'updated_at' => now(), 'created_at' => now()],
            );
        }
        unset(self::$cache[$group]);
    }

    public static function flush(): void { self::$cache = []; }

    public static function company(string $key, $default = '')
    {
        return self::get('company', $key) ?: $default;
    }
}
