<?php

use App\Http\Controllers as C;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web routes – hotels.luxuryattractions.com
|--------------------------------------------------------------------------
| Every Next.js API route from the source archive has a Laravel equivalent.
| Writes are guarded with the `perm:` middleware so authorization is always
| re-checked server side (hiding a button in Blade is not authorization).
*/

// ---- Browser installer (open before anything else) ----
Route::get('/install', [C\InstallController::class, 'show']);
Route::post('/install/test', [C\InstallController::class, 'test']);
Route::post('/install', [C\InstallController::class, 'install']);

// ---- Public ----
Route::get('/', fn () => redirect()->route('dashboard'));
Route::get('/login', [C\AuthController::class, 'show'])->name('login');
Route::post('/login', [C\AuthController::class, 'login'])->middleware('throttle:10,1');
Route::post('/logout', [C\AuthController::class, 'logout'])->name('logout');
Route::get('/forgot-password', fn () => view('auth.forgot'));
Route::post('/forgot-password', [C\AuthController::class, 'forgot'])->middleware('throttle:5,60');
Route::get('/reset-password', [C\AuthController::class, 'showReset']);
Route::post('/reset-password', [C\AuthController::class, 'reset'])->middleware('throttle:5,60');
Route::get('/health', fn () => response()->json([
    'status' => 'ok',
    'app' => config('app.name'),
    'version' => trim((string) @file_get_contents(base_path('VERSION'))),
    'installed' => \App\Support\Installer::installed(),
    'time' => now()->toIso8601String(),
]));

Route::middleware('auth')->group(function () {
    // ---- Overview ----
    Route::get('/dashboard', [C\DashboardController::class, 'index'])->name('dashboard');

    // ---- Availability & rate search (api/search) ----
    Route::get('/search', [C\SearchController::class, 'index'])->name('search');
    Route::post('/search', [C\SearchController::class, 'index']);
    Route::get('/api/search', [C\SearchController::class, 'api']);

    // ---- Hotels, contacts & lookups (manage_hotels) ----
    Route::get('/hotels', [C\HotelController::class, 'index'])->name('hotels');
    Route::get('/hotels/new', [C\HotelController::class, 'edit'])->middleware('perm:manage_hotels');
    Route::get('/hotels/{id}/edit', [C\HotelController::class, 'edit'])->middleware('perm:manage_hotels');
    Route::post('/hotels/{id?}', [C\HotelController::class, 'save'])->middleware('perm:manage_hotels');
    Route::get('/hotels/{id}', [C\HotelController::class, 'show'])->name('hotels.show');
    Route::get('/contacts', [C\HotelController::class, 'contacts'])->name('contacts');
    Route::post('/contacts/{id?}', [C\HotelController::class, 'saveContact'])->middleware('perm:manage_hotels');
    Route::get('/lookups', [C\HotelController::class, 'lookups'])->name('lookups');
    Route::post('/lookups/{kind}', [C\HotelController::class, 'saveLookup'])->middleware('perm:manage_hotels');

    // ---- Contracts, rooms, rates, closures (manage_rates) ----
    Route::get('/contracts/rooms', [C\ContractController::class, 'rooms'])->name('rooms');
    Route::post('/contracts/rooms/{id?}', [C\ContractController::class, 'saveRoom'])->middleware('perm:manage_rates');
    Route::post('/contracts/rooms/{id}/duplicate', [C\ContractController::class, 'duplicateRoom'])->middleware('perm:manage_rates');
    Route::get('/contracts/rates', [C\ContractController::class, 'rates'])->name('rates');
    Route::post('/contracts/rates/{id?}', [C\ContractController::class, 'saveRate'])->middleware('perm:manage_rates');
    Route::get('/contracts/blackouts', [C\ContractController::class, 'blackouts'])->name('blackouts');
    Route::post('/contracts/blackouts', [C\ContractController::class, 'saveBlackout'])->middleware('perm:manage_rates');
    Route::post('/contracts/blackouts/{id}/delete', [C\ContractController::class, 'deleteBlackout'])->middleware('perm:manage_rates');

    // ---- Quotations (manage_quotations) ----
    Route::get('/quotations', [C\QuotationController::class, 'index'])->name('quotations');
    Route::get('/quotations/new', [C\QuotationController::class, 'create'])->middleware('perm:manage_quotations');
    Route::get('/quotations/{id}/edit', [C\QuotationController::class, 'edit'])->middleware('perm:manage_quotations');
    Route::post('/quotations/{id?}', [C\QuotationController::class, 'store'])->middleware('perm:manage_quotations');
    Route::get('/quotations/{id}', [C\QuotationController::class, 'show'])->name('quotations.show');
    Route::post('/quotations/{id}/convert', [C\QuotationController::class, 'convert'])->middleware('perm:manage_bookings');
    Route::post('/quotations/{id}/delete', [C\QuotationController::class, 'destroy'])->middleware('perm:manage_quotations');

    // ---- Bookings (manage_bookings) ----
    Route::get('/bookings', [C\BookingController::class, 'index'])->name('bookings');
    Route::get('/bookings/new', [C\BookingController::class, 'create'])->middleware('perm:manage_bookings');
    Route::post('/bookings', [C\BookingController::class, 'store'])->middleware('perm:manage_bookings');
    Route::get('/bookings/{id}', [C\BookingController::class, 'show'])->name('bookings.show');
    Route::post('/bookings/{id}/status', [C\BookingController::class, 'status'])->middleware('perm:manage_bookings');
    Route::post('/bookings/{id}/delete', [C\BookingController::class, 'destroy'])->middleware('perm:manage_bookings');

    // ---- Services & tours (manage_services) ----
    Route::get('/services', [C\ServiceController::class, 'index'])->name('services');
    Route::post('/services/{id?}', [C\ServiceController::class, 'save'])->middleware('perm:manage_services');
    Route::post('/services/{id}/delete', [C\ServiceController::class, 'destroy'])->middleware('perm:manage_services');
    Route::post('/api/services/price', [C\ServiceController::class, 'price']);

    // ---- Trip packages (manage_packages) ----
    Route::get('/packages', [C\TripPackageController::class, 'index'])->name('packages');
    Route::get('/packages/new', [C\TripPackageController::class, 'edit'])->middleware('perm:manage_packages');
    Route::get('/packages/{id}/edit', [C\TripPackageController::class, 'edit'])->middleware('perm:manage_packages');
    Route::post('/packages/{id?}', [C\TripPackageController::class, 'save'])->middleware('perm:manage_packages');
    Route::get('/packages/{id}', [C\TripPackageController::class, 'show'])->name('packages.show');
    Route::post('/packages/{id}/delete', [C\TripPackageController::class, 'destroy'])->middleware('perm:manage_packages');

    // ---- PDFs & proposal email (send_email) ----
    Route::get('/quotations/{id}/pdf', [C\PdfController::class, 'quotation'])->name('quotations.pdf');
    Route::get('/packages/{id}/pdf', [C\PdfController::class, 'tripPackage'])->name('packages.pdf');
    Route::get('/bookings/{id}/pdf', [C\PdfController::class, 'booking'])->name('bookings.pdf');
    Route::post('/proposals/email', [C\PdfController::class, 'email'])->middleware('perm:send_email');

    // ---- Users & permissions (manage_users) ----
    Route::get('/users', [C\UserController::class, 'index'])->middleware('perm:manage_users')->name('users');
    Route::get('/users/new', fn () => app(C\UserController::class)->edit(0))->middleware('perm:manage_users');
    Route::get('/users/{id}/edit', [C\UserController::class, 'edit'])->middleware('perm:manage_users');
    Route::post('/users/{id?}', [C\UserController::class, 'save'])->middleware('perm:manage_users');
    Route::post('/users/{id}/toggle', [C\UserController::class, 'toggle'])->middleware('perm:manage_users');
    Route::post('/users/{id}/send-reset', [C\UserController::class, 'sendReset'])->middleware('perm:manage_users');
    Route::get('/profile', [C\UserController::class, 'profile'])->name('profile');
    Route::post('/profile', [C\UserController::class, 'saveProfile']);

    // ---- Company settings & audit ----
    Route::get('/settings', [C\SettingsController::class, 'index'])->middleware('perm:manage_users')->name('settings');
    Route::post('/settings', [C\SettingsController::class, 'save'])->middleware('perm:manage_users');
    Route::get('/audit', [C\SettingsController::class, 'audit'])->middleware('perm:manage_users')->name('audit');
});
