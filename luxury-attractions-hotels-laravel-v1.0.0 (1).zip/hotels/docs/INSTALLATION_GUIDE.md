# Installation guide – Luxury Attractions Hotels (Laravel + MySQL)

Target: **`hotels.luxuryattractions.com`** on cPanel / LiteSpeed shared hosting.
No SSH, no Composer and no npm are needed on the server – the published zip already contains
`vendor/` (after you run `composer install` once locally) and the compiled CSS.

The installer works exactly like WordPress: **unzip → open the site in a browser → enter database
details → create the administrator → done.**

---

## 1 · Requirements

| Item | Needed |
|---|---|
| PHP | **8.2 or newer** (8.3 recommended) |
| PHP extensions | `pdo_mysql`, `mbstring`, `openssl`, `dom`/`xml`, `curl`, `gd`, `fileinfo`, `zip` |
| MySQL / MariaDB | MySQL 5.7.8+ / MariaDB 10.3+ / MySQL 8.x |
| Web server | Apache with `mod_rewrite` (cPanel default) or LiteSpeed |
| Writable | `.env`, `storage/`, `bootstrap/cache/` |

cPanel → **Select PHP Version** lets you switch the PHP version and tick the extensions above.

## 2 · Create the subdomain and the database

1. cPanel → **Domains** (or **Subdomains**) → create `hotels.luxuryattractions.com`.
2. Set its **document root** to `hotels/public` if you can (best). If your host only allows
   `hotels/`, that also works – the shipped root `.htaccess` forwards everything into `public/`
   and blocks direct access to `.env`, `app/`, `vendor/` and `storage/`.
3. cPanel → **MySQL® Databases**:
   * create a database, e.g. `myuser_hotels`
   * create a user, e.g. `myuser_hotels`, with a strong password
   * **add the user to the database with ALL PRIVILEGES**
4. Note the four values – cPanel always prefixes names with the account username.

## 3 · Upload and unzip

1. Upload `luxury-attractions-hotels-laravel-v1.0.0.zip` to the subdomain folder in **File Manager**.
2. Right-click → **Extract**. You should end up with `artisan`, `app/`, `public/`, `routes/`, … in the
   subdomain folder (move the files up one level if the zip created a nested folder).
3. If you did **not** ship `vendor/` in the zip, run once on your own machine and upload the folder:
   ```bash
   composer install --no-dev --optimize-autoloader
   ```
4. Permissions: folders `755`, files `644`; `storage/` and `bootstrap/cache/` must be writable by PHP
   (`775` is usually enough on cPanel).

## 4 · Run the browser installer

Open **https://hotels.luxuryattractions.com/install**

* **Step 1 – Server check.** Every line must show ✓. Anything marked ✕ tells you exactly what to fix
  (PHP version, a missing extension, or an unwritable folder).
* **Step 2 – MySQL database.** Enter host (`localhost` on cPanel), port (`3306`), database name,
  username and password, then press **Test connection**. The app reports the MySQL/MariaDB version and
  how many tables already exist. Nothing is written until the test passes.
* **Step 3 – Company, administrator & email.** Company details printed on proposals, the first
  administrator (name, registered email, username, password), optional SMTP for proposal emails and
  password recovery, and two options: install the illustrative hotel catalogue and create a demo
  sales agent.

Press **Install now**. The installer then:

1. writes `.env` with your database credentials, a fresh `APP_KEY`, `APP_URL` and the SMTP settings;
2. creates **26 business tables** (32 in total including Laravel's cache, queue and migration tables) with `php artisan migrate --force` (run from PHP – no shell needed);
3. seeds the lookups (markets, room categories, amenities, areas) and, if selected, 14 illustrative
   hotels with rooms, occupancy rules, bedding, seasonal contracts and one stop-sale;
4. creates your administrator with all eight permissions;
5. writes `storage/installed.lock` and clears the config/route/view caches.

You are redirected to `/login`. Sign in with the username and password you chose.

## 5 · After installation (recommended)

* **HTTPS.** cPanel → SSL/TLS Status → run AutoSSL for the subdomain, then enable
  “Force HTTPS redirect”. The app already forces `https://` URLs when `APP_ENV=production`.
* **SMTP.** Add real credentials in `.env` (`MAIL_MAILER=smtp`, `MAIL_HOST`, `MAIL_PORT=587`,
  `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM_ADDRESS`). Port 587 = STARTTLS, port 465 = TLS.
  Without SMTP, PDF download/share still works and administrators can reset staff passwords manually.
* **`APP_URL`.** Confirm it is `https://hotels.luxuryattractions.com` so emailed recovery links and
  proposals point at the right origin.
* **Backups.** Back up the MySQL database (cPanel → Backup) and `storage/` regularly.
* **Delete the demo data.** The illustrative hotels, contacts, rates, Drive links and service prices
  are **examples only** – replace them with your real contracted supplier data before selling.

## 6 · Staff accounts & permissions

Roles: **Administrator**, **Contract manager**, **Sales agent**, **Read only**.
Eight permissions can be fine-tuned per account: hotels/contacts/groups, contracts/rates/closures,
bookings, quotations, services & tours, trip packages, proposal email and user management.

* Every write route re-checks the permission in middleware – hiding a button is not authorization.
* Changing a password or a permission set invalidates earlier sessions (`users.session_version`).
* Deactivated accounts cannot sign in; the last active administrator can never be demoted or disabled.
* Six failed sign-ins lock an account for 15 minutes.
* **Forgot password?** sends a single-use link to the registered email only, expiring after 30 minutes;
  just the SHA-256 hash is stored, limited to 3 requests per hour and never more than one per minute.
  The response never reveals whether the account exists.

## 7 · Re-running the installer / moving servers

* To run the installer again: delete `storage/installed.lock`. Existing tables and data are **not**
  deleted – `migrate` only adds what is missing and the seeder skips hotels if any exist.
* Moving to another host: copy the files, export/import the MySQL database, then open `/install`,
  enter the new database credentials and press **Test connection** → **Install now**. Your data stays.

## 8 · Trouble shooting

| Symptom | Fix |
|---|---|
| “Access denied for user” | The MySQL user is not added to that database, or the password is wrong. |
| “Unknown database” | Use the full cPanel name, e.g. `myuser_hotels`, not just `hotels`. |
| Blank page / 500 | Check `storage/logs/laravel.log`; usually a permission problem on `storage/` or `bootstrap/cache/`. |
| CSS looks unstyled | Upload `public/css/app.css` (it is compiled and included in the zip). |
| Routes 404 except `/` | `mod_rewrite` off, or `.htaccess` not uploaded (enable “show hidden files”). |
| PDF download fails | Install/enable the `gd` and `dom` PHP extensions for dompdf. |
| Emails not arriving | Set `MAIL_MAILER=smtp` with real credentials; check `storage/logs/laravel.log`. |

## 9 · Command line (optional)

If you do have SSH access:

```bash
php artisan migrate --force      # create/upgrade tables
php artisan config:cache && php artisan route:cache && php artisan view:cache
php artisan key:generate         # only if .env has no APP_KEY
```
