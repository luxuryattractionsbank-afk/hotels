<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title', 'Dashboard') – {{ $companyName ?? 'Luxury Attractions Hotels' }}</title>
<link rel="stylesheet" href="{{ asset('css/app.css') }}">
<script src="{{ asset('js/alpine.min.js') }}" defer></script>
</head>
<body class="min-h-screen bg-slate-100 text-slate-900" x-data="{ nav: false }">
<header class="no-print sticky top-0 z-30 border-b border-navy-700 bg-navy-900 text-white">
  <div class="mx-auto flex max-w-[1400px] flex-wrap items-center gap-3 px-4 py-3">
    <a href="/dashboard" class="flex items-center gap-2 font-bold">
      <span class="grid h-9 w-9 place-items-center rounded-lg bg-gold-500 text-sm font-black text-navy-900">LA</span>
      <span class="leading-tight">Hotels<span class="block text-[11px] font-normal text-gold-400">Contracts · Rates · Proposals</span></span>
    </a>
    <button class="ml-auto rounded-lg border border-navy-700 px-3 py-2 text-sm lg:hidden" @click="nav = !nav">Menu</button>
    <nav class="w-full flex-wrap gap-1 text-sm lg:flex lg:w-auto lg:items-center" :class="nav ? 'flex' : 'hidden'">
      @foreach ([
        ['Search rates', '/search'], ['Hotels', '/hotels'], ['Contacts', '/contacts'],
        ['Rooms', '/contracts/rooms'], ['Contracts', '/contracts/rates'], ['Closures', '/contracts/blackouts'],
        ['Quotations', '/quotations'], ['Bookings', '/bookings'], ['Services', '/services'],
        ['Trip packages', '/packages'], ['Lookups', '/lookups'],
      ] as [$label, $href])
        <a href="{{ $href }}" class="rounded-lg px-3 py-2 hover:bg-navy-700 {{ request()->is(ltrim($href, '/')) ? 'bg-navy-700 text-gold-400' : '' }}">{{ $label }}</a>
      @endforeach
      @if(can('manage_users'))
        <a href="/users" class="rounded-lg px-3 py-2 hover:bg-navy-700 {{ request()->is('users*') ? 'bg-navy-700 text-gold-400' : '' }}">Users</a>
        <a href="/settings" class="rounded-lg px-3 py-2 hover:bg-navy-700 {{ request()->is('settings*') ? 'bg-navy-700 text-gold-400' : '' }}">Settings</a>
      @endif
      <div class="ml-auto flex items-center gap-2 lg:pl-4">
        <a href="/profile" class="hidden text-xs text-gold-400 sm:block">{{ auth()->user()->name ?: auth()->user()->username }}</a>
        <form method="post" action="/logout">@csrf<button class="btn btn-sm btn-outline">Sign out</button></form>
      </div>
    </nav>
  </div>
</header>
<main class="mx-auto max-w-[1400px] space-y-4 px-4 py-6">
  @if(session('ok'))<div class="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">{{ session('ok') }}</div>@endif
  @if(session('error'))<div class="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{{ session('error') }}</div>@endif
  @if($errors->any())<div class="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
  @yield('content')
</main>
<footer class="no-print mx-auto max-w-[1400px] px-4 pb-8 text-xs text-slate-500">
  {{ $companyName ?? 'Luxury Attractions' }} · Laravel + MySQL build v{{ trim((string) @file_get_contents(base_path('VERSION'))) }} · Net supplier costs are never shown in client documents.
</footer>
</body>
</html>
