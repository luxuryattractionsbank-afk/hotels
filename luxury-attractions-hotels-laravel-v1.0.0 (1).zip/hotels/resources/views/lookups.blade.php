@extends('layouts.app')
@section('title', 'Lookups')
@section('content')
<div class="grid gap-4 lg:grid-cols-2">
  @foreach ([
    ['group', 'Hotel groups', 'name', $groups, ['name'=>'Name','website'=>'Website']],
    ['location', 'Areas / locations', 'name', $locations, ['city'=>'City','name'=>'Area']],
    ['amenity', 'Amenities', 'label', $amenities, ['label'=>'Label','icon'=>'Icon']],
    ['market', 'Source markets', 'label', $markets, ['label'=>'Label']],
    ['category', 'Room categories', 'label', $categories, ['label'=>'Label']],
  ] as [$kind, $title, $main, $rows, $fields])
  <div class="card">
    <div class="card-title">{{ $title }} ({{ count($rows) }})</div>
    <table class="tbl"><thead><tr>@foreach($fields as $f)<th>{{ ucfirst($f) }}</th>@endforeach<th>Slug</th><th></th></tr></thead>
      <tbody>@foreach($rows as $row)<tr>
        @foreach($fields as $f)<td>{{ $row->$f ?? '' }}</td>@endforeach
        <td class="font-mono text-xs">{{ $row->slug ?? '—' }}</td>
        <td class="text-right">@if(can('manage_hotels'))<button class="btn-sm btn-outline" onclick="document.getElementById('f-{{ $kind }}').scrollIntoView();document.querySelector('#f-{{ $kind }} [name=&quot;{{ $main }}&quot;]').value='{{ addslashes($row->$main) }}';document.querySelector('#f-{{ $kind }} [name=id]').value='{{ $row->id }}'">Edit</button>@endif</td>
      </tr>@endforeach</tbody></table>
    @if(can('manage_hotels'))
    <form id="f-{{ $kind }}" method="post" action="/lookups/{{ $kind }}" class="mt-3 grid gap-2 sm:grid-cols-3">@csrf
      <input type="hidden" name="id" value="">
      @foreach($fields as $f)<input name="{{ $f }}" class="input" placeholder="{{ ucfirst($f) }}">@endforeach
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" checked class="h-4 w-4">Active</label>
      <button class="btn-gold sm:col-span-2">Save {{ rtrim($title, 's') }}</button>
    </form>@endif
  </div>
  @endforeach
</div>
@endsection
