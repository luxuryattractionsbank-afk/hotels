@extends('layouts.app')
@section('title', 'Dashboard')
@section('content')
<div class="grid gap-4 lg:grid-cols-3">
  <div class="card lg:col-span-2">
    <div class="card-title">Contract portfolio</div>
    <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
      @foreach ([['Hotels', $stats['hotels'], '/hotels'], ['Room types', $stats['rooms'], '/contracts/rooms'],
                 ['Live rates', $stats['rates'], '/contracts/rates'], ['Contacts', $stats['contacts'], '/contacts'],
                 ['Services', $stats['services'], '/services'], ['Quotations', $stats['quotations'], '/quotations'],
                 ['Trip packages', $stats['packages'], '/packages']] as [$label, $value, $href])
        <a href="{{ $href }}" class="rounded-xl border border-slate-200 bg-slate-50 p-3 hover:border-navy-700">
          <div class="text-2xl font-bold text-navy-800">{{ $value }}</div><div class="text-xs text-slate-600">{{ $label }}</div></a>
      @endforeach
      <div class="rounded-xl border border-gold-500/40 bg-gold-500/10 p-3">
        <div class="text-2xl font-bold text-navy-800">{{ $permCount }}</div><div class="text-xs text-slate-600">Permissions</div></div>
    </div>
    <div class="mt-4 flex flex-wrap gap-2">
      <a class="btn-primary" href="/search">Search availability &amp; rates</a>
      @if(can('manage_quotations'))<a class="btn-gold" href="/quotations/new">New quotation</a>@endif
      @if(can('manage_bookings'))<a class="btn-outline" href="/bookings/new">New booking</a>@endif
      @if(can('manage_packages'))<a class="btn-outline" href="/packages/new">New trip package</a>@endif
    </div>
  </div>
  <div class="card">
    <div class="card-title">Arrivals in the next 30 days</div>
    @forelse($arrivals as $b)
      <a href="/bookings/{{ $b->id }}" class="block border-b border-slate-100 py-2 text-sm last:border-0 hover:bg-slate-50">
        <div class="font-semibold">{{ $b->guest_name }}</div>
        <div class="text-xs text-slate-600">{{ $b->hotel_name }} · {{ $b->room_name }}</div>
        <div class="text-xs text-slate-500">{{ \App\Support\Fmt::date((string) $b->check_in) }} → {{ \App\Support\Fmt::date((string) $b->check_out) }} · {{ $b->rooms }} room(s) · {!! badge($b->status) !!}</div>
      </a>
    @empty<p class="text-sm text-slate-500">No arrivals yet. Confirm a stay from the search screen.</p>@endforelse
  </div>
</div>

<div class="grid gap-4 lg:grid-cols-3">
  <div class="card">
    <div class="card-title">Contracts expiring within 60 days</div>
    @forelse($expiringRates as $r)
      <div class="flex items-start justify-between gap-2 border-b border-slate-100 py-2 text-sm last:border-0">
        <div><div class="font-medium">{{ $r->hotel_name }}</div><div class="text-xs text-slate-600">{{ $r->name }}</div></div>
        <div class="text-right text-xs"><div class="font-semibold text-amber-700">until {{ \App\Support\Fmt::date((string) $r->valid_to) }}</div>
          <div class="text-slate-500">{{ money($r->base_rate) }}</div></div>
      </div>
    @empty<p class="text-sm text-slate-500">Nothing expiring soon.</p>@endforelse
    @if(can('manage_rates'))<a class="btn-outline btn-sm mt-3" href="/contracts/rates">Renew contracts</a>@endif
  </div>
  <div class="card">
    <div class="card-title">Stop-sales &amp; closures</div>
    @forelse($blackouts as $b)
      <div class="border-b border-slate-100 py-2 text-sm last:border-0">
        <div class="font-medium">{{ $b->hotel_name }}</div>
        <div class="text-xs text-slate-600">{{ \App\Support\Fmt::date((string) $b->start_date) }} → {{ \App\Support\Fmt::date((string) $b->end_date) }}</div>
        <div class="text-xs text-slate-500">{{ $b->reason }}</div>
      </div>
    @empty<p class="text-sm text-slate-500">No closures recorded.</p>@endforelse
  </div>
  <div class="card">
    <div class="card-title">Latest quotations</div>
    @forelse($recentQuotations as $q)
      <a href="/quotations/{{ $q->id }}" class="block border-b border-slate-100 py-2 text-sm last:border-0 hover:bg-slate-50">
        <div class="flex justify-between gap-2"><span class="font-medium">{{ $q->client_name }}</span><span class="text-xs text-slate-500">{{ $q->reference }}</span></div>
        <div class="flex justify-between gap-2 text-xs text-slate-600"><span>{!! badge($q->status) !!}</span><span class="font-semibold">{{ money($q->proposal_total, $q->currency) }}</span></div>
      </a>
    @empty<p class="text-sm text-slate-500">No quotations yet.</p>@endforelse
  </div>
</div>
@endsection
