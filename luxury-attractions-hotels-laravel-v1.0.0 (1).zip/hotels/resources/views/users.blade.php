@extends('layouts.app')
@section('title', 'Users & permissions')
@section('content')
<div class="card">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div class="card-title mb-0">Staff accounts &amp; permissions</div>
    <a class="btn-gold" href="/users/new">Add staff account</a>
  </div>
  <p class="mt-1 text-xs text-slate-500">Administrators always hold all {{ count($permissions) }} permissions. For other roles the checked permissions are enforced server side on every write route.</p>
  <div class="mt-3 overflow-x-auto"><table class="tbl"><thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Permissions</th><th>Status</th><th></th></tr></thead>
    <tbody>@foreach($users as $u)<tr>
      <td class="font-medium">{{ $u->name }}</td><td class="font-mono text-xs">{{ $u->username }}</td><td class="text-xs">{{ $u->email }}</td>
      <td class="text-xs">{{ \App\Support\Perm::roleName($u->role) }}</td>
      <td class="text-xs text-slate-600">{{ $u->role === 'admin' ? 'All' : ($u->permissions() ? implode(', ', array_map(fn($p) => \App\Support\Perm::ALL[$p]['label'] ?? $p, $u->permissions())) : 'Read only') }}</td>
      <td>{!! $u->active ? '<span class="badge bg-emerald-100 text-emerald-800">Active</span>' : '<span class="badge bg-slate-200 text-slate-600">Deactivated</span>' !!}</td>
      <td class="whitespace-nowrap text-right">
        <a class="btn-sm btn-outline" href="/users/{{ $u->id }}/edit">Edit</a>
        <form method="post" action="/users/{{ $u->id }}/toggle" class="inline">@csrf<button class="btn-sm btn-outline">{{ $u->active ? 'Deactivate' : 'Activate' }}</button></form>
        <form method="post" action="/users/{{ $u->id }}/send-reset" class="inline">@csrf<button class="btn-sm btn-outline" title="Send a password recovery email">Send reset</button></form>
      </td></tr>@endforeach</tbody></table></div>
</div>
<div class="card">
  <div class="card-title">Permission catalogue</div>
  <div class="grid gap-2 sm:grid-cols-2">@foreach($permissions as $key => $p)
    <div class="rounded-lg border border-slate-200 p-2 text-sm"><div class="font-medium">{{ $p['label'] }} <span class="font-mono text-xs text-slate-500">{{ $key }}</span></div>
      <div class="text-xs text-slate-600">{{ $p['description'] }}</div></div>@endforeach</div>
</div>
@endsection
