<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Installation – Luxury Attractions Hotels</title><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="min-h-screen bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4 py-10">
<div class="mx-auto max-w-2xl space-y-4">
    <div class="text-center text-white"><div class="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-2xl bg-gold-500 text-2xl font-black text-navy-900">LA</div>
        <h1 class="text-2xl font-bold">Hotels &amp; Contracts – Installation</h1>
        <p class="text-sm text-gold-400">Luxury Attractions · Laravel + MySQL · hotels.luxuryattractions.com</p></div>
    @if(session('error'))<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">{{ session('error') }}</div>@endif
    @if($errors->any())<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif

    <div class="card"><div class="card-title">1 · Server check</div>
        <ul class="space-y-1 text-sm">@foreach($reqs as [$label, $ok, $detail])<li class="flex gap-2"><span class="{{ $ok ? 'text-emerald-600' : 'text-red-600' }}">{{ $ok ? '✓' : '✕' }}</span><span><b>{{ $label }}</b> <span class="text-xs text-slate-500">– {{ $detail }}</span></span></li>@endforeach</ul>
        @if(collect($reqs)->contains(fn ($r) => ! $r[1]))<p class="mt-2 rounded bg-red-50 p-2 text-xs text-red-700">Fix the items marked ✕ (see docs/INSTALLATION_GUIDE.md – usually folder permissions 755 or the PHP version/extensions in cPanel “Select PHP Version”), then reload this page.</p>@endif
    </div>

    <div class="card"><div class="card-title">2 · MySQL database</div>
        <p class="mb-2 text-xs text-slate-600">Create the database and its user in cPanel → <b>MySQL® Databases</b> first, then enter the full names here (for example <code>myuser_hotels</code>).</p>
        @if(session('install_db') && session('ok'))
            <p class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">✓ {{ session('ok') }}</p>
        @elseif(session('install_db'))
            <p class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">✓ Database connection tested ({{ session('install_db')['database'] }}).</p>
        @endif
        <form method="post" action="/install/test" class="mt-3 grid gap-3 sm:grid-cols-2">@csrf
            <label class="block"><span class="lbl">Database host</span><input name="host" value="{{ old('host', session('install_db')['host'] ?? 'localhost') }}" class="input"></label>
            <label class="block"><span class="lbl">Port</span><input name="port" value="{{ old('port', session('install_db')['port'] ?? '3306') }}" class="input"></label>
            <label class="block sm:col-span-2"><span class="lbl">Database name</span><input name="database" value="{{ old('database', session('install_db')['database'] ?? '') }}" placeholder="e.g. myuser_hotels" class="input" required></label>
            <label class="block"><span class="lbl">Database username</span><input name="username" value="{{ old('username', session('install_db')['username'] ?? '') }}" placeholder="e.g. myuser_hotels" class="input" required autocomplete="off"></label>
            <label class="block"><span class="lbl">Database password</span><input name="password" type="password" class="input" autocomplete="new-password"></label>
            <button class="btn-gold sm:col-span-2">{{ session('install_db') ? 'Test again' : 'Test connection' }}</button>
        </form>
    </div>

    @if(session('install_db'))
    <form method="post" action="/install" class="card space-y-3">@csrf
        <div class="card-title">3 · Company, administrator &amp; email</div>
        <div class="grid gap-3 sm:grid-cols-2">
            <label class="block sm:col-span-2"><span class="lbl">Company name</span><input name="company_name" value="{{ old('company_name', 'Luxury Attractions') }}" class="input" required></label>
            <label class="block"><span class="lbl">Company phone</span><input name="company_phone" value="{{ old('company_phone', '+971 52 888 5145') }}" class="input"></label>
            <label class="block"><span class="lbl">Company email</span><input name="company_email" type="email" value="{{ old('company_email', 'hotels@luxuryattractions.com') }}" class="input"></label>
            <label class="block sm:col-span-2"><span class="lbl">Company address</span><input name="company_address" value="{{ old('company_address') }}" class="input"></label>
            <label class="block"><span class="lbl">Default currency</span><select name="currency" class="input">@foreach(['AED','USD','EUR','GBP','SAR'] as $c)<option value="{{ $c }}" {{ old('currency','AED')===$c?'selected':'' }}>{{ $c }}</option>@endforeach</select></label>
            <label class="block"><span class="lbl">Default client markup %</span><input name="default_markup" type="number" step="0.5" min="0" max="400" value="{{ old('default_markup', '15') }}" class="input"></label>
            <label class="block"><span class="lbl">Administrator full name</span><input name="admin_name" value="{{ old('admin_name') }}" class="input" required></label>
            <label class="block"><span class="lbl">Administrator email</span><input name="admin_email" type="email" value="{{ old('admin_email') }}" class="input" required></label>
            <label class="block"><span class="lbl">Admin username</span><input name="admin_username" value="{{ old('admin_username', 'admin') }}" class="input" required></label>
            <span></span>
            <label class="block"><span class="lbl">Admin password (min. 8)</span><input name="admin_password" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
            <label class="block"><span class="lbl">Repeat password</span><input name="admin_password_confirmation" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
        </div>

        <details class="rounded-lg border border-slate-200 p-3 text-sm">
            <summary class="cursor-pointer font-semibold text-slate-700">SMTP for proposal emails &amp; password recovery (optional now)</summary>
            <div class="mt-3 grid gap-3 sm:grid-cols-2">
                <label class="block"><span class="lbl">SMTP host</span><input name="smtp_host" value="{{ old('smtp_host') }}" placeholder="smtp.your-provider.com" class="input"></label>
                <label class="block"><span class="lbl">SMTP port</span><input name="smtp_port" type="number" value="{{ old('smtp_port', '587') }}" class="input"></label>
                <label class="block"><span class="lbl">SMTP username</span><input name="smtp_user" value="{{ old('smtp_user') }}" class="input" autocomplete="off"></label>
                <label class="block"><span class="lbl">SMTP password</span><input name="smtp_password" type="password" class="input" autocomplete="new-password"></label>
                <label class="block sm:col-span-2"><span class="lbl">From address</span><input name="smtp_from" type="email" value="{{ old('smtp_from', 'proposals@luxuryattractions.com') }}" class="input"></label>
            </div>
            <p class="mt-2 text-xs text-slate-500">Port 587 uses STARTTLS, port 465 uses TLS. Leave blank to finish installing now and add SMTP later – download and share of PDF proposals work without it.</p>
        </details>

        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="example_data" value="1" checked class="h-5 w-5"> Add the illustrative hotel, contract &amp; service catalogue (14 hotels – edit or delete later)</label>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="demo_agent" value="1" class="h-5 w-5"> Also create a demo sales agent account (“agent” / agent12345)</label>
        <button class="btn-gold w-full text-base" onclick="this.innerText='Installing – creating 26 MySQL tables (+ Laravel cache/queue tables) (up to 1 minute)…';this.disabled=true;this.form.submit()">Install now</button>
    </form>
    @endif
</div></body></html>
