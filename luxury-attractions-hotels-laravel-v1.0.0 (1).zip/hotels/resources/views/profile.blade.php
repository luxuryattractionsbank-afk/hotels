@extends('layouts.app')
@section('title', 'My profile')
@section('content')
<div class="grid gap-4 lg:grid-cols-2">
  <form method="post" action="/profile" class="card space-y-3">@csrf
    <div class="card-title">My details</div>
    <label class="block"><span class="lbl">Full name</span><input name="name" value="{{ old('name', $user->name) }}" class="input" required></label>
    <label class="block"><span class="lbl">Username</span><input name="username" value="{{ old('username', $user->username) }}" class="input" required pattern="[a-zA-Z0-9._-]{3,60}"></label>
    <p class="text-xs text-slate-500">Role: {{ \App\Support\Perm::roleName($user->role) }} · registered email {{ $user->email }} (an administrator changes it in Users &amp; permissions).</p>
    <button class="btn-gold">Save details</button>
  </form>
  <form method="post" action="/profile" class="card space-y-3">@csrf
    <div class="card-title">Change my password</div>
    <label class="block"><span class="lbl">Current password</span><input name="current_password" type="password" class="input" required autocomplete="current-password"></label>
    <label class="block"><span class="lbl">New password (min. 8)</span><input name="password" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
    <label class="block"><span class="lbl">Repeat new password</span><input name="password_confirmation" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
    <button class="btn-primary">Change password</button>
    <p class="text-xs text-slate-500">Changing your password signs out every other session.</p>
  </form>
</div>
<div class="card">
  <div class="card-title">My permissions</div>
  <div class="flex flex-wrap gap-2">@foreach($user->permissions() as $p)<span class="badge bg-emerald-100 text-emerald-800">{{ \App\Support\Perm::ALL[$p]['label'] ?? $p }}</span>@endforeach
    @if(!$user->permissions())<span class="text-sm text-slate-500">Read only – ask an administrator for access.</span>@endif</div>
</div>
@endsection
