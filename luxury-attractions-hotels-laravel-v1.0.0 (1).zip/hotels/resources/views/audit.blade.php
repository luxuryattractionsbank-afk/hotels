@extends('layouts.app')
@section('title', 'Audit trail')
@section('content')
<div class="card">
  <div class="card-title">Audit trail (latest {{ count($rows) }})</div>
  <div class="overflow-x-auto"><table class="tbl"><thead><tr><th>When</th><th>Who</th><th>Entity</th><th>Action</th><th>Details</th><th>IP</th></tr></thead>
    <tbody>@forelse($rows as $r)<tr>
      <td class="whitespace-nowrap text-xs">{{ \App\Support\Fmt::date((string) $r->created_at, 'd M Y H:i') }}</td>
      <td class="text-xs">{{ $r->user_name ?: 'system' }}@if($r->username) <span class="text-slate-500">({{ $r->username }})</span>@endif</td>
      <td class="text-xs">{{ lbl($r->entity) }}{{ $r->entity_id ? ' #'.$r->entity_id : '' }}</td>
      <td class="text-xs font-medium">{{ lbl($r->action) }}</td>
      <td class="max-w-md truncate text-xs text-slate-500">{{ $r->payload }}</td>
      <td class="text-xs">{{ $r->ip }}</td></tr>
    @empty<tr><td colspan="6" class="py-6 text-center text-slate-500">Nothing logged yet.</td></tr>@endforelse</tbody></table></div>
</div>
@endsection
