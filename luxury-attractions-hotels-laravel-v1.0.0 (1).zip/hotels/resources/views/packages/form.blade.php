@extends('layouts.app')
@section('title', $package ? 'Edit trip package' : 'New trip package')
@section('content')
<form method="post" action="/packages/{{ $package?->id }}" class="space-y-4" x-data="{
  transfers: {{ Js::from($transfers->map(fn($t) => array_intersect_key((array) $t, array_flip(['service_id','mode','direction','vehicle','transfer_date','transfer_time','pickup','dropoff','flight_no','adults','children','vehicles','unit_price','notes'])))->values()->all()) }},
  tours: {{ Js::from($tours->map(fn($t) => array_intersect_key((array) $t, array_flip(['service_id','option_mode','tour_date','tour_time','meeting_point','adults','children','notes'])))->values()->all()) }},
  services: {{ Js::from($services->map(fn($s) => ['id'=>$s->id,'name'=>$s->name,'kind'=>$s->kind])->values()->all()) }}
}">@csrf
  <div class="card">
    <div class="card-title">Client &amp; package</div>
    <div class="grid gap-3 sm:grid-cols-3">
      <label class="block"><span class="lbl">Client name *</span><input name="client_name" value="{{ old('client_name', $package?->client_name) }}" class="input" required></label>
      <label class="block"><span class="lbl">Client email</span><input name="client_email" type="email" value="{{ old('client_email', $package?->client_email) }}" class="input"></label>
      <label class="block"><span class="lbl">Client phone</span><input name="client_phone" value="{{ old('client_phone', $package?->client_phone) }}" class="input"></label>
      <label class="block"><span class="lbl">Hotel quotation (net source)</span><select name="quotation_id" class="input"><option value="">— none —</option>@foreach($quotations as $q)<option value="{{ $q->id }}" {{ (int) old('quotation_id', $package?->quotation_id ?: request('quotation_id')) === (int) $q->id ?'selected':'' }}>{{ $q->reference }} · {{ $q->client_name }} · {{ money($q->proposal_total, $q->currency) }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Market</span><select name="market" class="input">@foreach($markets as $m)<option value="{{ $m->slug }}" {{ old('market', $package?->market ?? 'all')===$m->slug?'selected':'' }}>{{ $m->label }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Status</span><select name="status" class="input">@foreach($statuses as $s)<option value="{{ $s }}" {{ old('status', $package?->status ?? 'draft')===$s?'selected':'' }}>{{ lbl($s) }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Adults *</span><input type="number" min="1" name="adults" value="{{ old('adults', $package?->adults ?? 2) }}" class="input" required></label>
      <label class="block"><span class="lbl">Children</span><input type="number" min="0" name="children" value="{{ old('children', $package?->children ?? 0) }}" class="input"></label>
      <label class="block"><span class="lbl">Infants</span><input type="number" min="0" name="infants" value="{{ old('infants', $package?->infants ?? 0) }}" class="input"></label>
      <label class="block"><span class="lbl">Client markup %</span><input type="number" step="0.5" min="0" max="400" name="markup_percent" value="{{ old('markup_percent', $package?->markup_percent ?? 15) }}" class="input"></label>
      <label class="block"><span class="lbl">Valid until</span><input type="date" name="valid_until" value="{{ old('valid_until', $package?->valid_until ?: now()->addDays(7)->toDateString()) }}" class="input"></label>
      <label class="block"><span class="lbl">Currency</span><input name="currency" value="{{ old('currency', $package?->currency ?? 'AED') }}" class="input" maxlength="8"></label>
    </div>
    <label class="mt-3 block"><span class="lbl">Internal notes (never printed)</span><textarea name="notes" rows="2" class="input">{{ old('notes', $package?->notes) }}</textarea></label>
    <label class="mt-2 flex items-center gap-2 text-sm"><input type="checkbox" name="include_tourism_tax" value="1" {{ old('include_tourism_tax', $package?->include_tourism_tax ?? 1) ? 'checked':'' }} class="h-5 w-5">Hotel tourism tax already included in the quotation net</label>
  </div>

  <div class="card">
    <div class="flex items-center justify-between"><div class="card-title mb-0">Transfers</div>
      <button type="button" class="btn-outline btn-sm" @click="transfers.push({mode:'shared',direction:'oneway',adults:2,children:0,vehicles:1})">+ Add transfer</button></div>
    <template x-for="(t, i) in transfers" :key="i">
      <div class="mt-3 grid gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-4">
        <label class="block sm:col-span-2"><span class="lbl">Service</span><select class="input" x-model="t.service_id" name="transfer[][service_id]"><option value="">—</option><template x-for="s in services.filter(x => x.kind==='transfer')"><option :value="s.id" x-text="s.name"></option></template></select></label>
        <label class="block"><span class="lbl">Date *</span><input type="date" class="input" x-model="t.transfer_date" name="transfer[][transfer_date]"></label>
        <label class="block"><span class="lbl">Time</span><input class="input" x-model="t.transfer_time" name="transfer[][transfer_time]" placeholder="14:30"></label>
        <label class="block"><span class="lbl">Mode</span><select class="input" x-model="t.mode" name="transfer[][mode]"><option value="shared">Shared</option><option value="private7">Private 7-seat</option><option value="private12">Private 12-seat</option></select></label>
        <label class="block"><span class="lbl">Direction</span><select class="input" x-model="t.direction" name="transfer[][direction]"><option value="oneway">One way</option><option value="twoway">Two way</option></select></label>
        <label class="block"><span class="lbl">Pickup</span><input class="input" x-model="t.pickup" name="transfer[][pickup]" placeholder="DXB Terminal 3"></label>
        <label class="block"><span class="lbl">Drop-off</span><input class="input" x-model="t.dropoff" name="transfer[][dropoff]" placeholder="Hotel"></label>
        <label class="block"><span class="lbl">Flight no.</span><input class="input" x-model="t.flight_no" name="transfer[][flight_no]"></label>
        <label class="block"><span class="lbl">Vehicles</span><input type="number" min="1" class="input" x-model="t.vehicles" name="transfer[][vehicles]"></label>
        <label class="block"><span class="lbl">Adults</span><input type="number" min="0" class="input" x-model="t.adults" name="transfer[][adults]"></label>
        <label class="block"><span class="lbl">Children</span><input type="number" min="0" class="input" x-model="t.children" name="transfer[][children]"></label>
        <label class="block"><span class="lbl">Override unit price (net)</span><input type="number" step="0.01" min="0" class="input" x-model="t.unit_price" name="transfer[][unit_price]"></label>
        <label class="block"><span class="lbl">Notes</span><input class="input" x-model="t.notes" name="transfer[][notes]"></label>
        <div class="flex items-end"><button type="button" class="btn-danger btn-sm w-full" @click="transfers.splice(i,1)">Remove</button></div>
      </div>
    </template>
  </div>

  <div class="card">
    <div class="flex items-center justify-between"><div class="card-title mb-0">Tours &amp; tickets</div>
      <button type="button" class="btn-outline btn-sm" @click="tours.push({option_mode:'ticket',adults:2,children:0})">+ Add tour</button></div>
    <template x-for="(t, i) in tours" :key="i">
      <div class="mt-3 grid gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-4">
        <label class="block sm:col-span-2"><span class="lbl">Service</span><select class="input" x-model="t.service_id" name="tour[][service_id]"><option value="">—</option><template x-for="s in services.filter(x => x.kind==='tour')"><option :value="s.id" x-text="s.name"></option></template></select></label>
        <label class="block"><span class="lbl">Date *</span><input type="date" class="input" x-model="t.tour_date" name="tour[][tour_date]"></label>
        <label class="block"><span class="lbl">Time</span><input class="input" x-model="t.tour_time" name="tour[][tour_time]"></label>
        <label class="block"><span class="lbl">Option</span><select class="input" x-model="t.option_mode" name="tour[][option_mode]"><option value="ticket">Ticket only</option><option value="shared">Shared transfers</option><option value="private">Private transfers</option></select></label>
        <label class="block"><span class="lbl">Meeting point</span><input class="input" x-model="t.meeting_point" name="tour[][meeting_point]"></label>
        <label class="block"><span class="lbl">Adults</span><input type="number" min="0" class="input" x-model="t.adults" name="tour[][adults]"></label>
        <label class="block"><span class="lbl">Children</span><input type="number" min="0" class="input" x-model="t.children" name="tour[][children]"></label>
        <div class="flex items-end"><button type="button" class="btn-danger btn-sm w-full" @click="tours.splice(i,1)">Remove</button></div>
      </div>
    </template>
  </div>
  <div class="flex gap-2"><button class="btn-gold">Save trip package</button><a class="btn-outline" href="/packages">Cancel</a></div>
</form>
@endsection
