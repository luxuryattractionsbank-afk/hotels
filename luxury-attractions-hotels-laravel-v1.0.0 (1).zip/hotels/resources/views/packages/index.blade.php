@extends('layouts.app')
@section('title', 'Trip packages')
@section('content')
<div class="card">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div class="card-title mb-0">Trip packages (hotel + transfers + tours)</div>
    @if(can('manage_packages'))<a class="btn-gold" href="/packages/new">New trip package</a>@endif
  </div>
  <form method="get" class="mt-3 flex flex-wrap gap-2">
    <input name="q" value="{{ request('q') }}" class="input sm:max-w-xs" placeholder="Reference or client">
    <select name="status" class="input sm:max-w-40"><option value="">All statuses</option>@foreach($statuses as $s)<option value="{{ $s }}" {{ request('status')===$s?'selected':'' }}>{{ lbl($s) }}</option>@endforeach</select>
    <button class="btn-primary">Filter</button>
  </form>
  <div class="mt-4 overflow-x-auto"><table class="tbl"><thead><tr><th>Reference</th><th>Client</th><th>Guests</th><th class="text-right">Hotels net</th><th class="text-right">Transfers</th><th class="text-right">Tours</th><th class="text-right">Markup</th><th class="text-right">Client total</th><th>Status</th><th></th></tr></thead>
    <tbody>@forelse($packages as $p)<tr>
      <td class="font-mono text-xs"><a class="text-navy-700 underline" href="/packages/{{ $p->id }}">{{ $p->reference }}</a></td>
      <td>{{ $p->client_name }}<div class="text-xs text-slate-500">{{ $p->client_email }}</div></td>
      <td class="text-xs">{{ $p->adults }}A / {{ $p->children }}C / {{ $p->infants }}I</td>
      <td class="text-right text-xs">{{ money($p->hotels_net, $p->currency) }}</td>
      <td class="text-right text-xs">{{ money($p->transfers_net, $p->currency) }}</td>
      <td class="text-right text-xs">{{ money($p->tours_net, $p->currency) }}</td>
      <td class="text-right text-xs">{{ $p->markup_percent }}% · {{ money($p->markup_amount, $p->currency) }}</td>
      <td class="text-right font-semibold">{{ money($p->proposal_total, $p->currency) }}</td><td>{!! badge($p->status) !!}</td>
      <td class="text-right whitespace-nowrap"><a class="btn-sm btn-outline" href="/packages/{{ $p->id }}/pdf">PDF</a> <a class="btn-sm btn-outline" href="/packages/{{ $p->id }}">Open</a></td></tr>
    @empty<tr><td colspan="10" class="py-6 text-center text-slate-500">No trip packages yet.</td></tr>@endforelse</tbody></table></div>
  @include('partials.pagination', ['paginator' => $packages])
</div>
@endsection
