@extends('layouts.app')
@section('title', $package->reference)
@section('content')
<div class="card">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div><h1 class="text-xl font-bold">{{ $package->reference }}</h1>
      <p class="text-sm text-slate-600">{{ $package->client_name }} · {{ $package->adults }}A/{{ $package->children }}C/{{ $package->infants }}I · {!! badge($package->status) !!}</p>
      <p class="text-xs text-slate-500">Valid until {{ \App\Support\Fmt::date((string) $package->valid_until) }} · {{ \App\Support\Catalog::marketLabel($package->market) }}</p></div>
    <div class="flex flex-wrap gap-2">
      <a class="btn-outline" href="/packages/{{ $package->id }}/pdf">Download proposal PDF</a>
      @if(can('send_email'))<button class="btn-gold" onclick="document.getElementById('email-box').classList.toggle('hidden')">Email proposal</button>@endif
      @if(can('manage_packages'))<a class="btn-outline" href="/packages/{{ $package->id }}/edit">Edit</a>@endif
    </div>
  </div>
  @if(can('send_email'))
  <form id="email-box" method="post" action="/proposals/email" class="mt-3 hidden grid gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-2">@csrf
    <input type="hidden" name="kind" value="package"><input type="hidden" name="id" value="{{ $package->id }}">
    <label class="block sm:col-span-2"><span class="lbl">Send trip package PDF to</span><input name="to" type="email" value="{{ $package->client_email }}" class="input" required></label>
    <label class="block"><span class="lbl">Cc</span><input name="cc" class="input"></label>
    <label class="block"><span class="lbl">Subject</span><input name="subject" value="Your trip package {{ $package->reference }}" class="input" required></label>
    <label class="block sm:col-span-2"><span class="lbl">Message</span><textarea name="message" rows="3" class="input">Dear {{ $package->client_name }}, please find your complete trip package proposal attached.</textarea></label>
    <button class="btn-gold sm:col-span-2">Send with PDF attached</button>
  </form>@endif
</div>

<div class="grid gap-4 lg:grid-cols-2">
  <div class="card">
    <div class="card-title">Itinerary</div>
    @forelse($itinerary as $day)
      <div class="mb-2 border-l-2 border-gold-500 pl-3">
        <div class="text-xs font-semibold uppercase text-slate-500">{{ \App\Support\Fmt::date($day['date'], 'D d M Y') }}</div>
        @foreach($day['events'] as $ev)<div class="text-sm">{{ $ev['label'] }} <span class="text-xs text-slate-500">{{ $ev['detail'] }}</span></div>@endforeach
      </div>
    @empty<p class="text-sm text-slate-500">Add a hotel quotation, transfers and tours to build the day-by-day itinerary.</p>@endforelse
  </div>
  <div class="card">
    <div class="card-title">Hotels</div>
    @forelse($hotels as $h)<div class="border-b border-slate-100 py-2 text-sm last:border-0">
      <div class="flex justify-between"><span class="font-medium">{{ $h->hotel_name }} · {{ $h->room_name }}</span><span>{{ money($h->total_amount, $package->currency) }}</span></div>
      <div class="text-xs text-slate-500">{{ \App\Support\Fmt::date((string) $h->check_in) }} → {{ \App\Support\Fmt::date((string) $h->check_out) }} · {{ $h->nights }} night(s) · {{ \App\Support\Catalog::boardShort($h->board_type) }} · {{ $h->rooms }} room(s)</div></div>
    @empty<p class="text-sm text-slate-500">No hotel lines linked.</p>@endforelse
    <div class="card-title mt-4">Transfers</div>
    @forelse($transfers as $t)<div class="flex justify-between border-b border-slate-100 py-1 text-sm last:border-0">
      <span>{{ $t->service_name }} <span class="text-xs text-slate-500">{{ \App\Support\Fmt::date((string) $t->transfer_date) }} {{ $t->transfer_time }} · {{ $t->pickup }} → {{ $t->dropoff }}</span></span>
      <span class="text-xs">{{ money($t->total_net, $package->currency) }}</span></div>
    @empty<p class="text-sm text-slate-500">No transfers.</p>@endforelse
    <div class="card-title mt-4">Tours</div>
    @forelse($tours as $t)<div class="flex justify-between border-b border-slate-100 py-1 text-sm last:border-0">
      <span>{{ $t->service_name }} <span class="text-xs text-slate-500">{{ \App\Support\Fmt::date((string) $t->tour_date) }} · {{ $t->adults }}A/{{ $t->children }}C</span></span>
      <span class="text-xs">{{ money($t->total_net, $package->currency) }}</span></div>
    @empty<p class="text-sm text-slate-500">No tours.</p>@endforelse
    <div class="mt-3 rounded-lg bg-slate-50 p-3 text-sm">
      <div class="flex justify-between"><span>Hotels net</span><span>{{ money($package->hotels_net, $package->currency) }}</span></div>
      <div class="flex justify-between"><span>Transfers net</span><span>{{ money($package->transfers_net, $package->currency) }}</span></div>
      <div class="flex justify-between"><span>Tours net</span><span>{{ money($package->tours_net, $package->currency) }}</span></div>
      <div class="flex justify-between"><span>Client markup ({{ $package->markup_percent }}%)</span><span>{{ money($package->markup_amount, $package->currency) }}</span></div>
      <div class="mt-1 flex justify-between border-t border-slate-200 pt-1 text-base font-bold"><span>Client proposal total</span><span>{{ money($package->proposal_total, $package->currency) }}</span></div>
    </div>
  </div>
</div>
@endsection
