@extends('layouts.app')
@section('title', 'Services & tours')
@section('content')
<div class="grid gap-4 lg:grid-cols-3">
  <div class="card lg:col-span-2">
    <form method="get" class="flex flex-wrap gap-2">
      <input name="q" value="{{ request('q') }}" class="input sm:max-w-xs" placeholder="Service or city">
      <select name="kind" class="input sm:max-w-40"><option value="">Transfers & tours</option><option value="transfer" {{ request('kind')==='transfer'?'selected':'' }}>Transfers</option><option value="tour" {{ request('kind')==='tour'?'selected':'' }}>Tours</option></select>
      <button class="btn-primary">Filter</button>
    </form>
    <div class="mt-3 overflow-x-auto"><table class="tbl"><thead><tr><th>Service</th><th>City</th><th>Duration</th><th class="text-right">Shared</th><th class="text-right">Private 7</th><th class="text-right">Private 12</th><th class="text-right">Ticket A/C</th><th></th></tr></thead>
      <tbody>@forelse($services as $s)<tr>
        <td class="font-medium">{{ $s->name }}<span class="badge ml-1 {{ $s->kind==='transfer' ? 'bg-sky-100 text-sky-800' : 'bg-purple-100 text-purple-800' }}">{{ $s->kind }}</span>
          <div class="text-xs text-slate-500">{{ \Illuminate\Support\Str::limit($s->description, 70) }}</div></td>
        <td class="text-xs">{{ $s->city }}</td><td class="text-xs">{{ $s->duration }}</td>
        <td class="text-right text-xs">{{ money($s->shared_oneway_price) }} / {{ money($s->shared_twoway_price) }}</td>
        <td class="text-right text-xs">{{ money($s->private7_oneway_price) }} / {{ money($s->private7_twoway_price) }}</td>
        <td class="text-right text-xs">{{ money($s->private12_oneway_price) }} / {{ money($s->private12_twoway_price) }}</td>
        <td class="text-right text-xs">{{ $s->kind==='tour' ? money($s->ticket_only_adult).' / '.money($s->ticket_only_child) : money($s->shared_adult).' / '.money($s->shared_child) }}</td>
        <td class="text-right whitespace-nowrap">@if(can('manage_services'))<a class="btn-sm btn-outline" href="/services?edit={{ $s->id }}">Edit</a>@endif</td></tr>
      @empty<tr><td colspan="8" class="py-6 text-center text-slate-500">No services yet.</td></tr>@endforelse</tbody></table></div>
    @include('partials.pagination', ['paginator' => $services])
  </div>
  @if(can('manage_services'))
  <form method="post" action="/services/{{ $editing?->id }}" class="card space-y-3">@csrf
    <div class="card-title">{{ $editing ? 'Edit service' : 'Add service' }}</div>
    <div class="grid gap-2 sm:grid-cols-2">
      <label class="block"><span class="lbl">Kind *</span><select name="kind" class="input"><option value="transfer" {{ ($editing?->kind)==='transfer'?'selected':'' }}>Transfer</option><option value="tour" {{ ($editing?->kind)==='tour'?'selected':'' }}>Tour / ticket</option></select></label>
      <label class="block"><span class="lbl">Sort order</span><input type="number" name="sort_order" value="{{ old('sort_order', $editing?->sort_order ?? 100) }}" class="input"></label>
    </div>
    <label class="block"><span class="lbl">Name *</span><input name="name" value="{{ old('name', $editing?->name) }}" class="input" required></label>
    <label class="block"><span class="lbl">Description</span><textarea name="description" rows="2" class="input">{{ old('description', $editing?->description) }}</textarea></label>
    <div class="grid gap-2 sm:grid-cols-2">
      <label class="block"><span class="lbl">City *</span><input name="city" value="{{ old('city', $editing?->city ?? 'Dubai') }}" class="input" required list="svc-cities"><datalist id="svc-cities">@foreach($cities as $c)<option value="{{ $c }}"></option>@endforeach</datalist></label>
      <label class="block"><span class="lbl">Duration</span><input name="duration" value="{{ old('duration', $editing?->duration) }}" class="input"></label>
    </div>
    <fieldset class="rounded-lg border border-slate-200 p-2"><legend class="text-xs font-semibold text-slate-600">Transfer prices (AED)</legend>
      <div class="grid grid-cols-2 gap-2">
        @foreach ([['shared_oneway_price','Shared 1-way'],['shared_twoway_price','Shared 2-way'],['private7_oneway_price','Private 7 1-way'],['private7_twoway_price','Private 7 2-way'],['private12_oneway_price','Private 12 1-way'],['private12_twoway_price','Private 12 2-way']] as [$f,$l])
          <label class="block"><span class="lbl">{{ $l }}</span><input type="number" step="0.01" min="0" name="{{ $f }}" value="{{ old($f, $editing?->$f ?? 0) }}" class="input"></label>@endforeach
      </div></fieldset>
    <fieldset class="rounded-lg border border-slate-200 p-2"><legend class="text-xs font-semibold text-slate-600">Tour & ticket prices (AED)</legend>
      <div class="grid grid-cols-2 gap-2">
        @foreach ([['ticket_only_adult','Ticket adult'],['ticket_only_child','Ticket child'],['shared_adult','Shared adult'],['shared_child','Shared child'],['private_adult','Private adult'],['private_child','Private child']] as [$f,$l])
          <label class="block"><span class="lbl">{{ $l }}</span><input type="number" step="0.01" min="0" name="{{ $f }}" value="{{ old($f, $editing?->$f ?? 0) }}" class="input"></label>@endforeach
      </div></fieldset>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" {{ old('active', $editing?->active ?? 1) ? 'checked':'' }} class="h-4 w-4">Active</label>
    <div class="flex gap-2"><button class="btn-gold">Save service</button>@if($editing)<a class="btn-outline" href="/services">Cancel</a>@endif</div>
  </form>
  @endif
</div>
@endsection
