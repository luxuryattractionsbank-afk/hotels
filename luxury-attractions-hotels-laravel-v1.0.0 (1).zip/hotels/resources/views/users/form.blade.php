@extends('layouts.app')
@section('title', $user ? 'Edit account' : 'Add account')
@section('content')
<form method="post" action="/users/{{ $user?->id }}" class="card max-w-3xl space-y-3" x-data="{ role: '{{ old('role', $user?->role ?? 'sales') }}' }">@csrf
  <div class="card-title">{{ $user ? 'Edit '.$user->name : 'Add a staff account' }}</div>
  <div class="grid gap-3 sm:grid-cols-2">
    <label class="block"><span class="lbl">Full name *</span><input name="name" value="{{ old('name', $user?->name) }}" class="input" required></label>
    <label class="block"><span class="lbl">Username *</span><input name="username" value="{{ old('username', $user?->username) }}" class="input" required pattern="[a-zA-Z0-9._-]{3,60}"></label>
    <label class="block"><span class="lbl">Registered email *</span><input name="email" type="email" value="{{ old('email', $user?->email) }}" class="input" required></label>
    <label class="block"><span class="lbl">Role *</span><select name="role" x-model="role" class="input">@foreach($roles as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">{{ $user ? 'New password (blank keeps current)' : 'Password (min. 8) *' }}</span><input name="password" type="password" minlength="8" class="input" autocomplete="new-password" {{ $user ? '' : 'required' }}></label>
    <label class="flex items-end gap-2 pb-2 text-sm"><input type="checkbox" name="active" value="1" {{ old('active', $user?->active ?? 1) ? 'checked':'' }} class="h-5 w-5">Active account</label>
  </div>
  <div x-show="role !== 'admin'" class="rounded-lg border border-slate-200 p-3">
    <span class="lbl">Fine-tuned permissions</span>
    @php $current = collect(old('permissions', $user? $user->permissions() : \App\Support\Perm::defaults('sales')))->map('strval')->all(); @endphp
    <div class="grid gap-2 sm:grid-cols-2">
      @foreach($permissions as $key => $p)
        <label class="flex items-start gap-2 rounded-lg border border-slate-200 p-2 text-sm">
          <input type="checkbox" name="permissions[]" value="{{ $key }}" class="mt-1 h-4 w-4" {{ in_array($key, $current, true) ? 'checked' : '' }}>
          <span><b>{{ $p['label'] }}</b><span class="block text-xs text-slate-600">{{ $p['description'] }}</span></span></label>
      @endforeach</div>
  </div>
  <p x-show="role === 'admin'" class="rounded-lg bg-amber-50 p-2 text-xs text-amber-800">Administrators automatically hold every permission.</p>
  <div class="flex gap-2"><button class="btn-gold">Save account</button><a class="btn-outline" href="/users">Cancel</a></div>
</form>
@endsection
