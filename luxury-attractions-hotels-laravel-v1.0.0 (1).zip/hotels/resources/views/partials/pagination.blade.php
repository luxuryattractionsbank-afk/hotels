@if($paginator->hasPages())
<div class="no-print mt-3 flex flex-wrap items-center gap-2 text-sm">
  @if($paginator->onFirstPage())<span class="rounded-lg border border-slate-200 px-3 py-2 text-slate-400">Previous</span>
  @else<a class="btn-outline" href="{{ $paginator->previousPageUrl() }}">Previous</a>@endif
  <span class="text-xs text-slate-500">Page {{ $paginator->currentPage() }} of {{ $paginator->lastPage() }} · {{ $paginator->total() }} record(s)</span>
  @if($paginator->hasMorePages())<a class="btn-outline" href="{{ $paginator->nextPageUrl() }}">Next</a>
  @else<span class="rounded-lg border border-slate-200 px-3 py-2 text-slate-400">Next</span>@endif
</div>
@endif
