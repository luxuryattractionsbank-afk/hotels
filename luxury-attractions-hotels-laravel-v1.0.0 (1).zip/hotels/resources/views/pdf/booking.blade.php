<!DOCTYPE html><html><head><meta charset="utf-8"><style>
body{font-family:DejaVu Sans,sans-serif;font-size:11px;color:#0f172a;margin:0}
.hdr{background:#0f1a33;color:#fff;padding:16px 20px}.hdr h1{margin:0;font-size:18px}.hdr p{margin:2px 0 0;color:#e3c26b;font-size:10px}
.wrap{padding:16px 20px}table{width:100%;border-collapse:collapse}td{padding:6px;border-bottom:1px solid #e2e8f0;vertical-align:top}
.lbl{width:38%;color:#475569}.foot{margin-top:16px;padding-top:8px;border-top:1px solid #cbd5e1;font-size:9px;color:#475569}
</style></head><body>
<div class="hdr"><h1>{{ $company['name'] }} – Hotel Confirmation</h1><p>{{ $company['phone'] }} · {{ $company['email'] }}</p>
  <p>Reference {{ $booking->reference }} · status {{ \App\Support\Fmt::label($booking->status) }}</p></div>
<div class="wrap">
  <table><tbody>
    <tr><td class="lbl">Guest name</td><td><b>{{ $booking->guest_name }}</b></td></tr>
    <tr><td class="lbl">Hotel</td><td>{{ $booking->hotel_name }}<br>{{ $booking->address }}, {{ $booking->city }}</td></tr>
    <tr><td class="lbl">Room</td><td>{{ $booking->room_name }} · {{ \App\Support\Catalog::boardLabel($booking->board_type) }}</td></tr>
    <tr><td class="lbl">Stay</td><td>{{ \App\Support\Fmt::date((string) $booking->check_in) }} → {{ \App\Support\Fmt::date((string) $booking->check_out) }} ({{ count($nights) }} night(s))</td></tr>
    <tr><td class="lbl">Check-in / check-out</td><td>{{ $booking->check_in_time }} / {{ $booking->check_out_time }}</td></tr>
    <tr><td class="lbl">Guests</td><td>{{ $booking->adults }} adult(s), {{ $booking->children }} child(ren), {{ $booking->infants }} infant(s) in {{ $booking->rooms }} room(s)</td></tr>
    @if($booking->extra_beds || $booking->sofa_beds || $booking->baby_cots)<tr><td class="lbl">Extra bedding</td><td>{{ $booking->extra_beds }} extra bed(s), {{ $booking->sofa_beds }} sofa bed(s), {{ $booking->baby_cots }} baby cot(s)</td></tr>@endif
    @if($booking->rate_name)<tr><td class="lbl">Rate plan</td><td>{{ $booking->rate_name }}</td></tr>@endif
    @if($booking->notes)<tr><td class="lbl">Special requests</td><td>{{ $booking->notes }}</td></tr>@endif
    <tr><td class="lbl">Hotel contact</td><td>{{ $booking->contact_email }} · {{ $booking->contact_phone }}</td></tr>
  </tbody></table>
  <div class="foot">Please present this confirmation at check-in. Cancellation and amendment conditions follow the contracted rate plan.</div>
</div></body></html>
