<!DOCTYPE html><html><head><meta charset="utf-8"><style>
body{font-family:DejaVu Sans,sans-serif;font-size:11px;color:#0f172a;margin:0}
.hdr{background:#0f1a33;color:#fff;padding:16px 20px}.hdr h1{margin:0;font-size:18px}.hdr p{margin:2px 0 0;color:#e3c26b;font-size:10px}
.wrap{padding:16px 20px}table{width:100%;border-collapse:collapse;margin-top:8px}
th{background:#f1f5f9;text-align:left;padding:6px;font-size:9px;text-transform:uppercase;letter-spacing:.04em}
td{padding:6px;border-bottom:1px solid #e2e8f0;vertical-align:top}.right{text-align:right}.tot{font-size:14px;font-weight:bold}
.foot{margin-top:16px;padding-top:8px;border-top:1px solid #cbd5e1;font-size:9px;color:#475569}
</style></head><body>
<div class="hdr"><h1>{{ $company['name'] }}</h1>
  <p>{{ $company['address'] }} · {{ $company['phone'] }} · {{ $company['email'] }} · {{ $company['website'] }}</p>
  <p>Hotel proposal {{ $quotation->reference }} · issued {{ \App\Support\Fmt::date((string) $quotation->created_at) }} · valid until {{ \App\Support\Fmt::date((string) $quotation->valid_until) }}</p></div>
<div class="wrap">
  <p><b>Prepared for:</b> {{ $quotation->client_name }}@if($quotation->client_email) · {{ $quotation->client_email }}@endif @if($quotation->client_phone) · {{ $quotation->client_phone }}@endif</p>
  <table><thead><tr><th>Hotel</th><th>Room &amp; board</th><th>Stay</th><th class="right">Guests</th><th class="right">Rooms</th><th class="right">Amount</th></tr></thead><tbody>
  @foreach($lines as $line)<tr>
    <td><b>{{ $line->hotel_name }}</b><br>{{ $line->city }}<br><span style="color:#64748b">Check-in {{ $line->check_in_time }} · check-out {{ $line->check_out_time }}</span></td>
    <td>{{ $line->room_name }}<br>{{ \App\Support\Catalog::boardLabel($line->board_type) }}</td>
    <td>{{ \App\Support\Fmt::date((string) $line->check_in) }} → {{ \App\Support\Fmt::date((string) $line->check_out) }}<br>{{ $line->nights }} night(s)</td>
    <td class="right">{{ $line->adults }}A / {{ $line->children }}C / {{ $line->infants }}I</td>
    <td class="right">{{ $line->rooms }}</td>
    <td class="right">{{ money($line->total_amount, $currency) }}</td></tr>@endforeach
  </tbody></table>
  <table><tbody><tr><td class="right tot">Total for this proposal</td><td class="right tot">{{ money($clientTotal, $currency) }}</td></tr></tbody></table>
  @if($quotation->notes)<p style="margin-top:10px"><b>Notes:</b> {{ $quotation->notes }}</p>@endif
  <div class="foot">Contracted B2B rates including applicable tourism tax where stated. Availability is subject to confirmation at the time of booking.
    This document intentionally shows client pricing only.</div>
</div></body></html>
