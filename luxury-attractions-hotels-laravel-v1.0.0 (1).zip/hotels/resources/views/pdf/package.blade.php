<!DOCTYPE html><html><head><meta charset="utf-8"><style>
body{font-family:DejaVu Sans,sans-serif;font-size:11px;color:#0f172a;margin:0}
.hdr{background:#0f1a33;color:#fff;padding:16px 20px}.hdr h1{margin:0;font-size:18px}.hdr p{margin:2px 0 0;color:#e3c26b;font-size:10px}
.wrap{padding:16px 20px}h2{font-size:12px;margin:14px 0 4px;text-transform:uppercase;letter-spacing:.05em;color:#0f1a33}
table{width:100%;border-collapse:collapse}th{background:#f1f5f9;text-align:left;padding:6px;font-size:9px;text-transform:uppercase}
td{padding:6px;border-bottom:1px solid #e2e8f0;vertical-align:top}.right{text-align:right}.tot{font-size:14px;font-weight:bold}
.foot{margin-top:16px;padding-top:8px;border-top:1px solid #cbd5e1;font-size:9px;color:#475569}
</style></head><body>
<div class="hdr"><h1>{{ $company['name'] }} – Trip Package</h1>
  <p>{{ $company['address'] }} · {{ $company['phone'] }} · {{ $company['email'] }}</p>
  <p>{{ $package->reference }} · issued {{ \App\Support\Fmt::date((string) $package->created_at) }} · valid until {{ \App\Support\Fmt::date((string) $package->valid_until) }}</p></div>
<div class="wrap">
  <p><b>Prepared for:</b> {{ $package->client_name }} · {{ $package->adults }} adult(s), {{ $package->children }} child(ren), {{ $package->infants }} infant(s)</p>
  @if($hotels->count())<h2>Hotels</h2><table><thead><tr><th>Hotel</th><th>Room &amp; board</th><th>Stay</th><th class="right">Rooms</th></tr></thead><tbody>
    @foreach($hotels as $h)<tr><td><b>{{ $h->hotel_name }}</b><br>{{ $h->city }}</td><td>{{ $h->room_name }}<br>{{ \App\Support\Catalog::boardLabel($h->board_type) }}</td>
      <td>{{ \App\Support\Fmt::date((string) $h->check_in) }} → {{ \App\Support\Fmt::date((string) $h->check_out) }} ({{ $h->nights }} nights)</td><td class="right">{{ $h->rooms }}</td></tr>@endforeach
  </tbody></table>@endif
  @if($transfers->count())<h2>Transfers</h2><table><thead><tr><th>Date</th><th>Service</th><th>Route</th><th class="right">Party</th></tr></thead><tbody>
    @foreach($transfers as $t)<tr><td>{{ \App\Support\Fmt::date((string) $t->transfer_date) }} {{ $t->transfer_time }}</td>
      <td>{{ $t->service_name }}<br><span style="color:#64748b">{{ \App\Support\Fmt::label($t->mode) }} · {{ \App\Support\Fmt::label($t->direction) }}@if($t->flight_no) · {{ $t->flight_no }}@endif</span></td>
      <td>{{ $t->pickup }} → {{ $t->dropoff }}</td><td class="right">{{ $t->adults }}A / {{ $t->children }}C · {{ $t->vehicles }} vehicle(s)</td></tr>@endforeach
  </tbody></table>@endif
  @if($tours->count())<h2>Tours &amp; attractions</h2><table><thead><tr><th>Date</th><th>Experience</th><th>Option</th><th class="right">Party</th></tr></thead><tbody>
    @foreach($tours as $t)<tr><td>{{ \App\Support\Fmt::date((string) $t->tour_date) }} {{ $t->tour_time }}</td>
      <td>{{ $t->service_name }}@if($t->meeting_point)<br><span style="color:#64748b">Meeting point: {{ $t->meeting_point }}</span>@endif</td>
      <td>{{ \App\Support\Fmt::label($t->option_mode) }}</td><td class="right">{{ $t->adults }}A / {{ $t->children }}C</td></tr>@endforeach
  </tbody></table>@endif
  <table style="margin-top:14px"><tbody><tr><td class="right tot">Package total</td><td class="right tot">{{ money($clientTotal, $currency) }}</td></tr></tbody></table>
  @if($package->notes)<p style="margin-top:10px"><b>Notes:</b> {{ $package->notes }}</p>@endif
  <div class="foot">Prices are per package and include applicable taxes where stated. Timings are indicative and confirmed at booking.
    Net supplier costs and margins are internal and never appear on this document.</div>
</div></body></html>
