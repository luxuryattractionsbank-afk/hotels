<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot password – Luxury Attractions Hotels</title><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md space-y-4">
  <h1 class="text-center text-xl font-bold text-white">Reset your password</h1>
  @if(session('ok'))<div class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">{{ session('ok') }}</div>@endif
  @if(session('error'))<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">{{ session('error') }}</div>@endif
  @if($errors->any())<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
  <form method="post" action="/forgot-password" class="card space-y-3">@csrf
    <label class="block"><span class="lbl">Username or registered email</span>
      <input name="identifier" value="{{ old('identifier') }}" class="input" required></label>
    <button class="btn-gold w-full">Email me a recovery link</button>
    <p class="text-xs text-slate-600">Links are single use and expire after 30 minutes. They are sent to the registered email only; this page never reveals whether an account exists.</p>
    <p class="text-center text-xs"><a class="underline" href="/login">Back to sign in</a></p>
  </form>
</div></body></html>
