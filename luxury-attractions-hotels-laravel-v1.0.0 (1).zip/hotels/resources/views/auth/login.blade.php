<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in – Luxury Attractions Hotels</title><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md space-y-4">
  <div class="text-center text-white"><div class="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-2xl bg-gold-500 text-2xl font-black text-navy-900">LA</div>
    <h1 class="text-2xl font-bold">Hotels &amp; Contracts</h1><p class="text-sm text-gold-400">Luxury Attractions · staff sign in</p></div>
  @if(session('ok'))<div class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">{{ session('ok') }}</div>@endif
  @if(session('error'))<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">{{ session('error') }}</div>@endif
  @if($errors->any())<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
  <form method="post" action="/login" class="card space-y-3">@csrf
    <div class="card-title">Sign in</div>
    <label class="block"><span class="lbl">Username or registered email</span>
      <input name="identifier" value="{{ old('identifier') }}" class="input" required autofocus autocomplete="username"></label>
    <label class="block"><span class="lbl">Password</span>
      <input name="password" type="password" class="input" required autocomplete="current-password"></label>
    <button class="btn-gold w-full">Sign in</button>
    <p class="text-center text-xs text-slate-600"><a class="underline" href="/forgot-password">Forgot password?</a></p>
  </form>
  @if($needsSetup ?? false)<p class="rounded-lg bg-amber-50 p-3 text-xs text-amber-800">No staff accounts exist yet. Sign in once with the username and a password of at least 8 characters to create the first administrator.</p>@endif
</div></body></html>
