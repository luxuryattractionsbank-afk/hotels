<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Choose a new password – Luxury Attractions Hotels</title><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md space-y-4">
  <h1 class="text-center text-xl font-bold text-white">Choose a new password</h1>
  @if(session('error'))<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">{{ session('error') }}</div>@endif
  @if($errors->any())<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
  <form method="post" action="/reset-password" class="card space-y-3">@csrf
    <input type="hidden" name="token" value="{{ $token }}">
    <label class="block"><span class="lbl">New password (min. 8)</span>
      <input name="password" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
    <label class="block"><span class="lbl">Repeat new password</span>
      <input name="password_confirmation" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
    <button class="btn-gold w-full">Change password</button>
    <p class="text-xs text-slate-600">Changing your password signs out every other session.</p>
  </form>
</div></body></html>
