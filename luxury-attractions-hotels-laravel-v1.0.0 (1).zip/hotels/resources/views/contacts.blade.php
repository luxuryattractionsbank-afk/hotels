@extends('layouts.app')
@section('title', 'Hotel contacts')
@section('content')
<div class="grid gap-4 lg:grid-cols-3">
  <div class="card lg:col-span-2">
    <form method="get" class="flex gap-2"><input name="q" value="{{ request('q') }}" class="input" placeholder="Search name, email or phone"><button class="btn-primary">Search</button></form>
    <div class="mt-3 overflow-x-auto"><table class="tbl"><thead><tr><th>Name</th><th>Position</th><th>Email / phone</th><th>Messaging</th><th>Hotels</th><th></th></tr></thead>
      <tbody>@forelse($contacts as $c)
        <tr>
          <td class="font-medium">{{ $c->name }}{!! $c->active ? '' : ' <span class="badge bg-slate-200 text-slate-600">Inactive</span>' !!}</td>
          <td class="text-xs">{{ $c->position }}</td>
          <td class="text-xs">@if($c->email)<a class="underline" href="mailto:{{ $c->email }}">{{ $c->email }}</a><br>@endif {{ $c->phone }}</td>
          <td class="text-xs">@foreach(['whatsapp','telegram','viber'] as $k)@if($c->$k && $c->phone)<a class="mr-1 inline-block text-emerald-700 underline" href="{{ \App\Support\Catalog::messagingLink($k, $c->phone) }}">{{ ucfirst($k) }}</a>@endif @endforeach{{ $c->other_contact }}</td>
          <td class="text-xs text-slate-600">{{ $c->hotels->pluck('name')->implode(', ') ?: ($c->group_id ? 'Whole group' : '—') }}</td>
          <td class="text-right">@if(can('manage_hotels'))<a class="btn-sm btn-outline" href="/contacts?edit={{ $c->id }}">Edit</a>@endif</td>
        </tr>
      @empty<tr><td colspan="6" class="py-6 text-center text-slate-500">No contacts yet.</td></tr>@endforelse</tbody></table></div>
    @include('partials.pagination', ['paginator' => $contacts])
  </div>
  @if(can('manage_hotels'))
  <form method="post" action="/contacts/{{ $editing?->id }}" class="card space-y-3">@csrf
    <div class="card-title">{{ $editing ? 'Edit contact' : 'Add contact' }}</div>
    <label class="block"><span class="lbl">Full name *</span><input name="name" value="{{ old('name', $editing?->name) }}" class="input" required></label>
    <label class="block"><span class="lbl">Position</span><input name="position" value="{{ old('position', $editing?->position) }}" class="input"></label>
    <label class="block"><span class="lbl">Email</span><input name="email" type="email" value="{{ old('email', $editing?->email) }}" class="input"></label>
    <label class="block"><span class="lbl">Phone</span><input name="phone" value="{{ old('phone', $editing?->phone) }}" class="input" placeholder="+971501234567"></label>
    <label class="block"><span class="lbl">Business card link</span><input name="business_card_link" value="{{ old('business_card_link', $editing?->business_card_link) }}" class="input"></label>
    <label class="block"><span class="lbl">Other contact method</span><input name="other_contact" value="{{ old('other_contact', $editing?->other_contact) }}" class="input"></label>
    <label class="block"><span class="lbl">Hotel group (covers every hotel in it)</span><select name="group_id" class="input"><option value="">—</option>@foreach($groups as $g)<option value="{{ $g->id }}" {{ (int) old('group_id', $editing?->group_id) === (int) $g->id ?'selected':'' }}>{{ $g->name }}</option>@endforeach</select></label>
    <div><span class="lbl">Assigned hotels</span>
      <div class="max-h-40 overflow-y-auto rounded-lg border border-slate-200 p-2">@php $current = collect(old('hotels', $editing? $editing->hotels->pluck('id')->all() : []))->map(fn($v)=>(int)$v)->all(); @endphp
        @foreach($hotels as $h)<label class="flex items-center gap-2 text-sm"><input type="checkbox" name="hotels[]" value="{{ $h->id }}" {{ in_array((int) $h->id, $current, true) ? 'checked':'' }}>{{ $h->name }}</label>@endforeach</div></div>
    <div class="flex flex-wrap gap-3 text-sm">
      @foreach(['whatsapp'=>'WhatsApp','telegram'=>'Telegram','viber'=>'Viber'] as $k=>$label)
        <label class="flex items-center gap-2"><input type="checkbox" name="{{ $k }}" value="1" {{ old($k, $editing?->$k) ? 'checked':'' }} class="h-4 w-4">{{ $label }}</label>@endforeach
      <label class="flex items-center gap-2"><input type="checkbox" name="active" value="1" {{ old('active', $editing?->active ?? 1) ? 'checked':'' }} class="h-4 w-4">Active</label>
    </div>
    <div class="flex gap-2"><button class="btn-gold">Save contact</button>@if($editing)<a class="btn-outline" href="/contacts">Cancel</a>@endif</div>
  </form>
  @endif
</div>
@endsection
