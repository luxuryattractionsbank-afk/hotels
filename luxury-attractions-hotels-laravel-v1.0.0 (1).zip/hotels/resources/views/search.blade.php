@extends('layouts.app')
@section('title', 'Availability & rates')
@section('content')
<form method="get" action="/search" class="card space-y-3">
  <div class="card-title">Search contracted availability &amp; net rates</div>
  <div class="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
    <label class="block"><span class="lbl">Check-in</span><input type="date" name="check_in" value="{{ $criteria['checkIn'] }}" class="input" required></label>
    <label class="block"><span class="lbl">Check-out</span><input type="date" name="check_out" value="{{ $criteria['checkOut'] }}" class="input" required></label>
    <label class="block"><span class="lbl">Adults</span><input type="number" name="adults" min="1" max="20" value="{{ $criteria['adults'] }}" class="input"></label>
    <label class="block"><span class="lbl">Children</span><input type="number" name="children" min="0" max="20" value="{{ $criteria['children'] }}" class="input"></label>
    <label class="block"><span class="lbl">Infants</span><input type="number" name="infants" min="0" max="10" value="{{ $criteria['infants'] }}" class="input"></label>
    <label class="block"><span class="lbl">Rooms</span><input type="number" name="rooms" min="1" max="20" value="{{ $criteria['rooms'] }}" class="input"></label>
    <label class="block"><span class="lbl">Booking date</span><input type="date" name="booking_date" value="{{ $criteria['bookingDate'] }}" class="input"></label>
    <label class="block"><span class="lbl">Market</span><select name="market" class="input">@foreach($markets as $m)<option value="{{ $m->slug }}" {{ $criteria['market']===$m->slug?'selected':'' }}>{{ $m->label }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Room category</span><select name="category" class="input"><option value="any">Any</option>@foreach($categories as $slug => $label)<option value="{{ $slug }}" {{ $criteria['category']===$slug?'selected':'' }}>{{ $label }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Hotel</span><select name="hotel_id" class="input"><option value="">All hotels</option>@foreach($hotels as $h)<option value="{{ $h->id }}" {{ (int) $criteria['hotelId'] === (int) $h->id ? 'selected' : '' }}>{{ $h->name }} ({{ $h->city }})</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Extra beds</span><input type="number" name="extra_beds" min="0" value="{{ $criteria['extraBeds'] }}" class="input"></label>
    <label class="block"><span class="lbl">Baby cots</span><input type="number" name="baby_cots" min="0" value="{{ $criteria['babyCots'] }}" class="input"></label>
  </div>
  <div class="grid gap-3 sm:grid-cols-4">
    <label class="block"><span class="lbl">Hotel / area search</span><input name="q" value="{{ $filters['query'] }}" class="input" placeholder="name, city or area"></label>
    <label class="block"><span class="lbl">Sort</span><select name="sort" class="input">@foreach($sorts as $value => $label)<option value="{{ $value }}" {{ $filters['sort']===$value?'selected':'' }}>{{ $label }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Compare nightly rate</span><select name="rate_basis" class="input"><option value="excl_tax" {{ $filters['rateBasis']==='excl_tax'?'selected':'' }}>Excluding tax</option><option value="incl_tax" {{ $filters['rateBasis']==='incl_tax'?'selected':'' }}>Including tourism tax</option></select></label>
    <label class="block"><span class="lbl">Minimum stars</span><select name="min_stars" class="input">@for($s=0;$s<=5;$s++)<option value="{{ $s }}" {{ (int) $filters['minStars']===$s?'selected':'' }}>{{ $s ? $s.'★+' : 'Any' }}</option>@endfor</select></label>
  </div>
  <div class="flex flex-wrap gap-2">
    <button class="btn-primary">Search</button>
    <a class="btn-outline" href="/search">Reset</a>
    @if($response)<span class="self-center text-xs text-slate-500">{{ $response['nights'] }} night(s) · {{ $response['checkedHotels'] }} hotel(s) · {{ $response['checkedRooms'] }} room(s) checked</span>@endif
  </div>
</form>

@if($response && $response['error'])<div class="card border-red-200 bg-red-50 text-sm text-red-700">{{ $response['error'] }}</div>@endif

@forelse($results as $r)
@php $best = $r['best']; $offerB64 = base64_encode(json_encode(['hotel'=>$r['hotel'],'room'=>$r['room'],'offer'=>$best,'criteria'=>$criteria])); @endphp
<div class="card" x-data="{ open: {{ count($results) === 1 ? 'true' : 'false' }} }">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div>
      <div class="text-lg font-semibold">{{ $r['hotel']['name'] }} <span class="text-gold-600">{{ \App\Support\Fmt::stars((int) $r['hotel']['starRating']) }}</span></div>
      <div class="text-sm text-slate-600">{{ $r['hotel']['city'] }}{{ $r['hotel']['location'] ? ' · '.$r['hotel']['location'] : '' }} · {{ $r['room']['name'] }} ({{ $r['room']['code'] }})</div>
      <div class="mt-1 flex flex-wrap gap-1">@foreach(($r['hotel']['amenities'] ?? []) as $a)<span class="badge bg-slate-100 text-slate-700">{{ $a }}</span>@endforeach</div>
    </div>
    <div class="text-right">
      <div class="text-xl font-bold text-navy-800">{{ money($best['totalAmount'], $r['hotel']['currency']) }}</div>
      <div class="text-xs text-slate-500">{{ money(\App\Support\Pricing::comparableRate($best, $filters['rateBasis']), $r['hotel']['currency']) }} avg / room / night · {{ $best['nights'] }} night(s)</div>
      <div class="text-xs {{ $r['roomsLeft'] <= 2 ? 'text-red-600 font-semibold' : 'text-emerald-700' }}">{{ $r['roomsLeft'] }} contracted room(s) left</div>
    </div>
  </div>
  <div class="mt-3 flex flex-wrap gap-2">
    @foreach($r['offers'] as $o)
      <span class="badge {{ $o['boardType'] === $best['boardType'] ? 'bg-gold-500 text-navy-900' : 'bg-slate-100 text-slate-700' }}">{{ \App\Support\Catalog::boardShort($o['boardType']) }} {{ money($o['totalAmount'], $r['hotel']['currency']) }}</span>
    @endforeach
    <button class="btn-sm btn-outline ml-auto" @click="open = !open" x-text="open ? 'Hide breakdown' : 'Nightly breakdown'">Nightly breakdown</button>
    @if(can('manage_quotations'))
      <a class="btn-sm btn-gold" href="/quotations/new?offer={{ urlencode($offerB64) }}">Quote this</a>
    @endif
    @if(can('manage_bookings'))
      <a class="btn-sm btn-primary" href="/bookings/new?offer={{ urlencode($offerB64) }}">Book</a>
    @endif
  </div>
  <div x-show="open" x-cloak class="mt-3 overflow-x-auto">
    <table class="tbl"><thead><tr><th>Night</th><th>Contract</th><th class="text-right">Room</th><th class="text-right">Board</th><th class="text-right">Occupancy</th><th class="text-right">Bedding</th><th class="text-right">Total</th></tr></thead>
      <tbody>@foreach($best['nightly'] as $line)
        <tr><td>{{ \App\Support\Fmt::date($line['date'], 'D d M') }}</td><td class="text-xs">{{ $line['rateName'] }}</td>
          <td class="text-right">{{ money($line['roomAmount']) }}</td><td class="text-right">{{ money($line['boardAmount']) }}</td>
          <td class="text-right">{{ money($line['supplementAmount']) }}</td><td class="text-right">{{ money($line['extraBedAmount']) }}</td>
          <td class="text-right font-semibold">{{ money($line['total']) }}</td></tr>
      @endforeach</tbody></table>
    <p class="mt-2 text-xs text-slate-500">Tourism tax {{ money($best['tourismTaxAmount']) }} ({{ lbl($r['hotel']['tourismTaxBasis']) }}) · contracts: {{ implode(', ', $best['rateNames']) }}@if($best['promoCodes']) · promo {{ implode(', ', $best['promoCodes']) }}@endif · check-in {{ $r['hotel']['checkInTime'] }}, check-out {{ $r['hotel']['checkOutTime'] }}.</p>
  </div>
</div>
@empty
@if($response && !$response['error'])<div class="card text-sm text-slate-600">No contracted room matched those dates. {{ ($response['outsidePriceRange'] ?? 0) ? ($response['outsidePriceRange'].' result(s) fell outside the price filter.') : '' }} See the exclusions below for the reason each room was dropped.</div>@endif
@endforelse

@if(!empty($excluded))
<div class="card">
  <div class="card-title">Why rooms were excluded ({{ count($excluded) }})</div>
  <div class="max-h-80 overflow-y-auto">
  <table class="tbl"><thead><tr><th>Hotel</th><th>Room</th><th>Reason</th><th>Kind</th></tr></thead>
    <tbody>@foreach($excluded as $e)<tr><td>{{ $e['hotelName'] }}</td><td>{{ $e['roomName'] }}</td><td class="text-xs text-slate-600">{{ $e['reason'] }}</td><td><span class="badge bg-slate-100 text-slate-700">{{ lbl($e['kind']) }}</span></td></tr>@endforeach</tbody></table>
  </div>
</div>
@endif
@endsection
