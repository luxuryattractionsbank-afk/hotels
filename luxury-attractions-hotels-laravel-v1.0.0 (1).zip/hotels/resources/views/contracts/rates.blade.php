@extends('layouts.app')
@section('title', 'Contract rates')
@section('content')
<div class="grid gap-4 lg:grid-cols-3">
  <div class="card lg:col-span-2">
    <form method="get" class="flex flex-wrap gap-2">
      <select name="hotel_id" class="input sm:max-w-xs"><option value="">All hotels</option>@foreach($hotels as $h)<option value="{{ $h->id }}" {{ (int) request('hotel_id') === (int) $h->id ?'selected':'' }}>{{ $h->name }}</option>@endforeach</select>
      <select name="board" class="input sm:max-w-40"><option value="">All boards</option>@foreach($boards as $value => [$label, $short])<option value="{{ $value }}" {{ request('board')===$value?'selected':'' }}>{{ $label }}</option>@endforeach</select>
      <button class="btn-primary">Filter</button>
    </form>
    <div class="mt-3 overflow-x-auto"><table class="tbl"><thead><tr><th>Period</th><th>Hotel / room</th><th>Board</th><th>Dates</th><th>Market</th><th class="text-right">Net rate</th><th class="text-right">Supplements</th><th></th></tr></thead>
      <tbody>@forelse($rates as $r)<tr>
        <td class="font-medium">{{ $r->name }}{!! $r->active ? '' : ' <span class="badge bg-slate-200 text-slate-600">Off</span>' !!}@if($r->promo_code)<div class="text-xs text-gold-600">{{ $r->promo_code }}</div>@endif</td>
        <td class="text-xs">{{ $r->hotel?->name }}<div class="text-slate-500">{{ $r->roomType?->name }}</div></td>
        <td>{{ \App\Support\Catalog::boardShort($r->board_type) }}</td>
        <td class="text-xs">{{ \App\Support\Fmt::date((string) $r->valid_from, 'd M Y') }} → {{ \App\Support\Fmt::date((string) $r->valid_to, 'd M Y') }}
          @if($r->booking_window_start || $r->booking_window_end)<div class="text-slate-500">book {{ \App\Support\Fmt::date((string) $r->booking_window_start, 'd M') }}–{{ \App\Support\Fmt::date((string) $r->booking_window_end, 'd M') }}</div>@endif</td>
        <td class="text-xs">{{ \App\Support\Catalog::marketLabel($r->market) }}@if($r->market_exclusions)<div class="text-red-600">excl. {{ $r->market_exclusions }}</div>@endif</td>
        <td class="text-right font-semibold">{{ money($r->base_rate) }}<div class="text-xs font-normal text-slate-500">{{ lbl($r->rate_basis) }}</div></td>
        <td class="text-right text-xs">+{{ money($r->extra_adult_rate) }} adult<div>+{{ money($r->extra_child_rate) }} child · +{{ money($r->extra_bed_rate) }} bed</div><div>min {{ $r->minimum_nights }} night(s)</div></td>
        <td class="text-right">@if(can('manage_rates'))<a class="btn-sm btn-outline" href="/contracts/rates?edit={{ $r->id }}">Edit</a>@endif</td></tr>
      @empty<tr><td colspan="8" class="py-6 text-center text-slate-500">No contracted rates yet – a room needs at least one rate to appear in search.</td></tr>@endforelse</tbody></table></div>
    @include('partials.pagination', ['paginator' => $rates])
  </div>

  @if(can('manage_rates'))
  <form method="post" action="/contracts/rates/{{ $editing?->id }}" class="card space-y-3" x-data="{ hotel: '{{ old('hotel_id', $editing?->hotel_id) }}' }">@csrf
    <div class="card-title">{{ $editing ? 'Edit contract rate' : 'Add contract rate' }}</div>
    <label class="block"><span class="lbl">Hotel *</span><select name="hotel_id" x-model="hotel" class="input" required><option value="">—</option>@foreach($hotels as $h)<option value="{{ $h->id }}">{{ $h->name }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Room type *</span><select name="room_type_id" class="input" required><option value="">—</option>@foreach($rooms as $rm)<option value="{{ $rm->id }}" data-hotel="{{ $rm->hotel_id }}" x-show="hotel === '{{ $rm->hotel_id }}'" {{ (int) old('room_type_id', $editing?->room_type_id) === (int) $rm->id ? 'selected':'' }}>{{ $rm->name }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Rate period name *</span><input name="name" value="{{ old('name', $editing?->name) }}" class="input" required placeholder="Winter High 2026 – Deluxe King"></label>
    <div class="grid gap-2 sm:grid-cols-2">
      <label class="block"><span class="lbl">Board *</span><select name="board_type" class="input" required>@foreach($boards as $value => [$label, $short])<option value="{{ $value }}" {{ old('board_type', $editing?->board_type ?? 'breakfast')===$value?'selected':'' }}>{{ $label }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Market</span><select name="market" class="input">@foreach($markets as $m)<option value="{{ $m->slug }}" {{ old('market', $editing?->market ?? 'all')===$m->slug?'selected':'' }}>{{ $m->label }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Valid from *</span><input type="date" name="valid_from" value="{{ old('valid_from', $editing?->valid_from) }}" class="input" required></label>
      <label class="block"><span class="lbl">Valid to *</span><input type="date" name="valid_to" value="{{ old('valid_to', $editing?->valid_to) }}" class="input" required></label>
      <label class="block"><span class="lbl">Booking window start</span><input type="date" name="booking_window_start" value="{{ old('booking_window_start', $editing?->booking_window_start) }}" class="input"></label>
      <label class="block"><span class="lbl">Booking window end</span><input type="date" name="booking_window_end" value="{{ old('booking_window_end', $editing?->booking_window_end) }}" class="input"></label>
    </div>
    <label class="block"><span class="lbl">Market exclusions (comma separated slugs)</span><input name="market_exclusions" value="{{ old('market_exclusions', $editing?->market_exclusions) }}" class="input" placeholder="cis,india"></label>
    <label class="block"><span class="lbl">Promo code</span><input name="promo_code" value="{{ old('promo_code', $editing?->promo_code) }}" class="input"></label>
    <div class="grid gap-2 sm:grid-cols-2">
      <label class="block"><span class="lbl">Net base rate *</span><input type="number" step="0.01" min="0" name="base_rate" value="{{ old('base_rate', $editing?->base_rate) }}" class="input" required></label>
      <label class="block"><span class="lbl">Rate basis *</span><select name="rate_basis" class="input" required>@foreach(\App\Support\Catalog::RATE_BASES as $value => $label)<option value="{{ $value }}" {{ old('rate_basis', $editing?->rate_basis ?? 'room_night')===$value?'selected':'' }}>{{ $label }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Board adult supplement</span><input type="number" step="0.01" min="0" name="board_adult_supplement" value="{{ old('board_adult_supplement', $editing?->board_adult_supplement ?? 0) }}" class="input"></label>
      <label class="block"><span class="lbl">Board child supplement</span><input type="number" step="0.01" min="0" name="board_child_supplement" value="{{ old('board_child_supplement', $editing?->board_child_supplement ?? 0) }}" class="input"></label>
      <label class="block"><span class="lbl">Extra adult rate</span><input type="number" step="0.01" min="0" name="extra_adult_rate" value="{{ old('extra_adult_rate', $editing?->extra_adult_rate ?? 0) }}" class="input"></label>
      <label class="block"><span class="lbl">Extra child rate</span><input type="number" step="0.01" min="0" name="extra_child_rate" value="{{ old('extra_child_rate', $editing?->extra_child_rate ?? 0) }}" class="input"></label>
      <label class="block"><span class="lbl">Extra bed rate (overrides room default)</span><input type="number" step="0.01" min="0" name="extra_bed_rate" value="{{ old('extra_bed_rate', $editing?->extra_bed_rate ?? 0) }}" class="input"></label>
      <label class="block"><span class="lbl">Minimum nights</span><input type="number" min="1" max="60" name="minimum_nights" value="{{ old('minimum_nights', $editing?->minimum_nights ?? 1) }}" class="input"></label>
    </div>
    <label class="block"><span class="lbl">Board supplement basis</span><select name="board_supplement_basis" class="input">@foreach(['person_night'=>'Per person / night','room_night'=>'Per room / night'] as $v=>$l)<option value="{{ $v }}" {{ old('board_supplement_basis', $editing?->board_supplement_basis ?? 'person_night')===$v?'selected':'' }}>{{ $l }}</option>@endforeach</select></label>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" {{ old('active', $editing?->active ?? 1) ? 'checked':'' }} class="h-4 w-4">Active</label>
    <div class="flex gap-2"><button class="btn-gold">Save rate</button>@if($editing)<a class="btn-outline" href="/contracts/rates">Cancel</a>@endif</div>
  </form>
  @endif
</div>
@endsection
