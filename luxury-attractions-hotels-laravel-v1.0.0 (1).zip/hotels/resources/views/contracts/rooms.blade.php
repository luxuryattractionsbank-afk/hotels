@extends('layouts.app')
@section('title', 'Room types')
@section('content')
<div class="grid gap-4 lg:grid-cols-3">
  <div class="card lg:col-span-2">
    <form method="get" class="flex flex-wrap gap-2">
      <input name="q" value="{{ request('q') }}" class="input sm:max-w-xs" placeholder="Room name or code">
      <select name="hotel_id" class="input sm:max-w-xs"><option value="">All hotels</option>@foreach($hotels as $h)<option value="{{ $h->id }}" {{ (int) request('hotel_id') === (int) $h->id ?'selected':'' }}>{{ $h->name }}</option>@endforeach</select>
      <button class="btn-primary">Filter</button>
    </form>
    <div class="mt-3 overflow-x-auto"><table class="tbl"><thead><tr><th>Room</th><th>Hotel</th><th>Code</th><th>Category</th><th class="text-right">Occupancy</th><th class="text-right">Inventory</th><th></th></tr></thead>
      <tbody>@forelse($rooms as $r)<tr>
        <td class="font-medium">{{ $r->name }}{!! $r->active ? '' : ' <span class="badge bg-slate-200 text-slate-600">Inactive</span>' !!}</td>
        <td><a class="text-navy-700 underline" href="/hotels/{{ $r->hotel_id }}">{{ $r->hotel?->name }}</a></td>
        <td class="font-mono text-xs">{{ $r->code }}</td><td class="text-xs">{{ \App\Support\Catalog::categoryLabel($r->category) }}</td>
        <td class="text-right text-xs">{{ $r->max_adults }}A/{{ $r->max_children }}C/{{ $r->max_infants }}I · sleeps {{ $r->base_sleeps }}</td>
        <td class="text-right">{{ $r->default_inventory }}</td>
        <td class="whitespace-nowrap text-right">@if(can('manage_rates'))
          <a class="btn-sm btn-outline" href="/contracts/rooms?edit={{ $r->id }}&hotel_id={{ request('hotel_id') }}">Edit</a>
          <form method="post" action="/contracts/rooms/{{ $r->id }}/duplicate" class="inline">@csrf<button class="btn-sm btn-outline">Duplicate</button></form>
        @endif</td></tr>
      @empty<tr><td colspan="7" class="py-6 text-center text-slate-500">No room types yet.</td></tr>@endforelse</tbody></table></div>
    @include('partials.pagination', ['paginator' => $rooms])
  </div>

  @if(can('manage_rates'))
  <form method="post" action="/contracts/rooms/{{ $editing?->id }}" class="card space-y-3">@csrf
    <div class="card-title">{{ $editing ? 'Edit room – '.$editing->name : 'Add room type' }}</div>
    <label class="block"><span class="lbl">Hotel *</span><select name="hotel_id" class="input" required><option value="">—</option>@foreach($hotels as $h)<option value="{{ $h->id }}" {{ (int) old('hotel_id', $editing?->hotel_id ?? request('hotel_id')) === (int) $h->id ?'selected':'' }}>{{ $h->name }}</option>@endforeach</select></label>
    <div class="grid gap-2 sm:grid-cols-2">
      <label class="block"><span class="lbl">Room name *</span><input name="name" value="{{ old('name', $editing?->name) }}" class="input" required></label>
      <label class="block"><span class="lbl">Contract code *</span><input name="code" value="{{ old('code', $editing?->code) }}" class="input" required placeholder="DLX-KING"></label>
    </div>
    <label class="block"><span class="lbl">Category *</span><select name="category" class="input" required>@foreach($categories as $slug => $label)<option value="{{ $slug }}" {{ old('category', $editing?->category)===$slug?'selected':'' }}>{{ $label }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Description</span><textarea name="description" rows="2" class="input">{{ old('description', $editing?->description) }}</textarea></label>
    <label class="block"><span class="lbl">Media link</span><input name="media_link" value="{{ old('media_link', $editing?->media_link) }}" class="input"></label>
    <div class="grid grid-cols-3 gap-2">
      <label class="block"><span class="lbl">Max adults *</span><input type="number" min="1" name="max_adults" value="{{ old('max_adults', $editing?->max_adults ?? 2) }}" class="input" required></label>
      <label class="block"><span class="lbl">Max children</span><input type="number" min="0" name="max_children" value="{{ old('max_children', $editing?->max_children ?? 2) }}" class="input"></label>
      <label class="block"><span class="lbl">Max infants</span><input type="number" min="0" name="max_infants" value="{{ old('max_infants', $editing?->max_infants ?? 1) }}" class="input"></label>
      <label class="block"><span class="lbl">Included adults</span><input type="number" min="1" name="included_adults" value="{{ old('included_adults', $editing?->included_adults ?? 2) }}" class="input"></label>
      <label class="block"><span class="lbl">Base sleeps</span><input type="number" min="1" name="base_sleeps" value="{{ old('base_sleeps', $editing?->base_sleeps ?? 2) }}" class="input"></label>
      <label class="block"><span class="lbl">Inventory *</span><input type="number" min="0" name="default_inventory" value="{{ old('default_inventory', $editing?->default_inventory ?? 5) }}" class="input" required></label>
    </div>
    <div><span class="lbl">Bedding allowed per room</span>
      @foreach(\App\Support\Catalog::BEDDING_KINDS as $kind => [$label, $hint])
        @php $row = $editing? $editing->bedding->firstWhere('kind', $kind) : null; @endphp
        <div class="mb-2 rounded-lg border border-slate-200 p-2">
          <div class="text-sm font-medium">{{ $label }} <span class="text-xs text-slate-500">{{ $hint }}</span></div>
          <div class="mt-1 grid grid-cols-2 gap-2 items-end">
            <label class="block"><span class="lbl">Max per room</span><input type="number" min="0" name="bed_{{ $kind }}_max" value="{{ old('bed_'.$kind.'_max', $row?->max_per_room ?? 0) }}" class="input"></label>
            <label class="block"><span class="lbl">Rate / night</span><input type="number" step="0.01" min="0" name="bed_{{ $kind }}_rate" value="{{ old('bed_'.$kind.'_rate', $row?->rate_per_night ?? 0) }}" class="input"></label>
          </div>
          <div class="mt-1 flex gap-3 text-xs">
            <label class="flex items-center gap-1"><input type="checkbox" name="bed_{{ $kind }}_free" value="1" {{ old('bed_'.$kind.'_free', $row?->free) ? 'checked':'' }} class="h-4 w-4">Free</label>
            <label class="flex items-center gap-1"><input type="checkbox" name="bed_{{ $kind }}_per_stay" value="1" {{ old('bed_'.$kind.'_per_stay', $row?->per_stay) ? 'checked':'' }} class="h-4 w-4">Charged once per stay</label>
          </div>
        </div>
      @endforeach</div>
    <div><span class="lbl">Permitted occupancy combinations</span>
      @for($i = 0; $i < 3; $i++)
        @php $rule = $editing?->occupancyRules[$i] ?? null; @endphp
        <div class="mb-2 grid grid-cols-5 gap-1">
          <input type="number" min="0" name="rule_adults[]" value="{{ $rule?->adults }}" class="input" placeholder="Adults">
          <input type="number" min="0" name="rule_children[]" value="{{ $rule?->children }}" class="input" placeholder="Children">
          <input type="number" min="0" name="rule_infants[]" value="{{ $rule?->infants }}" class="input" placeholder="Infants">
          <input type="number" min="0" name="rule_extra_beds[]" value="{{ $rule?->extra_beds }}" class="input" placeholder="Beds">
          <input name="rule_label[]" value="{{ $rule?->label }}" class="input" placeholder="Label">
        </div>
      @endfor
      <p class="text-xs text-slate-500">Leave blank to allow any occupancy up to the room maximums.</p></div>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="extra_bed_allowed" value="1" {{ old('extra_bed_allowed', $editing?->extra_bed_allowed ?? 1) ? 'checked':'' }} class="h-4 w-4">Extra bed allowed</label>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" {{ old('active', $editing?->active ?? 1) ? 'checked':'' }} class="h-4 w-4">Active</label>
    <div class="flex gap-2"><button class="btn-gold">Save room</button>@if($editing)<a class="btn-outline" href="/contracts/rooms">Cancel</a>@endif</div>
  </form>
  @endif
</div>
@endsection
