@extends('layouts.app')
@section('title', 'Stop-sales')
@section('content')
<div class="grid gap-4 lg:grid-cols-3">
  <div class="card lg:col-span-2">
    <div class="card-title">Stop-sales &amp; closures</div>
    <div class="overflow-x-auto"><table class="tbl"><thead><tr><th>Hotel</th><th>Room</th><th>From</th><th>To</th><th>Reason</th><th></th></tr></thead>
      <tbody>@forelse($blackouts as $b)<tr>
        <td>{{ $b->hotel_name }}</td><td class="text-xs">{{ $b->room_name ?: 'All rooms' }}</td>
        <td>{{ \App\Support\Fmt::date((string) $b->start_date) }}</td><td>{{ \App\Support\Fmt::date((string) $b->end_date) }}</td>
        <td class="text-xs text-slate-600">{{ $b->reason }}</td>
        <td class="text-right">@if(can('manage_rates'))<form method="post" action="/contracts/blackouts/{{ $b->id }}/delete" onsubmit="return confirm('Remove this stop-sale?')">@csrf<button class="btn-sm btn-danger">Remove</button></form>@endif</td></tr>
      @empty<tr><td colspan="6" class="py-6 text-center text-slate-500">No closures recorded.</td></tr>@endforelse</tbody></table></div>
  </div>
  @if(can('manage_rates'))
  <form method="post" action="/contracts/blackouts" class="card space-y-3" x-data="{ hotel: '' }">@csrf
    <div class="card-title">Add a stop-sale</div>
    <label class="block"><span class="lbl">Hotel *</span><select name="hotel_id" x-model="hotel" class="input" required><option value="">—</option>@foreach($hotels as $h)<option value="{{ $h->id }}">{{ $h->name }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Room type (blank = whole hotel)</span><select name="room_type_id" class="input"><option value="">All rooms</option>@foreach($rooms as $rm)<option value="{{ $rm->id }}" x-show="hotel === '{{ $rm->hotel_id }}'">{{ $rm->name }}</option>@endforeach</select></label>
    <div class="grid gap-2 sm:grid-cols-2">
      <label class="block"><span class="lbl">From *</span><input type="date" name="start_date" value="{{ now()->toDateString() }}" class="input" required></label>
      <label class="block"><span class="lbl">To *</span><input type="date" name="end_date" value="{{ now()->addDay()->toDateString() }}" class="input" required></label>
    </div>
    <label class="block"><span class="lbl">Reason</span><input name="reason" value="Sold out by hotel" class="input" maxlength="190"></label>
    <button class="btn-gold w-full">Add closure</button>
    <p class="text-xs text-slate-500">Closed dates are excluded from availability search immediately and shown to staff with the reason.</p>
  </form>
  @endif
</div>
@endsection
