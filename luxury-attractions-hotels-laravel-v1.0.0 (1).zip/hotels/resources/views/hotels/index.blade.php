@extends('layouts.app')
@section('title', 'Hotels')
@section('content')
<div class="card">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div class="card-title mb-0">Contracted hotels &amp; suppliers</div>
    @if(can('manage_hotels'))<a class="btn-gold" href="/hotels/new">Add hotel</a>@endif
  </div>
  <form method="get" class="mt-3 grid gap-3 sm:grid-cols-4">
    <input name="q" value="{{ $q }}" class="input" placeholder="name, city or supplier code">
    <select name="city" class="input"><option value="">All cities</option>@foreach($cities as $c)<option value="{{ $c }}" {{ request('city')===$c?'selected':'' }}>{{ $c }}</option>@endforeach</select>
    <select name="group_id" class="input"><option value="">All groups</option>@foreach($groups as $g)<option value="{{ $g->id }}" {{ (int) request('group_id') === (int) $g->id ?'selected':'' }}>{{ $g->name }}</option>@endforeach</select>
    <button class="btn-primary">Filter</button>
  </form>
  <div class="mt-4 overflow-x-auto">
    <table class="tbl"><thead><tr><th>Hotel</th><th>City / area</th><th>Stars</th><th>Supplier code</th><th>Group</th><th class="text-right">Tourism tax</th><th>Status</th><th></th></tr></thead>
    <tbody>@forelse($hotels as $h)
      <tr>
        <td><a class="font-semibold text-navy-800 hover:underline" href="/hotels/{{ $h->id }}">{{ $h->name }}</a><div class="text-xs text-slate-500">{{ $h->business_type }}</div></td>
        <td>{{ $h->city }}<div class="text-xs text-slate-500">{{ $h->location?->name }}</div></td>
        <td class="text-gold-600">{{ \App\Support\Fmt::stars((int) $h->star_rating) }}</td>
        <td class="font-mono text-xs">{{ $h->supplier_code }}</td>
        <td>{{ $h->group?->name ?: '—' }}</td>
        <td class="text-right">{{ money($h->tourism_tax, $h->currency) }}<div class="text-xs text-slate-500">{{ lbl($h->tourism_tax_basis) }}</div></td>
        <td>{!! $h->active ? '<span class="badge bg-emerald-100 text-emerald-800">Active</span>' : '<span class="badge bg-slate-200 text-slate-600">Inactive</span>' !!}</td>
        <td class="text-right">@if(can('manage_hotels'))<a class="btn-sm btn-outline" href="/hotels/{{ $h->id }}/edit">Edit</a>@endif</td>
      </tr>
    @empty<tr><td colspan="8" class="py-6 text-center text-slate-500">No hotels yet. Add your first contracted supplier.</td></tr>@endforelse</tbody></table>
  </div>
  @include('partials.pagination', ['paginator' => $hotels])
</div>
@endsection
