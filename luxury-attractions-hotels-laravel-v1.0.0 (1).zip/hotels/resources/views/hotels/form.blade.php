@extends('layouts.app')
@section('title', $hotel ? 'Edit hotel' : 'Add hotel')
@section('content')
<form method="post" action="/hotels/{{ $hotel?->id }}" class="card space-y-4">@csrf
  <div class="card-title">{{ $hotel ? 'Edit '.$hotel->name : 'Add a contracted hotel' }}</div>
  <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
    <label class="block lg:col-span-2"><span class="lbl">Hotel name *</span><input name="name" value="{{ old('name', $hotel?->name) }}" class="input" required></label>
    <label class="block"><span class="lbl">Supplier code *</span><input name="supplier_code" value="{{ old('supplier_code', $hotel?->supplier_code) }}" class="input" required placeholder="AKE-DXB"></label>
    <label class="block"><span class="lbl">City *</span><input name="city" value="{{ old('city', $hotel?->city ?? 'Dubai') }}" class="input" required list="city-list">
      <datalist id="city-list">@foreach($locations as $l)<option value="{{ $l->city }}"></option>@endforeach</datalist></label>
    <label class="block"><span class="lbl">Area / location</span><select name="location_id" class="input"><option value="">—</option>@foreach($locations as $l)<option value="{{ $l->id }}" {{ (int) old('location_id', $hotel?->location_id) === (int) $l->id ? 'selected':'' }}>{{ $l->city }} · {{ $l->name }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Country</span><input name="country" value="{{ old('country', $hotel?->country ?? 'United Arab Emirates') }}" class="input"></label>
    <label class="block lg:col-span-2"><span class="lbl">Address</span><input name="address" value="{{ old('address', $hotel?->address) }}" class="input"></label>
    <label class="block"><span class="lbl">Star rating *</span><select name="star_rating" class="input">@for($s=1;$s<=5;$s++)<option value="{{ $s }}" {{ (int) old('star_rating', $hotel?->star_rating ?? 5) === $s ? 'selected':'' }}>{{ $s }}★</option>@endfor</select></label>
    <label class="block"><span class="lbl">Hotel group</span><select name="group_id" class="input"><option value="">—</option>@foreach($groups as $g)<option value="{{ $g->id }}" {{ (int) old('group_id', $hotel?->group_id) === (int) $g->id ?'selected':'' }}>{{ $g->name }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Business type</span><input name="business_type" value="{{ old('business_type', $hotel?->business_type ?? 'Hotel') }}" class="input"></label>
    <label class="block"><span class="lbl">Website</span><input name="website" value="{{ old('website', $hotel?->website) }}" class="input" placeholder="https://"></label>
    <label class="block"><span class="lbl">Contracts folder link (Drive)</span><input name="contracts_folder_link" value="{{ old('contracts_folder_link', $hotel?->contracts_folder_link) }}" class="input"></label>
    <label class="block"><span class="lbl">Media / photo link</span><input name="media_link" value="{{ old('media_link', $hotel?->media_link) }}" class="input"></label>
    <label class="block"><span class="lbl">Supplier email</span><input name="contact_email" type="email" value="{{ old('contact_email', $hotel?->contact_email) }}" class="input"></label>
    <label class="block"><span class="lbl">Supplier phone</span><input name="contact_phone" value="{{ old('contact_phone', $hotel?->contact_phone) }}" class="input"></label>
    <label class="block"><span class="lbl">Currency</span><input name="currency" value="{{ old('currency', $hotel?->currency ?? 'AED') }}" class="input" maxlength="8"></label>
    <label class="block"><span class="lbl">Check-in time</span><input name="check_in_time" value="{{ old('check_in_time', $hotel?->check_in_time ?? '15:00') }}" class="input"></label>
    <label class="block"><span class="lbl">Check-out time</span><input name="check_out_time" value="{{ old('check_out_time', $hotel?->check_out_time ?? '12:00') }}" class="input"></label>
    <label class="block"><span class="lbl">Tourism tax per unit</span><input name="tourism_tax" type="number" step="0.01" min="0" value="{{ old('tourism_tax', $hotel?->tourism_tax ?? 0) }}" class="input"></label>
    <label class="block"><span class="lbl">Tourism tax basis</span><select name="tourism_tax_basis" class="input">@foreach($taxBases as $value => $label)<option value="{{ $value }}" {{ old('tourism_tax_basis', $hotel?->tourism_tax_basis ?? 'room_night')===$value?'selected':'' }}>{{ $label }}</option>@endforeach</select></label>
  </div>
  <div>
    <span class="lbl">Amenities</span>
    <div class="flex flex-wrap gap-2">@php $current = collect(old('amenities', $hotel? $hotel->amenities->pluck('id')->all() : []))->map(fn($v)=>(int)$v)->all(); @endphp
      @foreach($amenities as $a)
        <label class="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-sm"><input type="checkbox" name="amenities[]" value="{{ $a->id }}" {{ in_array((int) $a->id, $current, true) ? 'checked' : '' }}>{{ $a->label }}</label>
      @endforeach</div>
  </div>
  <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" {{ old('active', $hotel?->active ?? 1) ? 'checked' : '' }} class="h-5 w-5"> Active – appears in availability search</label>
  <div class="flex gap-2"><button class="btn-gold">Save hotel</button><a class="btn-outline" href="/hotels">Cancel</a></div>
</form>
@endsection
