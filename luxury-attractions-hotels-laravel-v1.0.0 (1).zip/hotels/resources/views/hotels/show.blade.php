@extends('layouts.app')
@section('title', $hotel->name)
@section('content')
<div class="card">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div>
      <h1 class="text-xl font-bold">{{ $hotel->name }} <span class="text-gold-600">{{ \App\Support\Fmt::stars((int) $hotel->star_rating) }}</span></h1>
      <p class="text-sm text-slate-600">{{ $hotel->address }} · {{ $hotel->city }}{{ $hotel->location?->name ? ' · '.$hotel->location->name : '' }} · {{ $hotel->country }}</p>
      <p class="text-xs text-slate-500">Supplier code {{ $hotel->supplier_code }} · {{ $hotel->business_type }} · {{ $hotel->group?->name ?: 'Independent' }} · check-in {{ $hotel->check_in_time }} / out {{ $hotel->check_out_time }} · tourism tax {{ money($hotel->tourism_tax, $hotel->currency) }} {{ lbl($hotel->tourism_tax_basis) }}</p>
      <div class="mt-1 flex flex-wrap gap-1">@foreach($hotel->amenities as $a)<span class="badge bg-slate-100 text-slate-700">{{ $a->label }}</span>@endforeach</div>
    </div>
    <div class="flex flex-wrap gap-2">
      <a class="btn-outline" href="/search?hotel_id={{ $hotel->id }}">Search rates</a>
      @if($hotel->contracts_folder_link)<a class="btn-outline" href="{{ $hotel->contracts_folder_link }}" target="_blank" rel="noopener">Contracts folder</a>@endif
      @if(can('manage_hotels'))<a class="btn-gold" href="/hotels/{{ $hotel->id }}/edit">Edit</a>@endif
    </div>
  </div>
</div>

<div class="grid gap-4 lg:grid-cols-2">
  <div class="card">
    <div class="flex items-center justify-between"><div class="card-title mb-0">Room types ({{ $rooms->count() }})</div>
      @if(can('manage_rates'))<a class="btn-sm btn-outline" href="/contracts/rooms?hotel_id={{ $hotel->id }}">Manage rooms</a>@endif</div>
    <table class="tbl mt-3"><thead><tr><th>Room</th><th>Code</th><th>Category</th><th class="text-right">Sleeps</th><th class="text-right">Inventory</th></tr></thead>
      <tbody>@forelse($rooms as $r)<tr><td>{{ $r->name }}</td><td class="font-mono text-xs">{{ $r->code }}</td><td>{{ \App\Support\Catalog::categoryLabel($r->category) }}</td>
        <td class="text-right">{{ $r->max_adults }}A / {{ $r->max_children }}C / {{ $r->max_infants }}I</td><td class="text-right">{{ $r->default_inventory }}</td></tr>
      @empty<tr><td colspan="5" class="py-4 text-center text-slate-500">No rooms yet.</td></tr>@endforelse</tbody></table>
  </div>

  <div class="card">
    <div class="flex items-center justify-between"><div class="card-title mb-0">Contact people ({{ $contacts->count() }})</div>
      @if(can('manage_hotels'))<a class="btn-sm btn-outline" href="/contacts">Manage contacts</a>@endif</div>
    @forelse($contacts as $c)
      <div class="border-b border-slate-100 py-2 text-sm last:border-0">
        <div class="font-medium">{{ $c->name }} <span class="text-xs text-slate-500">{{ $c->position }}</span></div>
        <div class="flex flex-wrap gap-2 text-xs">
          @if($c->email)<a class="text-navy-700 underline" href="mailto:{{ $c->email }}">{{ $c->email }}</a>@endif
          @if($c->phone)<span>{{ $c->phone }}</span>@endif
          @foreach(['whatsapp','telegram','viber'] as $k)@if($c->$k && $c->phone)<a class="text-emerald-700 underline" href="{{ \App\Support\Catalog::messagingLink($k, $c->phone) }}">{{ ucfirst($k) }}</a>@endif @endforeach
          @if($c->business_card_link)<a class="underline" href="{{ $c->business_card_link }}" target="_blank" rel="noopener">Business card</a>@endif
        </div>
      </div>
    @empty<p class="text-sm text-slate-500">No contacts recorded.</p>@endforelse
  </div>
</div>

<div class="grid gap-4 lg:grid-cols-2">
  <div class="card">
    <div class="card-title">Contracted rates ({{ $rates->count() }})</div>
    <div class="max-h-96 overflow-y-auto"><table class="tbl"><thead><tr><th>Period</th><th>Board</th><th>Dates</th><th class="text-right">Net rate</th><th>Market</th></tr></thead>
      <tbody>@forelse($rates as $r)<tr><td>{{ $r->name }}</td><td>{{ \App\Support\Catalog::boardShort($r->board_type) }}</td>
        <td class="text-xs">{{ \App\Support\Fmt::date((string) $r->valid_from, 'd M') }} → {{ \App\Support\Fmt::date((string) $r->valid_to, 'd M Y') }}</td>
        <td class="text-right font-semibold">{{ money($r->base_rate, $hotel->currency) }}</td><td class="text-xs">{{ \App\Support\Catalog::marketLabel($r->market) }}</td></tr>
      @empty<tr><td colspan="5" class="py-4 text-center text-slate-500">No contracted rates yet.</td></tr>@endforelse</tbody></table></div>
  </div>
  <div class="card">
    <div class="card-title">Stop-sales</div>
    @forelse($blackouts as $b)<div class="border-b border-slate-100 py-2 text-sm last:border-0">
      {{ \App\Support\Fmt::date((string) $b->start_date) }} → {{ \App\Support\Fmt::date((string) $b->end_date) }} <span class="text-xs text-slate-500">{{ $b->reason }}</span></div>
    @empty<p class="text-sm text-slate-500">No closures.</p>@endforelse
    <div class="card-title mt-4">Recent bookings</div>
    @forelse($bookings as $b)<a href="/bookings/{{ $b->id }}" class="block border-b border-slate-100 py-2 text-sm last:border-0 hover:bg-slate-50">
      <div class="flex justify-between"><span class="font-medium">{{ $b->guest_name }}</span><span class="text-xs">{{ $b->reference }}</span></div>
      <div class="text-xs text-slate-600">{{ $b->room_name }} · {{ \App\Support\Fmt::date((string) $b->check_in) }} → {{ \App\Support\Fmt::date((string) $b->check_out) }} · {{ money($b->total_amount, $b->currency) }}</div></a>
    @empty<p class="text-sm text-slate-500">No bookings at this hotel yet.</p>@endforelse
  </div>
</div>
@endsection
