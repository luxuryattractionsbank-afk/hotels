@extends('layouts.app')
@section('title', 'Quotations')
@section('content')
<div class="card">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div class="card-title mb-0">Hotel quotations &amp; proposals</div>
    @if(can('manage_quotations'))<a class="btn-gold" href="/quotations/new">New quotation</a>@endif
  </div>
  <form method="get" class="mt-3 flex flex-wrap gap-2">
    <input name="q" value="{{ $q }}" class="input sm:max-w-xs" placeholder="Reference or client">
    <select name="status" class="input sm:max-w-40"><option value="">All statuses</option>@foreach($statuses as $s)<option value="{{ $s }}" {{ $status===$s?'selected':'' }}>{{ lbl($s) }}</option>@endforeach</select>
    <button class="btn-primary">Filter</button>
  </form>
  <div class="mt-4 overflow-x-auto"><table class="tbl"><thead><tr><th>Reference</th><th>Client</th><th>Market</th><th class="text-right">Net</th><th class="text-right">Markup</th><th class="text-right">Client total</th><th>Valid until</th><th>Status</th><th></th></tr></thead>
    <tbody>@forelse($quotations as $q2)<tr>
      <td class="font-mono text-xs"><a class="text-navy-700 underline" href="/quotations/{{ $q2->id }}">{{ $q2->reference }}</a></td>
      <td>{{ $q2->client_name }}<div class="text-xs text-slate-500">{{ $q2->client_email }}</div></td>
      <td class="text-xs">{{ \App\Support\Catalog::marketLabel($q2->market) }}</td>
      <td class="text-right text-xs">{{ money($q2->total_amount, $q2->currency) }}</td>
      <td class="text-right text-xs">{{ $q2->markup_percent }}% · {{ money($q2->markup_amount, $q2->currency) }}</td>
      <td class="text-right font-semibold">{{ money($q2->proposal_total, $q2->currency) }}</td>
      <td class="text-xs">{{ \App\Support\Fmt::date((string) $q2->valid_until) }}</td><td>{!! badge($q2->status) !!}</td>
      <td class="text-right whitespace-nowrap"><a class="btn-sm btn-outline" href="/quotations/{{ $q2->id }}/pdf">PDF</a> <a class="btn-sm btn-outline" href="/quotations/{{ $q2->id }}">Open</a></td></tr>
    @empty<tr><td colspan="9" class="py-6 text-center text-slate-500">No quotations yet.</td></tr>@endforelse</tbody></table></div>
  @include('partials.pagination', ['paginator' => $quotations])
</div>
@endsection
