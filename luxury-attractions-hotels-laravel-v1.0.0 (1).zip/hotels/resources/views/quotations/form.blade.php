@extends('layouts.app')
@section('title', $quotation ? 'Edit quotation' : 'New quotation')
@section('content')
@php
  $prefill = $fromSearch['offer'] ?? null; $ph = $fromSearch['hotel'] ?? null; $pr = $fromSearch['room'] ?? null; $pc = $fromSearch['criteria'] ?? [];
  $markup = old('markup_percent', $quotation?->markup_percent ?? $defaultMarkup);
@endphp
<form method="post" action="/quotations/{{ $quotation?->id }}" class="space-y-4" x-data="{
  lines: {{ Js::from(collect($quotation?->items ?? [])->map(fn($i) => ['hotel_id'=>$i->hotel_id,'room_type_id'=>$i->room_type_id,'board_type'=>$i->board_type,'check_in'=>(string) $i->check_in,'check_out'=>(string) $i->check_out,'adults'=>$i->adults,'children'=>$i->children,'infants'=>$i->infants,'rooms'=>$i->rooms])->values()->all()) }},
  prefilled: {{ Js::from($prefill ? ['hotel_id'=>$ph['id'],'room_type_id'=>$pr['id'],'board_type'=>$prefill['boardType'],'check_in'=>$pc['checkIn'],'check_out'=>$pc['checkOut'],'adults'=>$pc['adults'],'children'=>$pc['children'],'infants'=>$pc['infants'],'rooms'=>$pc['rooms']] : null) }},
  markup: {{ (float) $markup }},
  init() { if (this.prefilled && this.lines.length === 0) this.lines.push(this.prefilled); if (this.lines.length === 0) this.add(); }
}">@csrf
  <div class="card">
    <div class="card-title">Client</div>
    <div class="grid gap-3 sm:grid-cols-3">
      <label class="block"><span class="lbl">Client name *</span><input name="client_name" value="{{ old('client_name', $quotation?->client_name ?: ($ph['name'] ?? '')) }}" class="input" required></label>
      <label class="block"><span class="lbl">Client email</span><input name="client_email" type="email" value="{{ old('client_email', $quotation?->client_email) }}" class="input"></label>
      <label class="block"><span class="lbl">Client phone</span><input name="client_phone" value="{{ old('client_phone', $quotation?->client_phone) }}" class="input"></label>
      <label class="block"><span class="lbl">Source market</span><select name="market" class="input">@foreach($markets as $m)<option value="{{ $m->slug }}" {{ old('market', $quotation?->market ?? 'all')===$m->slug?'selected':'' }}>{{ $m->label }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Status</span><select name="status" class="input">@foreach(\App\Support\Catalog::STATUSES as $s)<option value="{{ $s }}" {{ old('status', $quotation?->status ?? 'draft')===$s?'selected':'' }}>{{ lbl($s) }}</option>@endforeach</select></label>
      <label class="block"><span class="lbl">Valid until</span><input type="date" name="valid_until" value="{{ old('valid_until', $quotation?->valid_until ?: now()->addDays(7)->toDateString()) }}" class="input"></label>
      <label class="block"><span class="lbl">Client markup %</span><input type="number" step="0.5" min="0" max="400" name="markup_percent" x-model="markup" class="input"></label>
      <label class="block"><span class="lbl">Currency</span><input name="currency" value="{{ old('currency', $quotation?->currency ?? 'AED') }}" class="input" maxlength="8"></label>
      <label class="flex items-end gap-2 pb-2 text-sm"><input type="checkbox" name="include_tourism_tax" value="1" {{ old('include_tourism_tax', $quotation?->include_tourism_tax ?? 1) ? 'checked':'' }} class="h-5 w-5">Include tourism tax</label>
    </div>
    <label class="mt-3 block"><span class="lbl">Internal notes (never printed)</span><textarea name="notes" rows="2" class="input">{{ old('notes', $quotation?->notes) }}</textarea></label>
  </div>

  <div class="card">
    <div class="flex items-center justify-between"><div class="card-title mb-0">Hotel lines</div>
      <button type="button" class="btn-outline btn-sm" @click="add()">+ Add line</button></div>
    <p class="mt-1 text-xs text-slate-500">Every line is priced from live contracts when you save – you cannot post your own amounts.</p>
    <template x-for="(line, i) in lines" :key="i">
      <div class="mt-3 grid gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-4">
        <label class="block"><span class="lbl">Hotel</span><select class="input" x-model="line.hotel_id" name="line[][hotel_id]" required><option value="">—</option>@foreach($hotels as $h)<option value="{{ $h->id }}">{{ $h->name }} ({{ $h->city }})</option>@endforeach</select></label>
        <label class="block"><span class="lbl">Room type</span><input class="input" type="number" x-model="line.room_type_id" name="line[][room_type_id]" placeholder="Room type ID" required></label>
        <label class="block"><span class="lbl">Board</span><select class="input" x-model="line.board_type" name="line[][board_type]">@foreach($boards as $value => [$label, $short])<option value="{{ $value }}">{{ $label }}</option>@endforeach</select></label>
        <div class="flex items-end"><button type="button" class="btn-danger btn-sm w-full" @click="lines.splice(i,1)">Remove line</button></div>
        <label class="block"><span class="lbl">Check-in</span><input type="date" class="input" x-model="line.check_in" name="line[][check_in]" required></label>
        <label class="block"><span class="lbl">Check-out</span><input type="date" class="input" x-model="line.check_out" name="line[][check_out]" required></label>
        <label class="block"><span class="lbl">Adults</span><input type="number" min="1" class="input" x-model="line.adults" name="line[][adults]"></label>
        <label class="block"><span class="lbl">Children</span><input type="number" min="0" class="input" x-model="line.children" name="line[][children]"></label>
        <label class="block"><span class="lbl">Infants</span><input type="number" min="0" class="input" x-model="line.infants" name="line[][infants]"></label>
        <label class="block"><span class="lbl">Rooms</span><input type="number" min="1" class="input" x-model="line.rooms" name="line[][rooms]"></label>
        <label class="block"><span class="lbl">Extra beds</span><input type="number" min="0" class="input" x-model="line.extra_beds" name="line[][extra_beds]"></label>
        <label class="block"><span class="lbl">Baby cots</span><input type="number" min="0" class="input" x-model="line.baby_cots" name="line[][baby_cots]"></label>
      </div>
    </template>
    <p class="mt-2 text-xs text-slate-500">Tip: use <b>Quote this</b> on the search screen to fill the room type and dates automatically.</p>
  </div>
  <div class="flex gap-2"><button class="btn-gold">Save &amp; price quotation</button><a class="btn-outline" href="/quotations">Cancel</a></div>
</form>
@endsection
