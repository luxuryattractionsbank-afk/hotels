@extends('layouts.app')
@section('title', $quotation->reference)
@section('content')
<div class="card">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div><h1 class="text-xl font-bold">{{ $quotation->reference }}</h1>
      <p class="text-sm text-slate-600">{{ $quotation->client_name }} · {{ \App\Support\Catalog::marketLabel($quotation->market) }} · {!! badge($quotation->status) !!}</p>
      <p class="text-xs text-slate-500">{{ $quotation->client_email }} {{ $quotation->client_phone }} · valid until {{ \App\Support\Fmt::date((string) $quotation->valid_until) }} · created {{ \App\Support\Fmt::date((string) $quotation->created_at, 'd M Y') }} by {{ $quotation->creator?->name ?: '—' }}</p></div>
    <div class="flex flex-wrap gap-2">
      <a class="btn-outline" href="/quotations/{{ $quotation->id }}/pdf">Download proposal PDF</a>
      @if(can('send_email'))<button class="btn-gold" onclick="document.getElementById('email-box').classList.toggle('hidden')">Email proposal</button>@endif
      @if(can('manage_quotations'))<a class="btn-outline" href="/quotations/{{ $quotation->id }}/edit">Edit</a>@endif
      @if(can('manage_packages'))<a class="btn-outline" href="/packages/new?quotation_id={{ $quotation->id }}">Build trip package</a>@endif
    </div>
  </div>
  @if(can('send_email'))
  <form id="email-box" method="post" action="/proposals/email" class="mt-3 hidden grid gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-2">@csrf
    <input type="hidden" name="kind" value="quotation"><input type="hidden" name="id" value="{{ $quotation->id }}">
    <label class="block sm:col-span-2"><span class="lbl">Send proposal PDF to</span><input name="to" type="email" value="{{ $quotation->client_email }}" class="input" required></label>
    <label class="block"><span class="lbl">Cc</span><input name="cc" class="input"></label>
    <label class="block"><span class="lbl">Subject</span><input name="subject" value="Hotel proposal {{ $quotation->reference }}" class="input" required></label>
    <label class="block sm:col-span-2"><span class="lbl">Message</span><textarea name="message" rows="3" class="input">Dear {{ $quotation->client_name }}, please find your hotel proposal attached.</textarea></label>
    <button class="btn-gold sm:col-span-2">Send with PDF attached</button>
  </form>@endif
</div>

<div class="card">
  <div class="card-title">Priced lines</div>
  @foreach($lines as $line)
  <div class="mb-3 rounded-lg border border-slate-200 p-3">
    <div class="flex flex-wrap items-start justify-between gap-2">
      <div><div class="font-semibold">{{ $line['hotel_name'] }} · {{ $line['room_name'] }}</div>
        <div class="text-xs text-slate-600">{{ \App\Support\Fmt::date($line['check_in']) }} → {{ \App\Support\Fmt::date($line['check_out']) }} · {{ $line['nights'] }} night(s) · {{ \App\Support\Catalog::boardLabel($line['board_type']) }} · {{ $line['rooms'] }} room(s) · {{ $line['adults'] }}A/{{ $line['children'] }}C/{{ $line['infants'] }}I</div>
        <div class="text-xs text-slate-500">Contracts: {{ $line['rate_names'] ?: '—' }}@if($line['promo_codes']) · promo {{ $line['promo_codes'] }}@endif</div></div>
      <div class="text-right"><div class="font-bold">{{ money($line['total_amount'], $quotation->currency) }}</div>
        @if(can('manage_bookings'))<form method="post" action="/quotations/{{ $quotation->id }}/convert" class="mt-1 space-y-1">@csrf
          <input type="hidden" name="item_id" value="{{ $line['id'] }}">
          <input name="guest_name" class="input" placeholder="Guest name" value="{{ $quotation->client_name }}" required>
          <input name="guest_email" type="email" class="input" placeholder="Guest email" value="{{ $quotation->client_email }}" required>
          <button class="btn-sm btn-primary w-full">Convert to booking</button></form>@endif</div>
    </div>
    @if(!empty($line['nightly']))
    <details class="mt-2"><summary class="cursor-pointer text-xs text-slate-600">Nightly net breakdown (staff only)</summary>
      <table class="tbl mt-2"><thead><tr><th>Night</th><th>Contract</th><th class="text-right">Room</th><th class="text-right">Board</th><th class="text-right">Occupancy</th><th class="text-right">Bedding</th><th class="text-right">Total</th></tr></thead>
      <tbody>@foreach($line['nightly'] as $n)<tr><td class="text-xs">{{ \App\Support\Fmt::date($n['date'] ?? '', 'D d M') }}</td><td class="text-xs">{{ $n['rateName'] ?? '' }}</td>
        <td class="text-right text-xs">{{ money($n['roomAmount'] ?? 0) }}</td><td class="text-right text-xs">{{ money($n['boardAmount'] ?? 0) }}</td>
        <td class="text-right text-xs">{{ money($n['supplementAmount'] ?? 0) }}</td><td class="text-right text-xs">{{ money($n['extraBedAmount'] ?? 0) }}</td>
        <td class="text-right text-xs font-semibold">{{ money($n['total'] ?? 0) }}</td></tr>@endforeach</tbody></table></details>
    @endif
  </div>
  @endforeach
  <div class="rounded-lg bg-slate-50 p-3 text-sm">
    <div class="flex justify-between"><span>Net supplier total</span><span>{{ money($quotation->total_amount, $quotation->currency) }}</span></div>
    <div class="flex justify-between"><span>Client markup ({{ $quotation->markup_percent }}%)</span><span>{{ money($quotation->markup_amount, $quotation->currency) }}</span></div>
    <div class="mt-1 flex justify-between border-t border-slate-200 pt-1 text-base font-bold"><span>Client proposal total</span><span>{{ money($quotation->proposal_total, $quotation->currency) }}</span></div>
    <p class="mt-1 text-xs text-slate-500">Only the client total appears on the PDF proposal.</p>
  </div>
</div>
@endsection
