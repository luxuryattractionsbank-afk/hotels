@extends('layouts.app')
@section('title', 'Settings')
@section('content')
<div class="grid gap-4 lg:grid-cols-2">
  <form method="post" action="/settings" class="card space-y-3">@csrf
    <div class="card-title">Company details (printed on proposals)</div>
    <label class="block"><span class="lbl">Company name *</span><input name="name" value="{{ old('name', $company['name'] ?? 'Luxury Attractions') }}" class="input" required></label>
    <div class="grid gap-2 sm:grid-cols-2">
      <label class="block"><span class="lbl">Phone</span><input name="phone" value="{{ old('phone', $company['phone'] ?? '') }}" class="input"></label>
      <label class="block"><span class="lbl">Email</span><input name="email" type="email" value="{{ old('email', $company['email'] ?? '') }}" class="input"></label>
      <label class="block"><span class="lbl">Website</span><input name="website" value="{{ old('website', $company['website'] ?? '') }}" class="input"></label>
      <label class="block"><span class="lbl">Default currency</span><select name="default_currency" class="input">@foreach($currencies as $c)<option value="{{ $c }}" {{ ($company['default_currency'] ?? 'AED')===$c?'selected':'' }}>{{ $c }}</option>@endforeach</select></label>
    </div>
    <label class="block"><span class="lbl">Address</span><input name="address" value="{{ old('address', $company['address'] ?? '') }}" class="input"></label>
    <label class="block"><span class="lbl">Default client markup %</span><input type="number" step="0.5" min="0" max="400" name="default_markup" value="{{ old('default_markup', $company['default_markup'] ?? 15) }}" class="input"></label>
    <button class="btn-gold">Save company details</button>
  </form>
  <div class="space-y-4">
    <div class="card"><div class="card-title">Email / SMTP</div>
      <table class="tbl"><tbody>
        <tr><td>Status</td><td>{!! $mail['configured'] ? '<span class="badge bg-emerald-100 text-emerald-800">Configured</span>' : '<span class="badge bg-amber-100 text-amber-800">Not configured – PDFs can still be downloaded</span>' !!}</td></tr>
        <tr><td>Driver</td><td>{{ $mail['driver'] }}</td></tr>
        <tr><td>Host / port</td><td>{{ $mail['host'] ?: '—' }} / {{ $mail['port'] ?: '—' }}</td></tr>
        <tr><td>From</td><td>{{ $mail['from'] ?: '—' }}</td></tr>
      </tbody></table>
      <p class="mt-2 text-xs text-slate-500">Set MAIL_HOST, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD and MAIL_MAILER=smtp in <code>.env</code>. Required for password recovery emails and emailing PDF proposals.</p></div>
    <div class="card"><div class="card-title">Installation</div>
      <table class="tbl"><tbody>
        <tr><td>Build version</td><td>{{ $version ?: '—' }}</td></tr>
        <tr><td>Installed</td><td class="text-xs">{{ $installed ?: 'lock file missing' }}</td></tr>
        <tr><td>MySQL tables</td><td>{{ count($tables) }}</td></tr>
        @foreach($counts as $label => $value)<tr><td>{{ \App\Support\Fmt::label($label) }}</td><td>{{ $value }}</td></tr>@endforeach
      </tbody></table>
      <p class="mt-2 text-xs text-slate-500">To run the browser installer again, delete <code>storage/installed.lock</code>. Existing data is never deleted by the installer.</p>
      <a class="btn-outline mt-2" href="/audit">View audit trail</a></div>
  </div>
</div>
@endsection
