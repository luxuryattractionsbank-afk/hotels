@extends('layouts.app')
@section('title', 'Bookings')
@section('content')
<div class="card">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div class="card-title mb-0">Confirmed hotel stays</div>
    @if(can('manage_bookings'))<a class="btn-gold" href="/bookings/new">New booking</a>@endif
  </div>
  <form method="get" class="mt-3 grid gap-2 sm:grid-cols-5">
    <input name="q" value="{{ request('q') }}" class="input" placeholder="Reference or guest">
    <select name="status" class="input"><option value="">All statuses</option>@foreach($statuses as $s)<option value="{{ $s }}" {{ request('status')===$s?'selected':'' }}>{{ lbl($s) }}</option>@endforeach</select>
    <input type="date" name="from" value="{{ request('from') }}" class="input">
    <input type="date" name="to" value="{{ request('to') }}" class="input">
    <button class="btn-primary">Filter</button>
  </form>
  <div class="mt-4 overflow-x-auto"><table class="tbl"><thead><tr><th>Reference</th><th>Guest</th><th>Hotel / room</th><th>Dates</th><th class="text-right">Rooms</th><th>Board</th><th class="text-right">Total</th><th>Status</th><th></th></tr></thead>
    <tbody>@forelse($bookings as $b)<tr>
      <td class="font-mono text-xs"><a class="text-navy-700 underline" href="/bookings/{{ $b->id }}">{{ $b->reference }}</a></td>
      <td>{{ $b->guest_name }}<div class="text-xs text-slate-500">{{ $b->guest_email }}</div></td>
      <td class="text-xs">{{ $b->hotel?->name }}<div class="text-slate-500">{{ $b->roomType?->name }}</div></td>
      <td class="text-xs">{{ \App\Support\Fmt::date((string) $b->check_in) }} → {{ \App\Support\Fmt::date((string) $b->check_out) }}<div class="text-slate-500">{{ $b->nights }} night(s) · {{ $b->adults }}A/{{ $b->children }}C/{{ $b->infants }}I</div></td>
      <td class="text-right">{{ $b->rooms }}</td><td class="text-xs">{{ \App\Support\Catalog::boardShort($b->board_type) }}</td>
      <td class="text-right font-semibold">{{ money($b->total_amount, $b->currency) }}</td><td>{!! badge($b->status) !!}</td>
      <td class="text-right"><a class="btn-sm btn-outline" href="/bookings/{{ $b->id }}">Open</a></td></tr>
    @empty<tr><td colspan="9" class="py-6 text-center text-slate-500">No bookings yet.</td></tr>@endforelse</tbody></table></div>
  @include('partials.pagination', ['paginator' => $bookings])
</div>
@endsection
