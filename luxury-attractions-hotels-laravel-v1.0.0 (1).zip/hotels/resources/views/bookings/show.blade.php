@extends('layouts.app')
@section('title', $booking->reference)
@section('content')
<div class="card">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div><h1 class="text-xl font-bold">{{ $booking->reference }}</h1>
      <p class="text-sm text-slate-600">{{ $booking->hotel?->name }} · {{ $booking->roomType?->name }} · {!! badge($booking->status) !!}</p>
      <p class="text-xs text-slate-500">{{ \App\Support\Fmt::date((string) $booking->check_in) }} → {{ \App\Support\Fmt::date((string) $booking->check_out) }} · {{ $booking->nights }} night(s) · {{ $booking->rooms }} room(s) · {{ $booking->adults }}A/{{ $booking->children }}C/{{ $booking->infants }}I
        @if($booking->extra_beds) · {{ $booking->extra_beds }} extra bed(s)@endif @if($booking->sofa_beds) · {{ $booking->sofa_beds }} sofa bed(s)@endif @if($booking->baby_cots) · {{ $booking->baby_cots }} cot(s)@endif</p></div>
    <div class="flex flex-wrap gap-2">
      <a class="btn-outline" href="/bookings/{{ $booking->id }}/pdf">Download PDF</a>
      @if(can('send_email'))<button class="btn-gold" onclick="document.getElementById('email-box').classList.toggle('hidden')">Email PDF</button>@endif
      @if(can('manage_bookings'))<form method="post" action="/bookings/{{ $booking->id }}/delete" onsubmit="return confirm('Delete this booking? The allocation is released.')">@csrf<button class="btn-danger">Delete</button></form>@endif
    </div>
  </div>
  @if(can('send_email'))
  <form id="email-box" method="post" action="/proposals/email" class="mt-3 hidden grid gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-2">@csrf
    <input type="hidden" name="kind" value="booking"><input type="hidden" name="id" value="{{ $booking->id }}">
    <label class="block sm:col-span-2"><span class="lbl">Send confirmation PDF to</span><input name="to" type="email" value="{{ $booking->guest_email }}" class="input" required></label>
    <label class="block"><span class="lbl">Cc</span><input name="cc" class="input"></label>
    <label class="block"><span class="lbl">Subject</span><input name="subject" value="Booking confirmation {{ $booking->reference }}" class="input" required></label>
    <label class="block sm:col-span-2"><span class="lbl">Message</span><textarea name="message" rows="3" class="input">Dear {{ $booking->guest_name }}, please find your hotel confirmation attached.</textarea></label>
    <button class="btn-gold sm:col-span-2">Send with PDF attached</button>
  </form>@endif
</div>

<div class="grid gap-4 lg:grid-cols-2">
  <div class="card">
    <div class="card-title">Guest &amp; hotel</div>
    <dl class="grid grid-cols-2 gap-2 text-sm">
      <dt class="text-slate-500">Guest</dt><dd class="font-medium">{{ $booking->guest_name }}</dd>
      <dt class="text-slate-500">Email</dt><dd>{{ $booking->guest_email }}</dd>
      <dt class="text-slate-500">Phone</dt><dd>{{ $booking->guest_phone ?: '—' }}</dd>
      <dt class="text-slate-500">Board</dt><dd>{{ \App\Support\Catalog::boardLabel($booking->board_type) }}</dd>
      <dt class="text-slate-500">Contract</dt><dd>{{ $booking->ratePeriod?->name ?: '—' }}</dd>
      <dt class="text-slate-500">Check-in / out</dt><dd>{{ $booking->hotel?->check_in_time }} / {{ $booking->hotel?->check_out_time }}</dd>
      <dt class="text-slate-500">Quotation</dt><dd>@if($booking->quotation_id)<a class="underline" href="/quotations/{{ $booking->quotation_id }}">{{ $booking->quotation?->reference }}</a>@else — @endif</dd>
      <dt class="text-slate-500">Created</dt><dd>{{ \App\Support\Fmt::date((string) $booking->created_at, 'd M Y H:i') }} by {{ $booking->creator?->name ?: '—' }}</dd>
    </dl>
    @if($booking->notes)<p class="mt-3 rounded-lg bg-slate-50 p-3 text-sm">{{ $booking->notes }}</p>@endif
    @if(can('manage_bookings'))
    <form method="post" action="/bookings/{{ $booking->id }}/status" class="mt-3 flex gap-2">@csrf
      <select name="status" class="input">@foreach(\App\Support\Catalog::STATUSES as $s)<option value="{{ $s }}" {{ $booking->status===$s?'selected':'' }}>{{ lbl($s) }}</option>@endforeach</select>
      <button class="btn-primary">Update status</button></form>@endif
  </div>
  <div class="card">
    <div class="card-title">Net supplier breakdown (staff only)</div>
    <table class="tbl"><tbody>
      @foreach ([['Room', $booking->base_amount], ['Board supplements', $booking->board_amount], ['Occupancy supplements', $booking->occupancy_amount],
                 ['Extra bedding', $booking->extra_bed_amount], ['Tourism tax', $booking->tourism_tax_amount]] as [$label, $amount])
        <tr><td>{{ $label }}</td><td class="text-right">{{ money($amount, $booking->currency) }}</td></tr>@endforeach
      <tr class="font-bold"><td>Net total</td><td class="text-right">{{ money($booking->total_amount, $booking->currency) }}</td></tr>
    </tbody></table>
    <p class="mt-2 text-xs text-slate-500">Never printed on client documents.</p>
    <div class="card-title mt-4">Nights</div>
    <div class="flex flex-wrap gap-1">@foreach($nights as $n)<span class="badge bg-slate-100 text-slate-700">{{ \App\Support\Fmt::date($n, 'D d M') }}</span>@endforeach</div>
  </div>
</div>
@endsection
