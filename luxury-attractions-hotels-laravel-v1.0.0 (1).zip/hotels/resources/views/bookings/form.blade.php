@extends('layouts.app')
@section('title', 'New booking')
@section('content')
@php $o = $offer['offer'] ?? null; $h = $offer['hotel'] ?? null; $rm = $offer['room'] ?? null; $c = $offer['criteria'] ?? []; @endphp
@if($o)<div class="card border-gold-500/40 bg-gold-500/10 text-sm">
  Priced from live contracts: <b>{{ $h['name'] }}</b> · {{ $rm['name'] }} · {{ \App\Support\Catalog::boardLabel($o['boardType']) }} ·
  {{ $o['nights'] }} night(s) · {{ $o['rooms'] }} room(s) · net total <b>{{ money($o['totalAmount'], $h['currency']) }}</b>.
  Amounts are recalculated server side when you save.</div>@endif
<form method="post" action="/bookings" class="card space-y-3">@csrf
  <div class="card-title">Confirm a hotel stay</div>
  <div class="grid gap-3 sm:grid-cols-3" x-data="{ hotel: '{{ $h['id'] ?? '' }}' }">
    <label class="block"><span class="lbl">Hotel *</span><select name="hotel_id" x-model="hotel" class="input" required><option value="">—</option>@foreach($hotels as $hh)<option value="{{ $hh->id }}" {{ (int) ($h['id'] ?? 0) === (int) $hh->id ? 'selected':'' }}>{{ $hh->name }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Room type *</span><select name="room_type_id" class="input" required><option value="">—</option>@foreach($rooms as $rr)<option value="{{ $rr->id }}" x-show="hotel === '{{ $rr->hotel_id }}'" {{ (int) ($rm['id'] ?? 0) === (int) $rr->id ? 'selected':'' }}>{{ $rr->name }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Board *</span><select name="board_type" class="input" required>@foreach($boards as $value => [$label, $short])<option value="{{ $value }}" {{ ($o['boardType'] ?? 'breakfast')===$value?'selected':'' }}>{{ $label }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Check-in *</span><input type="date" name="check_in" value="{{ $c['checkIn'] ?? now()->toDateString() }}" class="input" required></label>
    <label class="block"><span class="lbl">Check-out *</span><input type="date" name="check_out" value="{{ $c['checkOut'] ?? now()->addDays(2)->toDateString() }}" class="input" required></label>
    <label class="block"><span class="lbl">Status</span><select name="status" class="input">@foreach($statuses as $s)<option value="{{ $s }}" {{ $s==='confirmed'?'selected':'' }}>{{ lbl($s) }}</option>@endforeach</select></label>
    <label class="block"><span class="lbl">Adults *</span><input type="number" min="1" name="adults" value="{{ $c['adults'] ?? 2 }}" class="input" required></label>
    <label class="block"><span class="lbl">Children</span><input type="number" min="0" name="children" value="{{ $c['children'] ?? 0 }}" class="input"></label>
    <label class="block"><span class="lbl">Infants</span><input type="number" min="0" name="infants" value="{{ $c['infants'] ?? 0 }}" class="input"></label>
    <label class="block"><span class="lbl">Rooms *</span><input type="number" min="1" name="rooms" value="{{ $c['rooms'] ?? 1 }}" class="input" required></label>
    <label class="block"><span class="lbl">Extra beds</span><input type="number" min="0" name="extra_beds" value="{{ $c['extraBeds'] ?? 0 }}" class="input"></label>
    <label class="block"><span class="lbl">Baby cots</span><input type="number" min="0" name="baby_cots" value="{{ $c['babyCots'] ?? 0 }}" class="input"></label>
  </div>
  <div class="grid gap-3 sm:grid-cols-3">
    <label class="block"><span class="lbl">Guest name *</span><input name="guest_name" value="{{ old('guest_name') }}" class="input" required></label>
    <label class="block"><span class="lbl">Guest email *</span><input name="guest_email" type="email" value="{{ old('guest_email') }}" class="input" required></label>
    <label class="block"><span class="lbl">Guest phone</span><input name="guest_phone" value="{{ old('guest_phone') }}" class="input"></label>
  </div>
  <label class="block"><span class="lbl">Notes for the hotel</span><textarea name="notes" rows="2" class="input">{{ old('notes') }}</textarea></label>
  <div class="flex gap-2"><button class="btn-gold">Confirm booking</button><a class="btn-outline" href="/bookings">Cancel</a></div>
</form>
@endsection
