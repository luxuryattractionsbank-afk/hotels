import { db } from "@/db";
import { bookings } from "@/db/schema";
import { loadSearchContext } from "@/lib/search-data";
import { boardLabel, evaluateAvailability, parseCoreCriteria, todayIso } from "@/lib/search-engine";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    // Re-check the booking window against the real "today", not a value sent by the client.
    const criteria = { ...parseCoreCriteria(body), category: "any", bookingDate: todayIso() };
    const boardType = String(body.boardType || "");
    if (!criteria.hotelId || !criteria.roomTypeId || !boardType) {
      return Response.json({ error: "Select a hotel, room and board option from the search results." }, { status: 400 });
    }
    const guestName = String(body.guestName ?? "").trim();
    const guestEmail = String(body.guestEmail ?? "").trim();
    if (!guestName || !guestEmail) return Response.json({ error: "Guest name and email are required." }, { status: 400 });

    // Re-price on the server with the latest contracts, closures and inventory.
    const context = await loadSearchContext(criteria.checkIn, criteria.checkOut);
    const availability = evaluateAvailability(context, criteria);
    if (availability.error) return Response.json({ error: availability.error }, { status: 400 });
    const result = availability.results[0];
    if (!result) {
      const reason = availability.excluded[0]?.reason ?? "This room is no longer available.";
      return Response.json({ error: `Unavailable: ${reason}` }, { status: 409 });
    }
    const offer = result.offers.find((item) => item.boardType === boardType);
    if (!offer) return Response.json({ error: `${boardLabel(boardType)} is not contracted for every night of this stay.` }, { status: 409 });

    const reference = `LAH-${Date.now().toString().slice(-7)}-${Math.floor(Math.random() * 90 + 10)}`;
    const [booking] = await db
      .insert(bookings)
      .values({
        reference,
        hotelId: result.hotel.id,
        roomTypeId: result.room.id,
        ratePeriodId: offer.primaryRatePeriodId,
        boardType,
        guestName,
        guestEmail,
        guestPhone: String(body.guestPhone || ""),
        checkIn: criteria.checkIn,
        checkOut: criteria.checkOut,
        adults: criteria.adults,
        children: criteria.children,
        infants: criteria.infants,
        rooms: criteria.rooms,
        extraBeds: offer.extraBeds,
        nights: offer.nights,
        baseAmount: String(offer.baseAmount),
        boardAmount: String(offer.boardAmount),
        occupancyAmount: String(offer.occupancyAmount),
        extraBedAmount: String(offer.extraBedAmount),
        tourismTaxAmount: String(offer.tourismTaxAmount),
        totalAmount: String(offer.totalAmount),
        currency: result.hotel.currency,
        notes: String(body.notes || ""),
        status: "confirmed",
      })
      .returning();
    revalidatePath("/");
    return Response.json({ booking, offer }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to create this booking." }, { status: 400 });
  }
}
