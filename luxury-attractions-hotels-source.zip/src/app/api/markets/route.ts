import { db } from "@/db";
import { markets } from "@/db/schema";
import { slugifyLabel } from "@/lib/search-engine";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const label = String(body.label ?? "").trim();
    if (!label) return Response.json({ error: "Enter a market or nationality, e.g. DRC Nationals." }, { status: 400 });
    const slug = String(body.slug || slugifyLabel(label));
    if (!/^[a-z0-9_]+$/.test(slug)) return Response.json({ error: "Could not build a code for that name." }, { status: 400 });

    const [market] = await db
      .insert(markets)
      .values({ slug, label, sortOrder: Math.max(0, Number(body.sortOrder) || 200) })
      .onConflictDoUpdate({ target: markets.slug, set: { label, active: true } })
      .returning();
    revalidatePath("/");
    return Response.json({ market }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this market." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Market id is required." }, { status: 400 });
    await db.delete(markets).where(eq(markets.id, id));
    revalidatePath("/");
    return Response.json({ ok: true }, { status: 200 });
  } catch {
    return Response.json({ error: "Unable to delete this market. It may still be used by a rate line." }, { status: 400 });
  }
}
