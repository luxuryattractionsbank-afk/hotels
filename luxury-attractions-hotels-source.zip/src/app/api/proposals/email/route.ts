import { db } from "@/db";
import { quotations, tripPackages } from "@/db/schema";
import { permissionError, isEmail } from "@/lib/auth";
import { createQuotationPdf, createTripPackagePdf } from "@/lib/pdf";
import { quotationPdfData, tripPdfData } from "@/lib/proposal-pdf-data";
import { sendSmtpMail, smtpConfigured } from "@/lib/smtp";
import { and, eq, ne } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const denied = await permissionError("send_email");
  if (denied) return denied;
  return Response.json({
    configured: smtpConfigured(),
    from: process.env.SMTP_FROM_EMAIL ?? "",
    port: Number(process.env.SMTP_PORT || 587),
  });
}

export async function POST(request: Request) {
  const denied = await permissionError("send_email");
  if (denied) return denied;
  if (!smtpConfigured()) {
    return Response.json({ error: "SMTP is not configured. Set SMTP_HOST and SMTP_FROM_EMAIL (plus your provider's credentials) in the server environment." }, { status: 503 });
  }
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const type = body.type === "trip" ? "trip" : body.type === "quotation" ? "quotation" : null;
    const id = Number(body.id);
    const to = String(body.to ?? "").trim();
    if (!type || !Number.isSafeInteger(id) || id < 1 || !isEmail(to)) {
      return Response.json({ error: "Choose a saved proposal and enter one valid recipient email address." }, { status: 400 });
    }
    const input = type === "quotation" ? await quotationPdfData(id) : await tripPdfData(id);
    if (!input) return Response.json({ error: "The saved proposal could not be found." }, { status: 404 });

    const doc = type === "quotation" ? createQuotationPdf(input as NonNullable<Awaited<ReturnType<typeof quotationPdfData>>>) : createTripPackagePdf(input as NonNullable<Awaited<ReturnType<typeof tripPdfData>>>);
    const filename = `${input.reference}-${type === "quotation" ? "hotel-proposal" : "trip-package"}.pdf`;
    const pdf = Buffer.from(doc.output("arraybuffer"));
    const subject = String(body.subject || `Luxury Attractions ${type === "quotation" ? "hotel quotation" : "trip package"} — ${input.reference}`).trim().slice(0, 180);
    const defaultMessage = `Dear ${input.clientName},\n\nPlease find your ${type === "quotation" ? "hotel proposal" : "trip package and itinerary"} attached as a PDF.\n\nReference: ${input.reference}\n\nKind regards,\nLuxury Attractions`;
    const message = String(body.message || defaultMessage).trim().slice(0, 10_000);
    if (!subject || !message) return Response.json({ error: "Subject and message are required." }, { status: 400 });

    await sendSmtpMail({
      to,
      subject,
      text: message,
      attachments: [{ filename, content: pdf, contentType: "application/pdf" }],
    });
    if (type === "quotation") {
      await db.update(quotations).set({ status: "sent" }).where(and(eq(quotations.id, id), ne(quotations.status, "converted"), ne(quotations.status, "confirmed")));
    } else {
      await db.update(tripPackages).set({ status: "sent" }).where(and(eq(tripPackages.id, id), ne(tripPackages.status, "confirmed")));
    }
    revalidatePath("/");
    return Response.json({ ok: true, to, reference: input.reference, attachment: filename });
  } catch (cause) {
    console.error("SMTP proposal delivery failed:", cause);
    return Response.json({ error: "SMTP could not send the PDF. Verify the server SMTP host, port, credentials and TLS settings." }, { status: 502 });
  }
}
