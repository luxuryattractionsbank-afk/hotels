import { db } from "@/db";
import { hotels, locations } from "@/db/schema";
import { cleanPlace, findOrCreateLocation } from "@/lib/location-data";
import { count, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const city = cleanPlace(body.city);
    const name = cleanPlace(body.name);
    if (!city || !name) {
      return Response.json({ error: "Enter the city/emirate and the location inside it, e.g. Dubai → Deira." }, { status: 400 });
    }
    const id = await findOrCreateLocation(db, city, name);
    const [location] = await db.select().from(locations).where(eq(locations.id, id!)).limit(1);
    revalidatePath("/");
    return Response.json({ location }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this location." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Location id is required." }, { status: 400 });
    const [usage] = await db.select({ value: count() }).from(hotels).where(eq(hotels.locationId, id));
    const removed = await db.delete(locations).where(eq(locations.id, id)).returning({ id: locations.id });
    if (!removed.length) return Response.json({ error: "Location not found." }, { status: 404 });
    revalidatePath("/");
    // Hotels in this location keep their city; their location is simply cleared.
    return Response.json({ ok: true, hotelsCleared: usage?.value ?? 0 });
  } catch {
    return Response.json({ error: "Unable to delete this location." }, { status: 400 });
  }
}
