import { db } from "@/db";
import { occupancyRules, roomBedding, roomTypes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

/**
 * Duplicates a room type with its extra-bedding options and permitted occupancies.
 * Rate lines are commercial terms, so the copy starts without rates — add them as usual.
 */
export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const roomTypeId = Number((await params).id);
  if (!Number.isInteger(roomTypeId) || roomTypeId < 1) {
    return Response.json({ error: "Invalid room type." }, { status: 400 });
  }
  try {
    const [room] = await db.select().from(roomTypes).where(eq(roomTypes.id, roomTypeId)).limit(1);
    if (!room) return Response.json({ error: "Room type not found." }, { status: 404 });

    const [bedding, rules] = await Promise.all([
      db.select().from(roomBedding).where(eq(roomBedding.roomTypeId, roomTypeId)),
      db.select().from(occupancyRules).where(eq(occupancyRules.roomTypeId, roomTypeId)),
    ]);

    const created = await db.transaction(async (tx) => {
      // Keep codes unique inside the hotel by suffixing repeated duplicates.
      const taken = new Set(
        (await tx.select({ code: roomTypes.code }).from(roomTypes).where(eq(roomTypes.hotelId, room.hotelId)))
          .map((item) => item.code.toUpperCase()),
      );
      let code = `${room.code}-COPY`;
      let counter = 2;
      while (taken.has(code.toUpperCase())) code = `${room.code}-COPY-${counter++}`;

      const [copy] = await tx
        .insert(roomTypes)
        .values({
          hotelId: room.hotelId,
          name: `${room.name} (copy)`,
          code,
          category: room.category,
          description: room.description,
          mediaLink: room.mediaLink,
          maxAdults: room.maxAdults,
          maxChildren: room.maxChildren,
          maxInfants: room.maxInfants,
          includedAdults: room.includedAdults,
          baseSleeps: room.baseSleeps,
          defaultInventory: room.defaultInventory,
          extraBedAllowed: room.extraBedAllowed,
        })
        .returning();

      if (bedding.length > 0) {
        await tx.insert(roomBedding).values(bedding.map((item) => ({
          roomTypeId: copy.id,
          kind: item.kind,
          label: item.label,
          maxPerRoom: item.maxPerRoom,
          free: item.free,
          ratePerNight: item.ratePerNight,
          perStay: item.perStay,
          sortOrder: item.sortOrder,
        })));
      }
      if (rules.length > 0) {
        await tx.insert(occupancyRules).values(rules.map((rule) => ({
          roomTypeId: copy.id,
          adults: rule.adults,
          children: rule.children,
          infants: rule.infants,
          label: rule.label,
        })));
      }
      return copy;
    });

    revalidatePath("/");
    return Response.json(
      {
        room: created,
        copiedBedding: bedding.length,
        copiedOccupancies: rules.length,
        message: `Duplicated “${room.name}”. Add rate lines to make it sellable.`,
      },
      { status: 201 },
    );
  } catch {
    return Response.json({ error: "Unable to duplicate this room type." }, { status: 400 });
  }
}
