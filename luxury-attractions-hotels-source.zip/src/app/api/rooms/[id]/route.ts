import { db } from "@/db";
import { roomTypes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const roomTypeId = Number((await params).id);
  if (!Number.isInteger(roomTypeId) || roomTypeId < 1) {
    return Response.json({ error: "Invalid room type." }, { status: 400 });
  }
  try {
    const body = await request.json();
    const [room] = await db.select().from(roomTypes).where(eq(roomTypes.id, roomTypeId)).limit(1);
    if (!room) return Response.json({ error: "Room type not found." }, { status: 404 });

    const patch: Partial<typeof roomTypes.$inferInsert> = {};
    if (body.name !== undefined) {
      const name = String(body.name ?? "").trim();
      if (!name) return Response.json({ error: "Room name is required." }, { status: 400 });
      patch.name = name;
    }
    if (body.description !== undefined) patch.description = String(body.description ?? "").slice(0, 2000);
    if (body.mediaLink !== undefined) patch.mediaLink = String(body.mediaLink ?? "").trim().slice(0, 1000);
    if (body.defaultInventory !== undefined) {
      const inventory = Number(body.defaultInventory);
      if (!Number.isInteger(inventory) || inventory < 1 || inventory > 999) {
        return Response.json({ error: "Room inventory must be between 1 and 999." }, { status: 400 });
      }
      patch.defaultInventory = inventory;
    }
    if (body.baseSleeps !== undefined) {
      const baseSleeps = Number(body.baseSleeps);
      if (!Number.isInteger(baseSleeps) || baseSleeps < 1 || baseSleeps > 12) {
        return Response.json({ error: "Sleeps without extra bedding must be between 1 and 12." }, { status: 400 });
      }
      patch.baseSleeps = baseSleeps;
    }
    if (Object.keys(patch).length === 0) return Response.json({ error: "Nothing to update." }, { status: 400 });

    const [updated] = await db.update(roomTypes).set(patch).where(eq(roomTypes.id, roomTypeId)).returning();
    revalidatePath("/");
    return Response.json({ room: updated });
  } catch {
    return Response.json({ error: "Unable to update this room type." }, { status: 400 });
  }
}
