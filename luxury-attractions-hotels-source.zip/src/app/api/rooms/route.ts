import { db } from "@/db";
import { occupancyRules, roomBedding, roomTypes } from "@/db/schema";
import { revalidatePath } from "next/cache";
import { BEDDING_KINDS } from "@/lib/search-engine";

const BEDDING_INPUT: Record<string, { max: string; free: string; rate: string }> = {
  extra_bed: { max: "extraBedMax", free: "extraBedFree", rate: "extraBedRate" },
  sofa_bed: { max: "sofaBedMax", free: "sofaBedFree", rate: "sofaBedRate" },
  baby_cot: { max: "babyCotMax", free: "babyCotFree", rate: "babyCotRate" },
};

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const hotelId = Number(body.hotelId);
    const name = String(body.name ?? "").trim();
    const code = String(body.code ?? "").trim().toUpperCase();
    const category = String(body.category || "").trim();
    if (!hotelId || !name || !code || !category) {
      return Response.json({ error: "Hotel, room name, code and category are required." }, { status: 400 });
    }

    const maxAdults = Math.max(1, Number(body.maxAdults) || 2);
    const maxChildren = Math.max(0, Number(body.maxChildren) || 0);
    const maxInfants = Math.max(0, Number(body.maxInfants) || 0);
    const baseSleeps = Math.max(1, Number(body.baseSleeps) || 2);

    const [room] = await db
      .insert(roomTypes)
      .values({
        hotelId,
        name,
        code,
        category,
        description: String(body.description || ""),
        mediaLink: String(body.mediaLink || "").trim().slice(0, 1000),
        maxAdults,
        maxChildren,
        maxInfants,
        includedAdults: Math.max(1, Number(body.includedAdults) || 2),
        baseSleeps,
        defaultInventory: Math.max(1, Number(body.defaultInventory) || 1),
        extraBedAllowed: Number(body.extraBedMax) > 0,
      })
      .returning();

    const beddingValues = BEDDING_KINDS.flatMap((kind) => {
      const fields = BEDDING_INPUT[kind.value];
      const maxPerRoom = Math.max(0, Number(body[fields.max]) || 0);
      if (maxPerRoom === 0) return [];
      return [
        {
          roomTypeId: room.id,
          kind: kind.value,
          label: String(body[`${kind.value}Label`] || kind.label),
          maxPerRoom,
          free: Boolean(body[fields.free]),
          ratePerNight: String(Math.max(0, Number(body[fields.rate]) || 0)),
          perStay: Boolean(body[`${kind.value}PerStay`]),
          sortOrder: (BEDDING_KINDS.findIndex((item) => item.value === kind.value) + 1) * 10,
        },
      ];
    });
    if (beddingValues.length > 0) await db.insert(roomBedding).values(beddingValues);

    const rules: (typeof occupancyRules.$inferInsert)[] = [
      { roomTypeId: room.id, adults: 1, children: 0, infants: 0, label: "Single use" },
      { roomTypeId: room.id, adults: Math.min(2, maxAdults), children: 0, infants: 0, label: "Double" },
    ];
    if (maxChildren > 0) rules.push({ roomTypeId: room.id, adults: 1, children: Math.min(2, maxChildren), infants: 0, label: "1 adult + 2 children" });
    if (maxAdults > 2) rules.push({ roomTypeId: room.id, adults: maxAdults, children: 0, infants: 0, label: `${maxAdults} adults` });
    await db.insert(occupancyRules).values(rules);

    revalidatePath("/");
    return Response.json({ room }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("unique")
      ? "That room code already exists for this hotel."
      : "Unable to save this room type.";
    return Response.json({ error: message }, { status: 400 });
  }
}
