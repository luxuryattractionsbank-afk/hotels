import { db } from "@/db";
import { passwordResetTokens, users } from "@/db/schema";
import { currentUser, defaultPermissions, hasPermission, isEmail, normalizePermissions, PERMISSIONS, ROLE_NAMES, type UserRole } from "@/lib/auth";
import { ensureUsernames, normalizeUsername, validUsername } from "@/lib/usernames";
import { hash } from "bcryptjs";
import { and, count, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";
const roles = Object.keys(ROLE_NAMES) as UserRole[];
const safeFields = {
  id: users.id, name: users.name, username: users.username, email: users.email, role: users.role,
  permissions: users.permissions, active: users.active,
  createdAt: users.createdAt, updatedAt: users.updatedAt,
};

async function authorized() {
  const user = await currentUser();
  return user && hasPermission(user, "manage_users") ? user : null;
}

export async function GET() {
  const operator = await authorized();
  if (!operator) return Response.json({ error: "Administrator access required." }, { status: 403 });
  await ensureUsernames();
  const all = await db.select(safeFields).from(users).orderBy(users.createdAt);
  return Response.json({ users: all, permissionOptions: PERMISSIONS, roles: ROLE_NAMES });
}

export async function POST(request: Request) {
  const operator = await authorized();
  if (!operator) return Response.json({ error: "Administrator access required." }, { status: 403 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const username = normalizeUsername(body.username);
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    const role = String(body.role || "viewer") as UserRole;
    if (!roles.includes(role) || name.length < 2 || !validUsername(username) || !isEmail(email) || password.length < 12 || password.length > 200) {
      return Response.json({ error: "Enter a name, username (3–32 letters/numbers), valid email, role and password of at least 12 characters." }, { status: 400 });
    }
    const permissions = role === "admin" ? defaultPermissions(role) : body.permissions === undefined ? defaultPermissions(role) : normalizePermissions(body.permissions);
    if (role !== "admin" && permissions.includes("manage_users")) {
      return Response.json({ error: "Only administrators may manage users." }, { status: 400 });
    }
    const [created] = await db.insert(users).values({
      name: name.slice(0, 160), username, email, passwordHash: await hash(password, 12), role,
      permissions, active: true,
    }).returning(safeFields);
    return Response.json({ user: created }, { status: 201 });
  } catch (cause) {
    return Response.json({ error: cause instanceof Error && cause.message.includes("unique") ? "This username or email is already used by another account." : "Unable to create user." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  const operator = await authorized();
  if (!operator) return Response.json({ error: "Administrator access required." }, { status: 403 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!Number.isInteger(id) || id < 1) return Response.json({ error: "Select a valid user." }, { status: 400 });
    const [existing] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!existing) return Response.json({ error: "User not found." }, { status: 404 });

    const patch: Partial<typeof users.$inferInsert> = {};
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (name.length < 2) return Response.json({ error: "Name must be at least 2 characters." }, { status: 400 });
      patch.name = name.slice(0, 160);
    }
    if (body.username !== undefined) {
      const username = normalizeUsername(body.username);
      if (!validUsername(username)) return Response.json({ error: "Username must have 3–32 characters, start with a letter and use only letters, numbers, dots, underscores or hyphens." }, { status: 400 });
      patch.username = username;
    }
    if (body.email !== undefined) {
      const email = String(body.email).trim().toLowerCase();
      if (!isEmail(email)) return Response.json({ error: "Enter a valid email address." }, { status: 400 });
      patch.email = email;
    }
    if (body.role !== undefined) {
      const role = String(body.role) as UserRole;
      if (!roles.includes(role)) return Response.json({ error: "Choose a valid role." }, { status: 400 });
      patch.role = role;
      if (body.permissions === undefined) patch.permissions = defaultPermissions(role);
    }
    const resultRole = (patch.role ?? existing.role) as UserRole;
    if (body.permissions !== undefined) patch.permissions = resultRole === "admin" ? defaultPermissions("admin") : normalizePermissions(body.permissions);
    if (resultRole !== "admin" && (patch.permissions ?? normalizePermissions(existing.permissions)).includes("manage_users")) {
      return Response.json({ error: "Only administrators may manage users." }, { status: 400 });
    }
    if (body.active !== undefined) patch.active = body.active === true;
    if (body.password !== undefined && String(body.password).trim()) {
      const password = String(body.password);
      if (password.length < 12 || password.length > 200) return Response.json({ error: "New password must have at least 12 characters." }, { status: 400 });
      patch.passwordHash = await hash(password, 12);
    }
    if (!Object.keys(patch).length) return Response.json({ error: "Nothing to update." }, { status: 400 });
    if (id === operator.id && (patch.active === false || resultRole !== "admin")) {
      return Response.json({ error: "You cannot disable or demote your own administrator account." }, { status: 400 });
    }
    const changeAuth = patch.email !== undefined || patch.active !== undefined || patch.passwordHash !== undefined || patch.role !== undefined || patch.permissions !== undefined;
    const updated = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(786349133)`);
      if (existing.role === "admin" && (resultRole !== "admin" || patch.active === false)) {
        const [admins] = await tx.select({ count: count() }).from(users).where(and(eq(users.role, "admin"), eq(users.active, true)));
        if ((admins?.count ?? 0) <= 1) return null;
      }
      const [row] = await tx.update(users).set({ ...patch, updatedAt: new Date(), sessionVersion: changeAuth ? existing.sessionVersion + 1 : existing.sessionVersion }).where(eq(users.id, id)).returning(safeFields);
      if (patch.email !== undefined || patch.passwordHash !== undefined || patch.active === false) {
        await tx.delete(passwordResetTokens).where(eq(passwordResetTokens.userId, id));
      }
      return row;
    });
    if (!updated) return Response.json({ error: "At least one administrator must remain active." }, { status: 400 });
    return Response.json({ user: updated });
  } catch (cause) {
    return Response.json({ error: cause instanceof Error && cause.message.includes("unique") ? "This username or email is already used by another account." : "Unable to update user." }, { status: 400 });
  }
}
