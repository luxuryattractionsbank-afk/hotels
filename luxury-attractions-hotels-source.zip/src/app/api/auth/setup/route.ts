import { db } from "@/db";
import { users } from "@/db/schema";
import { defaultPermissions, getSession, isEmail } from "@/lib/auth";
import { normalizeUsername, validUsername } from "@/lib/usernames";
import { hash } from "bcryptjs";
import { sql } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const username = normalizeUsername(body.username);
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (name.length < 2 || name.length > 160 || !validUsername(username) || !isEmail(email) || password.length < 12 || password.length > 200) {
      return Response.json({ error: "Enter your name, a username (3–32 letters/numbers), valid email and a password of at least 12 characters." }, { status: 400 });
    }
    if (process.env.INITIAL_SETUP_TOKEN && body.setupToken !== process.env.INITIAL_SETUP_TOKEN) {
      return Response.json({ error: "Invalid setup token." }, { status: 403 });
    }

    const created = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(786349132)`);
      const existing = await tx.select({ id: users.id }).from(users).limit(1);
      if (existing.length) return null;
      const [user] = await tx.insert(users).values({
        name,
        username,
        email,
        passwordHash: await hash(password, 12),
        role: "admin",
        permissions: defaultPermissions("admin"),
      }).returning({ id: users.id, name: users.name, username: users.username, email: users.email });
      return user;
    });
    if (!created) return Response.json({ error: "Setup is complete. Sign in with your account." }, { status: 409 });
    const session = await getSession();
    session.userId = created.id;
    session.version = 1;
    await session.save();
    return Response.json({ ok: true, user: created }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to set up the administrator account." }, { status: 400 });
  }
}
