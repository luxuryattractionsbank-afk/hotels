import { db } from "@/db";
import { users } from "@/db/schema";
import { getSession, toSafeUser } from "@/lib/auth";
import { ensureUsernames, findUserByIdentifier } from "@/lib/usernames";
import { compare } from "bcryptjs";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const identifier = String(body.identifier ?? body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!identifier || identifier.length > 254 || !password) {
      return Response.json({ error: "Enter your username or email and password." }, { status: 400 });
    }
    await ensureUsernames();
    const user = await findUserByIdentifier(identifier);
    const genericError = "Username/email or password is incorrect, or this account is disabled.";
    if (!user || !user.active || (user.lockedUntil && user.lockedUntil > new Date())) {
      return Response.json({ error: user?.lockedUntil && user.lockedUntil > new Date() ? "Too many attempts. Try again in 15 minutes." : genericError }, { status: 401 });
    }
    if (!(await compare(password, user.passwordHash))) {
      const attempts = user.failedAttempts + 1;
      await db.update(users).set({
        failedAttempts: attempts >= 5 ? 0 : attempts,
        lockedUntil: attempts >= 5 ? new Date(Date.now() + 15 * 60 * 1000) : null,
      }).where(eq(users.id, user.id));
      return Response.json({ error: attempts >= 5 ? "Too many attempts. Try again in 15 minutes." : genericError }, { status: 401 });
    }
    await db.update(users).set({ failedAttempts: 0, lockedUntil: null }).where(eq(users.id, user.id));
    const session = await getSession();
    session.userId = user.id;
    session.version = user.sessionVersion;
    await session.save();
    return Response.json({ ok: true, user: toSafeUser(user) });
  } catch {
    return Response.json({ error: "Unable to sign in at the moment." }, { status: 500 });
  }
}
