import { db } from "@/db";
import { passwordResetTokens } from "@/db/schema";
import { sendSmtpMail, smtpConfigured } from "@/lib/smtp";
import { ensureUsernames, findUserByIdentifier } from "@/lib/usernames";
import { randomBytes, createHash } from "node:crypto";
import { and, eq, gte, sql } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const REPLY = "If an active account matches that username or email, a reset link will be sent to its registered email address.";
const headers = { "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" };

export async function GET() {
  return Response.json({ available: smtpConfigured() }, { headers });
}

export async function POST(request: Request) {
  if (!smtpConfigured()) {
    return Response.json({ error: "Email recovery is not configured yet. Please ask an administrator to reset your password." }, { status: 503, headers });
  }
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const identifier = String(body.identifier ?? "").trim().toLowerCase();
    if (!identifier || identifier.length > 254) {
      return Response.json({ error: "Enter your registered username or email." }, { status: 400, headers });
    }
    let origin: string;
    try {
      const url = new URL(process.env.APP_BASE_URL?.trim() || request.url);
      if (!["https:", "http:"].includes(url.protocol)) throw new Error("Invalid reset URL scheme");
      if (process.env.NODE_ENV === "production" && url.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(url.hostname)) throw new Error("Recovery links require HTTPS");
      origin = url.origin;
    } catch {
      return Response.json({ error: "The password-recovery URL is not configured correctly. Ask your administrator for help." }, { status: 503, headers });
    }
    await ensureUsernames();
    const user = await findUserByIdentifier(identifier);
    if (!user?.active) return Response.json({ message: REPLY }, { headers });

    const token = randomBytes(32).toString("base64url");
    const tokenHash = createHash("sha256").update(token).digest("hex");
    const now = new Date();
    // Limit each account to 3 requests per hour, and at least 60 seconds between requests.
    const created = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(786349135, ${user.id})`);
      const recent = await tx
        .select({ createdAt: passwordResetTokens.createdAt })
        .from(passwordResetTokens)
        .where(and(eq(passwordResetTokens.userId, user.id), gte(passwordResetTokens.createdAt, new Date(now.getTime() - 60 * 60 * 1000))));
      if (recent.length >= 3 || recent.some((item) => item.createdAt.getTime() > now.getTime() - 60 * 1000)) return null;
      const [row] = await tx.insert(passwordResetTokens).values({
        userId: user.id,
        tokenHash,
        expiresAt: new Date(now.getTime() + 30 * 60 * 1000),
      }).returning({ id: passwordResetTokens.id });
      return row;
    });
    if (!created) return Response.json({ message: REPLY }, { headers });

    // In local/managed previews we use the incoming origin; production should
    // set APP_BASE_URL to the canonical HTTPS host.
    const resetUrl = new URL("/reset-password", origin);
    resetUrl.searchParams.set("token", token);
    try {
      await sendSmtpMail({
        to: user.email,
        subject: "Reset your Luxury Attractions password",
        text: `Hello ${user.name},\n\nWe received a request to reset your Luxury Attractions Hotel Contracts password.\n\nOpen this link to choose a new password:\n${resetUrl.toString()}\n\nThis link can be used once and expires in 30 minutes. If you did not request a reset, ignore this email. Your existing password remains unchanged.\n\nLuxury Attractions`,
      });
    } catch (error) {
      // Never reveal whether an account exists through a different response.
      // Remove the undelivered token so it cannot be used if mail failed.
      await db.delete(passwordResetTokens).where(eq(passwordResetTokens.id, created.id));
      console.error("Password-recovery SMTP delivery failed:", error);
    }
    return Response.json({ message: REPLY }, { headers });
  } catch (error) {
    console.error("Password recovery request failed:", error);
    return Response.json({ message: REPLY }, { headers });
  }
}
