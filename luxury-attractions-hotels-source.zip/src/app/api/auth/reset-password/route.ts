import { db } from "@/db";
import { passwordResetTokens, users } from "@/db/schema";
import { hash } from "bcryptjs";
import { createHash } from "node:crypto";
import { and, eq, gt, isNull, sql } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" };
const validToken = (value: string) => /^[A-Za-z0-9_-]{43}$/.test(value);
const digest = (token: string) => createHash("sha256").update(token).digest("hex");
const invalid = () => Response.json({ error: "This reset link is invalid or has expired. Request a new one." }, { status: 400, headers });

export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("token") ?? "";
  if (!validToken(token)) return Response.json({ valid: false }, { headers });
  try {
    const [record] = await db
      .select({ id: passwordResetTokens.id, userId: passwordResetTokens.userId })
      .from(passwordResetTokens)
      .where(and(eq(passwordResetTokens.tokenHash, digest(token)), gt(passwordResetTokens.expiresAt, new Date()), isNull(passwordResetTokens.consumedAt)))
      .limit(1);
    if (!record) return Response.json({ valid: false }, { headers });
    const [account] = await db.select({ active: users.active }).from(users).where(eq(users.id, record.userId)).limit(1);
    return Response.json({ valid: account?.active === true }, { headers });
  } catch {
    return Response.json({ valid: false }, { headers });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const token = String(body.token ?? "");
    const password = String(body.password ?? "");
    const confirmPassword = String(body.confirmPassword ?? "");
    if (!validToken(token)) return invalid();
    if (password.length < 12 || password.length > 200 || password !== confirmPassword) {
      return Response.json({ error: "Enter matching passwords of at least 12 characters." }, { status: 400, headers });
    }
    const passwordHash = await hash(password, 12);
    const result = await db.transaction(async (tx) => {
      const [record] = await tx
        .select({ id: passwordResetTokens.id, userId: passwordResetTokens.userId })
        .from(passwordResetTokens)
        .where(and(eq(passwordResetTokens.tokenHash, digest(token)), gt(passwordResetTokens.expiresAt, new Date()), isNull(passwordResetTokens.consumedAt)))
        .limit(1);
      if (!record) return null;
      const [account] = await tx.select({ active: users.active }).from(users).where(eq(users.id, record.userId)).limit(1);
      if (!account?.active) return null;
      // Conditional UPDATE ensures concurrent requests cannot reuse the same link.
      const [consumed] = await tx.update(passwordResetTokens).set({ consumedAt: new Date() })
        .where(and(eq(passwordResetTokens.id, record.id), gt(passwordResetTokens.expiresAt, new Date()), isNull(passwordResetTokens.consumedAt)))
        .returning({ id: passwordResetTokens.id });
      if (!consumed) return null;
      await tx.update(users).set({
        passwordHash,
        failedAttempts: 0,
        lockedUntil: null,
        sessionVersion: sql`${users.sessionVersion} + 1`,
        updatedAt: new Date(),
      }).where(eq(users.id, record.userId));
      // Revoke any other outstanding reset links for this user.
      await tx.delete(passwordResetTokens).where(eq(passwordResetTokens.userId, record.userId));
      return true;
    });
    if (!result) return invalid();
    return Response.json({ ok: true, message: "Password changed. Sign in with your new password." }, { headers });
  } catch {
    return invalid();
  }
}
