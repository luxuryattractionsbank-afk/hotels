import { db } from "@/db";
import { users } from "@/db/schema";
import { currentUser } from "@/lib/auth";

export async function GET() {
  const [existing] = await db.select({ id: users.id }).from(users).limit(1);
  const user = await currentUser();
  return Response.json({ setupRequired: !existing, user });
}
