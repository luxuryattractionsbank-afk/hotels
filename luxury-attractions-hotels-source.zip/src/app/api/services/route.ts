import { db } from "@/db";
import { services } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

const priceFields = [
  "sharedOneWayPrice",
  "sharedTwoWayPrice",
  "private7OneWayPrice",
  "private7TwoWayPrice",
  "private12OneWayPrice",
  "private12TwoWayPrice",
  "ticketOnlyAdult",
  "ticketOnlyChild",
  "sharedAdult",
  "sharedChild",
  "privateAdult",
  "privateChild",
] as const;

function cleanPrice(value: unknown): string {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return "0";
  return String(Math.round(n * 100) / 100);
}

export async function GET() {
  try {
    const all = await db.select().from(services).orderBy(asc(services.sortOrder), asc(services.name));
    return Response.json({ services: all });
  } catch {
    return Response.json({ error: "Unable to load services." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    if (!name) return Response.json({ error: "Service name is required." }, { status: 400 });
    const kind = body.kind === "tour" ? "tour" : "transfer";
    const values: Record<string, unknown> = {
      kind,
      name: name.slice(0, 160),
      description: String(body.description ?? "").slice(0, 2000),
      city: String(body.city ?? "Dubai").slice(0, 120) || "Dubai",
      duration: String(body.duration ?? "").slice(0, 120),
      sortOrder: Math.max(0, Math.min(9999, Number(body.sortOrder) || 100)),
    };
    for (const field of priceFields) values[field] = cleanPrice(body[field]);
    const [service] = await db.insert(services).values(values as typeof services.$inferInsert).returning();
    revalidatePath("/");
    return Response.json({ service }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this service." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return Response.json({ error: "Service id is required." }, { status: 400 });
    const patch: Partial<typeof services.$inferInsert> = {};
    if (body.name !== undefined) {
      const name = String(body.name ?? "").trim();
      if (!name) return Response.json({ error: "Service name is required." }, { status: 400 });
      patch.name = name.slice(0, 160);
    }
    if (body.kind !== undefined) patch.kind = body.kind === "tour" ? "tour" : "transfer";
    if (body.description !== undefined) patch.description = String(body.description ?? "").slice(0, 2000);
    if (body.city !== undefined) patch.city = String(body.city ?? "").slice(0, 120);
    if (body.duration !== undefined) patch.duration = String(body.duration ?? "").slice(0, 120);
    if (body.sortOrder !== undefined) patch.sortOrder = Math.max(0, Math.min(9999, Number(body.sortOrder) || 100));
    if (body.active !== undefined) patch.active = body.active !== false;
    for (const field of priceFields) {
      if (body[field] !== undefined) (patch as Record<string, unknown>)[field] = cleanPrice(body[field]);
    }
    if (Object.keys(patch).length === 0) return Response.json({ error: "Nothing to update." }, { status: 400 });
    const [updated] = await db.update(services).set(patch).where(eq(services.id, id)).returning();
    if (!updated) return Response.json({ error: "Service not found." }, { status: 404 });
    revalidatePath("/");
    return Response.json({ service: updated });
  } catch {
    return Response.json({ error: "Unable to update this service." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Service id is required." }, { status: 400 });
    await db.delete(services).where(eq(services.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this service." }, { status: 400 });
  }
}
