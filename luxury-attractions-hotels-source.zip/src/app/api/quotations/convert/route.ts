import { db } from "@/db";
import { bookings, quotationItems, quotations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { priceLeg } from "../route";

/**
 * Converts a quotation into real bookings — one booking per leg (stay).
 * Every leg is re-priced against live contracts first; if any leg fails,
 * nothing is booked and the error names the leg.
 */
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return Response.json({ error: "Quotation id is required." }, { status: 400 });
    const guestName = String(body.guestName ?? "").trim();
    const guestEmail = String(body.guestEmail ?? "").trim();
    if (!guestName || !guestEmail) return Response.json({ error: "Guest name and email are required." }, { status: 400 });

    const [quotation] = await db.select().from(quotations).where(eq(quotations.id, id)).limit(1);
    if (!quotation) return Response.json({ error: "Quotation not found." }, { status: 404 });
    if (quotation.status === "converted") {
      return Response.json({ error: "This quotation was already converted into bookings." }, { status: 409 });
    }
    const items = (await db.select().from(quotationItems).where(eq(quotationItems.quotationId, id))).sort(
      (a, b) => a.position - b.position,
    );
    if (items.length === 0) return Response.json({ error: "This quotation has no stays to book." }, { status: 400 });

    // Validate + re-price all legs before creating anything.
    const priced: ({ item: (typeof items)[number] } & Awaited<ReturnType<typeof priceLeg>>)[] = [];
    for (let i = 0; i < items.length; i += 1) {
      const item = items[i];
      try {
        priced.push({
          item,
          ...(await priceLeg(
            {
              hotelId: item.hotelId,
              roomTypeId: item.roomTypeId,
              boardType: item.boardType,
              checkIn: item.checkIn,
              checkOut: item.checkOut,
              adults: item.adults,
              children: item.children,
              infants: item.infants,
              rooms: item.rooms,
              extraBeds: item.extraBeds,
              sofaBeds: item.sofaBeds,
              babyCots: item.babyCots,
            },
            quotation.market,
            i + 1,
          )),
        });
      } catch (error) {
        return Response.json({ error: error instanceof Error ? error.message : `Leg ${i + 1} could not be booked.` }, { status: 409 });
      }
    }

    const stamp = Date.now().toString().slice(-6);
    const created = await db.transaction(async (tx) => {
      const rows = [];
      for (let i = 0; i < priced.length; i += 1) {
        const { item, criteria, result, offer } = priced[i];
        const reference = `LAH-${stamp}-${String(Math.floor(Math.random() * 90 + 10))}${items.length > 1 ? `-${i + 1}` : ""}`;
        const [booking] = await tx
          .insert(bookings)
          .values({
            reference,
            hotelId: result.hotel.id,
            roomTypeId: result.room.id,
            ratePeriodId: offer.primaryRatePeriodId,
            boardType: offer.boardType,
            guestName,
            guestEmail,
            guestPhone: String(body.guestPhone || quotation.clientPhone || ""),
            checkIn: criteria.checkIn,
            checkOut: criteria.checkOut,
            adults: criteria.adults,
            children: criteria.children,
            infants: criteria.infants,
            rooms: criteria.rooms,
            extraBeds: offer.extraBeds,
            sofaBeds: offer.sofaBeds,
            babyCots: offer.babyCots,
            nights: offer.nights,
            baseAmount: String(offer.baseAmount),
            boardAmount: String(offer.boardAmount),
            occupancyAmount: String(offer.occupancyAmount),
            extraBedAmount: String(offer.extraBedAmount),
            tourismTaxAmount: String(offer.tourismTaxAmount),
            totalAmount: String(offer.totalAmount),
            currency: result.hotel.currency,
            notes: String(body.notes || `From quotation ${quotation.reference} (leg ${item.position})`),
            status: "confirmed",
            quotationId: quotation.id,
          })
          .returning();
        rows.push(booking);
      }
      await tx.update(quotations).set({ status: "converted" }).where(eq(quotations.id, id));
      return rows;
    });

    revalidatePath("/");
    return Response.json({ bookings: created }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to convert this quotation." }, { status: 400 });
  }
}
