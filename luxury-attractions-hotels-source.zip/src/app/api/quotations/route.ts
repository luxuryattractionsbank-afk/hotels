import { db } from "@/db";
import { quotationItems, quotations } from "@/db/schema";
import { computeProposal, sanitizeMarkupAmount, sanitizeMarkupPercent } from "@/lib/proposal";
import { loadSearchContext } from "@/lib/search-data";
import { boardLabel, CoreCriteria, evaluateAvailability, todayIso } from "@/lib/search-engine";
import { desc, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export type QuotationLegInput = {
  hotelId: number;
  roomTypeId: number;
  boardType: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children?: number;
  infants?: number;
  rooms?: number;
  extraBeds?: number;
  sofaBeds?: number;
  babyCots?: number;
  /** Market the leg was searched under; falls back to the quotation market. */
  market?: string;
};

export async function GET(request: Request) {
  try {
    const id = new URL(request.url).searchParams.get("id");
    if (id) {
      const [quotation] = await db.select().from(quotations).where(eq(quotations.id, Number(id))).limit(1);
      if (!quotation) return Response.json({ error: "Quotation not found." }, { status: 404 });
      const items = await db.select().from(quotationItems).where(eq(quotationItems.quotationId, quotation.id));
      items.sort((a, b) => a.position - b.position);
      return Response.json({ quotation, items });
    }
    const all = await db.select().from(quotations).orderBy(desc(quotations.createdAt), desc(quotations.id));
    const items = all.length
      ? await db.select().from(quotationItems)
      : [];
    items.sort((a, b) => a.position - b.position);
    return Response.json({ quotations: all, items });
  } catch {
    return Response.json({ error: "Unable to load quotations." }, { status: 500 });
  }
}

function legCriteria(leg: QuotationLegInput, market: string): CoreCriteria {
  return {
    checkIn: String(leg.checkIn),
    checkOut: String(leg.checkOut),
    adults: Math.max(1, Number(leg.adults) || 1),
    children: Math.max(0, Number(leg.children) || 0),
    infants: Math.max(0, Number(leg.infants) || 0),
    rooms: Math.max(1, Number(leg.rooms) || 1),
    extraBeds: Math.max(0, Number(leg.extraBeds) || 0),
    sofaBeds: Math.max(0, Number(leg.sofaBeds) || 0),
    babyCots: Math.max(0, Number(leg.babyCots) || 0),
    category: "any",
    market: String(leg.market || market || "all"),
    bookingDate: todayIso(),
    hotelId: Number(leg.hotelId),
    roomTypeId: Number(leg.roomTypeId),
  };
}

/** Re-prices one leg against live contracts. Throws an Error describing the problem. */
export async function priceLeg(leg: QuotationLegInput, market: string, legNo: number) {
  const boardType = String(leg.boardType || "");
  if (!leg.hotelId || !leg.roomTypeId || !boardType) {
    throw new Error(`Leg ${legNo}: hotel, room and board option are required.`);
  }
  const criteria = legCriteria(leg, market);
  const context = await loadSearchContext(criteria.checkIn, criteria.checkOut);
  const availability = evaluateAvailability(context, criteria);
  if (availability.error) throw new Error(`Leg ${legNo}: ${availability.error}`);
  const result = availability.results[0];
  if (!result) throw new Error(`Leg ${legNo} unavailable: ${availability.excluded[0]?.reason ?? "no longer available"}.`);
  const offer = result.offers.find((item) => item.boardType === boardType);
  if (!offer) throw new Error(`Leg ${legNo}: ${boardLabel(boardType)} is not contracted for every night of this stay.`);
  return { criteria, result, offer };
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const clientName = String(body.clientName ?? "").trim();
    if (!clientName) return Response.json({ error: "Client name is required." }, { status: 400 });
    const legs = (Array.isArray(body.items) ? body.items : []) as QuotationLegInput[];
    if (legs.length < 1 || legs.length > 12) {
      return Response.json({ error: "A quotation needs between 1 and 12 stays (legs)." }, { status: 400 });
    }
    const market = String(body.market || "all");
    const validUntilRaw = String(body.validUntil || "").trim();
    const validUntil = /^\d{4}-\d{2}-\d{2}$/.test(validUntilRaw) ? validUntilRaw : null;
    const includeTourismTax = body.includeTourismTax !== false;
    const markupPercent = sanitizeMarkupPercent(body.markupPercent);
    const markupAmount = sanitizeMarkupAmount(body.markupAmount);

    // Re-price every leg with live contracts before saving anything.
    const priced: Awaited<ReturnType<typeof priceLeg>>[] = [];
    for (let i = 0; i < legs.length; i += 1) {
      try {
        priced.push(await priceLeg(legs[i], market, i + 1));
      } catch (error) {
        return Response.json({ error: error instanceof Error ? error.message : `Leg ${i + 1} could not be priced.` }, { status: 409 });
      }
    }

    const total = priced.reduce((sum, leg) => sum + leg.offer.totalAmount, 0);
    const proposal = computeProposal(
      priced.map((leg) => ({
        totalAmount: leg.offer.totalAmount,
        tourismTaxAmount: leg.offer.tourismTaxAmount,
        nights: leg.offer.nights,
        rooms: leg.offer.rooms,
      })),
      { includeTourismTax, markupPercent, markupAmount },
    );
    const reference = `LAQ-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 90 + 10)}`;

    const created = await db.transaction(async (tx) => {
      const [quotation] = await tx
        .insert(quotations)
        .values({
          reference,
          clientName,
          clientEmail: String(body.clientEmail || ""),
          clientPhone: String(body.clientPhone || ""),
          market,
          status: "draft",
          totalAmount: String(Math.round(total * 100) / 100),
          currency: priced[0].result.hotel.currency || "AED",
          validUntil,
          notes: String(body.notes || ""),
          includeTourismTax,
          markupPercent: String(markupPercent),
          markupAmount: String(markupAmount),
          proposalTotal: String(proposal.proposalTotal),
        })
        .returning();
      const rows = await tx
        .insert(quotationItems)
        .values(
          priced.map(({ criteria, result, offer }, index) => ({
            quotationId: quotation.id,
            position: index + 1,
            hotelId: result.hotel.id,
            roomTypeId: result.room.id,
            ratePeriodId: offer.primaryRatePeriodId,
            boardType: offer.boardType,
            checkIn: criteria.checkIn,
            checkOut: criteria.checkOut,
            nights: offer.nights,
            adults: criteria.adults,
            children: criteria.children,
            infants: criteria.infants,
            rooms: criteria.rooms,
            extraBeds: offer.extraBeds,
            sofaBeds: offer.sofaBeds,
            babyCots: offer.babyCots,
            baseAmount: String(offer.baseAmount),
            boardAmount: String(offer.boardAmount),
            occupancyAmount: String(offer.occupancyAmount),
            extraBedAmount: String(offer.extraBedAmount),
            tourismTaxAmount: String(offer.tourismTaxAmount),
            totalAmount: String(offer.totalAmount),
            rateNames: offer.rateNames.join(" + "),
            promoCodes: offer.promoCodes.join(", "),
            allocationJson: JSON.stringify(result.allocation),
            nightlyJson: JSON.stringify(offer.nightly),
          })),
        )
        .returning();
      return { quotation, items: rows };
    });

    revalidatePath("/");
    return Response.json(created, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this quotation." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return Response.json({ error: "Quotation id is required." }, { status: 400 });
    const patch: Partial<typeof quotations.$inferInsert> = {};
    if (body.clientName !== undefined) patch.clientName = String(body.clientName);
    if (body.clientEmail !== undefined) patch.clientEmail = String(body.clientEmail);
    if (body.clientPhone !== undefined) patch.clientPhone = String(body.clientPhone);
    if (body.notes !== undefined) patch.notes = String(body.notes);
    if (body.validUntil !== undefined) {
      const value = String(body.validUntil || "");
      patch.validUntil = /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
    }
    if (body.status !== undefined) {
      const status = String(body.status);
      if (!["draft", "sent", "confirmed", "expired", "cancelled", "converted"].includes(status)) {
        return Response.json({ error: "Invalid status." }, { status: 400 });
      }
      patch.status = status;
    }
    const touchesPricing =
      body.includeTourismTax !== undefined || body.markupPercent !== undefined || body.markupAmount !== undefined;
    if (body.includeTourismTax !== undefined) patch.includeTourismTax = body.includeTourismTax !== false;
    if (body.markupPercent !== undefined) patch.markupPercent = String(sanitizeMarkupPercent(body.markupPercent));
    if (body.markupAmount !== undefined) patch.markupAmount = String(sanitizeMarkupAmount(body.markupAmount));
    if (Object.keys(patch).length === 0) return Response.json({ error: "Nothing to update." }, { status: 400 });
    const [updated] = await db.update(quotations).set(patch).where(eq(quotations.id, id)).returning();
    if (!updated) return Response.json({ error: "Quotation not found." }, { status: 404 });
    if (touchesPricing) {
      // Stored legs never change here — only the client-facing proposal math is recomputed.
      const items = await db.select().from(quotationItems).where(eq(quotationItems.quotationId, id));
      const proposal = computeProposal(
        items.map((item) => ({
          totalAmount: item.totalAmount,
          tourismTaxAmount: item.tourismTaxAmount,
          nights: item.nights,
          rooms: item.rooms,
        })),
        {
          includeTourismTax: updated.includeTourismTax,
          markupPercent: updated.markupPercent,
          markupAmount: updated.markupAmount,
        },
      );
      const [repriced] = await db
        .update(quotations)
        .set({ proposalTotal: String(proposal.proposalTotal) })
        .where(eq(quotations.id, id))
        .returning();
      revalidatePath("/");
      return Response.json({ quotation: repriced ?? updated });
    }
    revalidatePath("/");
    return Response.json({ quotation: updated });
  } catch {
    return Response.json({ error: "Unable to update this quotation." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Quotation id is required." }, { status: 400 });
    await db.delete(quotations).where(eq(quotations.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this quotation." }, { status: 400 });
  }
}
