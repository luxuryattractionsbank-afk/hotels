import { db } from "@/db";
import { blackoutDates } from "@/db/schema";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const hotelId = Number(body.hotelId);
    const startDate = String(body.startDate || "");
    const endDate = String(body.endDate || "");
    if (!hotelId || !startDate || !endDate || endDate < startDate) {
      return Response.json({ error: "Hotel and a valid closure date range are required." }, { status: 400 });
    }
    const [blackout] = await db
      .insert(blackoutDates)
      .values({
        hotelId,
        roomTypeId: body.roomTypeId ? Number(body.roomTypeId) : null,
        startDate,
        endDate,
        reason: String(body.reason || "Sold out by hotel"),
      })
      .returning();
    revalidatePath("/");
    return Response.json({ blackout }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this closure period." }, { status: 400 });
  }
}
