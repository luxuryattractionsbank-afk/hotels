import { db } from "@/db";
import {
  quotationItems,
  quotations,
  tripPackages,
  tripPackageTours,
  tripPackageTransfers,
} from "@/db/schema";
import { sanitizeMarkupAmount, sanitizeMarkupPercent } from "@/lib/proposal";
import { computeTripPackage, tourTotal, transferTotal, tripReference } from "@/lib/trip-package";
import { desc, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export type TripTransferInput = {
  serviceId?: number | null;
  serviceName: string;
  mode: string;
  direction: string;
  vehicle?: string;
  transferDate: string;
  transferTime?: string;
  pickup?: string;
  dropoff?: string;
  flightNo?: string;
  adults?: number;
  children?: number;
  vehicles?: number;
  unitPrice?: number | string;
  totalNet?: number | string;
  notes?: string;
};

export type TripTourInput = {
  serviceId?: number | null;
  serviceName: string;
  optionMode: string;
  tourDate: string;
  tourTime?: string;
  meetingPoint?: string;
  adults?: number;
  children?: number;
  priceAdult?: number | string;
  priceChild?: number | string;
  totalNet?: number | string;
  notes?: string;
};

const num = (value: unknown, fallback = 0) => {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
};
const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
const clean = (value: unknown, max = 500) => String(value ?? "").trim().slice(0, max);
const isoDate = (value: unknown) => (/^\d{4}-\d{2}-\d{2}$/.test(String(value ?? "")) ? String(value) : "");

function normalizeTransfer(raw: TripTransferInput, position: number) {
  const mode = raw.mode === "private" ? "private" : "shared";
  const direction = raw.direction === "twoway" ? "twoway" : "oneway";
  const adults = Math.max(0, Math.floor(num(raw.adults, 2)));
  const children = Math.max(0, Math.floor(num(raw.children, 0)));
  const vehicles = Math.max(1, Math.floor(num(raw.vehicles, 1)));
  const unitPrice = Math.max(0, num(raw.unitPrice, 0));
  const computed = transferTotal({ mode, direction, adults, children, vehicles, unitPrice });
  const totalNet = raw.totalNet !== undefined && raw.totalNet !== null && String(raw.totalNet) !== "" ? Math.max(0, num(raw.totalNet)) : computed;
  const date = isoDate(raw.transferDate);
  if (!date) throw new Error(`Transfer ${position}: date is required.`);
  if (!clean(raw.serviceName, 160)) throw new Error(`Transfer ${position}: service name is required.`);
  return {
    position,
    serviceId: raw.serviceId ? Number(raw.serviceId) : null,
    serviceName: clean(raw.serviceName, 160),
    mode,
    direction,
    vehicle: clean(raw.vehicle, 80),
    transferDate: date,
    transferTime: clean(raw.transferTime, 20),
    pickup: clean(raw.pickup),
    dropoff: clean(raw.dropoff),
    flightNo: clean(raw.flightNo, 40),
    adults,
    children,
    vehicles,
    unitPrice: String(round2(unitPrice)),
    totalNet: String(round2(totalNet)),
    notes: clean(raw.notes, 1000),
  };
}

function normalizeTour(raw: TripTourInput, position: number) {
  const optionMode = ["ticket_only", "shared", "private"].includes(String(raw.optionMode)) ? String(raw.optionMode) : "shared";
  const adults = Math.max(0, Math.floor(num(raw.adults, 2)));
  const children = Math.max(0, Math.floor(num(raw.children, 0)));
  const priceAdult = Math.max(0, num(raw.priceAdult, 0));
  const priceChild = Math.max(0, num(raw.priceChild, 0));
  const computed = tourTotal({ adults, children, priceAdult, priceChild });
  const totalNet = raw.totalNet !== undefined && raw.totalNet !== null && String(raw.totalNet) !== "" ? Math.max(0, num(raw.totalNet)) : computed;
  const date = isoDate(raw.tourDate);
  if (!date) throw new Error(`Tour ${position}: date is required.`);
  if (!clean(raw.serviceName, 160)) throw new Error(`Tour ${position}: tour name is required.`);
  return {
    position,
    serviceId: raw.serviceId ? Number(raw.serviceId) : null,
    serviceName: clean(raw.serviceName, 160),
    optionMode,
    tourDate: date,
    tourTime: clean(raw.tourTime, 20),
    meetingPoint: clean(raw.meetingPoint),
    adults,
    children,
    priceAdult: String(round2(priceAdult)),
    priceChild: String(round2(priceChild)),
    totalNet: String(round2(totalNet)),
    notes: clean(raw.notes, 1000),
  };
}

async function hotelLegsFor(quotationId: number | null) {
  if (!quotationId) return [];
  const items = await db.select().from(quotationItems).where(eq(quotationItems.quotationId, quotationId));
  return items
    .sort((a, b) => a.position - b.position)
    .map((item) => ({ totalAmount: item.totalAmount, tourismTaxAmount: item.tourismTaxAmount, nights: item.nights, rooms: item.rooms }));
}

export async function GET(request: Request) {
  try {
    const id = new URL(request.url).searchParams.get("id");
    if (id) {
      const [pkg] = await db.select().from(tripPackages).where(eq(tripPackages.id, Number(id))).limit(1);
      if (!pkg) return Response.json({ error: "Trip package not found." }, { status: 404 });
      const [transfers, tours] = await Promise.all([
        db.select().from(tripPackageTransfers).where(eq(tripPackageTransfers.packageId, pkg.id)),
        db.select().from(tripPackageTours).where(eq(tripPackageTours.packageId, pkg.id)),
      ]);
      transfers.sort((a, b) => a.position - b.position);
      tours.sort((a, b) => a.position - b.position);
      return Response.json({ package: pkg, transfers, tours });
    }
    const all = await db.select().from(tripPackages).orderBy(desc(tripPackages.createdAt), desc(tripPackages.id));
    const [transfers, tours] = all.length
      ? await Promise.all([db.select().from(tripPackageTransfers), db.select().from(tripPackageTours)])
      : [[], []];
    transfers.sort((a, b) => a.position - b.position);
    tours.sort((a, b) => a.position - b.position);
    return Response.json({ packages: all, transfers, tours });
  } catch {
    return Response.json({ error: "Unable to load trip packages." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const clientName = clean(body.clientName, 160);
    if (!clientName) return Response.json({ error: "Client name is required." }, { status: 400 });
    const quotationId = body.quotationId ? Number(body.quotationId) : null;
    if (quotationId) {
      const [q] = await db.select({ id: quotations.id }).from(quotations).where(eq(quotations.id, quotationId)).limit(1);
      if (!q) return Response.json({ error: "Linked quotation was not found." }, { status: 400 });
    }
    const rawTransfers = (Array.isArray(body.transfers) ? body.transfers : []) as TripTransferInput[];
    const rawTours = (Array.isArray(body.tours) ? body.tours : []) as TripTourInput[];
    if (!quotationId && rawTransfers.length === 0 && rawTours.length === 0) {
      return Response.json({ error: "Link a hotel quotation, or add at least one transfer or tour." }, { status: 400 });
    }
    let transfers: ReturnType<typeof normalizeTransfer>[] = [];
    let tours: ReturnType<typeof normalizeTour>[] = [];
    try {
      transfers = rawTransfers.map((t, i) => normalizeTransfer(t, i + 1));
      tours = rawTours.map((t, i) => normalizeTour(t, i + 1));
    } catch (error) {
      return Response.json({ error: error instanceof Error ? error.message : "Invalid itinerary item." }, { status: 400 });
    }

    const includeTourismTax = body.includeTourismTax !== false;
    const markupPercent = sanitizeMarkupPercent(body.markupPercent);
    const markupAmount = sanitizeMarkupAmount(body.markupAmount);
    const legs = await hotelLegsFor(quotationId);
    const totals = computeTripPackage(
      legs,
      transfers.reduce((s, t) => s + Number(t.totalNet), 0),
      tours.reduce((s, t) => s + Number(t.totalNet), 0),
      { includeTourismTax, markupPercent, markupAmount },
    );
    const validUntilRaw = clean(body.validUntil, 10);
    const reference = tripReference();

    const created = await db.transaction(async (tx) => {
      const [pkg] = await tx
        .insert(tripPackages)
        .values({
          reference,
          clientName,
          clientEmail: clean(body.clientEmail, 240),
          clientPhone: clean(body.clientPhone, 64),
          quotationId,
          market: clean(body.market, 60) || "all",
          status: "draft",
          adults: Math.max(1, Math.floor(num(body.adults, 2))),
          children: Math.max(0, Math.floor(num(body.children, 0))),
          infants: Math.max(0, Math.floor(num(body.infants, 0))),
          includeTourismTax,
          markupPercent: String(markupPercent),
          markupAmount: String(markupAmount),
          hotelsNet: String(totals.hotelsNet),
          transfersNet: String(totals.transfersNet),
          toursNet: String(totals.toursNet),
          subtotalNet: String(totals.subtotal),
          proposalTotal: String(totals.proposalTotal),
          currency: clean(body.currency, 8) || "AED",
          validUntil: /^\d{4}-\d{2}-\d{2}$/.test(validUntilRaw) ? validUntilRaw : null,
          notes: clean(body.notes, 2000),
        })
        .returning();
      const transferRows = transfers.length
        ? await tx.insert(tripPackageTransfers).values(transfers.map((t) => ({ ...t, packageId: pkg.id }))).returning()
        : [];
      const tourRows = tours.length ? await tx.insert(tripPackageTours).values(tours.map((t) => ({ ...t, packageId: pkg.id }))).returning() : [];
      return { package: pkg, transfers: transferRows, tours: tourRows };
    });
    revalidatePath("/");
    return Response.json(created, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this trip package." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return Response.json({ error: "Trip package id is required." }, { status: 400 });
    const [existing] = await db.select().from(tripPackages).where(eq(tripPackages.id, id)).limit(1);
    if (!existing) return Response.json({ error: "Trip package not found." }, { status: 404 });

    const patch: Partial<typeof tripPackages.$inferInsert> = {};
    if (body.clientName !== undefined) {
      const name = clean(body.clientName, 160);
      if (!name) return Response.json({ error: "Client name is required." }, { status: 400 });
      patch.clientName = name;
    }
    if (body.clientEmail !== undefined) patch.clientEmail = clean(body.clientEmail, 240);
    if (body.clientPhone !== undefined) patch.clientPhone = clean(body.clientPhone, 64);
    if (body.notes !== undefined) patch.notes = clean(body.notes, 2000);
    if (body.market !== undefined) patch.market = clean(body.market, 60) || "all";
    if (body.currency !== undefined) patch.currency = clean(body.currency, 8) || "AED";
    if (body.adults !== undefined) patch.adults = Math.max(1, Math.floor(num(body.adults, existing.adults)));
    if (body.children !== undefined) patch.children = Math.max(0, Math.floor(num(body.children, 0)));
    if (body.infants !== undefined) patch.infants = Math.max(0, Math.floor(num(body.infants, 0)));
    if (body.validUntil !== undefined) {
      const value = clean(body.validUntil, 10);
      patch.validUntil = /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
    }
    if (body.status !== undefined) {
      const status = String(body.status);
      if (!["draft", "sent", "confirmed", "expired", "cancelled"].includes(status)) {
        return Response.json({ error: "Invalid status." }, { status: 400 });
      }
      patch.status = status;
    }
    if (body.quotationId !== undefined) {
      const quotationId = body.quotationId ? Number(body.quotationId) : null;
      if (quotationId) {
        const [q] = await db.select({ id: quotations.id }).from(quotations).where(eq(quotations.id, quotationId)).limit(1);
        if (!q) return Response.json({ error: "Linked quotation was not found." }, { status: 400 });
      }
      patch.quotationId = quotationId;
    }
    if (body.includeTourismTax !== undefined) patch.includeTourismTax = body.includeTourismTax !== false;
    if (body.markupPercent !== undefined) patch.markupPercent = String(sanitizeMarkupPercent(body.markupPercent));
    if (body.markupAmount !== undefined) patch.markupAmount = String(sanitizeMarkupAmount(body.markupAmount));

    const replaceTransfers = Array.isArray(body.transfers);
    const replaceTours = Array.isArray(body.tours);
    let nextTransfers: ReturnType<typeof normalizeTransfer>[] | null = null;
    let nextTours: ReturnType<typeof normalizeTour>[] | null = null;
    try {
      if (replaceTransfers) nextTransfers = (body.transfers as TripTransferInput[]).map((t, i) => normalizeTransfer(t, i + 1));
      if (replaceTours) nextTours = (body.tours as TripTourInput[]).map((t, i) => normalizeTour(t, i + 1));
    } catch (error) {
      return Response.json({ error: error instanceof Error ? error.message : "Invalid itinerary item." }, { status: 400 });
    }
    if (Object.keys(patch).length === 0 && !replaceTransfers && !replaceTours) {
      return Response.json({ error: "Nothing to update." }, { status: 400 });
    }

    const updated = await db.transaction(async (tx) => {
      if (replaceTransfers) {
        await tx.delete(tripPackageTransfers).where(eq(tripPackageTransfers.packageId, id));
        if (nextTransfers!.length) await tx.insert(tripPackageTransfers).values(nextTransfers!.map((t) => ({ ...t, packageId: id })));
      }
      if (replaceTours) {
        await tx.delete(tripPackageTours).where(eq(tripPackageTours.packageId, id));
        if (nextTours!.length) await tx.insert(tripPackageTours).values(nextTours!.map((t) => ({ ...t, packageId: id })));
      }
      const [merged] = Object.keys(patch).length
        ? await tx.update(tripPackages).set(patch).where(eq(tripPackages.id, id)).returning()
        : await tx.select().from(tripPackages).where(eq(tripPackages.id, id)).limit(1);
      if (!merged) throw new Error("Trip package not found.");
      const [transferRows, tourRows] = await Promise.all([
        tx.select().from(tripPackageTransfers).where(eq(tripPackageTransfers.packageId, id)),
        tx.select().from(tripPackageTours).where(eq(tripPackageTours.packageId, id)),
      ]);
      const legs = merged.quotationId
        ? (await tx.select().from(quotationItems).where(eq(quotationItems.quotationId, merged.quotationId))).map((item) => ({
            totalAmount: item.totalAmount,
            tourismTaxAmount: item.tourismTaxAmount,
            nights: item.nights,
            rooms: item.rooms,
          }))
        : [];
      const totals = computeTripPackage(
        legs,
        transferRows.reduce((s, t) => s + Number(t.totalNet), 0),
        tourRows.reduce((s, t) => s + Number(t.totalNet), 0),
        { includeTourismTax: merged.includeTourismTax, markupPercent: merged.markupPercent, markupAmount: merged.markupAmount },
      );
      const [repriced] = await tx
        .update(tripPackages)
        .set({
          hotelsNet: String(totals.hotelsNet),
          transfersNet: String(totals.transfersNet),
          toursNet: String(totals.toursNet),
          subtotalNet: String(totals.subtotal),
          proposalTotal: String(totals.proposalTotal),
        })
        .where(eq(tripPackages.id, id))
        .returning();
      return repriced ?? merged;
    });

    revalidatePath("/");
    return Response.json({ package: updated });
  } catch {
    return Response.json({ error: "Unable to update this trip package." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Trip package id is required." }, { status: 400 });
    await db.delete(tripPackages).where(eq(tripPackages.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this trip package." }, { status: 400 });
  }
}
