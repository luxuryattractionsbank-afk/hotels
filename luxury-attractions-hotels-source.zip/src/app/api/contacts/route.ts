import { db } from "@/db";
import { hotelContactAssignments, hotelContacts, hotelGroups, hotels } from "@/db/schema";
import { ensureContactAssignments, parseContactIds, readContact } from "@/lib/contact-data";
import { and, eq, inArray } from "drizzle-orm";
import { revalidatePath } from "next/cache";

class ContactError extends Error {}

function positiveId(value: unknown): number | null {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

async function pruneContactIfUnused(tx: Parameters<Parameters<typeof db.transaction>[0]>[0], id: number) {
  const [contact] = await tx.select({ groupId: hotelContacts.groupId }).from(hotelContacts).where(eq(hotelContacts.id, id)).limit(1);
  if (!contact || contact.groupId) return;
  const [link] = await tx.select({ id: hotelContactAssignments.id }).from(hotelContactAssignments).where(eq(hotelContactAssignments.contactId, id)).limit(1);
  if (!link) await tx.delete(hotelContacts).where(eq(hotelContacts.id, id));
}

export async function POST(request: Request) {
  try {
    await ensureContactAssignments();
    const body = (await request.json()) as Record<string, unknown>;
    const details = readContact(body);
    if (!details.name) return Response.json({ error: "Contact name is required." }, { status: 400 });

    const hotelId = positiveId(body.hotelId);
    const explicitGroupId = positiveId(body.groupId);
    if (!hotelId && !explicitGroupId) {
      return Response.json({ error: "Choose a hotel or umbrella company for this contact." }, { status: 400 });
    }
    const selectedHotelIds = body.hotelIds === undefined ? [] : parseContactIds(body.hotelIds);
    if (selectedHotelIds === null) return Response.json({ error: "Invalid hotel selection." }, { status: 400 });

    const result = await db.transaction(async (tx) => {
      const [hotel] = hotelId
        ? await tx.select({ id: hotels.id, groupId: hotels.groupId }).from(hotels).where(eq(hotels.id, hotelId)).limit(1)
        : [];
      if (hotelId && !hotel) throw new ContactError("That hotel no longer exists.");

      const groupId = hotelId ? (body.addToGroup === true ? hotel?.groupId ?? null : null) : explicitGroupId;
      if (hotelId && body.addToGroup === true && !groupId) {
        throw new ContactError("Assign this hotel to an umbrella company before sharing the contact with it.");
      }
      if (explicitGroupId && hotel && hotel.groupId !== explicitGroupId) {
        throw new ContactError("The selected hotel does not belong to that umbrella company.");
      }
      if (groupId) {
        const [group] = await tx.select({ id: hotelGroups.id }).from(hotelGroups).where(eq(hotelGroups.id, groupId)).limit(1);
        if (!group) throw new ContactError("That umbrella company no longer exists.");
      }

      const hotelIds = [...new Set([...(hotelId ? [hotelId] : []), ...selectedHotelIds])];
      if (hotelIds.length > 0 && groupId) {
        const eligible = await tx.select({ id: hotels.id }).from(hotels).where(and(inArray(hotels.id, hotelIds), eq(hotels.groupId, groupId)));
        if (eligible.length !== hotelIds.length) throw new ContactError("Select only hotels in this umbrella company.");
      } else if (selectedHotelIds.length > 0) {
        throw new ContactError("Choose an umbrella company before assigning this contact to multiple hotels.");
      }

      const [contact] = await tx.insert(hotelContacts).values({ ...details, groupId }).returning();
      if (hotelIds.length) {
        await tx.insert(hotelContactAssignments).values(hotelIds.map((id) => ({ contactId: contact.id, hotelId: id })));
      }
      return { contact, hotelIds };
    });
    revalidatePath("/");
    return Response.json(result, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof ContactError ? error.message : "Unable to save this contact." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  try {
    await ensureContactAssignments();
    const body = (await request.json()) as Record<string, unknown>;
    const id = positiveId(body.id);
    if (!id) return Response.json({ error: "Contact id is required." }, { status: 400 });

    const result = await db.transaction(async (tx) => {
      const [contact] = await tx.select().from(hotelContacts).where(eq(hotelContacts.id, id)).limit(1);
      if (!contact) throw new ContactError("Contact not found.");

      if ("groupId" in body) {
        const groupId = body.groupId === null ? null : positiveId(body.groupId);
        if (body.groupId !== null && !groupId) throw new ContactError("Choose a valid umbrella company.");
        if (groupId) {
          const [group] = await tx.select({ id: hotelGroups.id }).from(hotelGroups).where(eq(hotelGroups.id, groupId)).limit(1);
          if (!group) throw new ContactError("Umbrella company not found.");
          if (contact.groupId && contact.groupId !== groupId) throw new ContactError("Remove this contact from its current group before sharing it with another.");
          const links = await tx.select({ hotelId: hotelContactAssignments.hotelId }).from(hotelContactAssignments).where(eq(hotelContactAssignments.contactId, id));
          if (links.length) {
            const inGroup = await tx.select({ id: hotels.id }).from(hotels).where(and(inArray(hotels.id, links.map((link) => link.hotelId)), eq(hotels.groupId, groupId)));
            if (inGroup.length !== links.length) throw new ContactError("This contact is used outside that umbrella company. Remove the other hotel assignments first.");
          }
        } else if (!contact.groupId) throw new ContactError("This contact is not shared with a group.");
        await tx.update(hotelContacts).set({ groupId }).where(eq(hotelContacts.id, id));
        if (!groupId) await pruneContactIfUnused(tx, id);
        return { ok: true, contactId: id, groupId };
      }

      const hotelId = positiveId(body.hotelId);
      if (!hotelId || typeof body.attached !== "boolean") throw new ContactError("Choose a hotel and an assignment action.");
      const [hotel] = await tx.select({ id: hotels.id, groupId: hotels.groupId }).from(hotels).where(eq(hotels.id, hotelId)).limit(1);
      if (!hotel) throw new ContactError("Hotel not found.");
      if (body.attached) {
        if (!hotel.groupId) throw new ContactError("The hotel must belong to an umbrella company to reuse a shared contact.");
        if (contact.groupId && contact.groupId !== hotel.groupId) throw new ContactError("This contact belongs to another umbrella company.");
        const linkedToSibling = await tx
          .select({ id: hotelContactAssignments.id })
          .from(hotelContactAssignments)
          .innerJoin(hotels, eq(hotelContactAssignments.hotelId, hotels.id))
          .where(and(eq(hotelContactAssignments.contactId, id), eq(hotels.groupId, hotel.groupId)))
          .limit(1);
        if (contact.groupId !== hotel.groupId && !linkedToSibling.length) {
          throw new ContactError("That contact does not belong to this umbrella company or one of its hotels.");
        }
        await tx.insert(hotelContactAssignments).values({ contactId: id, hotelId }).onConflictDoNothing({ target: [hotelContactAssignments.hotelId, hotelContactAssignments.contactId] });
      } else {
        const removed = await tx.delete(hotelContactAssignments).where(and(eq(hotelContactAssignments.hotelId, hotelId), eq(hotelContactAssignments.contactId, id))).returning({ id: hotelContactAssignments.id });
        if (!removed.length) throw new ContactError("The contact is not assigned to this hotel.");
        await pruneContactIfUnused(tx, id);
      }
      return { ok: true, contactId: id, hotelId, attached: body.attached };
    });
    revalidatePath("/");
    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error instanceof ContactError ? error.message : "Unable to update this contact." }, { status: 400 });
  }
}

/** Removing a hotel assignment must not remove the person from their group or any other hotel. */
export async function DELETE(request: Request) {
  try {
    await ensureContactAssignments();
    const params = new URL(request.url).searchParams;
    const id = positiveId(params.get("id"));
    const hotelId = positiveId(params.get("hotelId"));
    const groupId = positiveId(params.get("groupId"));
    if (!id || Number(Boolean(hotelId)) + Number(Boolean(groupId)) !== 1) {
      return Response.json({ error: "Choose exactly one hotel or umbrella company to remove the contact from." }, { status: 400 });
    }
    const result = await db.transaction(async (tx) => {
      if (hotelId) {
        const removed = await tx.delete(hotelContactAssignments).where(and(eq(hotelContactAssignments.hotelId, hotelId), eq(hotelContactAssignments.contactId, id))).returning({ id: hotelContactAssignments.id });
        if (!removed.length) throw new ContactError("The contact is not assigned to this hotel.");
        await pruneContactIfUnused(tx, id);
        return { ok: true, removedFrom: "hotel", hotelId, contactId: id };
      }
      const [contact] = await tx.select({ groupId: hotelContacts.groupId }).from(hotelContacts).where(eq(hotelContacts.id, id)).limit(1);
      if (!contact || contact.groupId !== groupId) throw new ContactError("The contact is not shared with this umbrella company.");
      await tx.update(hotelContacts).set({ groupId: null }).where(eq(hotelContacts.id, id));
      await pruneContactIfUnused(tx, id);
      return { ok: true, removedFrom: "group", groupId, contactId: id };
    });
    revalidatePath("/");
    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error instanceof ContactError ? error.message : "Unable to remove this contact." }, { status: 400 });
  }
}
