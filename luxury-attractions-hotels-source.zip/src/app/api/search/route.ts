import { seedHotelData } from "@/lib/hotel-data";
import { searchAllHotels } from "@/lib/search-data";
import { parseCoreCriteria, parseFilters } from "@/lib/search-engine";

export const dynamic = "force-dynamic";

async function handle(input: Record<string, unknown>) {
  try {
    await seedHotelData();
    const criteria = parseCoreCriteria(input);
    const filters = parseFilters(input);
    const response = await searchAllHotels(criteria, filters);
    return Response.json(response, { status: response.error ? 400 : 200 });
  } catch {
    return Response.json({ error: "Search failed. Please try again." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  return handle(body);
}

export async function GET(request: Request) {
  const params = Object.fromEntries(new URL(request.url).searchParams.entries());
  return handle(params);
}
