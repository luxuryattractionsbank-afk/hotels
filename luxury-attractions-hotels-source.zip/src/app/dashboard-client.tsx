"use client";

import {
  AlertTriangle,
  ArrowUpRight,
  BadgeDollarSign,
  BedDouble,
  BookOpenCheck,
  Building2,
  CalendarDays,
  CalendarX2,
  CarFront,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleDot,
  Clock3,
  Copy,
  ExternalLink,
  FileDown,
  FileText,
  Hotel,
  LayoutDashboard,
  Loader2,
  Luggage,
  Mail,
  MapPin,
  Menu,
  MoonStar,
  Plus,
  Search,
  SearchCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Trash2,
  UtensilsCrossed,
  UsersRound,
  WalletCards,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, ReactNode, useState } from "react";
import { BEDDING_KINDS, boardLabel, marketLabel, messagingLink, parseMarketList } from "@/lib/search-engine";
import { buildProposalText, computeProposal, copyText, ProposalTextLeg } from "@/lib/proposal";
import { createQuotationPdf, downloadQuotationPdf } from "@/lib/pdf";
import { sharePdf } from "@/lib/share-pdf";
import type { SafeUser, Permission } from "@/lib/auth";
import SearchPanel, { AmenityIcon, InitialSearch } from "./search-panel";
import ContactManager from "./contact-manager";
import ComboBox from "./combo-box";
import ServicesPanel, { ServiceRow } from "./services-panel";
import TripPackagesPanel, { TripPackageRow, TripTourRow, TripTransferRow } from "./trip-packages-panel";
import UsersPanel from "./users-panel";
import EmailProposalDialog, { type EmailTarget } from "./email-proposal-dialog";
import { groupContactCandidates } from "@/lib/contact-sharing";

type LocationRow = { id: number; city: string; name: string; active: boolean };

type HotelRow = {
  id: number;
  name: string;
  city: string;
  locationId: number | null;
  country: string;
  address: string;
  starRating: number;
  supplierCode: string;
  groupId: number | null;
  businessType: string;
  website: string;
  contractsFolderLink: string;
  mediaLink: string;
  contactEmail: string;
  contactPhone: string;
  currency: string;
  checkInTime: string;
  checkOutTime: string;
  tourismTax: string;
  tourismTaxBasis: string;
  active: boolean;
};

type RoomCategoryRow = { id: number; slug: string; label: string; sortOrder: number; active: boolean };

type BeddingRow = {
  id: number;
  roomTypeId: number;
  kind: string;
  label: string;
  maxPerRoom: number;
  free: boolean;
  ratePerNight: string;
  perStay: boolean;
  sortOrder: number;
};

type RoomRow = {
  id: number;
  hotelId: number;
  name: string;
  code: string;
  category: string;
  description: string;
  mediaLink: string;
  maxAdults: number;
  maxChildren: number;
  maxInfants: number;
  includedAdults: number;
  baseSleeps: number;
  defaultInventory: number;
  extraBedAllowed: boolean;
  active: boolean;
};

type AmenityRow = { id: number; slug: string; label: string; icon: string; sortOrder: number; active: boolean };
type HotelAmenityRow = { id: number; hotelId: number; amenityId: number };
type MarketRow = { id: number; slug: string; label: string; sortOrder: number; active: boolean };
type HotelGroupRow = { id: number; name: string; website: string; notes: string; active: boolean };

type ContactRow = {
  id: number;
  hotelId: number | null;
  groupId: number | null;
  name: string;
  position: string;
  email: string;
  phone: string;
  businessCardLink: string;
  whatsapp: boolean;
  telegram: boolean;
  viber: boolean;
  otherContact: string;
  active: boolean;
};

type OccupancyRow = { id: number; roomTypeId: number; adults: number; children: number; infants: number; extraBeds: number; label: string };

type RateRow = {
  id: number;
  hotelId: number;
  roomTypeId: number;
  name: string;
  boardType: string;
  validFrom: string;
  validTo: string;
  bookingWindowStart: string | null;
  bookingWindowEnd: string | null;
  market: string;
  marketExclusions: string;
  promoCode: string;
  baseRate: string;
  rateBasis: string;
  boardAdultSupplement: string;
  boardChildSupplement: string;
  boardSupplementBasis: string;
  extraAdultRate: string;
  extraChildRate: string;
  extraBedRate: string;
  extraBedBasis: string;
  minimumNights: number;
  active: boolean;
};

type BlackoutRow = { id: number; hotelId: number; roomTypeId: number | null; startDate: string; endDate: string; reason: string };

type BookingRow = {
  id: number;
  reference: string;
  hotelId: number;
  roomTypeId: number;
  boardType: string;
  guestName: string;
  guestEmail: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  nights: number;
  tourismTaxAmount: string;
  totalAmount: string;
  currency: string;
  status: string;
  quotationId: number | null;
};

type QuotationRow = {
  id: number;
  reference: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  market: string;
  status: string;
  totalAmount: string;
  currency: string;
  validUntil: string | null;
  notes: string;
  includeTourismTax: boolean;
  markupPercent: string;
  markupAmount: string;
  proposalTotal: string;
  createdAt: string;
};

type QuotationItemRow = {
  id: number;
  quotationId: number;
  position: number;
  hotelId: number;
  roomTypeId: number;
  ratePeriodId: number;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  extraBeds: number;
  sofaBeds: number;
  babyCots: number;
  baseAmount: string;
  boardAmount: string;
  occupancyAmount: string;
  extraBedAmount: string;
  tourismTaxAmount: string;
  totalAmount: string;
  rateNames: string;
  promoCodes: string;
  allocationJson: string;
  nightlyJson: string;
};

export type DashboardData = {
  hotels: HotelRow[];
  locations: LocationRow[];
  markets: MarketRow[];
  hotelGroups: HotelGroupRow[];
  contacts: ContactRow[];
  contactAssignments: { id: number; hotelId: number; contactId: number; createdAt: string }[];
  amenities: AmenityRow[];
  hotelAmenities: HotelAmenityRow[];
  roomCategories: RoomCategoryRow[];
  rooms: RoomRow[];
  bedding: BeddingRow[];
  occupancies: OccupancyRow[];
  rates: RateRow[];
  blackouts: BlackoutRow[];
  bookings: BookingRow[];
  quotations: QuotationRow[];
  quotationItems: QuotationItemRow[];
  services: ServiceRow[];
  tripPackages: TripPackageRow[];
  tripTransfers: TripTransferRow[];
  tripTours: TripTourRow[];
};

export type View = "search" | "dashboard" | "hotels" | "rooms" | "rates" | "blackouts" | "bookings" | "quotations" | "services" | "trips" | "users";
type Dialog = "hotel" | "room" | "rate" | "blackout" | "amenity" | "hotelAmenities" | "category" | "contact" | "group" | "market" | "locations" | null;

const navItems: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "search", label: "Search & compare", icon: SearchCheck },
  { id: "dashboard", label: "Overview", icon: LayoutDashboard },
  { id: "bookings", label: "Bookings", icon: BookOpenCheck },
  { id: "quotations", label: "Quotations", icon: FileText },
  { id: "trips", label: "Trip packages", icon: Luggage },
  { id: "services", label: "Services & tours", icon: CarFront },
  { id: "hotels", label: "Hotels", icon: Building2 },
  { id: "rooms", label: "Room types", icon: BedDouble },
  { id: "rates", label: "Rates & board", icon: BadgeDollarSign },
  { id: "blackouts", label: "Blackout dates", icon: CalendarX2 },
  { id: "users", label: "Users & permissions", icon: UsersRound },
];

const pageTitles: Record<View, { eyebrow: string; title: string; copy: string }> = {
  search: { eyebrow: "All contracted hotels", title: "Search & compare rates", copy: "Enter the stay and guests — every contract is checked and priced for you." },
  dashboard: { eyebrow: "Contract operations", title: "Portfolio overview", copy: "Key figures across your hotel contracts and reservations." },
  hotels: { eyebrow: "Supplier portfolio", title: "Contracted hotels", copy: "Supplier details, check-in policies and tourism taxes." },
  rooms: { eyebrow: "Accommodation", title: "Room types & occupancy", copy: "Room categories, inventory, guest limits and permitted occupancy combinations." },
  rates: { eyebrow: "Commercial contracts", title: "Rates & board plans", copy: "Seasonal net prices, meal supplements and extra-bed costs." },
  blackouts: { eyebrow: "Availability controls", title: "Blackout dates", copy: "Fully booked and stop-sale dates sent by hotels. These rooms never appear in search." },
  bookings: { eyebrow: "Reservation desk", title: "Bookings", copy: "Confirmed reservations with their stored cost." },
  quotations: { eyebrow: "Quotations", title: "Saved quotations", copy: "Single- or multi-hotel quotes built from search. Convert any quotation into bookings." },
  trips: { eyebrow: "Trip packages", title: "Trip packages", copy: "Hotel quotation + transfers + tours in one client itinerary with a single PDF." },
  services: { eyebrow: "Internal rates", title: "Services & tours", copy: "Net supplier costs for airport transfers, tours and tickets. Client markup is added per package." },
  users: { eyebrow: "Administration", title: "Team access", copy: "Manage user accounts, roles, permissions and active status." },
};

const formatMoney = (value: number | string, currency = "AED") =>
  `${currency} ${Number(value).toLocaleString("en-AE", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

const formatDate = (date: string, options?: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat("en-GB", options ?? { day: "2-digit", month: "short", year: "numeric" }).format(new Date(`${date.slice(0, 10)}T00:00:00Z`));

const hotelInitials = (name: string) =>
  name
    .split(" ")
    .filter((word) => word.length > 2 && word !== "The")
    .slice(0, 2)
    .map((word) => word[0])
    .join("");

const card = "rounded-2xl border border-slate-200/80 bg-white shadow-[0_2px_10px_rgba(15,23,42,0.025)]";
const inputClass = "h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10";
const selectClass = `${inputClass} appearance-none pr-9`;

function QuoteStatusBadge({ status }: { status: string }) {
  const tones: Record<string, [string, string]> = {
    draft: ["bg-slate-100 text-slate-600", "bg-slate-400"],
    sent: ["bg-sky-50 text-sky-700", "bg-sky-500"],
    confirmed: ["bg-emerald-50 text-emerald-700", "bg-emerald-500"],
    converted: ["bg-teal-50 text-teal-700", "bg-teal-600"],
    expired: ["bg-amber-50 text-amber-700", "bg-amber-500"],
    cancelled: ["bg-rose-50 text-rose-700", "bg-rose-500"],
  };
  const tone = tones[status] ?? tones.draft;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ${tone[0]}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${tone[1]}`} />
      {status}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const tone = status === "confirmed" ? ["bg-emerald-50 text-emerald-700", "bg-emerald-500"] : status === "cancelled" ? ["bg-rose-50 text-rose-700", "bg-rose-500"] : ["bg-amber-50 text-amber-700", "bg-amber-500"];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ${tone[0]}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${tone[1]}`} />
      {status}
    </span>
  );
}

function Modal({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: ReactNode }) {
  return (
    <div data-internal className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px] print:hidden" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5">
          <div>
            <h2 className="text-xl font-bold text-slate-950">{title}</h2>
            <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
          </div>
          <button onClick={onClose} className="rounded-xl border border-slate-200 p-2 text-slate-500 transition hover:bg-slate-50" aria-label="Close dialog"><X size={18} /></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children, hint, className = "" }: { label: string; children: ReactNode; hint?: string; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-xs text-slate-400">{hint}</span>}
    </label>
  );
}

function SelectWrap({ children }: { children: ReactNode }) {
  return <div className="relative">{children}<ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} /></div>;
}

function toList(value: unknown): string[] {
  if (Array.isArray(value)) return value.map((item) => String(item));
  if (value === undefined || value === null || value === "") return [];
  return [String(value)];
}

function SubmitRow({ saving, label }: { saving: boolean; label: string }) {
  return (
    <div className="mt-2 flex justify-end border-t border-slate-100 pt-5 md:col-span-2">
      <button disabled={saving} className="flex h-11 min-w-36 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white transition hover:bg-[#103f3a] disabled:opacity-60">
        {saving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
        {saving ? "Saving…" : label}
      </button>
    </div>
  );
}

/** Per-hotel card panel: every room type with its normal rate and any booking-window-only rate. */
function HotelRoomRates({ rooms, rates, categories, today }: { rooms: RoomRow[]; rates: RateRow[]; categories: RoomCategoryRow[]; today: string }) {
  const roomCategoryLabel = (slug: string) => categories.find((category) => category.slug === slug)?.label ?? slug;
  const [open, setOpen] = useState(false);
  const isBookingOnly = (rate: RateRow) => Boolean(rate.bookingWindowStart || rate.bookingWindowEnd || rate.promoCode);
  const validToday = (rate: RateRow) => rate.validFrom <= today && today <= rate.validTo;
  const bookableToday = (rate: RateRow) =>
    (!rate.bookingWindowStart || rate.bookingWindowStart <= today) && (!rate.bookingWindowEnd || rate.bookingWindowEnd >= today);
  const cheapest = (list: RateRow[]) => list.reduce<RateRow | null>((best, item) => (!best || Number(item.baseRate) < Number(best.baseRate) ? item : best), null);

  const rows = rooms.map((room) => {
    const lines = rates.filter((rate) => rate.roomTypeId === room.id);
    const normalLines = lines.filter((rate) => !isBookingOnly(rate));
    const promoLines = lines.filter((rate) => isBookingOnly(rate));
    return {
      room,
      normal: cheapest(normalLines.filter(validToday)) ?? cheapest(normalLines),
      promoLive: cheapest(promoLines.filter((rate) => validToday(rate) && bookableToday(rate))),
      promoLater: cheapest(promoLines.filter((rate) => validToday(rate) && !bookableToday(rate) && Boolean(rate.bookingWindowStart) && String(rate.bookingWindowStart) > today)),
    };
  });

  return (
    <div className="mt-5 border-t border-slate-100 pt-4">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        className="flex w-full items-center justify-between rounded-xl bg-slate-50 px-3.5 py-2.5 text-left transition hover:bg-slate-100"
      >
        <span className="flex items-center gap-2 text-xs font-extrabold text-slate-800">
          <BadgeDollarSign size={15} className="text-teal-700" /> Room types & cost
          <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-slate-500 ring-1 ring-slate-200">{rooms.length}</span>
        </span>
        <ChevronDown size={16} className={`text-slate-500 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="mt-2 space-y-2">
          {rows.map(({ room, normal, promoLive, promoLater }) => (
            <div key={room.id} className="rounded-xl border border-slate-100 bg-white p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="truncate text-xs font-bold text-slate-800">{room.name}</div>
                  <div className="mt-0.5 text-[10px] text-slate-400">{roomCategoryLabel(room.category)} · {room.code}</div>
                </div>
                {room.mediaLink && <a href={room.mediaLink} target="_blank" rel="noreferrer" className="shrink-0 rounded bg-slate-100 px-1.5 py-0.5 text-[9px] font-bold text-slate-600 hover:bg-slate-200">Media ↗</a>}
              </div>
              <div className="mt-2 space-y-1.5">
                {normal && (
                  <div className="flex items-center justify-between gap-2 rounded-lg bg-teal-50 px-2.5 py-1.5 ring-1 ring-teal-100">
                    <span className="text-[10px] font-semibold text-teal-800">Normal rate · {boardLabel(normal.boardType)}</span>
                    <span className="text-xs font-extrabold text-teal-900">{formatMoney(normal.baseRate)}</span>
                  </div>
                )}
                {promoLive && (
                  <div className="flex items-center justify-between gap-2 rounded-lg bg-amber-100 px-2.5 py-1.5 ring-1 ring-amber-300">
                    <span className="text-[10px] font-bold text-amber-900">
                      Booking window only{promoLive.promoCode ? ` · ${promoLive.promoCode}` : ""}
                      {promoLive.bookingWindowEnd ? ` · book by ${formatDate(promoLive.bookingWindowEnd, { day: "2-digit", month: "short" })}` : ""}
                    </span>
                    <span className="text-xs font-extrabold text-amber-950">{formatMoney(promoLive.baseRate)}</span>
                  </div>
                )}
                {promoLater && (
                  <div className="flex items-center justify-between gap-2 rounded-lg bg-sky-50 px-2.5 py-1.5 ring-1 ring-sky-100">
                    <span className="text-[10px] font-semibold text-sky-800">Booking window opens {formatDate(String(promoLater.bookingWindowStart), { day: "2-digit", month: "short" })}</span>
                    <span className="text-xs font-extrabold text-sky-900">{formatMoney(promoLater.baseRate)}</span>
                  </div>
                )}
                {!normal && !promoLive && !promoLater && <div className="text-[10px] text-slate-400">No rate line yet — add one under Rates & board.</div>}
              </div>
            </div>
          ))}
          <p className="px-1 text-[10px] leading-4 text-slate-400">Teal = standard contract rate. Amber = bookable only inside its booking window. Prices are per room per night, before meal supplements and tax.</p>
        </div>
      )}
    </div>
  );
}

export default function DashboardClient({ data, initialSearch, today, user, initialView }: { data: DashboardData; initialSearch: InitialSearch; today: string; user: SafeUser; initialView: View }) {
  const router = useRouter();
  const [view, setView] = useState<View>(initialView);
  const allowed = (permission: Permission) => user.role === "admin" || user.permissions.includes(permission);
  const [dialog, setDialog] = useState<Dialog>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [rateHotel, setRateHotel] = useState<number>(0);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [toast, setToast] = useState<{ type: "success" | "error"; message: string } | null>(null);

  const cities = Array.from(new Set([...data.hotels.map((hotel) => hotel.city), ...data.locations.map((location) => location.city)])).sort();
  const locationName = (id: number | null) => (id ? data.locations.find((location) => location.id === id)?.name ?? "" : "");
  const placeLabel = (hotel: HotelRow) => [locationName(hotel.locationId), hotel.city].filter(Boolean).join(", ");
  const amenityById = (id: number) => data.amenities.find((amenity) => amenity.id === id);
  const categoryLabel = (slug: string) => data.roomCategories.find((category) => category.slug === slug)?.label ?? slug;
  const beddingFor = (roomTypeId: number) => data.bedding.filter((item) => item.roomTypeId === roomTypeId);
  const hotelAmenityIds = (hotelId: number) => data.hotelAmenities.filter((link) => link.hotelId === hotelId).map((link) => link.amenityId);
  const [amenityEditHotel, setAmenityEditHotel] = useState<number>(0);
  const [contactHotel, setContactHotel] = useState<number>(0);
  const [contactGroupId, setContactGroupId] = useState<number>(0);
  const [groupHotelSelections, setGroupHotelSelections] = useState<number[]>([]);
  const [managerGroupId, setManagerGroupId] = useState<number | null>(null);
  const [managerHotelId, setManagerHotelId] = useState<number | null>(null);
  const [newHotelGroupId, setNewHotelGroupId] = useState<string>("");
  const [newHotelContactSlots, setNewHotelContactSlots] = useState<number[]>([0, 1]);
  const [newHotelSharedContactIds, setNewHotelSharedContactIds] = useState<number[]>([]);
  const [roomEditId, setRoomEditId] = useState<number | null>(null);
  const [newHotelCity, setNewHotelCity] = useState("");
  const [newLocation, setNewLocation] = useState({ city: "", name: "" });
  const [rateHotelId, setRateHotelId] = useState<number>(0);
  const [rateRoomId, setRateRoomId] = useState<number>(0);
  const [blackoutHotelId, setBlackoutHotelId] = useState<number>(0);
  const [blackoutRoomId, setBlackoutRoomId] = useState<number>(0);
  const [blackoutRoomQuery, setBlackoutRoomQuery] = useState("");
  const [cardQuery, setCardQuery] = useState("");
  const [tableFilters, setTableFilters] = useState<Record<string, string>>({});
  const [hotelLayout, setHotelLayout] = useState<"table" | "cards">("table");
  const [newMarket, setNewMarket] = useState("");
  const [expandedQuotation, setExpandedQuotation] = useState<number | null>(null);
  const [convertingQuotation, setConvertingQuotation] = useState<QuotationRow | null>(null);
  const [convertGuest, setConvertGuest] = useState({ name: "", email: "", phone: "", notes: "" });
  const [convertSaving, setConvertSaving] = useState(false);
  const [convertError, setConvertError] = useState("");
  const [pricingQuotation, setPricingQuotation] = useState<QuotationRow | null>(null);
  const [pricingFields, setPricingFields] = useState({ includeTax: true, pct: "", amt: "" });
  const [pricingSaving, setPricingSaving] = useState(false);
  const [pricingError, setPricingError] = useState("");
  const [copiedProposal, setCopiedProposal] = useState<string | null>(null);
  const [quotePdfBusy, setQuotePdfBusy] = useState<number | null>(null);
  const [quoteShareBusy, setQuoteShareBusy] = useState<number | null>(null);
  const [emailTarget, setEmailTarget] = useState<EmailTarget | null>(null);
  const hotelName = (id: number) => data.hotels.find((hotel) => hotel.id === id)?.name ?? "Unknown hotel";
  const groupName = (id: number | null) => (id ? data.hotelGroups.find((group) => group.id === id)?.name ?? "" : "");
  const contactsFor = (hotelId: number) => {
    const ids = new Set(data.contactAssignments.filter((item) => item.hotelId === hotelId).map((item) => item.contactId));
    return data.contacts.filter((contact) => ids.has(contact.id) && contact.active);
  };
  const groupCandidates = (groupId: number) => groupContactCandidates(groupId, data.contacts.filter((contact) => contact.active), data.contactAssignments, data.hotels);
  const inheritedCandidates = Number(newHotelGroupId) > 0 ? groupCandidates(Number(newHotelGroupId)) : [];

  const openNewHotel = () => {
    setFormError("");
    setNewHotelCity("");
    setNewHotelGroupId("");
    setNewHotelSharedContactIds([]);
    setNewHotelContactSlots([0, 1]);
    setDialog("hotel");
  };

  const openRate = () => {
    setFormError("");
    const firstHotel = data.hotels.find((hotel) => data.rooms.some((room) => room.hotelId === hotel.id)) ?? data.hotels[0];
    setRateHotelId(firstHotel?.id ?? 0);
    setRateRoomId(data.rooms.find((room) => room.hotelId === firstHotel?.id)?.id ?? 0);
    setDialog("rate");
  };

  const openBlackout = () => {
    setFormError("");
    setBlackoutHotelId(data.hotels[0]?.id ?? 0);
    setBlackoutRoomId(0);
    setBlackoutRoomQuery("");
    setDialog("blackout");
  };
  const selectHotelGroup = (id: string) => {
    setNewHotelGroupId(id);
    setNewHotelSharedContactIds(Number(id) > 0 ? groupCandidates(Number(id)).map((contact) => contact.id) : []);
  };
  const openHotelContact = (hotelId: number) => {
    setFormError("");
    setManagerGroupId(null);
    setManagerHotelId(null);
    setContactGroupId(0);
    setContactHotel(hotelId);
    setDialog("contact");
  };
  const openGroupContact = (groupId: number) => {
    setFormError("");
    setManagerGroupId(null);
    setManagerHotelId(null);
    setContactHotel(0);
    setContactGroupId(groupId);
    setGroupHotelSelections(data.hotels.filter((hotel) => hotel.groupId === groupId).map((hotel) => hotel.id));
    setDialog("contact");
  };

  const createMarket = async () => {
    if (!newMarket.trim()) return;
    setSaving(true);
    try {
      const response = await fetch("/api/markets", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ label: newMarket }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to add market.");
      setNewMarket("");
      setToast({ type: "success", message: `${result.market.label} added. You can now tick it as not applicable.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to add market." });
    } finally {
      setSaving(false);
    }
  };

  const deleteMarket = async (market: MarketRow) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/markets?id=${market.id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to delete market.");
      setToast({ type: "success", message: `${market.label} removed.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to delete market." });
    } finally {
      setSaving(false);
    }
  };

  const deleteContact = async (contact: ContactRow, hotelId: number) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/contacts?id=${contact.id}&hotelId=${hotelId}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to remove contact from this hotel.");
      setToast({ type: "success", message: `${contact.name} removed from ${hotelName(hotelId)} only. Group and other hotel assignments were kept.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to remove contact." });
    } finally {
      setSaving(false);
    }
  };
  const addLocation = async () => {
    if (!newLocation.city.trim() || !newLocation.name.trim()) return;
    setSaving(true);
    setFormError("");
    try {
      const response = await fetch("/api/locations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(newLocation) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to add location.");
      setToast({ type: "success", message: `${result.location.name} saved under ${result.location.city}.` });
      setNewLocation((current) => ({ ...current, name: "" }));
      router.refresh();
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Unable to add location.");
    } finally {
      setSaving(false);
    }
  };

  const deleteLocation = async (location: LocationRow) => {
    setSaving(true);
    setFormError("");
    try {
      const response = await fetch(`/api/locations?id=${location.id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to delete location.");
      setToast({ type: "success", message: `${location.name} removed${result.hotelsCleared ? ` — ${result.hotelsCleared} hotel(s) keep their city but no longer have a location` : ""}.` });
      router.refresh();
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Unable to delete location.");
    } finally {
      setSaving(false);
    }
  };

  const duplicateRoom = async (room: RoomRow) => {
    setSaving(true);
    setToast(null);
    try {
      const response = await fetch(`/api/rooms/${room.id}/duplicate`, { method: "POST" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to duplicate this room type.");
      setToast({ type: "success", message: result.message ?? `“${room.name}” duplicated.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to duplicate this room type." });
    } finally {
      setSaving(false);
    }
  };

  const saveRoomEdit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!roomEditId) return;
    setSaving(true);
    setToast(null);
    const raw = Object.fromEntries(new FormData(event.currentTarget).entries());
    try {
      const response = await fetch(`/api/rooms/${roomEditId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: raw.name,
          description: raw.description,
          mediaLink: raw.mediaLink,
          defaultInventory: raw.defaultInventory,
          baseSleeps: raw.baseSleeps,
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to update this room type.");
      setRoomEditId(null);
      setToast({ type: "success", message: `Room type updated. ${result.room.defaultInventory} rooms now in the contracted inventory.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to update this room type." });
    } finally {
      setSaving(false);
    }
  };

  const itemsFor = (quotationId: number) =>
    data.quotationItems.filter((item) => item.quotationId === quotationId).sort((a, b) => a.position - b.position);
  const quotationRef = (id: number | null) => (id ? data.quotations.find((item) => item.id === id)?.reference ?? "" : "");

  const proposalLegsFor = (quotation: QuotationRow): ProposalTextLeg[] =>
    itemsFor(quotation.id).map((leg) => {
      const hotel = data.hotels.find((item) => item.id === leg.hotelId);
      return {
        totalAmount: leg.totalAmount,
        tourismTaxAmount: leg.tourismTaxAmount,
        nights: leg.nights,
        rooms: leg.rooms,
        hotelName: hotel?.name ?? "Unknown hotel",
        city: hotel?.city ?? "",
        location: hotel ? locationName(hotel.locationId) : "",
        roomName: roomName(leg.roomTypeId),
        boardType: leg.boardType,
        checkIn: leg.checkIn,
        checkOut: leg.checkOut,
        adults: leg.adults,
        children: leg.children,
        infants: leg.infants,
      };
    });

  const proposalFor = (quotation: QuotationRow) =>
    computeProposal(itemsFor(quotation.id), {
      includeTourismTax: quotation.includeTourismTax,
      markupPercent: quotation.markupPercent,
      markupAmount: quotation.markupAmount,
    });

  const openPricing = (quotation: QuotationRow) => {
    setPricingError("");
    setPricingFields({
      includeTax: quotation.includeTourismTax,
      pct: Number(quotation.markupPercent) > 0 ? String(Number(quotation.markupPercent)) : "",
      amt: Number(quotation.markupAmount) > 0 ? String(Number(quotation.markupAmount)) : "",
    });
    setPricingQuotation(quotation);
  };

  const savePricing = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!pricingQuotation) return;
    setPricingSaving(true);
    setPricingError("");
    try {
      const response = await fetch("/api/quotations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: pricingQuotation.id,
          includeTourismTax: pricingFields.includeTax,
          markupPercent: pricingFields.pct === "" ? 0 : Number(pricingFields.pct),
          markupAmount: pricingFields.amt === "" ? 0 : Number(pricingFields.amt),
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to update pricing.");
      setPricingQuotation(null);
      setToast({ type: "success", message: `Proposal updated — client total ${formatMoney(result.quotation.proposalTotal, result.quotation.currency)}.` });
      router.refresh();
    } catch (error) {
      setPricingError(error instanceof Error ? error.message : "Unable to update pricing.");
    } finally {
      setPricingSaving(false);
    }
  };

  const copyProposal = async (quotation: QuotationRow, format: "whatsapp" | "email") => {
    const text = buildProposalText(
      {
        reference: quotation.reference,
        clientName: quotation.clientName,
        validUntil: quotation.validUntil,
        currency: quotation.currency,
        legs: proposalLegsFor(quotation),
        options: {
          includeTourismTax: quotation.includeTourismTax,
          markupPercent: quotation.markupPercent,
          markupAmount: quotation.markupAmount,
        },
      },
      format,
    );
    const ok = await copyText(text);
    if (ok) {
      setCopiedProposal(`${quotation.id}-${format}`);
      window.setTimeout(() => setCopiedProposal((current) => (current === `${quotation.id}-${format}` ? null : current)), 2500);
    } else {
      setToast({ type: "error", message: "Copy was blocked by the browser. Select the preview text manually." });
    }
  };

  const downloadQuotePdf = (quotation: QuotationRow) => {
    setQuotePdfBusy(quotation.id);
    try {
      downloadQuotationPdf({
        reference: quotation.reference,
        clientName: quotation.clientName,
        validUntil: quotation.validUntil,
        currency: quotation.currency,
        legs: proposalLegsFor(quotation),
        options: {
          includeTourismTax: quotation.includeTourismTax,
          markupPercent: quotation.markupPercent,
          markupAmount: quotation.markupAmount,
        },
      });
      setToast({ type: "success", message: `PDF downloaded for ${quotation.reference} — ready to attach to your email.` });
    } finally {
      setQuotePdfBusy(null);
    }
  };

  const shareQuotationPdf = async (quotation: QuotationRow) => {
    setQuoteShareBusy(quotation.id);
    try {
      const doc = createQuotationPdf({
        reference: quotation.reference,
        clientName: quotation.clientName,
        validUntil: quotation.validUntil,
        currency: quotation.currency,
        legs: proposalLegsFor(quotation),
        options: { includeTourismTax: quotation.includeTourismTax, markupPercent: quotation.markupPercent, markupAmount: quotation.markupAmount },
      });
      const result = await sharePdf(doc, `${quotation.reference}-hotel-proposal.pdf`, `${quotation.reference} · Luxury Attractions hotel proposal`);
      if (result === "downloaded") setToast({ type: "success", message: "This browser cannot share PDF files directly. The PDF was downloaded — attach that file in WhatsApp or Telegram." });
      else if (result === "shared") setToast({ type: "success", message: "The PDF was handed to your device's share sheet. Choose WhatsApp, Telegram or another app." });
    } catch {
      setToast({ type: "error", message: "Unable to share this PDF. Try downloading it instead." });
    } finally {
      setQuoteShareBusy(null);
    }
  };

  const deleteQuotation = async (quotation: QuotationRow) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/quotations?id=${quotation.id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to delete quotation.");
      setToast({ type: "success", message: `Quotation ${quotation.reference} deleted.` });
      router.refresh();
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Unable to delete quotation." });
    } finally {
      setSaving(false);
    }
  };

  const openConvert = (quotation: QuotationRow) => {
    setConvertError("");
    setConvertGuest({ name: quotation.clientName, email: quotation.clientEmail, phone: quotation.clientPhone, notes: "" });
    setConvertingQuotation(quotation);
  };

  const convertQuotation = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!convertingQuotation) return;
    setConvertSaving(true);
    setConvertError("");
    try {
      const response = await fetch("/api/quotations/convert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: convertingQuotation.id,
          guestName: convertGuest.name,
          guestEmail: convertGuest.email,
          guestPhone: convertGuest.phone,
          notes: convertGuest.notes,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Unable to convert quotation.");
      const refs = (data.bookings as { reference: string }[]).map((booking) => booking.reference).join(", ");
      setConvertingQuotation(null);
      setToast({ type: "success", message: `Quotation converted — booking${data.bookings.length === 1 ? "" : "s"} ${refs} created.` });
      router.refresh();
    } catch (error) {
      setConvertError(error instanceof Error ? error.message : "Unable to convert quotation.");
    } finally {
      setConvertSaving(false);
    }
  };

  const roomName = (id: number | null) => (id ? data.rooms.find((room) => room.id === id)?.name ?? "Unknown room" : "All room types");
  const normalizedSearch = search.trim().toLowerCase();

  const submitForm = async (event: FormEvent<HTMLFormElement>, endpoint: string, successMessage: string, transform?: (value: Record<string, unknown>) => Record<string, unknown>) => {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    setToast(null);
    const formData = new FormData(event.currentTarget);
    const raw: Record<string, unknown> = {};
    for (const key of Array.from(new Set(formData.keys()))) {
      const values = formData.getAll(key);
      raw[key] = values.length > 1 ? values : values[0];
    }
    try {
      const response = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(transform ? transform(raw) : raw) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Something went wrong.");
      setDialog(null);
      setToast({ type: "success", message: successMessage });
      router.refresh();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unable to save changes.";
      setFormError(message);
      setToast({ type: "error", message });
    } finally {
      setSaving(false);
    }
  };

  const navigate = (next: View) => {
    if (next === "users" && user.role !== "admin") return;
    setView(next);
    setMenuOpen(false);
    setSearch("");
    const url = new URL(window.location.href);
    if (next === "search") url.searchParams.delete("view");
    else url.searchParams.set("view", next);
    window.history.replaceState(window.history.state, "", url.pathname + url.search);
  };

  const upcomingBlackouts = data.blackouts.filter((item) => item.endDate >= today);
  const confirmedValue = data.bookings.filter((booking) => booking.status === "confirmed").reduce((sum, booking) => sum + Number(booking.totalAmount), 0);
  const upcomingArrivals = data.bookings.filter((booking) => booking.checkIn >= today && booking.status !== "cancelled").sort((a, b) => a.checkIn.localeCompare(b.checkIn));
  const page = pageTitles[view];

  const filteredHotels = data.hotels.filter((hotel) => `${hotel.name} ${hotel.city} ${hotel.supplierCode}`.toLowerCase().includes(normalizedSearch));

  const cardHotels = filteredHotels.filter((hotel) => {
    const query = cardQuery.trim().toLowerCase();
    if (!query) return true;
    return `${hotel.name} ${hotel.city} ${locationName(hotel.locationId)} ${hotel.supplierCode} ${groupName(hotel.groupId)} ${hotel.businessType} ${contactsFor(hotel.id).map((contact) => contact.name).join(" ")}`
      .toLowerCase()
      .includes(query);
  });

  const rowMatches = (hotel: HotelRow, contact: ContactRow | null) => {
    const cells: Record<string, string> = {
      hotel: hotel.name,
      group: groupName(hotel.groupId),
      website: hotel.website,
      email: contact?.email ?? "",
      name: contact?.name ?? "",
      position: contact?.position ?? "",
      phone: contact?.phone ?? "",
      chat: [contact?.whatsapp && "whatsapp", contact?.telegram && "telegram", contact?.viber && "viber"].filter(Boolean).join(" "),
      region: `${placeLabel(hotel)}, ${hotel.country}`,
      address: hotel.address,
      businessType: hotel.businessType,
      contracts: [hotel.contractsFolderLink && "contracts folder", hotel.mediaLink && "media"].filter(Boolean).join(" "),
      card: contact?.businessCardLink ? "business card" : "",
    };
    return Object.entries(tableFilters).every(
      ([key, value]) => !value.trim() || (cells[key] ?? "").toLowerCase().includes(value.trim().toLowerCase()),
    );
  };

  // Each visible row keeps its position inside the hotel, so hotel-level cells appear once per hotel.
  const tableRows = filteredHotels.flatMap((hotel) => {
    const contacts = contactsFor(hotel.id);
    const rows: (ContactRow | null)[] = contacts.length > 0 ? contacts : [null];
    return rows.filter((contact) => rowMatches(hotel, contact)).map((contact, index) => ({ hotel, contact, index }));
  });

  const tableFilterInput = (key: string) => (
    <input
      value={tableFilters[key] ?? ""}
      onChange={(event) => setTableFilters((current) => ({ ...current, [key]: event.target.value }))}
      placeholder="Filter…"
      aria-label={`Filter ${key} column`}
      className="h-8 w-full min-w-0 rounded-md border border-slate-200 bg-white px-2 text-[11px] font-normal text-slate-700 outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/15"
    />
  );
  const activeTableFilters = Object.values(tableFilters).filter((value) => value.trim()).length;

  // Blackout form: room types are scoped to the picked hotel and narrowed by typed text.
  const blackoutRoomCount = data.rooms.filter((room) => room.hotelId === blackoutHotelId).length;
  const blackoutRoomOptions = data.rooms.filter((room) =>
    room.hotelId === blackoutHotelId &&
    `${room.name} ${room.code}`.toLowerCase().includes(blackoutRoomQuery.trim().toLowerCase()),
  );
  const filteredRooms = data.rooms.filter((room) => `${room.name} ${room.code} ${categoryLabel(room.category)} ${hotelName(room.hotelId)}`.toLowerCase().includes(normalizedSearch));
  const filteredRates = data.rates.filter((rate) => (!rateHotel || rate.hotelId === rateHotel) && `${rate.name} ${hotelName(rate.hotelId)} ${roomName(rate.roomTypeId)} ${boardLabel(rate.boardType)}`.toLowerCase().includes(normalizedSearch));
  const filteredBookings = data.bookings.filter((booking) => `${booking.reference} ${booking.guestName} ${hotelName(booking.hotelId)}`.toLowerCase().includes(normalizedSearch));
  const filteredQuotations = data.quotations.filter((quotation) => {
    const legs = itemsFor(quotation.id).map((item) => `${hotelName(item.hotelId)} ${roomName(item.roomTypeId)}`).join(" ");
    return `${quotation.reference} ${quotation.clientName} ${quotation.clientEmail} ${quotation.status} ${legs}`.toLowerCase().includes(normalizedSearch);
  });

  const addAction: Partial<Record<View, { label: string; dialog: Dialog }>> = {
    hotels: { label: "Add hotel", dialog: "hotel" },
    rooms: { label: "Add room type", dialog: "room" },
    rates: { label: "Add rate plan", dialog: "rate" },
    blackouts: { label: "Add blackout dates", dialog: "blackout" },
  };

  const bookingTable = (rows: BookingRow[]) => (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[980px] text-left">
        <thead className="bg-slate-50/70 text-[10px] uppercase tracking-[0.08em] text-slate-400">
          <tr>
            <th className="px-5 py-3.5">Reference / guest</th>
            <th className="px-4 py-3.5">Hotel & room</th>
            <th className="px-4 py-3.5">Stay</th>
            <th className="px-4 py-3.5">Guests</th>
            <th className="px-4 py-3.5">Board</th>
            <th className="px-4 py-3.5">Net total</th>
            <th className="px-5 py-3.5">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((booking) => (
            <tr key={booking.id} className="text-sm transition hover:bg-slate-50/60">
              <td className="px-5 py-4">
                <div className="font-extrabold text-[#175a53]">{booking.reference}</div>
                <div className="mt-1 text-xs font-semibold text-slate-700">{booking.guestName}</div>
                <div className="mt-0.5 text-[10px] text-slate-400">{booking.guestEmail}</div>
                {booking.quotationId && quotationRef(booking.quotationId) && (
                  <button onClick={() => navigate("quotations")} title="Open quotations" className="mt-1.5 inline-flex items-center gap-1 rounded-md bg-teal-50 px-1.5 py-0.5 text-[10px] font-bold text-teal-700 hover:bg-teal-100">
                    <FileText size={10} /> {quotationRef(booking.quotationId)}
                  </button>
                )}
              </td>
              <td className="px-4 py-4">
                <div className="max-w-[230px] truncate text-xs font-bold text-slate-700">{hotelName(booking.hotelId)}</div>
                <div className="mt-1 max-w-[230px] truncate text-[10px] text-slate-400">{roomName(booking.roomTypeId)}</div>
              </td>
              <td className="px-4 py-4">
                <div className="text-xs font-semibold text-slate-600">{formatDate(booking.checkIn, { day: "2-digit", month: "short" })} – {formatDate(booking.checkOut)}</div>
                <div className="mt-1 text-[10px] text-slate-400">{booking.nights} nights · {booking.rooms} room{booking.rooms > 1 ? "s" : ""}</div>
              </td>
              <td className="px-4 py-4 text-xs text-slate-600">{booking.adults}A · {booking.children}C · {booking.infants}I</td>
              <td className="px-4 py-4 text-xs text-slate-600">{boardLabel(booking.boardType)}</td>
              <td className="px-4 py-4">
                <div className="font-extrabold text-slate-900">{formatMoney(booking.totalAmount, booking.currency)}</div>
                <div className="mt-1 text-[10px] text-slate-400">incl. {formatMoney(booking.tourismTaxAmount)} tax</div>
              </td>
              <td className="px-5 py-4"><StatusBadge status={booking.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length === 0 && (
        <div className="grid place-items-center px-6 py-16 text-center">
          <MoonStar size={26} className="text-slate-300" />
          <div className="mt-3 text-sm font-bold text-slate-700">No reservations found</div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f7f9] text-slate-900">
      {dialog && formError && <div role="alert" className="fixed right-4 top-4 z-[100] flex max-w-md items-start gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-800 shadow-xl"><AlertTriangle size={18} className="mt-0.5 shrink-0" /><span className="flex-1">{formError}</span><button type="button" onClick={() => setFormError("")} aria-label="Dismiss error" className="rounded p-0.5 hover:bg-rose-100"><X size={16} /></button></div>}
      {menuOpen && <button className="fixed inset-0 z-30 bg-slate-950/40 md:hidden" onClick={() => setMenuOpen(false)} aria-label="Close navigation" />}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[252px] flex-col border-r border-slate-200/80 bg-white transition-transform duration-300 md:translate-x-0 ${menuOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex h-[78px] items-center gap-3 border-b border-slate-100 px-6">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#164e48] text-white shadow-lg shadow-teal-900/15"><Hotel size={21} strokeWidth={2.2} /></div>
          <div>
            <div className="text-[15px] font-extrabold tracking-tight text-slate-950">Luxury Attractions</div>
            <div className="mt-0.5 text-[10px] font-bold uppercase tracking-[0.16em] text-[#b27a4b]">Hotel contracts</div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-3.5 py-6">
          <p className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Workspace</p>
          <nav className="space-y-1">
            {navItems.filter((item) => item.id !== "users" || user.role === "admin").map((item, index) => {
              const Icon = item.icon;
              const active = view === item.id;
              return (
                <div key={item.id}>
                  {index === 6 && <p className="mb-2 mt-6 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Contracts</p>}
                  <button onClick={() => navigate(item.id)} className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-left text-sm font-semibold transition ${active ? "bg-[#eaf4f2] text-[#14544d]" : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"}`}>
                    <Icon size={18} strokeWidth={active ? 2.3 : 1.9} />
                    <span className="flex-1">{item.label}</span>
                    {item.id === "blackouts" && upcomingBlackouts.length > 0 && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-extrabold text-amber-700">{upcomingBlackouts.length}</span>}
                  </button>
                </div>
              );
            })}
          </nav>
          <div className="mt-8 rounded-2xl bg-[#173f3b] p-4 text-white">
            <div className="flex items-center gap-2 text-xs font-bold text-teal-100"><Sparkles size={14} /> How pricing works</div>
            <p className="mt-2 text-[11px] leading-5 text-teal-50/80">Each night is priced with the contract valid on that date, plus meals, occupancy supplements, extra beds and tourism tax.</p>
          </div>
        </div>
        <div className="border-t border-slate-100 p-4">
          <div className="flex items-center gap-3 rounded-xl p-2">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-[#dcece9] text-xs font-extrabold text-[#15554e]">{user.name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("")}</div>
            <div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{user.name}</p><p className="truncate text-[11px] capitalize text-slate-400">{user.role} · {user.email}</p></div>
          </div>
          <button onClick={async () => { await fetch("/api/auth/logout", { method: "POST" }); window.location.assign("/login"); }} className="mt-1 w-full rounded-lg px-3 py-2 text-left text-xs font-bold text-slate-500 hover:bg-slate-50 hover:text-rose-700">Sign out</button>
        </div>
      </aside>

      <main className="min-h-screen md:pl-[252px]">
        <header className="sticky top-0 z-20 flex h-[78px] items-center gap-4 border-b border-slate-200/80 bg-white/95 px-4 backdrop-blur md:px-7 lg:px-9">
          <button onClick={() => setMenuOpen(true)} className="rounded-xl border border-slate-200 p-2 text-slate-600 md:hidden" aria-label="Open navigation"><Menu size={20} /></button>
          {view !== "search" && view !== "dashboard" ? (
            <div className="relative hidden w-full max-w-md sm:block">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={`Search ${pageTitles[view].title.toLowerCase()}…`} className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50/70 pl-10 pr-4 text-sm outline-none transition focus:border-teal-600 focus:bg-white focus:ring-4 focus:ring-teal-700/10" />
            </div>
          ) : (
            <div className="hidden text-sm font-bold text-slate-500 sm:block">{data.hotels.length} contracted hotels · {data.rooms.length} room types · {data.rates.length} rate lines</div>
          )}
          <div className="ml-auto flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-500 lg:flex"><CircleDot size={13} className="text-emerald-500" /> Net rates in AED</div>
            {view !== "search" && (
              <button onClick={() => navigate("search")} className="flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a]"><Search size={16} /> <span className="hidden sm:inline">Search rates</span></button>
            )}
          </div>
        </header>

        <div className="mx-auto max-w-[1540px] p-4 md:p-7 lg:p-9">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a66e42]"><Sparkles size={13} /> {page.eyebrow}</div>
              <h1 className="text-2xl font-extrabold tracking-[-0.025em] text-slate-950 md:text-[30px]">{page.title}</h1>
              <p className="mt-1.5 text-sm text-slate-500">{page.copy}</p>
            </div>
            {addAction[view] && (view === "hotels" ? allowed("manage_hotels") : allowed("manage_rates")) && (
              <button onClick={() => (view === "hotels" ? openNewHotel() : view === "blackouts" ? openBlackout() : view === "rates" ? openRate() : setDialog(addAction[view]!.dialog))} className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a]"><Plus size={17} /> {addAction[view]!.label}</button>
            )}
          </div>

          {toast && (
            <div className={`mb-5 flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold ${toast.type === "success" ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-rose-200 bg-rose-50 text-rose-800"}`}>
              {toast.type === "success" ? <CheckCircle2 size={18} /> : <AlertTriangle size={18} />}
              <span className="flex-1">{toast.message}</span>
              <button onClick={() => setToast(null)} aria-label="Dismiss"><X size={16} /></button>
            </div>
          )}

          <div className={view === "search" ? "" : "hidden"}>
            <SearchPanel
              initial={initialSearch}
              cities={cities}
              locationOptions={data.locations.filter((location) => location.active).map((location) => ({ city: location.city, name: location.name }))}
              amenityOptions={data.amenities.map((amenity) => ({ slug: amenity.slug, label: amenity.label, icon: amenity.icon }))}
              categoryOptions={data.roomCategories.map((category) => ({ slug: category.slug, label: category.label }))}
              userId={user.id}
              canQuote={allowed("manage_quotations")}
              canBook={allowed("manage_bookings")}
              onBooked={(reference) => {
                setToast({ type: "success", message: `Booking confirmed — reference ${reference}. It has been added to the bookings ledger.` });
                router.refresh();
              }}
              onQuoted={(reference) => {
                setToast({ type: "success", message: `Quotation ${reference} saved. Find it under Quotations.` });
                navigate("quotations");
                router.refresh();
              }}
            />
          </div>

          {view === "dashboard" && (
            <>
              <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  { label: "Contracted hotels", value: data.hotels.length, note: `${cities.length} emirates / cities`, icon: Building2, tone: "bg-teal-50 text-teal-700", target: "hotels" as View },
                  { label: "Rate lines loaded", value: data.rates.length, note: `${data.rooms.length} room types covered`, icon: BadgeDollarSign, tone: "bg-blue-50 text-blue-700", target: "rates" as View },
                  { label: "Active blackout periods", value: upcomingBlackouts.length, note: "Excluded from search results", icon: CalendarX2, tone: "bg-amber-50 text-amber-700", target: "blackouts" as View },
                  { label: "Confirmed value", value: formatMoney(confirmedValue), note: `${data.bookings.length} reservations on file`, icon: WalletCards, tone: "bg-violet-50 text-violet-700", target: "bookings" as View },
                ].map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <button key={stat.label} onClick={() => navigate(stat.target)} className={`${card} group p-5 text-left transition hover:-translate-y-0.5 hover:shadow-lg`}>
                      <div className="flex items-start justify-between"><div className={`grid h-10 w-10 place-items-center rounded-xl ${stat.tone}`}><Icon size={19} /></div><ArrowUpRight size={16} className="text-slate-300 transition group-hover:text-slate-600" /></div>
                      <div className="mt-4 text-[25px] font-extrabold tracking-tight text-slate-950">{stat.value}</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-700">{stat.label}</div>
                      <div className="mt-2 text-[11px] text-slate-400">{stat.note}</div>
                    </button>
                  );
                })}
              </section>
              <section className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1.5fr)_minmax(320px,.8fr)]">
                <div className={`${card} overflow-hidden`}>
                  <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4"><div><h2 className="font-extrabold text-slate-950">Upcoming arrivals</h2><p className="mt-1 text-xs text-slate-400">Next check-ins across all hotels</p></div><button onClick={() => navigate("bookings")} className="flex items-center gap-1 text-xs font-bold text-[#166159]">All bookings <ArrowUpRight size={14} /></button></div>
                  {bookingTable(upcomingArrivals.slice(0, 6))}
                </div>
                <div className={`${card} p-5`}>
                  <div className="flex items-center justify-between"><h2 className="font-extrabold text-slate-950">Upcoming blackout dates</h2><button onClick={() => navigate("blackouts")} className="text-[11px] font-bold text-[#166159]">Manage</button></div>
                  <div className="mt-4 space-y-3">
                    {upcomingBlackouts.slice(0, 5).map((item) => (
                      <div key={item.id} className="flex gap-3 rounded-xl border border-slate-100 p-3">
                        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-amber-50 text-amber-700"><CalendarX2 size={16} /></div>
                        <div className="min-w-0">
                          <div className="truncate text-xs font-bold text-slate-800">{hotelName(item.hotelId)}</div>
                          <div className="mt-0.5 text-[10px] text-slate-500">{roomName(item.roomTypeId)}</div>
                          <div className="mt-1 text-[10px] font-semibold text-amber-700">{formatDate(item.startDate, { day: "2-digit", month: "short" })} – {formatDate(item.endDate)}</div>
                        </div>
                      </div>
                    ))}
                    {upcomingBlackouts.length === 0 && <p className="text-xs text-slate-400">No upcoming closures.</p>}
                  </div>
                </div>
              </section>
            </>
          )}

          {view === "hotels" && (
            <>
            <section className={`${card} mb-5 flex flex-wrap items-center justify-between gap-4 px-5 py-4`}>
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">Amenity types</h2>
                <p className="mt-1 text-xs text-slate-400">These appear as filters in search. Add new ones as your contracts grow.</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {data.amenities.map((amenity) => (
                  <span key={amenity.id} className="inline-flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[11px] font-bold text-slate-600 ring-1 ring-slate-200" title={`${data.hotelAmenities.filter((link) => link.amenityId === amenity.id).length} hotels`}>
                    <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={12} />
                    <span className="text-slate-400">{data.hotelAmenities.filter((link) => link.amenityId === amenity.id).length}</span>
                  </span>
                ))}
                <button onClick={() => setDialog("amenity")} className="inline-flex items-center gap-1.5 rounded-lg bg-[#174e48] px-3 py-1.5 text-[11px] font-bold text-white"><Plus size={13} /> Add amenity</button>
              </div>
            </section>
            <section className={`${card} mb-5 flex flex-wrap items-center justify-between gap-3 px-5 py-4`}>
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">Hotel groups & contacts</h2>
                <p className="mt-1 text-xs text-slate-400">
                  {data.hotelGroups.length} group{data.hotelGroups.length === 1 ? "" : "s"} · {data.contacts.length} contacts · one sales team can cover every property in a group
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="grid grid-cols-2 rounded-xl bg-slate-100 p-1 text-[11px] font-bold">
                  {(["table", "cards"] as const).map((layout) => (
                    <button key={layout} onClick={() => setHotelLayout(layout)} className={`rounded-lg px-3 py-1.5 transition ${hotelLayout === layout ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"}`}>
                      {layout === "table" ? "Table view" : "Card view"}
                    </button>
                  ))}
                </div>
                <button onClick={() => setDialog("group")} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-bold text-slate-600"><Plus size={13} /> Add group</button>
                <button onClick={() => { setFormError(""); setNewLocation({ city: cities[0] ?? "", name: "" }); setDialog("locations"); }} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-bold text-slate-600"><MapPin size={13} /> Locations</button>
                <button onClick={() => setManagerGroupId(data.hotelGroups[0]?.id ?? null)} disabled={!data.hotelGroups.length} className="inline-flex items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 px-3 py-1.5 text-[11px] font-bold text-teal-800 hover:bg-teal-100 disabled:opacity-50"><UsersRound size={13} /> Manage group contacts</button>
                <button onClick={() => openHotelContact(data.hotels[0]?.id ?? 0)} className="inline-flex items-center gap-1.5 rounded-lg bg-[#174e48] px-3 py-1.5 text-[11px] font-bold text-white"><Plus size={13} /> Add contact</button>
                {hotelLayout === "cards" && (
                  <div className="relative">
                    <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input value={cardQuery} onChange={(event) => setCardQuery(event.target.value)} placeholder="Search hotels…" aria-label="Search hotels in card view" className="h-8 w-52 rounded-lg border border-slate-200 bg-white pl-8 pr-7 text-[11px] text-slate-700 outline-none transition focus:border-teal-500 focus:ring-2 focus:ring-teal-600/15" />
                    {cardQuery && <button type="button" onClick={() => setCardQuery("")} className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-0.5 text-slate-400 transition hover:text-slate-700" aria-label="Clear hotel search"><X size={13} /></button>}
                  </div>
                )}
              </div>
            </section>

            {hotelLayout === "table" && (
              <section className={`${card} mb-5 overflow-hidden`}>
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-4 py-3">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <SlidersHorizontal size={14} className="text-teal-700" />
                    <span><b className="text-slate-700">{tableRows.length}</b> row{tableRows.length === 1 ? "" : "s"} shown · type in any column to filter, like Excel</span>
                    {activeTableFilters > 0 && <span className="rounded-full bg-teal-50 px-2 py-0.5 text-[10px] font-bold text-teal-700">{activeTableFilters} filter{activeTableFilters === 1 ? "" : "s"} on</span>}
                  </div>
                  <button type="button" disabled={activeTableFilters === 0} onClick={() => setTableFilters({})} className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-[11px] font-bold text-slate-600 transition hover:border-teal-300 hover:text-teal-700 disabled:opacity-40">Clear filters</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1500px] text-left text-xs">
                    <thead className="bg-[#174e48] text-[10px] uppercase tracking-[0.06em] text-white">
                      <tr>
                        <th className="px-3 py-3">Hotel</th>
                        <th className="px-3 py-3">Group</th>
                        <th className="px-3 py-3">Website</th>
                        <th className="px-3 py-3">Email</th>
                        <th className="px-3 py-3">Name</th>
                        <th className="px-3 py-3">Position</th>
                        <th className="px-3 py-3">Contact No</th>
                        <th className="px-3 py-3">Chat</th>
                        <th className="px-3 py-3">Region/Country</th>
                        <th className="px-3 py-3">Address</th>
                        <th className="px-3 py-3">Business Type</th>
                        <th className="px-3 py-3">Contracts</th>
                        <th className="px-3 py-3">Business Card</th>
                        <th className="px-3 py-3"></th>
                      </tr>
                      <tr className="bg-white">
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("hotel")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("group")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("website")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("email")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("name")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("position")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("phone")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("chat")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("region")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("address")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("businessType")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("contracts")}</th>
                        <th className="border-b border-slate-200 px-2 py-2">{tableFilterInput("card")}</th>
                        <th className="border-b border-slate-200"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {tableRows.map(({ hotel, contact, index: rowIndex }) => (
                          <tr key={`${hotel.id}-${contact?.id ?? "none"}`} className="align-top hover:bg-slate-50/60">
                            <td className="border-l-4 border-[#0ea5b7] px-3 py-3 font-bold text-slate-900">
                              {rowIndex === 0 && <><div>{hotel.name}</div><button onClick={() => setManagerHotelId(hotel.id)} className="mt-1.5 text-[10px] font-bold text-teal-700 hover:underline">Manage contacts</button></>}
                            </td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? groupName(hotel.groupId) || "—" : ""}</td>
                            <td className="px-3 py-3">{rowIndex === 0 && hotel.website ? <a href={hotel.website} target="_blank" rel="noreferrer" className="text-sky-700 underline">{hotel.website.replace(/^https?:\/\//, "")}</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3">{contact?.email ? <a href={`mailto:${contact.email}`} className="text-sky-700 underline">{contact.email}</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3 font-semibold text-slate-800">{contact?.name ?? "No contact added"}</td>
                            <td className="px-3 py-3 text-slate-600">{contact?.position || "—"}</td>
                            <td className="px-3 py-3 whitespace-nowrap font-semibold text-slate-700">{contact?.phone || "—"}</td>
                            <td className="px-3 py-3">
                              <div className="flex gap-1">
                                {contact?.whatsapp && contact.phone && <a href={messagingLink("whatsapp", contact.phone)} target="_blank" rel="noreferrer" title="WhatsApp" className="rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-bold text-emerald-700">WA</a>}
                                {contact?.telegram && contact.phone && <a href={messagingLink("telegram", contact.phone)} target="_blank" rel="noreferrer" title="Telegram" className="rounded bg-sky-50 px-1.5 py-0.5 text-[10px] font-bold text-sky-700">TG</a>}
                                {contact?.viber && contact.phone && <a href={messagingLink("viber", contact.phone)} target="_blank" rel="noreferrer" title="Viber" className="rounded bg-violet-50 px-1.5 py-0.5 text-[10px] font-bold text-violet-700">VB</a>}
                                {!contact?.phone && <span className="text-slate-300">—</span>}
                              </div>
                              {contact?.otherContact && <div className="mt-1 text-[10px] text-slate-500">{contact.otherContact}</div>}
                            </td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? <>{locationName(hotel.locationId) && <b className="font-semibold text-slate-800">{locationName(hotel.locationId)}, </b>}{hotel.city}, {hotel.country}</> : ""}</td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? hotel.address || "—" : ""}</td>
                            <td className="px-3 py-3 text-slate-600">{rowIndex === 0 ? hotel.businessType : ""}</td>
                            <td className="px-3 py-3">{rowIndex === 0 && hotel.contractsFolderLink ? <a href={hotel.contractsFolderLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">Folder</a> : <span className="text-slate-300">—</span>}{rowIndex === 0 && hotel.mediaLink && <a href={hotel.mediaLink} target="_blank" rel="noreferrer" className="ml-1 inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-600">Media</a>}</td>
                            <td className="px-3 py-3">{contact?.businessCardLink ? <a href={contact.businessCardLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-600">Card</a> : <span className="text-slate-300">—</span>}</td>
                            <td className="px-3 py-3">{contact && <button disabled={saving} onClick={() => void deleteContact(contact, hotel.id)} className="rounded p-1 text-slate-300 transition hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50" title={`Remove ${contact.name} from ${hotel.name} only`} aria-label={`Remove ${contact.name} from ${hotel.name} only`}><Trash2 size={14} /></button>}</td>
                          </tr>
                      ))}
                      {tableRows.length === 0 && (
                        <tr><td colSpan={14} className="px-4 py-12 text-center text-xs text-slate-500">No rows match the column filters. Clear a filter to see more.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            <section className={hotelLayout === "cards" ? "grid gap-4 md:grid-cols-2 xl:grid-cols-3" : "hidden"}>
              {cardHotels.map((hotel, index) => {
                const hotelRooms = data.rooms.filter((room) => room.hotelId === hotel.id);
                const hotelRates = data.rates.filter((rate) => rate.hotelId === hotel.id);
                const colors = ["from-[#174e48] to-[#247267]", "from-[#263d5d] to-[#3e6089]", "from-[#5c4736] to-[#8a6a4f]"];
                return (
                  <article key={hotel.id} className={`${card} overflow-hidden transition hover:-translate-y-0.5 hover:shadow-lg`}>
                    <div className={`bg-gradient-to-br ${colors[index % colors.length]} p-5 text-white`}>
                      <div className="flex items-start justify-between"><div className="grid h-11 w-11 place-items-center rounded-xl bg-white/15 text-sm font-extrabold ring-1 ring-white/15">{hotelInitials(hotel.name)}</div><span className="rounded-full bg-white/12 px-2.5 py-1 text-[10px] font-bold ring-1 ring-white/15">{hotel.supplierCode}</span></div>
                      <h2 className="mt-5 text-lg font-extrabold">{hotel.name}</h2>
                      <div className="mt-1.5 flex items-center gap-2 text-xs text-white/70"><MapPin size={13} /> {placeLabel(hotel)}, {hotel.country}</div>
                      {groupName(hotel.groupId) && <div className="mt-1 text-[11px] font-semibold text-white/60">Part of {groupName(hotel.groupId)}</div>}
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {hotel.website && <a href={hotel.website} target="_blank" rel="noreferrer" className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">Website</a>}
                        {hotel.contractsFolderLink && <a href={hotel.contractsFolderLink} target="_blank" rel="noreferrer" className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">Contracts folder</a>}
                        {hotel.mediaLink && <a href={hotel.mediaLink} target="_blank" rel="noreferrer" className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">Media</a>}
                        <span className="rounded-full bg-white/12 px-2 py-1 text-[10px] font-bold ring-1 ring-white/15">{hotel.businessType}</span>
                      </div>
                      <div className="mt-3 flex">{Array.from({ length: hotel.starRating }).map((_, star) => <Star key={star} size={12} className="fill-[#e7b980] text-[#e7b980]" />)}</div>
                    </div>
                    <div className="p-5">
                      <div className="grid grid-cols-3 divide-x divide-slate-100 text-center">
                        <div><div className="text-lg font-extrabold">{hotelRooms.length}</div><div className="text-[10px] text-slate-400">Room types</div></div>
                        <div><div className="text-lg font-extrabold">{hotelRates.length}</div><div className="text-[10px] text-slate-400">Rate lines</div></div>
                        <div><div className="text-lg font-extrabold">{Number(hotel.tourismTax)}</div><div className="text-[10px] text-slate-400">Tax AED</div></div>
                      </div>
                      <HotelRoomRates rooms={hotelRooms} rates={hotelRates} categories={data.roomCategories} today={today} />
                      <div className="mt-5 border-t border-slate-100 pt-4">
                        <div className="mb-2 flex items-center justify-between">
                          <span className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Amenities</span>
                          <button
                            onClick={() => { setAmenityEditHotel(hotel.id); setDialog("hotelAmenities"); }}
                            className="text-[10px] font-bold text-[#166159]"
                          >
                            Edit
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {hotelAmenityIds(hotel.id).map((amenityId) => {
                            const amenity = amenityById(amenityId);
                            if (!amenity) return null;
                            return (
                              <span key={amenityId} className="inline-flex items-center gap-1 rounded-md bg-slate-50 px-2 py-1 text-[10px] font-bold text-slate-600 ring-1 ring-slate-200">
                                <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={11} />
                              </span>
                            );
                          })}
                          {hotelAmenityIds(hotel.id).length === 0 && <span className="text-[11px] text-slate-400">None set</span>}
                        </div>
                      </div>
                      <div className="mt-4 space-y-2.5 border-t border-slate-100 pt-4 text-xs text-slate-500">
                        <div className="flex items-center justify-between"><span className="flex items-center gap-2"><Clock3 size={14} /> Check-in / out</span><b className="text-slate-700">{hotel.checkInTime} / {hotel.checkOutTime}</b></div>
                        <div className="flex items-center justify-between"><span>Tax basis</span><b className="text-slate-700">{hotel.tourismTaxBasis.replace("_", " / ")}</b></div>
                      </div>
                      <div className="mt-4 border-t border-slate-100 pt-4">
                        <div className="mb-2 flex items-center justify-between">
                          <span className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Contacts ({contactsFor(hotel.id).length})</span>
                          <div className="flex items-center gap-3"><button onClick={() => setManagerHotelId(hotel.id)} className="text-[10px] font-bold text-[#166159]">Manage</button><button onClick={() => openHotelContact(hotel.id)} className="text-[10px] font-bold text-[#166159]">Add new</button></div>
                        </div>
                        <div className="space-y-2">
                          {contactsFor(hotel.id).map((contact) => (
                            <div key={contact.id} className="rounded-xl border border-slate-100 p-2.5">
                              <div className="flex items-start justify-between gap-2">
                                <div className="min-w-0">
                                  <div className="truncate text-xs font-bold text-slate-800">{contact.name}</div>
                                  <div className="truncate text-[10px] text-slate-500">{contact.position}</div>
                                </div>
                                <button disabled={saving} onClick={() => void deleteContact(contact, hotel.id)} className="rounded p-1 text-slate-300 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50" title={`Remove only from ${hotel.name}`} aria-label={`Remove ${contact.name} from ${hotel.name}`}><Trash2 size={13} /></button>
                              </div>
                              {contact.email && <a href={`mailto:${contact.email}`} className="mt-1 block truncate text-[10px] text-sky-700 underline">{contact.email}</a>}
                              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                                {contact.phone && <span className="text-[10px] font-semibold text-slate-600">{contact.phone}</span>}
                                {contact.whatsapp && contact.phone && <a href={messagingLink("whatsapp", contact.phone)} target="_blank" rel="noreferrer" className="rounded bg-emerald-50 px-1.5 py-0.5 text-[9px] font-bold text-emerald-700">WhatsApp</a>}
                                {contact.telegram && contact.phone && <a href={messagingLink("telegram", contact.phone)} target="_blank" rel="noreferrer" className="rounded bg-sky-50 px-1.5 py-0.5 text-[9px] font-bold text-sky-700">Telegram</a>}
                                {contact.viber && contact.phone && <a href={messagingLink("viber", contact.phone)} target="_blank" rel="noreferrer" className="rounded bg-violet-50 px-1.5 py-0.5 text-[9px] font-bold text-violet-700">Viber</a>}
                                {contact.businessCardLink && <a href={contact.businessCardLink} target="_blank" rel="noreferrer" className="rounded bg-slate-100 px-1.5 py-0.5 text-[9px] font-bold text-slate-600">Card</a>}
                              </div>
                              {contact.otherContact && <div className="mt-1 text-[10px] text-slate-500">Other: {contact.otherContact}</div>}
                            </div>
                          ))}
                          {contactsFor(hotel.id).length === 0 && <p className="text-[11px] text-slate-400">No contacts yet.</p>}
                        </div>
                      </div>
                    </div>
                  </article>
                );
              })}
              {cardHotels.length === 0 && (
                <div className="col-span-full rounded-2xl border border-dashed border-slate-200 bg-white/60 px-6 py-12 text-center">
                  <div className="text-sm font-bold text-slate-700">No hotels match “{cardQuery}”</div>
                  <button type="button" onClick={() => setCardQuery("")} className="mt-2 text-xs font-bold text-teal-700 underline">Clear search</button>
                </div>
              )}
            </section>
            </>
          )}

          {view === "rooms" && (
            <>
            <section className={`${card} mb-5 flex flex-wrap items-center justify-between gap-4 px-5 py-4`}>
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">Search categories</h2>
                <p className="mt-1 text-xs text-slate-400">These are the room types guests can search for across all hotels. Add your own if a contract needs one.</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {data.roomCategories.map((category) => (
                  <span key={category.id} className="inline-flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[11px] font-bold text-slate-600 ring-1 ring-slate-200" title={`${data.rooms.filter((room) => room.category === category.slug).length} room types`}>
                    {category.label}
                    <span className="text-slate-400">{data.rooms.filter((room) => room.category === category.slug).length}</span>
                  </span>
                ))}
                <button onClick={() => setDialog("category")} className="inline-flex items-center gap-1.5 rounded-lg bg-[#174e48] px-3 py-1.5 text-[11px] font-bold text-white"><Plus size={13} /> Add category</button>
              </div>
            </section>
            <section className={`${card} overflow-hidden`}>
              <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-extrabold">Room inventory</h2><p className="mt-1 text-xs text-slate-400">{filteredRooms.length} room types · the category is what search uses to compare hotels (e.g. every “Triple Room”)</p></div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[980px] text-left">
                  <thead className="bg-slate-50/80 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                    <tr><th className="px-5 py-3.5">Room & hotel</th><th className="px-4 py-3.5">Category</th><th className="px-4 py-3.5">Sleeps / max occupancy</th><th className="px-4 py-3.5">Permitted combinations</th><th className="px-4 py-3.5">Extra bedding</th><th className="px-4 py-3.5">Allocation</th><th className="px-3 py-3.5">Media</th><th className="px-5 py-3.5">Actions</th></tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredRooms.map((room) => (
                      <tr key={room.id} className="text-sm hover:bg-slate-50/60">
                        <td className="px-5 py-4"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-teal-50 text-teal-700"><BedDouble size={17} /></div><div><div className="font-bold text-slate-800">{room.name}</div><div className="mt-0.5 text-[11px] text-slate-400">{hotelName(room.hotelId)} · {room.code}</div></div></div></td>
                        <td className="px-4 py-4"><span className="rounded-md bg-teal-50 px-2 py-1 text-[10px] font-extrabold uppercase text-teal-700">{categoryLabel(room.category)}</span></td>
                        <td className="px-4 py-4 text-xs text-slate-600"><b className="text-slate-800">Sleeps {room.baseSleeps}</b><div className="mt-0.5">{room.maxAdults} adults · {room.maxChildren} children · {room.maxInfants} infants</div></td>
                        <td className="max-w-[260px] px-4 py-4"><div className="flex flex-wrap gap-1">{data.occupancies.filter((rule) => rule.roomTypeId === room.id).map((rule) => <span key={rule.id} title={rule.label} className="rounded-md border border-slate-200 px-1.5 py-1 text-[10px] font-semibold text-slate-500">{rule.label}</span>)}</div></td>
                        <td className="max-w-[240px] px-4 py-4">
                          <div className="flex flex-wrap gap-1">
                            {beddingFor(room.id).map((option) => (
                              <span key={option.id} className={`rounded-md px-1.5 py-1 text-[10px] font-bold ${option.free ? "bg-emerald-50 text-emerald-700" : "bg-violet-50 text-violet-700"}`} title={option.perStay ? "Charged once per stay" : "Charged per night"}>
                                {option.label} ×{option.maxPerRoom}{option.free ? " free" : ` ${Number(option.ratePerNight)}`}
                              </span>
                            ))}
                            {beddingFor(room.id).length === 0 && <span className="text-[11px] text-slate-400">None</span>}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-xs font-bold">{room.defaultInventory} rooms</td>
                        <td className="px-3 py-4">{room.mediaLink ? <a href={room.mediaLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600 hover:bg-slate-200"><ExternalLink size={11} /> Media</a> : <span className="text-[10px] text-slate-300">—</span>}</td>
                        <td className="px-5 py-4">
                          <div className="flex flex-wrap gap-1.5">
                            <button disabled={saving} onClick={() => setRoomEditId(room.id)} className="rounded-lg border border-slate-200 px-2 py-1 text-[10px] font-bold text-slate-600 transition hover:border-teal-300 hover:text-teal-700 disabled:opacity-50">Edit</button>
                            <button disabled={saving} onClick={() => void duplicateRoom(room)} title="Copy room type with its bedding and occupancy rules" className="rounded-lg border border-slate-200 px-2 py-1 text-[10px] font-bold text-slate-600 transition hover:border-teal-300 hover:text-teal-700 disabled:opacity-50">Duplicate</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
            </>
          )}

          {view === "rates" && (
            <section className={`${card} overflow-hidden`}>
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
                <div><h2 className="font-extrabold">Seasonal rate lines</h2><p className="mt-1 text-xs text-slate-400">{filteredRates.length} lines · net AED · shorter periods (e.g. festive peak) override the season they fall in</p></div>
                <div className="w-full sm:w-72"><SelectWrap><select value={rateHotel} onChange={(event) => setRateHotel(Number(event.target.value))} className={`${selectClass} h-10`}><option value={0}>All hotels</option>{data.hotels.map((hotel) => <option key={hotel.id} value={hotel.id}>{hotel.name}</option>)}</select></SelectWrap></div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1320px] text-left">
                  <thead className="bg-slate-50/80 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                    <tr><th className="px-5 py-3.5">Rate & hotel</th><th className="px-4 py-3.5">Room</th><th className="px-4 py-3.5">Stay period</th><th className="px-4 py-3.5">Booking window</th><th className="px-4 py-3.5">Market / promo</th><th className="px-4 py-3.5">Board</th><th className="px-4 py-3.5">Base net</th><th className="px-4 py-3.5">Meal supplement</th><th className="px-5 py-3.5">Extra adult / child / bed</th></tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredRates.slice(0, 250).map((rate) => (
                      <tr key={rate.id} className="text-sm hover:bg-slate-50/60">
                        <td className="px-5 py-3.5"><div className="font-bold text-slate-800">{rate.name}</div><div className="mt-0.5 text-[11px] text-slate-400">{hotelName(rate.hotelId)}</div></td>
                        <td className="px-4 py-3.5 text-xs font-semibold text-slate-600">{roomName(rate.roomTypeId)}</td>
                        <td className="px-4 py-3.5"><div className="flex items-center gap-1.5 text-xs text-slate-600"><CalendarDays size={13} /> {formatDate(rate.validFrom, { day: "2-digit", month: "short", year: "2-digit" })} – {formatDate(rate.validTo, { day: "2-digit", month: "short", year: "2-digit" })}</div>{rate.minimumNights > 1 && <div className="mt-1 text-[10px] font-semibold text-amber-700">Min. {rate.minimumNights} nights</div>}</td>
                        <td className="px-4 py-3.5 text-xs text-slate-600">{rate.bookingWindowStart || rate.bookingWindowEnd ? <span className="inline-flex items-center gap-1.5 rounded-full bg-sky-50 px-2 py-1 text-[10px] font-bold text-sky-700"><Clock3 size={11} /> {rate.bookingWindowStart ? formatDate(rate.bookingWindowStart, { day: "2-digit", month: "short", year: "2-digit" }) : "open"} – {rate.bookingWindowEnd ? formatDate(rate.bookingWindowEnd, { day: "2-digit", month: "short", year: "2-digit" }) : "open"}</span> : <span className="text-[10px] text-slate-400">Always open</span>}</td>
                        <td className="px-4 py-3.5 text-xs">
                          <div className="font-semibold text-slate-600">{marketLabel(rate.market)}</div>
                          {parseMarketList(rate.marketExclusions).length > 0 && <div className="mt-0.5 text-[10px] text-rose-600">excl. {parseMarketList(rate.marketExclusions).map((slug) => marketLabel(slug)).join(", ")}</div>}
                          {rate.promoCode && <div className="mt-1 inline-flex items-center gap-1 rounded bg-rose-50 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-rose-700">{rate.promoCode}</div>}
                        </td>
                        <td className="px-4 py-3.5"><span className="inline-flex items-center gap-1.5 rounded-full bg-orange-50 px-2.5 py-1 text-[10px] font-bold text-orange-700"><UtensilsCrossed size={11} /> {boardLabel(rate.boardType)}</span></td>
                        <td className="px-4 py-3.5"><div className="font-extrabold text-slate-900">{formatMoney(rate.baseRate)}</div><div className="text-[10px] text-slate-400">per {rate.rateBasis === "person_night" ? "person" : "room"} / night</div></td>
                        <td className="px-4 py-3.5 text-xs text-slate-600">{Number(rate.boardAdultSupplement) === 0 ? <span className="text-slate-400">Included</span> : rate.boardSupplementBasis === "room_night" ? <>{formatMoney(rate.boardAdultSupplement)} per room</> : <><div>Adult {formatMoney(rate.boardAdultSupplement)}</div><div className="mt-0.5">Child {formatMoney(rate.boardChildSupplement)}</div></>}</td>
                        <td className="px-5 py-3.5 text-xs text-slate-600">{formatMoney(rate.extraAdultRate)} / {formatMoney(rate.extraChildRate)} / {formatMoney(rate.extraBedRate)}{rate.extraBedBasis === "per_stay" ? " stay" : ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredRates.length > 250 && <div className="border-t border-slate-100 px-5 py-3 text-center text-xs text-slate-400">Showing 250 of {filteredRates.length} lines — choose a hotel to narrow the list.</div>}
              </div>
            </section>
          )}

          {view === "blackouts" && (
            <section className="grid gap-4 lg:grid-cols-2">
              {data.blackouts.filter((item) => `${hotelName(item.hotelId)} ${item.reason}`.toLowerCase().includes(normalizedSearch)).map((blackout) => {
                const past = blackout.endDate < today;
                return (
                  <article key={blackout.id} className={`${card} p-5 ${past ? "opacity-60" : ""}`}>
                    <div className="flex items-start gap-4">
                      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-amber-50 text-amber-700"><CalendarX2 size={22} /></div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="font-extrabold text-slate-900">{hotelName(blackout.hotelId)}</h2><span className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide ${past ? "bg-slate-100 text-slate-500" : "bg-rose-50 text-rose-700"}`}>{past ? "Past" : "Do not book"}</span></div>
                        <p className="mt-1 text-xs font-semibold text-slate-500">{roomName(blackout.roomTypeId)}</p>
                        <div className="mt-4 flex items-center gap-2 rounded-xl bg-slate-50 px-3.5 py-3 text-sm font-bold text-slate-700"><CalendarDays size={16} className="text-amber-700" /> {formatDate(blackout.startDate)} <span className="text-slate-300">→</span> {formatDate(blackout.endDate)}</div>
                        <p className="mt-3 text-xs leading-5 text-slate-500">{blackout.reason}</p>
                      </div>
                    </div>
                  </article>
                );
              })}
              <button onClick={openBlackout} className="flex min-h-[190px] items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 bg-white/50 text-sm font-bold text-slate-400 transition hover:border-teal-300 hover:text-teal-700"><Plus size={17} className="mr-2" /> Record fully booked dates</button>
            </section>
          )}

          {view === "bookings" && (
            <section className={`${card} overflow-hidden`}>
              <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-extrabold">Reservation ledger</h2><p className="mt-1 text-xs text-slate-400">{filteredBookings.length} reservations · {formatMoney(confirmedValue)} confirmed value · new bookings are made from Search & compare</p></div>
              {bookingTable(filteredBookings)}
            </section>
          )}

          {view === "quotations" && (
            <section className="space-y-4">
              {filteredQuotations.map((quotation) => {
                const legs = itemsFor(quotation.id);
                const open = expandedQuotation === quotation.id;
                const proposal = proposalFor(quotation);
                const hasMarkup = Number(quotation.markupPercent) > 0 || Number(quotation.markupAmount) > 0;
                return (
                  <article key={quotation.id} className={`${card} overflow-hidden`}>
                    <div className="flex flex-wrap items-center gap-4 px-5 py-4">
                      <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-teal-50 text-teal-700"><FileText size={19} /></div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-extrabold text-[#175a53]">{quotation.reference}</span>
                          <QuoteStatusBadge status={quotation.status} />
                          <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">
                            {legs.length} stay{legs.length === 1 ? "" : "s"}
                          </span>
                          <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${quotation.includeTourismTax ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}>
                            {quotation.includeTourismTax ? "Tax included" : "Tax excluded"}
                          </span>
                          {hasMarkup && (
                            <span data-internal className="rounded-full bg-violet-50 px-2 py-0.5 text-[10px] font-bold text-violet-700 print:hidden">
                              Markup{Number(quotation.markupPercent) > 0 ? ` ${Number(quotation.markupPercent)}%` : ""}{Number(quotation.markupAmount) > 0 ? ` +${formatMoney(quotation.markupAmount, quotation.currency)}` : ""}
                            </span>
                          )}
                        </div>
                        <div className="mt-1 truncate text-xs font-semibold text-slate-700">
                          {quotation.clientName}
                          {quotation.clientEmail && <span className="font-normal text-slate-400"> · {quotation.clientEmail}</span>}
                        </div>
                        <div className="mt-0.5 truncate text-[11px] text-slate-400">
                          {legs.map((leg) => `${leg.nights}n ${hotelName(leg.hotelId)}`).join("  +  ") || "No stays"}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[9px] font-bold uppercase tracking-[0.1em] text-slate-400">Proposal total</div>
                        <div className="text-lg font-extrabold text-[#175a53]">{formatMoney(proposal.proposalTotal, quotation.currency)}</div>
                        <div data-internal className="mt-0.5 text-[10px] text-slate-400 print:hidden">
                          Net {formatMoney(proposal.subtotal, quotation.currency)}{proposal.margin > 0 ? ` · margin +${formatMoney(proposal.margin, quotation.currency)}` : ""}
                        </div>
                        <div className="mt-0.5 text-[10px] text-slate-400">
                          {quotation.validUntil ? `Valid until ${formatDate(quotation.validUntil, { day: "2-digit", month: "short" })} · ` : ""}
                          {formatDate(quotation.createdAt, { day: "2-digit", month: "short" })}
                        </div>
                      </div>
                      <div data-internal className="flex flex-wrap gap-1.5 print:hidden">
                        <button onClick={() => setExpandedQuotation(open ? null : quotation.id)} className="flex h-9 items-center gap-1 rounded-lg border border-slate-200 px-3 text-[11px] font-bold text-slate-600 hover:bg-slate-50">
                          Details {open ? <ChevronDown size={13} className="rotate-180" /> : <ChevronDown size={13} />}
                        </button>
                        {allowed("manage_quotations") && <button onClick={() => openPricing(quotation)} className="flex h-9 items-center gap-1.5 rounded-lg border border-violet-200 bg-violet-50 px-3 text-[11px] font-extrabold text-violet-700 hover:bg-violet-100">
                          <BadgeDollarSign size={13} /> Tax & markup
                        </button>}
                        <button
                          onClick={() => void copyProposal(quotation, "whatsapp")}
                          className={`flex h-9 items-center gap-1.5 rounded-lg border px-3 text-[11px] font-extrabold transition ${
                            copiedProposal === `${quotation.id}-whatsapp`
                              ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                              : "border-slate-200 text-slate-600 hover:bg-slate-50"
                          }`}
                          title="Copy the client proposal for WhatsApp"
                        >
                          {copiedProposal === `${quotation.id}-whatsapp` ? <Check size={13} /> : <Copy size={13} />}
                          {copiedProposal === `${quotation.id}-whatsapp` ? "Copied!" : "Copy proposal"}
                        </button>
                        <button
                          disabled={quotePdfBusy === quotation.id}
                          onClick={() => downloadQuotePdf(quotation)}
                          className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 px-3 text-[11px] font-extrabold text-slate-600 hover:bg-slate-50 disabled:opacity-60"
                          title="Download PDF to attach to an email"
                        >
                          {quotePdfBusy === quotation.id ? <Loader2 size={13} className="animate-spin" /> : <FileDown size={13} />}
                          PDF
                        </button>
                        <button onClick={() => void shareQuotationPdf(quotation)} disabled={quoteShareBusy === quotation.id} className="flex h-9 items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 px-3 text-[11px] font-extrabold text-teal-800 hover:bg-teal-100 disabled:opacity-60" title="Share the actual PDF file to WhatsApp, Telegram or another app"><ExternalLink size={13} /> Share PDF</button>
                        {allowed("send_email") && <button onClick={() => setEmailTarget({ type: "quotation", id: quotation.id, reference: quotation.reference, clientName: quotation.clientName, clientEmail: quotation.clientEmail })} className="flex h-9 items-center gap-1.5 rounded-lg border border-sky-200 bg-sky-50 px-3 text-[11px] font-extrabold text-sky-700 hover:bg-sky-100" title="Send the PDF attachment via SMTP"><Mail size={13} /> Email PDF</button>}
                        {allowed("manage_bookings") && quotation.status !== "converted" && quotation.status !== "cancelled" && (
                          <button onClick={() => openConvert(quotation)} className="flex h-9 items-center gap-1.5 rounded-lg bg-[#174e48] px-3 text-[11px] font-extrabold text-white hover:bg-[#103f3a]">
                            <CheckCircle2 size={13} /> Convert to booking{legs.length > 1 ? "s" : ""}
                          </button>
                        )}
                        {allowed("manage_quotations") && <button disabled={saving} onClick={() => void deleteQuotation(quotation)} className="grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-slate-400 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50" aria-label={`Delete ${quotation.reference}`} title="Delete quotation"><Trash2 size={14} /></button>}
                      </div>
                    </div>

                    {open && (
                      <div className="border-t border-slate-100 bg-slate-50/40 px-5 py-4">
                        <div className="space-y-3">
                          {legs.map((leg, index) => {
                            const share = proposal.legs[index];
                            return (
                              <div key={leg.id} className="rounded-xl border border-slate-200 bg-white p-4">
                                <div className="flex flex-wrap items-start justify-between gap-3">
                                  <div className="flex items-start gap-3">
                                    <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-teal-700 text-xs font-extrabold text-white">{index + 1}</div>
                                    <div>
                                      <div className="text-sm font-extrabold text-slate-900">{hotelName(leg.hotelId)}</div>
                                      <div className="mt-0.5 text-xs text-slate-500">{roomName(leg.roomTypeId)} · {boardLabel(leg.boardType)}</div>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <div className="text-sm font-extrabold text-[#175a53]">{formatMoney(share?.share ?? leg.totalAmount, quotation.currency)}</div>
                                    <div className="mt-0.5 text-[10px] text-slate-400">
                                      {formatMoney(share?.dailyRate ?? 0, quotation.currency)}/room/night<span data-internal className="print:hidden"> · net {formatMoney(leg.totalAmount, quotation.currency)}</span>
                                    </div>
                                  </div>
                                </div>
                                <div className="mt-3 grid gap-x-6 gap-y-1.5 text-[11px] text-slate-500 sm:grid-cols-2 lg:grid-cols-4">
                                  <span className="flex items-center gap-1.5"><CalendarDays size={12} /> {formatDate(leg.checkIn, { day: "2-digit", month: "short" })} → {formatDate(leg.checkOut, { day: "2-digit", month: "short", year: "numeric" })} ({leg.nights}n)</span>
                                  <span>{leg.adults}A · {leg.children}C · {leg.infants}I · {leg.rooms} room{leg.rooms === 1 ? "" : "s"}</span>
                                  <span data-internal className="print:hidden">Base {formatMoney(leg.baseAmount)} · Meals {formatMoney(leg.boardAmount)} · Tax {formatMoney(leg.tourismTaxAmount)}</span>
                                  <span data-internal className="truncate print:hidden" title={leg.rateNames}>{leg.rateNames || "Contract rate"}{leg.promoCodes ? ` · ${leg.promoCodes}` : ""}</span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                        <div data-internal className="mt-3 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 text-xs print:hidden md:grid-cols-2">
                          <div className="space-y-1.5">
                            <div className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Proposal breakdown (internal)</div>
                            <div className="flex justify-between text-slate-500"><span>Net cost{quotation.includeTourismTax ? " (tax included)" : " (tax excluded)"}</span><b className="text-slate-800">{formatMoney(proposal.subtotal, quotation.currency)}</b></div>
                            {(Number(quotation.markupPercent) > 0 || Number(quotation.markupAmount) > 0) && (
                              <div className="flex justify-between text-slate-500">
                                <span>Markup{Number(quotation.markupPercent) > 0 ? ` ${Number(quotation.markupPercent)}% (${formatMoney(proposal.markupPercentAmount, quotation.currency)})` : ""}{Number(quotation.markupAmount) > 0 ? ` + ${formatMoney(proposal.markupFixedAmount, quotation.currency)}` : ""}</span>
                                <b className="text-violet-700">+{formatMoney(proposal.margin, quotation.currency)}</b>
                              </div>
                            )}
                            {!quotation.includeTourismTax && (
                              <div className="flex justify-between text-amber-700"><span>Tourism tax excluded (payable at hotel)</span><b>{formatMoney(proposal.excludedTax, quotation.currency)}</b></div>
                            )}
                            <div className="flex justify-between border-t border-slate-100 pt-1.5 text-sm font-extrabold text-[#175a53]"><span>Proposal total</span><span>{formatMoney(proposal.proposalTotal, quotation.currency)}</span></div>
                          </div>
                          <div className="flex flex-col justify-between gap-3">
                            <p className="text-[11px] leading-5 text-slate-500">Copy the client-ready proposal — daily rates already include your markup. Margin is never shown to the client.</p>
                            <div className="flex flex-wrap gap-2">
                              <button onClick={() => void copyProposal(quotation, "whatsapp")} className="flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-3 text-xs font-extrabold text-white hover:bg-emerald-700">
                                {copiedProposal === `${quotation.id}-whatsapp` ? <Check size={14} /> : <Copy size={14} />} {copiedProposal === `${quotation.id}-whatsapp` ? "Copied!" : "Copy for WhatsApp"}
                              </button>
                              <button onClick={() => void copyProposal(quotation, "email")} className="flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-extrabold text-slate-700 hover:bg-slate-50">
                                {copiedProposal === `${quotation.id}-email` ? <Check size={14} /> : <Copy size={14} />} {copiedProposal === `${quotation.id}-email` ? "Copied!" : "Copy for email"}
                              </button>
                            </div>
                          </div>
                        </div>
                        {(quotation.notes || quotation.clientPhone) && (
                          <div className="mt-3 space-y-1 text-xs text-slate-500">
                            {quotation.clientPhone && <p>Client phone: <b className="text-slate-700">{quotation.clientPhone}</b></p>}
                            {quotation.notes && <p className="leading-5">Notes: {quotation.notes}</p>}
                          </div>
                        )}
                      </div>
                    )}
                  </article>
                );
              })}
              {filteredQuotations.length === 0 && (
                <div className={`${card} grid place-items-center px-6 py-16 text-center`}>
                  <FileText size={26} className="text-slate-300" />
                  <div className="mt-3 text-sm font-bold text-slate-700">No quotations yet</div>
                  <div className="mt-1 max-w-sm text-xs text-slate-400">Search for a stay, press “Add to quotation” on any result, then review and save — combine several hotels into one quotation.</div>
                  <button onClick={() => navigate("search")} className="mt-4 flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-bold text-white">Go to Search & compare</button>
                </div>
              )}
            </section>
          )}

          {view === "trips" && (
            <TripPackagesPanel
              packages={data.tripPackages}
              transfers={data.tripTransfers}
              tours={data.tripTours}
              services={data.services}
              quotations={data.quotations}
              quotationItems={data.quotationItems}
              hotels={data.hotels}
              rooms={data.rooms}
              locations={data.locations}
              canManage={allowed("manage_packages")}
              canEmail={allowed("send_email")}
              onEmail={(pkg) => setEmailTarget({ type: "trip", id: pkg.id, reference: pkg.reference, clientName: pkg.clientName, clientEmail: pkg.clientEmail })}
              onChanged={(message) => {
                setToast({ type: "success", message });
                navigate("trips");
                router.refresh();
              }}
            />
          )}

          {view === "services" && (
            <ServicesPanel
              services={data.services}
              canManage={allowed("manage_services")}
              onChanged={(message) => {
                setToast({ type: "success", message });
                navigate("services");
                router.refresh();
              }}
            />
          )}
          {view === "users" && user.role === "admin" && <UsersPanel currentId={user.id} />}
        </div>
      </main>

      {pricingQuotation && (() => {
        const legs = itemsFor(pricingQuotation.id);
        const preview = computeProposal(legs, {
          includeTourismTax: pricingFields.includeTax,
          markupPercent: pricingFields.pct === "" ? 0 : Number(pricingFields.pct),
          markupAmount: pricingFields.amt === "" ? 0 : Number(pricingFields.amt),
        });
        return (
          <Modal title={`Proposal pricing · ${pricingQuotation.reference}`} subtitle="Hotel net cost never changes — this only sets what the client pays." onClose={() => setPricingQuotation(null)}>
            <form onSubmit={savePricing} className="grid gap-4">
              <label className="flex cursor-pointer items-center justify-between gap-3 rounded-xl bg-slate-50 px-4 py-3.5">
                <span>
                  <span className="block text-sm font-bold text-slate-800">Include tourism tax in proposal</span>
                  <span className="mt-0.5 block text-[11px] text-slate-500">Off = client pays it at the hotel; the proposal says so.</span>
                </span>
                <input
                  type="checkbox"
                  checked={pricingFields.includeTax}
                  onChange={(event) => setPricingFields((current) => ({ ...current, includeTax: event.target.checked }))}
                  className="h-5 w-5 accent-teal-700"
                />
              </label>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Markup %">
                  <input
                    type="number"
                    min="0"
                    max="500"
                    step="0.5"
                    value={pricingFields.pct}
                    onChange={(event) => setPricingFields((current) => ({ ...current, pct: event.target.value }))}
                    placeholder="0"
                    className={inputClass}
                  />
                </Field>
                <Field label={`Markup ${pricingQuotation.currency}`}>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={pricingFields.amt}
                    onChange={(event) => setPricingFields((current) => ({ ...current, amt: event.target.value }))}
                    placeholder="0"
                    className={inputClass}
                  />
                </Field>
              </div>
              <p className="-mt-1 text-[11px] text-slate-400">% applies to the net subtotal first, then the fixed amount is added. Both can be combined.</p>
              <div className="space-y-1.5 rounded-xl bg-slate-50 p-4 text-xs">
                <div className="flex justify-between text-slate-500"><span>Net cost{pricingFields.includeTax ? " (incl. tax)" : " (excl. tax)"}</span><b className="text-slate-800">{formatMoney(preview.subtotal, pricingQuotation.currency)}</b></div>
                <div className="flex justify-between text-slate-500"><span>Markup</span><b className="text-violet-700">+{formatMoney(preview.margin, pricingQuotation.currency)}</b></div>
                {!pricingFields.includeTax && (
                  <div className="flex justify-between text-amber-700"><span>Tourism tax excluded</span><b>{formatMoney(preview.excludedTax, pricingQuotation.currency)}</b></div>
                )}
                <div className="flex justify-between border-t border-slate-200 pt-2 text-sm font-extrabold text-[#175a53]"><span>Proposal total</span><span>{formatMoney(preview.proposalTotal, pricingQuotation.currency)}</span></div>
              </div>
              {pricingError && <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-xs font-semibold text-rose-700"><AlertTriangle size={15} className="shrink-0" /> {pricingError}</div>}
              <div className="flex justify-end border-t border-slate-100 pt-5">
                <button disabled={pricingSaving} className="flex h-11 min-w-36 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white transition hover:bg-[#103f3a] disabled:opacity-60">
                  {pricingSaving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />} {pricingSaving ? "Saving…" : "Save pricing"}
                </button>
              </div>
            </form>
          </Modal>
        );
      })()}

      {convertingQuotation && (
        <Modal title={`Convert ${convertingQuotation.reference}`} subtitle="Creates one confirmed booking per stay at net hotel cost (your markup is not booked with the hotel). Every price is re-checked against live contracts first." onClose={() => setConvertingQuotation(null)}>
          <form onSubmit={convertQuotation} className="grid gap-4 md:grid-cols-2">
            <Field label="Lead guest name"><input value={convertGuest.name} onChange={(event) => setConvertGuest((current) => ({ ...current, name: event.target.value }))} required className={inputClass} placeholder="Full name as per passport" /></Field>
            <Field label="Guest / agent email"><input value={convertGuest.email} onChange={(event) => setConvertGuest((current) => ({ ...current, email: event.target.value }))} required type="email" className={inputClass} placeholder="guest@email.com" /></Field>
            <Field label="Phone"><input value={convertGuest.phone} onChange={(event) => setConvertGuest((current) => ({ ...current, phone: event.target.value }))} className={inputClass} placeholder="+971" /></Field>
            <Field label="Notes for hotels"><input value={convertGuest.notes} onChange={(event) => setConvertGuest((current) => ({ ...current, notes: event.target.value }))} className={inputClass} placeholder="Arrival time, bed preference…" /></Field>
            <div className="rounded-xl bg-slate-50 p-4 md:col-span-2">
              <div className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-slate-400">Stays to be booked · {formatMoney(convertingQuotation.totalAmount, convertingQuotation.currency)}</div>
              <div className="mt-2 space-y-1.5">
                {itemsFor(convertingQuotation.id).map((leg, index) => (
                  <div key={leg.id} className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-semibold text-slate-700">{index + 1}. {hotelName(leg.hotelId)} · {roomName(leg.roomTypeId)}</span>
                    <span className="text-slate-500">{formatDate(leg.checkIn, { day: "2-digit", month: "short" })} → {formatDate(leg.checkOut, { day: "2-digit", month: "short" })} · {formatMoney(leg.totalAmount)}</span>
                  </div>
                ))}
              </div>
            </div>
            {convertError && <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-xs font-semibold text-rose-700 md:col-span-2"><AlertTriangle size={15} className="shrink-0" /> {convertError}</div>}
            <SubmitRow saving={convertSaving} label={`Confirm ${itemsFor(convertingQuotation.id).length === 1 ? "booking" : "bookings"}`} />
          </form>
        </Modal>
      )}

      {dialog === "hotel" && (
        <Modal title="Add contracted hotel" subtitle="Supplier profile with tax and arrival policies." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/hotels", "Hotel added with the selected group and contacts. Now add its rooms and rates.", (raw) => ({
            ...raw,
            groupId: Number(newHotelGroupId) > 0 ? Number(newHotelGroupId) : null,
            newGroup: newHotelGroupId === "__new__" ? { name: String(raw.newGroupName ?? ""), website: String(raw.newGroupWebsite ?? "") } : null,
            includedContactIds: newHotelSharedContactIds,
            amenityIds: toList(raw.amenityIds),
            contacts: newHotelContactSlots
              .map((slot) => ({
                name: String(raw[`contactName${slot}`] ?? ""),
                position: String(raw[`contactPosition${slot}`] ?? ""),
                email: String(raw[`contactEmail${slot}`] ?? ""),
                phone: String(raw[`contactPhone${slot}`] ?? ""),
                businessCardLink: String(raw[`contactCard${slot}`] ?? ""),
                whatsapp: raw[`contactWhatsapp${slot}`] === "on",
                telegram: raw[`contactTelegram${slot}`] === "on",
                viber: raw[`contactViber${slot}`] === "on",
                otherContact: String(raw[`contactOther${slot}`] ?? ""),
                addToGroup: raw[`contactShare${slot}`] === "on" && newHotelGroupId !== "",
              }))
              .filter((contact) => contact.name.trim().length > 0),
          }))} className="grid gap-4 md:grid-cols-2">
            <Field label="Hotel name"><input name="name" required className={inputClass} placeholder="e.g. Jumeirah Al Naseem" /></Field>
            <Field label="Supplier code"><input name="supplierCode" required className={inputClass} placeholder="e.g. JAN-DXB" /></Field>
            <Field label="City / emirate" hint="Pick an existing one or type a new city/emirate.">
              <input name="city" required list="city-options" value={newHotelCity} onChange={(event) => setNewHotelCity(event.target.value)} className={inputClass} placeholder="Dubai" autoComplete="off" />
              <datalist id="city-options">{cities.map((city) => <option key={city} value={city} />)}</datalist>
            </Field>
            {(() => {
              const cityPlaces = data.locations.filter((location) => location.city.toLowerCase() === newHotelCity.trim().toLowerCase());
              return (
                <Field
                  label="Location in this city / emirate"
                  hint={newHotelCity.trim()
                    ? cityPlaces.length > 0
                      ? `${cityPlaces.length} saved in ${newHotelCity.trim()} — pick one or type a new area (e.g. Deira).`
                      : `No areas saved for ${newHotelCity.trim()} yet — typing one here creates it.`
                    : "Enter the city/emirate first, e.g. Dubai → Deira."}
                >
                  <input name="location" list="location-options" disabled={!newHotelCity.trim()} className={`${inputClass} disabled:bg-slate-50 disabled:text-slate-400`} placeholder={newHotelCity.trim() ? "e.g. Deira" : "Choose the city first"} autoComplete="off" />
                  <datalist id="location-options">{cityPlaces.map((location) => <option key={location.id} value={location.name} />)}</datalist>
                </Field>
              );
            })()}
            <Field label="Star rating"><SelectWrap><select name="starRating" defaultValue="4" className={selectClass}>{[5, 4, 3, 2, 1].map((stars) => <option key={stars} value={stars}>{stars} stars</option>)}</select></SelectWrap></Field>
            <div className="md:col-span-2 rounded-2xl border border-teal-100 bg-[#f0f8f6] p-4 sm:p-5">
              <div className="flex items-start gap-3"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-teal-700"><UsersRound size={17} /></div><div><div className="text-sm font-extrabold text-[#174e48]">Umbrella company & shared sales team</div><p className="mt-0.5 text-[11px] leading-5 text-slate-500">Choosing a group brings in contacts used at its other hotels. Untick anyone this hotel does not need.</p></div></div>
              <label className="mt-4 block"><span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Umbrella company</span><SelectWrap><select value={newHotelGroupId} onChange={(event) => selectHotelGroup(event.target.value)} className={selectClass}><option value="">Independent (no group)</option>{data.hotelGroups.map((group) => <option key={group.id} value={group.id}>{group.name}</option>)}<option value="__new__">＋ Create a new umbrella company</option></select></SelectWrap></label>
              {newHotelGroupId === "__new__" && <div className="mt-3 grid gap-3 rounded-xl border border-teal-200 bg-white p-3 sm:grid-cols-2"><Field label="New group name"><input name="newGroupName" required className={inputClass} placeholder="e.g. Al Khoory Hotels" /></Field><Field label="Group website (optional)"><input name="newGroupWebsite" type="url" className={inputClass} placeholder="https://hotelgroup.com" /></Field><p className="text-[11px] leading-5 text-slate-500 sm:col-span-2">The umbrella company and this hotel will be saved together. Contacts marked “also share with group” will be available for its next hotels.</p></div>}
              {Number(newHotelGroupId) > 0 && <div className="mt-4 rounded-xl border border-teal-200 bg-white p-3.5"><div className="flex items-center justify-between gap-2"><span className="text-xs font-extrabold text-slate-800">Contacts from this group and its hotels</span><span className="rounded-full bg-teal-50 px-2 py-1 text-[10px] font-bold text-teal-700">{newHotelSharedContactIds.length} selected</span></div>{inheritedCandidates.length > 0 ? <div className="mt-3 grid gap-2 sm:grid-cols-2">{inheritedCandidates.map((contact) => <label key={contact.id} className={`flex cursor-pointer items-start gap-2.5 rounded-xl border p-3 transition ${newHotelSharedContactIds.includes(contact.id) ? "border-teal-300 bg-teal-50/60" : "border-slate-200 bg-white"}`}><input type="checkbox" checked={newHotelSharedContactIds.includes(contact.id)} onChange={(event) => setNewHotelSharedContactIds((current) => event.target.checked ? [...current, contact.id] : current.filter((id) => id !== contact.id))} className="mt-0.5 accent-teal-700" /><span className="min-w-0"><span className="block truncate text-xs font-bold text-slate-800">{contact.name}</span><span className="block truncate text-[10px] text-slate-500">{contact.position || contact.email || contact.phone || "Sales contact"}</span><span className="mt-1 block text-[10px] font-semibold text-teal-700">{contact.groupId ? "Group contact" : "From another group hotel"}</span></span></label>)}</div> : <p className="mt-2 text-xs text-slate-400">No contacts yet in this group. Add the first below, or save the hotel without contacts.</p>}<p className="mt-3 text-[11px] text-slate-500">Unchecked contacts stay at their original hotel or group; this new hotel will not use them.</p></div>}
            </div>
            <Field label="Business type"><input name="businessType" defaultValue="Hotel" className={inputClass} placeholder="Hotel / Hotel Apartments / DMC" /></Field>
            <Field label="Website"><input name="website" className={inputClass} placeholder="https://hotel.com" /></Field>
            <Field label="Contracts folder (Google Drive)" hint="Where the signed contracts for this hotel are stored."><input name="contractsFolderLink" className={inputClass} placeholder="https://drive.google.com/drive/folders/…" /></Field>
            <Field label="Media folder (Google Drive)" hint="Room photos and media for this hotel."><input name="mediaLink" className={inputClass} placeholder="https://drive.google.com/drive/folders/…" /></Field>
            <div className="md:col-span-2">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Contacts</span>
              <p className="mb-3 text-xs text-slate-400">Add as many as you need. Tick WhatsApp or Telegram and the number becomes a chat link.</p>
              <div className="space-y-3">
                {newHotelContactSlots.map((slot, index) => (
                  <div key={slot} className="rounded-xl border border-slate-200 bg-white p-3.5">
                    <div className="mb-3 flex items-center justify-between"><span className="text-xs font-extrabold text-slate-700">New contact {index + 1} <span className="font-medium text-slate-400">· optional</span></span><button type="button" onClick={() => setNewHotelContactSlots((slots) => slots.filter((item) => item !== slot))} className="text-[10px] font-bold text-rose-600 hover:underline">Remove block</button></div>
                    <div className="grid gap-3 md:grid-cols-2">
                      <Field label="Full name"><input name={`contactName${slot}`} className={inputClass} placeholder={slot === 0 ? "Farah Cadinouche" : ""} /></Field>
                      <Field label="Company position"><input name={`contactPosition${slot}`} className={inputClass} placeholder="Director of Sales & Marketing" /></Field>
                      <Field label="Email"><input name={`contactEmail${slot}`} type="email" className={inputClass} placeholder="name@hotel.com" /></Field>
                      <Field label="Contact number"><input name={`contactPhone${slot}`} className={inputClass} placeholder="+971501234567" /></Field>
                    </div>
                    <div className="mt-3 grid gap-3 md:grid-cols-2">
                      <Field label="Business card / contact card link"><input name={`contactCard${slot}`} className={inputClass} placeholder="https://drive.google.com/file/d/…" /></Field>
                      <Field label="Other (SMS, WeChat, extension…)"><input name={`contactOther${slot}`} className={inputClass} placeholder="e.g. WeChat: hotel Dos" /></Field>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {([["contactWhatsapp", "WhatsApp"], ["contactTelegram", "Telegram"], ["contactViber", "Viber"]] as const).map(([field, label]) => (
                        <label key={field} className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50"><input name={`${field}${slot}`} type="checkbox" defaultChecked={field === "contactWhatsapp"} className="accent-teal-700" /> {label}</label>
                      ))}
                    </div>
                    {newHotelGroupId !== "" && <label className="mt-3 flex cursor-pointer items-center gap-2.5 rounded-xl border border-teal-200 bg-teal-50 px-3 py-2.5 text-xs font-bold text-teal-900"><input name={`contactShare${slot}`} type="checkbox" className="accent-teal-700" /> Also add this contact to the umbrella company <span className="font-medium text-teal-700">(available to other hotels)</span></label>}
                  </div>
                ))}
              </div>
              <button type="button" onClick={() => setNewHotelContactSlots((slots) => [...slots, (Math.max(-1, ...slots) + 1)])} className="mt-3 inline-flex items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 px-3 py-2 text-xs font-bold text-teal-800 hover:bg-teal-100"><Plus size={14} /> Add another contact</button>
              <p className="mt-2 text-[11px] text-slate-400">Hotel-only contacts are not automatically added to the umbrella company. You can change their group membership later.</p>
            </div>
            <Field label="Contact email"><input name="contactEmail" type="email" className={inputClass} placeholder="contracts@hotel.com" /></Field>
            <Field label="Contact phone"><input name="contactPhone" className={inputClass} placeholder="+971" /></Field>
            <Field label="Check-in time"><input name="checkInTime" type="time" defaultValue="15:00" className={inputClass} /></Field>
            <Field label="Check-out time"><input name="checkOutTime" type="time" defaultValue="12:00" className={inputClass} /></Field>
            <Field label="Tourism tax (AED)"><input name="tourismTax" type="number" min="0" step="0.01" defaultValue="15" className={inputClass} /></Field>
            <Field label="Tax basis"><SelectWrap><select name="tourismTaxBasis" className={selectClass}><option value="room_night">Per room / night</option><option value="person_night">Per person / night</option><option value="per_stay">Per room / stay</option></select></SelectWrap></Field>
            <div className="md:col-span-2">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Amenities</span>
              <div className="grid gap-2 sm:grid-cols-2">
                {data.amenities.map((amenity) => (
                  <label key={amenity.id} className="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 px-3.5 py-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-50">
                    <input type="checkbox" name="amenityIds" value={amenity.id} className="accent-teal-700" />
                    <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={14} />
                  </label>
                ))}
              </div>
            </div>
            <SubmitRow saving={saving} label="Save hotel" />
          </form>
        </Modal>
      )}

      {dialog === "room" && (
        <Modal title="Add room type" subtitle="Choose the category so this room is compared with similar rooms at other hotels." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/rooms", "Room type added.", (raw) => ({ ...raw, extraBedAllowed: Number(raw.extra_bedMax) > 0 }))} className="grid gap-4 md:grid-cols-2">
            <Field label="Hotel"><SelectWrap><select name="hotelId" required className={selectClass}>{data.hotels.map((hotel) => <option key={hotel.id} value={hotel.id}>{hotel.name}</option>)}</select></SelectWrap></Field>
            <Field label="Search category" hint="Rooms in the same category are compared with each other in search."><SelectWrap><select name="category" required className={selectClass}>{data.roomCategories.map((category) => <option key={category.slug} value={category.slug}>{category.label}</option>)}</select></SelectWrap></Field>
            <Field label="Room name (as the hotel calls it)"><input name="name" required className={inputClass} placeholder="Triple Room Sea View" /></Field>
            <Field label="Room code"><input name="code" required className={inputClass} placeholder="TRIPLE" /></Field>
            <Field label="Room media folder (Google Drive)" className="md:col-span-2" hint="Shown next to the room type in search results."><input name="mediaLink" className={inputClass} placeholder="https://drive.google.com/drive/folders/…" /></Field>
            <Field label="Max adults"><input name="maxAdults" type="number" min="1" defaultValue="3" className={inputClass} /></Field>
            <Field label="Adults included in base rate"><input name="includedAdults" type="number" min="1" defaultValue="2" className={inputClass} /></Field>
            <Field label="Max children"><input name="maxChildren" type="number" min="0" defaultValue="2" className={inputClass} /></Field>
            <Field label="Max infants"><input name="maxInfants" type="number" min="0" defaultValue="1" className={inputClass} /></Field>
            <Field label="Sleeps without extra bedding" hint="Guests above this need an extra bed or sofa bed."><input name="baseSleeps" type="number" min="1" defaultValue="3" className={inputClass} /></Field>
            <Field label="Contracted allocation (rooms)"><input name="defaultInventory" type="number" min="1" defaultValue="5" className={inputClass} /></Field>
            <div className="md:col-span-2">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Extra bedding</span>
              <p className="mb-3 text-xs text-slate-400">Set how many are allowed per room. Leave “allowed” at 0 if the room cannot take it. Baby cots are often free.</p>
              <div className="grid gap-3 lg:grid-cols-3">
                {BEDDING_KINDS.map((kind) => (
                  <div key={kind.value} className="rounded-xl border border-slate-200 p-3.5">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-extrabold text-slate-800">{kind.label}</span>
                      <span className="text-[10px] text-slate-400">{kind.hint}</span>
                    </div>
                    <label className="mt-3 block">
                      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Allowed per room</span>
                      <input name={`${kind.value}Max`} type="number" min="0" max="4" defaultValue={kind.value === "baby_cot" ? 1 : 0} className={`${inputClass} h-10`} />
                    </label>
                    <label className="mt-2.5 flex items-center gap-2 text-xs font-semibold text-slate-600"><input name={`${kind.value}Free`} type="checkbox" defaultChecked={kind.value === "baby_cot"} className="accent-teal-700" /> Free of charge</label>
                    <label className="mt-2.5 block">
                      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Cost per night (AED)</span>
                      <input name={`${kind.value}Rate`} type="number" min="0" step="0.01" defaultValue="0" className={`${inputClass} h-10`} />
                    </label>
                    <label className="mt-2.5 flex items-center gap-2 text-xs font-semibold text-slate-600"><input name={`${kind.value}PerStay`} type="checkbox" className="accent-teal-700" /> Charge once per stay</label>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11px] text-slate-400">If a rate line has an extra-bed price for the season, it is used instead of the default above.</p>
            </div>
            <SubmitRow saving={saving} label="Save room type" />
          </form>
        </Modal>
      )}

      {roomEditId !== null && (() => {
        const room = data.rooms.find((item) => item.id === roomEditId);
        if (!room) return null;
        return (
          <Modal title={`Edit room type · ${room.name}`} subtitle={`${hotelName(room.hotelId)} · ${room.code}`} onClose={() => setRoomEditId(null)}>
            <form onSubmit={saveRoomEdit} className="grid gap-4 md:grid-cols-2">
              <Field label="Room name"><input name="name" required defaultValue={room.name} className={inputClass} /></Field>
              <Field label="Room media folder (Google Drive)" hint="Shown next to the room type in search results."><input name="mediaLink" defaultValue={room.mediaLink} className={inputClass} placeholder="https://drive.google.com/drive/folders/…" /></Field>
              <Field label="Contracted inventory (rooms)" hint="How many rooms the hotel has contracted for this type."><input name="defaultInventory" type="number" min="1" max="999" defaultValue={room.defaultInventory} className={inputClass} /></Field>
              <Field label="Sleeps without extra bedding" hint="Guests above this number need an extra bed or sofa bed."><input name="baseSleeps" type="number" min="1" max="12" defaultValue={room.baseSleeps} className={inputClass} /></Field>
              <Field label="Description" className="md:col-span-2"><input name="description" defaultValue={room.description} className={inputClass} placeholder="Room description for the sales team" /></Field>
              <p className="text-[11px] leading-5 text-slate-500 md:col-span-2">Category, occupancy limits and extra bedding are set when the room type is created. Use <b>Duplicate</b> to make a variant, or add new rate lines under Rates &amp; board.</p>
              <SubmitRow saving={saving} label="Save room type" />
            </form>
          </Modal>
        );
      })()}

      {dialog === "rate" && (
        <Modal title="Add rate line" subtitle="One line per room, board type and validity period." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => {
            if (!rateRoomId) {
              event.preventDefault();
              setFormError("Choose a room type for this hotel before saving the rate line.");
              return;
            }
            void submitForm(event, "/api/rates", "Rate line added.", (raw) => ({ ...raw, hotelId: rateHotelId, roomTypeId: rateRoomId, marketExclusions: toList(raw.marketExclusions) }));
          }} className="grid gap-4 md:grid-cols-2">
            <div>
              <div className="mb-2 text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Hotel</div>
              <ComboBox
                options={data.hotels.map((hotel) => ({ value: hotel.id, label: hotel.name, meta: placeLabel(hotel) }))}
                value={rateHotelId}
                onChange={(id) => { setRateHotelId(id); setRateRoomId(data.rooms.find((room) => room.hotelId === id)?.id ?? 0); }}
                ariaLabel="Rate hotel"
                placeholder="Type to find a hotel…"
                emptyMessage="No hotel matches that text."
              />
              <p className="mt-1.5 text-xs text-slate-400">Type to find the hotel this contract is from.</p>
            </div>
            <div>
              <div className="mb-2 text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Room type · {data.rooms.filter((room) => room.hotelId === rateHotelId).length} at this hotel</div>
              <ComboBox
                key={rateHotelId}
                options={data.rooms.filter((room) => room.hotelId === rateHotelId).map((room) => ({ value: room.id, label: room.name, meta: `${categoryLabel(room.category)} · ${room.code}` }))}
                value={rateRoomId}
                onChange={setRateRoomId}
                ariaLabel="Rate room type"
                placeholder={data.rooms.some((room) => room.hotelId === rateHotelId) ? "Type to find a room type…" : "This hotel has no room types yet"}
                emptyMessage="No room type at this hotel matches that text."
              />
              <p className="mt-1.5 text-xs text-slate-400">Only rooms belonging to the chosen hotel are listed.</p>
            </div>
            <Field label="Rate name"><input name="name" required className={inputClass} placeholder="Winter 2026 BB" /></Field>
            <Field label="Board type"><SelectWrap><select name="boardType" defaultValue="breakfast" className={selectClass}><option value="room_only">Room only</option><option value="breakfast">Bed & breakfast</option><option value="half_board">Half board</option><option value="full_board">Full board</option></select></SelectWrap></Field>
            <Field label="Stay period from" hint="First night the guest can stay on this rate."><input name="validFrom" required type="date" className={inputClass} /></Field>
            <Field label="Stay period to (last night)"><input name="validTo" required type="date" className={inputClass} /></Field>
            <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 md:col-span-2">
              <span className="mb-1 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Booking window (optional)</span>
              <p className="mb-3 text-xs text-slate-400">Only lets this rate be booked between these dates — used for flash sales and early-bird offers. Leave blank to keep it open the whole time.</p>
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Booking opens</span><input name="bookingWindowStart" type="date" className={inputClass} /></label>
                <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Booking closes</span><input name="bookingWindowEnd" type="date" className={inputClass} /></label>
              </div>
            </div>
            <Field label="Market"><SelectWrap><select name="market" defaultValue="all" className={selectClass}>{data.markets.map((market) => <option key={market.slug} value={market.slug}>{market.label}</option>)}</select></SelectWrap></Field>
            <Field label="Promo code (optional)"><input name="promoCode" className={inputClass} placeholder="e.g. RAMADAN-FLASH-4" /></Field>
            <div className="md:col-span-2">
              <div className="mb-2 flex items-center justify-between gap-3">
                <span className="text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Markets not applicable</span>
                <button type="button" onClick={() => setDialog("market")} className="text-[11px] font-bold text-[#166159]">Add market / nationality</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {data.markets.filter((market) => market.slug !== "all").map((market) => (
                  <label key={market.id} className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50">
                    <input name="marketExclusions" type="checkbox" value={market.slug} className="accent-teal-700" /> {market.label}
                  </label>
                ))}
              </div>
            </div>
            <Field label="Base rate (AED)"><input name="baseRate" required type="number" min="0" step="0.01" className={inputClass} /></Field>
            <Field label="Base rate is"><SelectWrap><select name="rateBasis" className={selectClass}><option value="room_night">Per room / night</option><option value="person_night">Per person / night</option></select></SelectWrap></Field>
            <Field label="Meal supplement – adult (or per room)"><input name="boardAdultSupplement" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Meal supplement – child"><input name="boardChildSupplement" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Meal supplement is" hint="Leave supplements at 0 if meals are included in the base rate." className="md:col-span-2"><SelectWrap><select name="boardSupplementBasis" className={selectClass}><option value="person_night">Per person / night</option><option value="room_night">Per room / night (adult field used)</option></select></SelectWrap></Field>
            <Field label="Extra adult / night"><input name="extraAdultRate" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Child / night"><input name="extraChildRate" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Extra bed cost"><input name="extraBedRate" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></Field>
            <Field label="Extra bed charged"><SelectWrap><select name="extraBedBasis" className={selectClass}><option value="bed_night">Per bed / night</option><option value="per_stay">Per bed / stay</option></select></SelectWrap></Field>
            <Field label="Minimum nights"><input name="minimumNights" type="number" min="1" defaultValue="1" className={inputClass} /></Field>
            <SubmitRow saving={saving} label="Save rate line" />
          </form>
        </Modal>
      )}

      {dialog === "amenity" && (
        <Modal title="Add amenity type" subtitle="New amenity types become available to every hotel and as a search filter." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/amenities", "Amenity type added. You can now tick it for any hotel.")} className="grid gap-4">
            <Field label="Amenity name" hint="The code is generated from the name, e.g. “Spa access” becomes spa_access.">
              <input name="label" required className={inputClass} placeholder="e.g. Spa access" />
            </Field>
            <Field label="Icon">
              <SelectWrap>
                <select name="icon" defaultValue="check" className={selectClass}>
                  <option value="waves">Swimming (waves)</option>
                  <option value="umbrella">Beach (umbrella)</option>
                  <option value="dumbbell">Gym (dumbbell)</option>
                  <option value="train">Metro (train)</option>
                  <option value="check">Generic (tick)</option>
                </select>
              </SelectWrap>
            </Field>
            <SubmitRow saving={saving} label="Save amenity" />
          </form>
        </Modal>
      )}

      {dialog === "contact" && (
        <Modal title={contactGroupId ? "Add umbrella company contact" : "Add hotel contact"} subtitle={contactGroupId ? `${groupName(contactGroupId)} · choose which hotels use this person` : contactHotel ? hotelName(contactHotel) : "Choose a hotel"} onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/contacts", "Contact added to the selected group or hotels.", (raw) => ({
            ...raw,
            hotelId: contactGroupId ? null : contactHotel,
            groupId: contactGroupId || null,
            hotelIds: contactGroupId ? groupHotelSelections : [],
            addToGroup: contactGroupId ? true : raw.addToGroup === "on",
            whatsapp: raw.whatsapp === "on",
            telegram: raw.telegram === "on",
            viber: raw.viber === "on",
          }))} className="grid gap-4 md:grid-cols-2">
            {!contactGroupId && (
              <div className="md:col-span-2">
                <div className="mb-2 text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Hotel</div>
                <ComboBox
                  options={data.hotels.map((hotel) => ({ value: hotel.id, label: hotel.name, meta: hotel.city }))}
                  value={contactHotel}
                  onChange={setContactHotel}
                  ariaLabel="Hotel"
                  placeholder="Type to find a hotel…"
                  emptyMessage="No hotel matches that text."
                />
                <p className="mt-1.5 text-xs text-slate-400">Type to find the hotel this person works with.</p>
              </div>
            )}
            <Field label="Full name"><input name="name" required className={inputClass} placeholder="Farah Cadinouche" /></Field>
            <Field label="Company position"><input name="position" className={inputClass} placeholder="Assistant Director of Sales" /></Field>
            <Field label="Email"><input name="email" type="email" className={inputClass} placeholder="name@hotel.com" /></Field>
            <Field label="Contact number" hint="Include the country code so chat links work."><input name="phone" className={inputClass} placeholder="+971509340811" /></Field>
            <Field label="Business card link" className="md:col-span-2" hint="Paste a Google Drive link to their card."><input name="businessCardLink" className={inputClass} placeholder="https://drive.google.com/file/d/…" /></Field>
            <div className="md:col-span-2"><span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Chat apps available</span><div className="flex flex-wrap gap-2"><label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600"><input name="whatsapp" type="checkbox" defaultChecked className="accent-teal-700" /> WhatsApp</label><label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600"><input name="telegram" type="checkbox" className="accent-teal-700" /> Telegram</label><label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600"><input name="viber" type="checkbox" className="accent-teal-700" /> Viber</label></div></div>
            <Field label="Other" className="md:col-span-2"><input name="otherContact" className={inputClass} placeholder="e.g. WeChat, SMS only, extension 204" /></Field>
            {!contactGroupId && data.hotels.find((hotel) => hotel.id === contactHotel)?.groupId && <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-teal-200 bg-teal-50 px-4 py-3 text-sm font-bold text-teal-900 md:col-span-2"><input name="addToGroup" type="checkbox" className="accent-teal-700" /><span>Add this contact to {groupName(data.hotels.find((hotel) => hotel.id === contactHotel)?.groupId ?? null)} <span className="block text-xs font-normal text-teal-700">The contact becomes available for other hotels in this umbrella company.</span></span></label>}
            {contactGroupId > 0 && <div className="md:col-span-2"><div className="mb-2 text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Also assign to these hotels</div><div className="grid gap-2 sm:grid-cols-2">{data.hotels.filter((hotel) => hotel.groupId === contactGroupId).map((hotel) => <label key={hotel.id} className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-700"><input type="checkbox" checked={groupHotelSelections.includes(hotel.id)} onChange={(event) => setGroupHotelSelections((current) => event.target.checked ? [...current, hotel.id] : current.filter((id) => id !== hotel.id))} className="accent-teal-700" />{hotel.name}</label>)}</div><p className="mt-2 text-[11px] text-slate-500">Leave hotels unticked to keep the person in the group only. You can assign them later.</p></div>}
            <SubmitRow saving={saving} label="Save contact" />
          </form>
        </Modal>
      )}

      {dialog === "locations" && (
        <Modal title="Locations" subtitle="Areas inside each city/emirate — e.g. Dubai → Deira. Used when adding hotels and to filter search results." onClose={() => setDialog(null)}>
          <div className="grid gap-3 rounded-2xl bg-slate-50 p-4 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
            <Field label="City / emirate">
              <input value={newLocation.city} onChange={(event) => setNewLocation((current) => ({ ...current, city: event.target.value }))} list="location-city-options" className={inputClass} placeholder="Dubai" autoComplete="off" />
              <datalist id="location-city-options">{cities.map((city) => <option key={city} value={city} />)}</datalist>
            </Field>
            <Field label="Location">
              <input value={newLocation.name} onChange={(event) => setNewLocation((current) => ({ ...current, name: event.target.value }))} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); void addLocation(); } }} className={inputClass} placeholder="Deira" autoComplete="off" />
            </Field>
            <button type="button" onClick={() => void addLocation()} disabled={saving || !newLocation.city.trim() || !newLocation.name.trim()} className="flex h-11 items-center justify-center gap-1.5 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white disabled:opacity-50"><Plus size={15} /> Add</button>
          </div>
          <div className="mt-5 space-y-4">
            {Array.from(new Set(data.locations.map((location) => location.city))).sort().map((city) => (
              <section key={city}>
                <h3 className="mb-2 flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-[0.08em] text-slate-500"><MapPin size={13} className="text-teal-700" /> {city}</h3>
                <div className="flex flex-wrap gap-2">
                  {data.locations.filter((location) => location.city === city).map((location) => {
                    const used = data.hotels.filter((hotel) => hotel.locationId === location.id).length;
                    return (
                      <span key={location.id} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white py-1.5 pl-3 pr-1.5 text-xs font-semibold text-slate-700">
                        {location.name}
                        <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-500" title="Hotels in this location">{used}</span>
                        <button type="button" disabled={saving} onClick={() => void deleteLocation(location)} className="rounded p-1 text-slate-300 transition hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50" aria-label={`Delete ${location.name}`} title={used ? `${used} hotel(s) keep their city; only the location is cleared` : "Delete location"}><Trash2 size={12} /></button>
                      </span>
                    );
                  })}
                </div>
              </section>
            ))}
            {data.locations.length === 0 && <p className="text-sm text-slate-500">No locations yet. Add the first above.</p>}
          </div>
        </Modal>
      )}

      {dialog === "group" && (
        <Modal title="Add umbrella company" subtitle="Group several hotels under one sales team, e.g. Al Khoory Hotels." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/hotel-groups", "Group added. You can now assign hotels to it.")} className="grid gap-4 md:grid-cols-2">
            <Field label="Group name"><input name="name" required className={inputClass} placeholder="Al Khoory Hotels" /></Field>
            <Field label="Group website"><input name="website" className={inputClass} placeholder="https://alkhooryhotels.com" /></Field>
            <Field label="Notes" className="md:col-span-2"><input name="notes" className={inputClass} placeholder="One sales team covers all properties." /></Field>
            <SubmitRow saving={saving} label="Save group" />
          </form>
        </Modal>
      )}

      {dialog === "market" && (
        <Modal title="Markets & nationalities" subtitle="Add the markets you sell to, or nationalities a rate does not apply to." onClose={() => setDialog(null)}>
          <div className="flex gap-2">
            <input value={newMarket} onChange={(event) => setNewMarket(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); void createMarket(); } }} placeholder="e.g. DRC Nationals" className={inputClass} />
            <button onClick={() => void createMarket()} disabled={saving || !newMarket.trim()} className="h-11 shrink-0 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white disabled:opacity-50">Add</button>
          </div>
          <p className="mt-2 text-xs text-slate-400">These appear in the rate form under “Markets not applicable” and as the Client market in search.</p>
          <div className="mt-4 max-h-80 space-y-1.5 overflow-y-auto">
            {data.markets.map((market) => (
              <div key={market.id} className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2.5">
                <div>
                  <div className="text-sm font-bold text-slate-800">{market.label}</div>
                  <div className="text-[10px] text-slate-400">{market.slug}</div>
                </div>
                {market.slug === "all" ? <span className="text-[10px] font-bold uppercase text-slate-300">Default</span> : (
                  <button onClick={() => void deleteMarket(market)} className="rounded-lg p-1.5 text-slate-300 transition hover:bg-rose-50 hover:text-rose-600" title="Delete"><Trash2 size={15} /></button>
                )}
              </div>
            ))}
          </div>
        </Modal>
      )}

      {dialog === "category" && (
        <Modal title="Add search category" subtitle="New categories appear in the search dropdown and can be used by any hotel." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/room-categories", "Category added. You can now use it when adding a room type.")} className="grid gap-4">
            <Field label="Category name" hint="The code is generated from the name, e.g. “Quad Room” becomes quad_room.">
              <input name="label" required className={inputClass} placeholder="e.g. Quad Room" />
            </Field>
            <SubmitRow saving={saving} label="Save category" />
          </form>
        </Modal>
      )}

      {dialog === "hotelAmenities" && (
        <Modal title="Hotel amenities" subtitle={amenityEditHotel ? hotelName(amenityEditHotel) : ""} onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/hotel-amenities", "Amenities updated. Search filters now use the new set.", (raw) => ({ hotelId: amenityEditHotel, amenityIds: toList(raw.amenityIds) }))} className="grid gap-4">
            <div className="grid gap-2 sm:grid-cols-2">
              {data.amenities.map((amenity) => {
                const checked = hotelAmenityIds(amenityEditHotel).includes(amenity.id);
                return (
                  <label key={amenity.id} className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3.5 py-3 text-sm font-semibold transition ${checked ? "border-teal-600 bg-teal-50/60 text-teal-800" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
                    <input type="checkbox" name="amenityIds" value={amenity.id} defaultChecked={checked} className="accent-teal-700" />
                    <AmenityIcon slug={amenity.slug} label={amenity.label} icon={amenity.icon} size={14} />
                  </label>
                );
              })}
            </div>
            <p className="text-xs text-slate-400">Untick everything and save to clear the amenities for this hotel.</p>
            <SubmitRow saving={saving} label="Save amenities" />
          </form>
        </Modal>
      )}

      {dialog === "blackout" && (
        <Modal title="Record fully booked dates" subtitle="Rooms in this period will be excluded from search and cannot be booked." onClose={() => setDialog(null)}>
          <form onSubmit={(event) => submitForm(event, "/api/blackouts", "Blackout dates saved.", (raw) => ({ ...raw, hotelId: blackoutHotelId, roomTypeId: blackoutRoomId || "" }))} className="grid gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <div className="mb-2 text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Hotel</div>
              <ComboBox
                options={data.hotels.map((hotel) => ({ value: hotel.id, label: hotel.name, meta: `${hotel.city} · ${hotel.supplierCode}` }))}
                value={blackoutHotelId}
                onChange={(id) => { setBlackoutHotelId(id); setBlackoutRoomId(0); setBlackoutRoomQuery(""); }}
                ariaLabel="Hotel"
                placeholder="Type to find a hotel…"
                emptyMessage="No hotel matches that text."
              />
              <p className="mt-1.5 text-xs text-slate-400">Type in the box to find a hotel — the room list below updates to the rooms that hotel actually has.</p>
            </div>

            <div className="md:col-span-2">
              <div className="mb-2 flex items-center justify-between gap-3">
                <span className="text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Room type · {blackoutRoomCount} at {hotelName(blackoutHotelId)}</span>
                <button type="button" onClick={() => { setBlackoutRoomId(0); setBlackoutRoomQuery(""); }} className="text-[10px] font-bold text-teal-700 hover:underline">Use all room types</button>
              </div>
              <div className="relative">
                <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  value={blackoutRoomQuery}
                  onChange={(event) => setBlackoutRoomQuery(event.target.value)}
                  placeholder="Type to shorten the list, e.g. “Triple” or “DLX”…"
                  aria-label="Search room types"
                  className={`${inputClass} pl-9 pr-9`}
                />
                {blackoutRoomQuery && <button type="button" onClick={() => setBlackoutRoomQuery("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-0.5 text-slate-400 hover:text-slate-700" aria-label="Clear room search"><X size={15} /></button>}
              </div>
              <div className="mt-2 max-h-56 space-y-1 overflow-y-auto rounded-xl border border-slate-200 bg-slate-50/60 p-1.5">
                <button type="button" onClick={() => setBlackoutRoomId(0)} className={`flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2.5 text-left text-xs font-semibold transition ${blackoutRoomId === 0 ? "bg-teal-700 text-white" : "bg-white text-slate-700 hover:bg-teal-50"}`}>
                  <span>All room types</span>
                  <span className={`text-[10px] ${blackoutRoomId === 0 ? "text-teal-100" : "text-slate-400"}`}>full hotel stop sale</span>
                </button>
                {blackoutRoomOptions.map((room) => (
                  <button key={room.id} type="button" onClick={() => setBlackoutRoomId(room.id)} className={`flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2.5 text-left text-xs font-semibold transition ${blackoutRoomId === room.id ? "bg-teal-700 text-white" : "bg-white text-slate-700 hover:bg-teal-50"}`}>
                    <span className="truncate">{room.name}</span>
                    <span className={`shrink-0 text-[10px] ${blackoutRoomId === room.id ? "text-teal-100" : "text-slate-400"}`}>{room.code}</span>
                  </button>
                ))}
                {blackoutRoomOptions.length === 0 && <p className="px-3 py-3 text-[11px] text-slate-400">No room type matches “{blackoutRoomQuery}”. Clear the text to see all {blackoutRoomCount}.</p>}
              </div>
              <p className="mt-2 text-[11px] text-slate-500">
                {blackoutRoomId === 0
                  ? "Every room type at this hotel will be blocked for those nights."
                  : <>Only <b className="text-slate-700">{roomName(blackoutRoomId)}</b> will be blocked — other room types stay bookable.</>}
              </p>
            </div>

            <Field label="First night closed"><input name="startDate" required type="date" className={inputClass} /></Field>
            <Field label="Last night closed"><input name="endDate" required type="date" className={inputClass} /></Field>
            <Field label="Reason" className="md:col-span-2"><input name="reason" required className={inputClass} placeholder="Hotel fully booked" /></Field>
            <SubmitRow saving={saving} label="Block these dates" />
          </form>
        </Modal>
      )}

      {emailTarget && <EmailProposalDialog
        key={`${emailTarget.type}-${emailTarget.id}`}
        target={emailTarget}
        onClose={() => setEmailTarget(null)}
        onSent={(message) => { setToast({ type: "success", message }); router.refresh(); }}
      />}
      {managerGroupId !== null && <ContactManager
        data={data}
        mode="group"
        groupId={managerGroupId}
        onClose={() => setManagerGroupId(null)}
        onChanged={(message) => { setToast({ type: "success", message }); router.refresh(); }}
        onAddGroupContact={openGroupContact}
        onAddHotelContact={openHotelContact}
      />}
      {managerHotelId !== null && <ContactManager
        data={data}
        mode="hotel"
        hotelId={managerHotelId}
        onClose={() => setManagerHotelId(null)}
        onChanged={(message) => { setToast({ type: "success", message }); router.refresh(); }}
        onAddGroupContact={openGroupContact}
        onAddHotelContact={openHotelContact}
      />}
    </div>
  );
}
