"use client";

import { ArrowRight, Hotel, Loader2, LockKeyhole, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { FormEvent, useState } from "react";

export default function AuthForm({ setup, setupTokenRequired, next }: { setup: boolean; setupTokenRequired: boolean; next: string }) {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [setupToken, setSetupToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch(setup ? "/api/auth/setup" : "/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(setup ? { name, username, email, password, setupToken } : { identifier, password }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to sign in.");
      window.location.assign(next);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to sign in.");
    } finally {
      setBusy(false);
    }
  };

  const input = "h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10";
  return (
    <div className="grid min-h-screen grid-cols-1 bg-[#f5f7f9] lg:grid-cols-[1fr_1.05fr]">
      <div className="flex min-h-[280px] flex-col justify-between bg-[#173f3b] p-7 text-white sm:p-10 lg:min-h-screen lg:p-14">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-white/10 ring-1 ring-white/20"><Hotel size={23} /></div>
          <div><p className="text-lg font-extrabold tracking-tight">Luxury Attractions</p><p className="mt-0.5 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#e1bb96]">Hotel contracts</p></div>
        </div>
        <div className="max-w-lg py-9 lg:py-0">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[11px] font-bold text-teal-100"><ShieldCheck size={14} /> Private B2B workspace</div>
          <h1 className="text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl lg:text-5xl">Every contract.<br />Every stay.<br /><span className="text-[#d7a776]">One place.</span></h1>
          <p className="mt-5 max-w-md text-sm leading-7 text-teal-50/75">Manage contracted hotels, client quotations, trip packages, tours and reservations securely with your team.</p>
        </div>
        <div className="hidden text-xs text-teal-50/55 lg:block">hotels.luxuryattractions.com · Staff access only</div>
      </div>
      <div className="flex min-h-[60vh] items-center justify-center px-5 py-12 sm:px-10">
        <div className="w-full max-w-[440px] rounded-[24px] border border-slate-200/80 bg-white p-7 shadow-[0_18px_55px_rgba(20,55,50,.08)] sm:p-9">
          <div className="mb-7 flex items-start gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-teal-50 text-teal-700"><LockKeyhole size={19} /></div>
            <div><h2 className="text-[23px] font-extrabold tracking-tight text-slate-950">{setup ? "Set up your workspace" : "Welcome back"}</h2><p className="mt-1 text-sm leading-6 text-slate-500">{setup ? "Create the first administrator account. This step is available only once." : "Sign in to manage hotel contracts and proposals."}</p></div>
          </div>
          {error && <div role="alert" className="mb-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold leading-5 text-rose-700">{error}</div>}
          <form onSubmit={submit} className="space-y-4">
            {setup && <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.08em] text-slate-500">Your name</span><input required autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} className={input} placeholder="Your full name" /></label>}
            {setup && <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.08em] text-slate-500">Username</span><input required minLength={3} maxLength={32} autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value.toLowerCase())} className={input} placeholder="e.g. sarah.ahmed" /></label>}
            {setup ? <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.08em] text-slate-500">Registered work email</span><input required type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className={input} placeholder="you@luxuryattractions.com" /></label> : <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.08em] text-slate-500">Username or email</span><input required autoComplete="username" value={identifier} onChange={(e) => setIdentifier(e.target.value)} className={input} placeholder="Your username or work email" /></label>}
            <label className="block"><span className="mb-1.5 flex items-center justify-between gap-2 text-xs font-bold uppercase tracking-[0.08em] text-slate-500"><span>Password</span>{!setup && <Link href="/forgot-password" className="text-[11px] normal-case tracking-normal text-teal-700 hover:underline">Forgot password?</Link>}</span><input required type="password" autoComplete={setup ? "new-password" : "current-password"} minLength={setup ? 12 : 1} value={password} onChange={(e) => setPassword(e.target.value)} className={input} placeholder={setup ? "At least 12 characters" : "Enter your password"} /></label>
            {setup && setupTokenRequired && <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.08em] text-slate-500">Setup token</span><input required type="password" autoComplete="off" value={setupToken} onChange={(e) => setSetupToken(e.target.value)} className={input} placeholder="From INITIAL_SETUP_TOKEN" /></label>}
            {setup && <p className="rounded-xl bg-amber-50 px-3.5 py-3 text-[11px] leading-5 text-amber-800">Set up the first administrator before publishing your domain. After that, new users can only be added by an administrator.</p>}
            <button disabled={busy} className="mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#174e48] text-sm font-extrabold text-white shadow-md shadow-teal-900/10 transition hover:bg-[#103f3a] disabled:opacity-60">{busy ? <Loader2 size={17} className="animate-spin" /> : <ArrowRight size={17} />}{busy ? "Please wait…" : setup ? "Create administrator" : "Sign in"}</button>
          </form>
          <p className="mt-6 text-center text-[11px] text-slate-400">Your account and permissions are managed by your team administrator.</p>
        </div>
      </div>
    </div>
  );
}
