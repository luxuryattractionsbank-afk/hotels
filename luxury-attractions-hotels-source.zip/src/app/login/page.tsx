import { db } from "@/db";
import { users } from "@/db/schema";
import { currentUser } from "@/lib/auth";
import { ensureUsernames } from "@/lib/usernames";
import { redirect } from "next/navigation";
import AuthForm from "./auth-form";

export const dynamic = "force-dynamic";

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  await ensureUsernames();
  const user = await currentUser();
  if (user) redirect("/");
  const [existing] = await db.select({ id: users.id }).from(users).limit(1);
  const params = await searchParams;
  const next = params.next?.startsWith("/") && !params.next.startsWith("//") && !params.next.startsWith("/login") ? params.next : "/";
  return <AuthForm setup={!existing} setupTokenRequired={Boolean(process.env.INITIAL_SETUP_TOKEN)} next={next} />;
}
