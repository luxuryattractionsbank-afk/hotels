"use client";

import {
  AlertTriangle,
  ArrowDownWideNarrow,
  BedDouble,
  CalendarDays,
  CalendarX2,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock3,
  Dumbbell,
  FileText,
  Filter,
  Globe2,
  Hotel,
  Info,
  Loader2,
  MapPin,
  Minus,
  Plus,
  RotateCcw,
  Search,
  Sparkles,
  Star,
  TicketPercent,
  TrainFront,
  Trash2,
  TrendingDown,
  Umbrella,
  Users,
  UtensilsCrossed,
  Waves,
  X,
  XCircle,
} from "lucide-react";
import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";
import {
  applyFilters,
  AvailabilityResponse,
  BOARD_TYPES,
  boardLabel,
  boardShort,
  categoryLabel,
  comparableRate,
  CoreCriteria,
  daysBetween,
  ExcludedKind,
  MARKETS,
  marketLabel,
  Offer,
  ResultFilters,
  SearchResult,
  SORT_OPTIONS,
  SortKey,
} from "@/lib/search-engine";
import { computeProposal } from "@/lib/proposal";

export type InitialSearch = { criteria: CoreCriteria; response: AvailabilityResponse };

type FilterState = Omit<ResultFilters, "minRate" | "maxRate"> & { minRate: string; maxRate: string };

const DEFAULT_FILTER_STATE: FilterState = {
  boardType: "any",
  city: "any",
  location: "any",
  minStars: 0,
  minRate: "",
  maxRate: "",
  rateBasis: "excl_tax",
  amenities: [],
  sort: "price_asc",
  query: "",
};

export type AmenityOption = { slug: string; label: string; icon: string };

const AMENITY_ICONS: Record<string, typeof Waves> = {
  waves: Waves,
  umbrella: Umbrella,
  dumbbell: Dumbbell,
  train: TrainFront,
};

export function AmenityIcon({ slug, label, icon, size = 12 }: { slug?: string; label: string; icon?: string; size?: number }) {
  const Icon = AMENITY_ICONS[icon ?? ""] ?? (slug ? AMENITY_ICONS[slug] : undefined) ?? Check;
  return (
    <span className="inline-flex items-center gap-1" title={label}>
      <Icon size={size} />
      {label}
    </span>
  );
}

const RATE_PRESETS = [
  { label: "Under 150", min: "", max: "150" },
  { label: "100 – 150", min: "100", max: "150" },
  { label: "150 – 300", min: "150", max: "300" },
  { label: "300 – 700", min: "300", max: "700" },
  { label: "700 +", min: "700", max: "" },
];

const EXCLUDED_STYLE: Record<ExcludedKind, { label: string; className: string }> = {
  blackout: { label: "Fully booked", className: "bg-rose-50 text-rose-700" },
  sold_out: { label: "Allocation used", className: "bg-orange-50 text-orange-700" },
  occupancy: { label: "Occupancy", className: "bg-violet-50 text-violet-700" },
  min_stay: { label: "Minimum stay", className: "bg-amber-50 text-amber-700" },
  no_rate: { label: "No rate loaded", className: "bg-slate-100 text-slate-600" },
};

const money = (value: number | string, digits = 0) =>
  `AED ${Number(value).toLocaleString("en-AE", { minimumFractionDigits: digits, maximumFractionDigits: 2 })}`;

const shortDate = (date: string, withYear = false) =>
  new Intl.DateTimeFormat("en-GB", { weekday: withYear ? undefined : "short", day: "2-digit", month: "short", ...(withYear ? { year: "numeric" } : {}) }).format(new Date(`${date}T00:00:00Z`));

const inputClass =
  "h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10";

function Stars({ count, size = 12 }: { count: number; size?: number }) {
  return (
    <span className="inline-flex items-center gap-0.5">
      {Array.from({ length: count }).map((_, index) => (
        <Star key={index} size={size} className="fill-[#d9a25f] text-[#d9a25f]" />
      ))}
    </span>
  );
}

function Stepper({ label, hint, value, min, max, onChange }: { label: string; hint: string; value: number; min: number; max: number; onChange: (value: number) => void }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div>
        <div className="text-sm font-bold text-slate-800">{label}</div>
        <div className="text-[11px] text-slate-400">{hint}</div>
      </div>
      <div className="flex items-center gap-3">
        <button type="button" disabled={value <= min} onClick={() => onChange(value - 1)} className="grid h-8 w-8 place-items-center rounded-full border border-slate-200 text-slate-600 transition hover:border-teal-600 hover:text-teal-700 disabled:opacity-30" aria-label={`Decrease ${label}`}>
          <Minus size={14} />
        </button>
        <span className="w-5 text-center text-sm font-extrabold">{value}</span>
        <button type="button" disabled={value >= max} onClick={() => onChange(value + 1)} className="grid h-8 w-8 place-items-center rounded-full border border-slate-200 text-slate-600 transition hover:border-teal-600 hover:text-teal-700 disabled:opacity-30" aria-label={`Increase ${label}`}>
          <Plus size={14} />
        </button>
      </div>
    </div>
  );
}

function FilterBlock({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="border-b border-slate-100 px-5 py-5 last:border-b-0">
      <div className="mb-3 text-[10px] font-extrabold uppercase tracking-[0.12em] text-slate-400">{title}</div>
      {children}
    </div>
  );
}

export type CategoryOption = { slug: string; label: string };

export type LocationOption = { city: string; name: string };

/** One stay inside a multi-hotel quotation, e.g. 2 nights in hotel A + 2 nights in hotel B. */
export type QuoteLeg = {
  key: string;
  hotelId: number;
  hotelName: string;
  city: string;
  location: string;
  roomId: number;
  roomName: string;
  roomCode: string;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  extraBeds: number;
  sofaBeds: number;
  babyCots: number;
  market: string;
  totalAmount: number;
  tourismTaxAmount: number;
  rateNames: string[];
  promoCodes: string[];
};

// v2: legs now carry their tourism-tax amount so proposals can exclude it.
const quoteStorageKey = (userId: number) => `la-quotation-builder-v2-user-${userId}`;

function loadQuoteLegs(userId: number): QuoteLeg[] {
  try {
    const raw = localStorage.getItem(quoteStorageKey(userId));
    const parsed = raw ? (JSON.parse(raw) as QuoteLeg[]) : [];
    return Array.isArray(parsed) ? parsed.filter((leg) => leg && typeof leg.key === "string") : [];
  } catch {
    return [];
  }
}

export default function SearchPanel({ initial, cities, locationOptions = [], amenityOptions, categoryOptions, userId, canQuote, canBook, onBooked, onQuoted }: { initial: InitialSearch; cities: string[]; locationOptions?: LocationOption[]; amenityOptions: AmenityOption[]; categoryOptions: CategoryOption[]; userId: number; canQuote: boolean; canBook: boolean; onBooked: (reference: string) => void; onQuoted: (reference: string) => void }) {
  const [form, setForm] = useState<CoreCriteria>(initial.criteria);
  const [criteria, setCriteria] = useState<CoreCriteria>(initial.criteria);
  const [response, setResponse] = useState<AvailabilityResponse>(initial.response);
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTER_STATE);
  const [loading, setLoading] = useState(false);
  const [searchError, setSearchError] = useState(initial.response.error ?? "");
  const [guestsOpen, setGuestsOpen] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [selectedBoard, setSelectedBoard] = useState<Record<string, string>>({});
  const [showUnavailable, setShowUnavailable] = useState(false);
  const [bookingTarget, setBookingTarget] = useState<{ result: SearchResult; offer: Offer } | null>(null);
  const [bookingSaving, setBookingSaving] = useState(false);
  const [bookingError, setBookingError] = useState("");

  // Multi-hotel quotation builder. Legs survive navigation via localStorage,
  // so a 2-night stay can be quoted, then another search adds 2 more nights elsewhere.
  const [quoteLegs, setQuoteLegs] = useState<QuoteLeg[]>([]);
  const [quoteStorageReady, setQuoteStorageReady] = useState(false);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [quoteSaving, setQuoteSaving] = useState(false);
  const [quoteError, setQuoteError] = useState("");
  const [quoteClient, setQuoteClient] = useState({ name: "", email: "", phone: "", notes: "" });
  const [quoteValidUntil, setQuoteValidUntil] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() + 7);
    return date.toISOString().slice(0, 10);
  });
  const [quoteIncludeTax, setQuoteIncludeTax] = useState(true);
  const [quoteMarkupPct, setQuoteMarkupPct] = useState("");
  const [quoteMarkupAmt, setQuoteMarkupAmt] = useState("");

  useEffect(() => {
    setQuoteLegs(loadQuoteLegs(userId));
    setQuoteStorageReady(true);
  }, [userId]);

  useEffect(() => {
    if (!quoteStorageReady) return;
    try {
      localStorage.setItem(quoteStorageKey(userId), JSON.stringify(quoteLegs));
    } catch {
      // Storage full or unavailable — the builder still works for this session.
    }
  }, [quoteLegs, quoteStorageReady, userId]);

  const quotePreview = useMemo(
    () =>
      computeProposal(quoteLegs, {
        includeTourismTax: quoteIncludeTax,
        markupPercent: quoteMarkupPct === "" ? 0 : Number(quoteMarkupPct),
        markupAmount: quoteMarkupAmt === "" ? 0 : Number(quoteMarkupAmt),
      }),
    [quoteLegs, quoteIncludeTax, quoteMarkupPct, quoteMarkupAmt],
  );
  const legKeyFor = (result: SearchResult, offer: Offer) =>
    `${result.hotel.id}-${result.room.id}-${criteria.checkIn}-${criteria.checkOut}-${criteria.adults}-${criteria.children}-${criteria.infants}-${criteria.rooms}-${offer.boardType}`;

  const addLeg = (result: SearchResult, offer: Offer) => {
    const key = legKeyFor(result, offer);
    setQuoteLegs((current) => {
      if (current.some((leg) => leg.key === key)) return current;
      return [
        ...current,
        {
          key,
          hotelId: result.hotel.id,
          hotelName: result.hotel.name,
          city: result.hotel.city,
          location: result.hotel.location,
          roomId: result.room.id,
          roomName: result.room.name,
          roomCode: result.room.code,
          boardType: offer.boardType,
          checkIn: criteria.checkIn,
          checkOut: criteria.checkOut,
          nights: offer.nights,
          adults: criteria.adults,
          children: criteria.children,
          infants: criteria.infants,
          rooms: criteria.rooms,
          extraBeds: criteria.extraBeds,
          sofaBeds: criteria.sofaBeds,
          babyCots: criteria.babyCots,
          market: criteria.market,
          totalAmount: offer.totalAmount,
          tourismTaxAmount: offer.tourismTaxAmount,
          rateNames: offer.rateNames,
          promoCodes: offer.promoCodes,
        },
      ];
    });
  };

  const removeLeg = (key: string) => setQuoteLegs((current) => current.filter((leg) => leg.key !== key));

  const moveLeg = (index: number, direction: -1 | 1) =>
    setQuoteLegs((current) => {
      const next = [...current];
      const target = index + direction;
      if (target < 0 || target >= next.length) return current;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });

  const saveQuotation = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (quoteLegs.length === 0) return;
    setQuoteSaving(true);
    setQuoteError("");
    try {
      const response = await fetch("/api/quotations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: quoteClient.name,
          clientEmail: quoteClient.email,
          clientPhone: quoteClient.phone,
          notes: quoteClient.notes,
          validUntil: quoteValidUntil,
          market: quoteLegs[0].market,
          includeTourismTax: quoteIncludeTax,
          markupPercent: quoteMarkupPct === "" ? 0 : Number(quoteMarkupPct),
          markupAmount: quoteMarkupAmt === "" ? 0 : Number(quoteMarkupAmt),
          items: quoteLegs.map((leg) => ({
            hotelId: leg.hotelId,
            roomTypeId: leg.roomId,
            boardType: leg.boardType,
            checkIn: leg.checkIn,
            checkOut: leg.checkOut,
            adults: leg.adults,
            children: leg.children,
            infants: leg.infants,
            rooms: leg.rooms,
            extraBeds: leg.extraBeds,
            sofaBeds: leg.sofaBeds,
            babyCots: leg.babyCots,
            market: leg.market,
          })),
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Unable to save quotation.");
      setQuoteLegs([]);
      setQuoteOpen(false);
      setQuoteClient({ name: "", email: "", phone: "", notes: "" });
      onQuoted(data.quotation.reference);
    } catch (error) {
      setQuoteError(error instanceof Error ? error.message : "Unable to save quotation.");
    } finally {
      setQuoteSaving(false);
    }
  };

  const formNights = daysBetween(form.checkIn || criteria.checkIn, form.checkOut || criteria.checkOut);

  const engineFilters: ResultFilters = useMemo(
    () => ({
      ...filters,
      minRate: filters.minRate === "" ? null : Number(filters.minRate),
      maxRate: filters.maxRate === "" ? null : Number(filters.maxRate),
    }),
    [filters],
  );
  const filtered = useMemo(() => applyFilters(response.results, engineFilters), [response.results, engineFilters]);
  const lowestRate = filtered.results.length ? Math.min(...filtered.results.map((result) => comparableRate(result.best, filters.rateBasis))) : null;

  const boardCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const result of response.results) for (const offer of result.offers) counts[offer.boardType] = (counts[offer.boardType] ?? 0) + 1;
    return counts;
  }, [response.results]);

  const amenityCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const result of response.results) for (const slug of result.hotel.amenities) counts[slug] = (counts[slug] ?? 0) + 1;
    return counts;
  }, [response.results]);

  const toggleAmenity = (slug: string) =>
    setFilters((current) => ({
      ...current,
      amenities: current.amenities.includes(slug) ? current.amenities.filter((item) => item !== slug) : [...current.amenities, slug],
    }));

  const activeFilterCount = [
    filters.boardType !== "any",
    filters.city !== "any",
    filters.city !== "any" && filters.location !== "any",
    filters.minStars > 0,
    filters.minRate !== "" || filters.maxRate !== "",
    filters.amenities.length > 0,
    filters.query !== "",
  ].filter(Boolean).length;

  const runSearch = async (next: CoreCriteria) => {
    setLoading(true);
    setSearchError("");
    try {
      const result = await fetch("/api/search", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(next) });
      const data = (await result.json()) as AvailabilityResponse & { error: string | null };
      if (!result.ok || data.error) throw new Error(data.error || "Search failed.");
      setResponse(data);
      setCriteria(next);
      setExpanded(null);
      setSelectedBoard({});
    } catch (error) {
      setSearchError(error instanceof Error ? error.message : "Search failed.");
    } finally {
      setLoading(false);
    }
  };

  const submitSearch = (event: FormEvent) => {
    event.preventDefault();
    setGuestsOpen(false);
    void runSearch(form);
  };

  const setGuests = (key: "adults" | "children" | "infants" | "rooms" | "extraBeds" | "sofaBeds" | "babyCots", value: number) =>
    setForm((current) => {
      const next = { ...current, [key]: value };
      if (key === "rooms" && next.adults < value) next.adults = value;
      if (key === "adults" && next.rooms > value) next.rooms = value;
      if (key === "rooms" && value > 1) {
        // Bedding is requested per room; keep totals in step with the room count.
        next.extraBeds = Math.min(next.extraBeds, value * 2);
        next.sofaBeds = Math.min(next.sofaBeds, value * 2);
        next.babyCots = Math.min(next.babyCots, value * 2);
      }
      return next;
    });

  const updateCheckIn = (value: string) =>
    setForm((current) => {
      if (!value) return { ...current, checkIn: value };
      const nights = Math.max(1, daysBetween(current.checkIn, current.checkOut) || 1);
      const shouldShift = !current.checkOut || current.checkOut <= value;
      const out = new Date(`${value}T00:00:00Z`);
      out.setUTCDate(out.getUTCDate() + nights);
      return { ...current, checkIn: value, checkOut: shouldShift ? out.toISOString().slice(0, 10) : current.checkOut };
    });

  const confirmBooking = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!bookingTarget) return;
    setBookingSaving(true);
    setBookingError("");
    const form = new FormData(event.currentTarget);
    try {
      const result = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...criteria,
          hotelId: bookingTarget.result.hotel.id,
          roomTypeId: bookingTarget.result.room.id,
          boardType: bookingTarget.offer.boardType,
          guestName: form.get("guestName"),
          guestEmail: form.get("guestEmail"),
          guestPhone: form.get("guestPhone"),
          notes: form.get("notes"),
        }),
      });
      const data = await result.json();
      if (!result.ok) throw new Error(data.error || "Unable to confirm booking.");
      setBookingTarget(null);
      onBooked(data.booking.reference);
      void runSearch(criteria);
    } catch (error) {
      setBookingError(error instanceof Error ? error.message : "Unable to confirm booking.");
    } finally {
      setBookingSaving(false);
    }
  };

  const guestSummary = `${form.adults} adult${form.adults === 1 ? "" : "s"}${form.children ? ` · ${form.children} child${form.children === 1 ? "" : "ren"}` : ""}${form.infants ? ` · ${form.infants} infant${form.infants === 1 ? "" : "s"}` : ""} · ${form.rooms} room${form.rooms === 1 ? "" : "s"}`;
  const beddingSummary = [form.extraBeds ? `${form.extraBeds} extra bed${form.extraBeds === 1 ? "" : "s"}` : "", form.sofaBeds ? `${form.sofaBeds} sofa bed${form.sofaBeds === 1 ? "" : "s"}` : "", form.babyCots ? `${form.babyCots} cot${form.babyCots === 1 ? "" : "s"}` : ""].filter(Boolean).join(" · ");
  const criteriaSummary = `${shortDate(criteria.checkIn)} → ${shortDate(criteria.checkOut)} · ${response.nights} night${response.nights === 1 ? "" : "s"} · ${criteria.adults}A${criteria.children ? ` ${criteria.children}C` : ""}${criteria.infants ? ` ${criteria.infants}I` : ""} · ${criteria.rooms} room${criteria.rooms === 1 ? "" : "s"}${beddingSummary ? ` · ${beddingSummary}` : ""} · ${marketLabel(criteria.market)}`;

  const filterPanel = (
    <div className="overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-[0_2px_10px_rgba(15,23,42,0.025)]">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
        <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900">
          <Filter size={15} /> Filters {activeFilterCount > 0 && <span className="rounded-full bg-teal-700 px-1.5 py-0.5 text-[10px] text-white">{activeFilterCount}</span>}
        </div>
        {activeFilterCount > 0 && (
          <button onClick={() => setFilters((current) => ({ ...DEFAULT_FILTER_STATE, sort: current.sort, rateBasis: current.rateBasis }))} className="flex items-center gap-1 text-[11px] font-bold text-teal-700">
            <RotateCcw size={12} /> Reset
          </button>
        )}
      </div>

      <FilterBlock title="Rate per night (AED)">
        <div className="grid grid-cols-2 gap-2">
          <label>
            <span className="mb-1 block text-[10px] font-semibold text-slate-400">Min</span>
            <input type="number" min="0" inputMode="numeric" value={filters.minRate} onChange={(event) => setFilters((current) => ({ ...current, minRate: event.target.value }))} placeholder="0" className={`${inputClass} h-10`} />
          </label>
          <label>
            <span className="mb-1 block text-[10px] font-semibold text-slate-400">Max</span>
            <input type="number" min="0" inputMode="numeric" value={filters.maxRate} onChange={(event) => setFilters((current) => ({ ...current, maxRate: event.target.value }))} placeholder="Any" className={`${inputClass} h-10`} />
          </label>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {RATE_PRESETS.map((preset) => {
            const active = filters.minRate === preset.min && filters.maxRate === preset.max;
            return (
              <button key={preset.label} onClick={() => setFilters((current) => (active ? { ...current, minRate: "", maxRate: "" } : { ...current, minRate: preset.min, maxRate: preset.max }))} className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition ${active ? "bg-teal-700 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
                {preset.label}
              </button>
            );
          })}
        </div>
        <div className="mt-4 grid grid-cols-2 rounded-xl bg-slate-100 p-1 text-[11px] font-bold">
          {(["excl_tax", "incl_tax"] as const).map((basis) => (
            <button key={basis} onClick={() => setFilters((current) => ({ ...current, rateBasis: basis }))} className={`rounded-lg px-2 py-1.5 transition ${filters.rateBasis === basis ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"}`}>
              {basis === "excl_tax" ? "Excl. tourism tax" : "Incl. tourism tax"}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[10px] leading-4 text-slate-400">Average cost per room per night for your dates, including meal plan and occupancy supplements.</p>
      </FilterBlock>

      <FilterBlock title="Board / meal plan">
        <div className="space-y-1">
          {[{ value: "any", label: "Any board (show all)" }, ...BOARD_TYPES].map((board) => (
            <label key={board.value} className={`flex cursor-pointer items-center justify-between rounded-lg px-2.5 py-2 text-sm transition ${filters.boardType === board.value ? "bg-teal-50 font-bold text-teal-800" : "text-slate-600 hover:bg-slate-50"}`}>
              <span className="flex items-center gap-2.5">
                <input type="radio" name="boardFilter" checked={filters.boardType === board.value} onChange={() => setFilters((current) => ({ ...current, boardType: board.value }))} className="accent-teal-700" />
                {board.label}
              </span>
              {board.value !== "any" && <span className="text-[10px] font-semibold text-slate-400">{boardCounts[board.value] ?? 0}</span>}
            </label>
          ))}
        </div>
      </FilterBlock>

      <FilterBlock title="Location & category">
        <div className="space-y-3">
          <div className="relative">
            <select value={filters.city} onChange={(event) => setFilters((current) => ({ ...current, city: event.target.value, location: "any" }))} className={`${inputClass} h-10 appearance-none pr-9`} aria-label="City or emirate">
              <option value="any">All emirates / cities</option>
              {cities.map((city) => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
            <ChevronDown size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
          </div>
          {filters.city !== "any" && (() => {
            const places = Array.from(new Set(locationOptions.filter((option) => option.city === filters.city).map((option) => option.name))).sort();
            const inCity = response.results.filter((result) => result.hotel.city === filters.city);
            const countFor = (place: string) => inCity.filter((result) => result.hotel.location === place).length;
            return (
              <div className="rounded-xl border border-teal-100 bg-teal-50/50 p-2.5">
                <div className="mb-2 flex items-center justify-between px-0.5">
                  <span className="flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-[0.1em] text-teal-800"><MapPin size={11} /> Locations in {filters.city}</span>
                  {filters.location !== "any" && <button type="button" onClick={() => setFilters((current) => ({ ...current, location: "any" }))} className="text-[10px] font-bold text-teal-700 hover:underline">Show all</button>}
                </div>
                {places.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    <button type="button" onClick={() => setFilters((current) => ({ ...current, location: "any" }))} className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition ${filters.location === "any" ? "bg-teal-700 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:ring-teal-300"}`}>
                      All {filters.city} <span className="opacity-70">{inCity.length}</span>
                    </button>
                    {places.map((place) => (
                      <button key={place} type="button" onClick={() => setFilters((current) => ({ ...current, location: place }))} className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition ${filters.location === place ? "bg-teal-700 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:ring-teal-300"}`}>
                        {place} <span className="opacity-70">{countFor(place)}</span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="px-0.5 text-[11px] text-slate-500">No locations added for {filters.city} yet. Add one when creating or editing a hotel.</p>
                )}
              </div>
            );
          })()}
          <div className="grid grid-cols-4 gap-1.5">
            {[0, 3, 4, 5].map((stars) => (
              <button key={stars} onClick={() => setFilters((current) => ({ ...current, minStars: stars }))} className={`flex h-9 items-center justify-center gap-1 rounded-lg text-[11px] font-bold transition ${filters.minStars === stars ? "bg-teal-700 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
                {stars === 0 ? "Any" : <>{stars}<Star size={10} className={filters.minStars === stars ? "fill-white" : "fill-slate-500"} />+</>}
              </button>
            ))}
          </div>
          <div className="mt-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Hotel amenities</span>
              {filters.amenities.length > 0 && (
                <button onClick={() => setFilters((current) => ({ ...current, amenities: [] }))} className="text-[10px] font-bold text-teal-700">Clear</button>
              )}
            </div>
            <div className="space-y-1.5">
              {amenityOptions.map((amenity) => {
                const active = filters.amenities.includes(amenity.slug);
                const count = amenityCounts[amenity.slug] ?? 0;
                return (
                  <button key={amenity.slug} onClick={() => toggleAmenity(amenity.slug)} className={`flex w-full items-center justify-between rounded-lg border px-2.5 py-2 text-left text-xs font-semibold transition ${active ? "border-teal-600 bg-teal-50 text-teal-800" : "border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50"}`}>
                    <span className="flex items-center gap-2">
                      <span className={`grid h-5 w-5 place-items-center rounded-md ${active ? "bg-teal-600 text-white" : "bg-slate-100 text-slate-500"}`}>{active ? <Check size={12} /> : <AmenityIcon slug={amenity.slug} label="" icon={amenity.icon} size={12} />}</span>
                      {amenity.label}
                    </span>
                    <span className={`text-[10px] font-bold ${count > 0 ? "text-slate-400" : "text-slate-300"}`}>{count}</span>
                  </button>
                );
              })}
            </div>
            <p className="mt-2 text-[10px] leading-4 text-slate-400">Selecting more than one requires the hotel to have all of them.</p>
          </div>
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={filters.query} onChange={(event) => setFilters((current) => ({ ...current, query: event.target.value }))} placeholder="Hotel name…" className={`${inputClass} h-10 pl-9`} />
          </div>
        </div>
      </FilterBlock>
    </div>
  );

  return (
    <div>
      {/* Search bar */}
      <form onSubmit={submitSearch} className="relative z-10 rounded-2xl border border-slate-200/80 bg-white p-3 shadow-[0_10px_30px_rgba(15,23,42,0.06)]">
        <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-[1fr_1fr_1.3fr_1fr_1fr_auto]">
          <label className="rounded-xl px-3 py-2 transition hover:bg-slate-50">
            <span className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400"><CalendarDays size={12} /> Check-in</span>
            <input type="date" required value={form.checkIn} onChange={(event) => updateCheckIn(event.target.value)} className="mt-1 w-full bg-transparent text-sm font-bold text-slate-900 outline-none" />
          </label>
          <label className="rounded-xl px-3 py-2 transition hover:bg-slate-50 xl:border-l xl:border-slate-100">
            <span className="flex items-center justify-between text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">
              <span className="flex items-center gap-1.5"><CalendarDays size={12} /> Check-out</span>
              {formNights > 0 && <span className="rounded-full bg-teal-50 px-2 py-0.5 normal-case tracking-normal text-teal-700">{formNights} night{formNights === 1 ? "" : "s"}</span>}
            </span>
            <input type="date" required min={form.checkIn} value={form.checkOut} onChange={(event) => setForm((current) => ({ ...current, checkOut: event.target.value }))} className="mt-1 w-full bg-transparent text-sm font-bold text-slate-900 outline-none" />
          </label>
          <div className="relative xl:border-l xl:border-slate-100">
            <button type="button" onClick={() => setGuestsOpen((open) => !open)} className="w-full rounded-xl px-3 py-2 text-left transition hover:bg-slate-50">
              <span className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400"><Users size={12} /> Guests & rooms</span>
              <span className="mt-1 flex items-center justify-between text-sm font-bold text-slate-900">
                <span className="truncate">{guestSummary}</span>
                <ChevronDown size={15} className={`shrink-0 text-slate-400 transition ${guestsOpen ? "rotate-180" : ""}`} />
              </span>
            </button>
            {guestsOpen && (
              <>
                <button type="button" aria-label="Close guests" className="fixed inset-0 z-20 cursor-default" onClick={() => setGuestsOpen(false)} />
                <div className="absolute left-0 right-0 top-full z-30 mt-2 min-w-[300px] divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white px-5 py-2 shadow-2xl">
                  <Stepper label="Adults" hint="Age 12+" value={form.adults} min={1} max={40} onChange={(value) => setGuests("adults", value)} />
                  <Stepper label="Children" hint="Age 2 – 11" value={form.children} min={0} max={20} onChange={(value) => setGuests("children", value)} />
                  <Stepper label="Infants" hint="Under 2" value={form.infants} min={0} max={10} onChange={(value) => setGuests("infants", value)} />
                  <Stepper label="Rooms" hint="Guests are split evenly" value={form.rooms} min={1} max={Math.min(20, form.adults)} onChange={(value) => setGuests("rooms", value)} />
                  <Stepper label="Extra beds" hint="Rollaway bed, if the room allows" value={form.extraBeds} min={0} max={4} onChange={(value) => setGuests("extraBeds", value)} />
                  <Stepper label="Sofa beds" hint="Pull-out sofa bed" value={form.sofaBeds} min={0} max={4} onChange={(value) => setGuests("sofaBeds", value)} />
                  <Stepper label="Baby cots" hint="Usually free of charge" value={form.babyCots} min={0} max={4} onChange={(value) => setGuests("babyCots", value)} />
                  <div className="py-3">
                    <button type="button" onClick={() => setGuestsOpen(false)} className="h-9 w-full rounded-lg bg-slate-900 text-xs font-bold text-white">Done</button>
                  </div>
                </div>
              </>
            )}
          </div>
          <label className="rounded-xl px-3 py-2 transition hover:bg-slate-50 xl:border-l xl:border-slate-100">
            <span className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400"><BedDouble size={12} /> Room category</span>
            <select value={form.category} onChange={(event) => setForm((current) => ({ ...current, category: event.target.value }))} className="mt-1 w-full cursor-pointer bg-transparent text-sm font-bold text-slate-900 outline-none">
              {categoryOptions.map((category) => (
                <option key={category.slug} value={category.slug}>{category.label}</option>
              ))}
              <option value="any">All room types</option>
            </select>
          </label>
          <label className="rounded-xl px-3 py-2 transition hover:bg-slate-50 xl:border-l xl:border-slate-100">
            <span className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400"><Globe2 size={12} /> Client market</span>
            <select value={form.market} onChange={(event) => setForm((current) => ({ ...current, market: event.target.value }))} className="mt-1 w-full cursor-pointer bg-transparent text-sm font-bold text-slate-900 outline-none">
              {MARKETS.map((market) => (
                <option key={market.value} value={market.value}>{market.label}</option>
              ))}
            </select>
          </label>
          <button disabled={loading} className="flex h-full min-h-[52px] items-center justify-center gap-2 rounded-xl bg-[#174e48] px-7 text-sm font-extrabold text-white shadow-md shadow-teal-900/15 transition hover:bg-[#103f3a] disabled:opacity-70 md:col-span-2 xl:col-span-1">
            {loading ? <Loader2 size={17} className="animate-spin" /> : <Search size={17} />} Search all hotels
          </button>
        </div>
      </form>

      {searchError && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-700">
          <AlertTriangle size={16} /> {searchError}
        </div>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-[280px_minmax(0,1fr)]">
        <aside className="hidden lg:block">
          <div className="sticky top-[100px]">{filterPanel}</div>
        </aside>

        <section className={loading ? "pointer-events-none opacity-60 transition" : "transition"}>
          {/* Summary bar */}
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-extrabold text-slate-950">
                {filtered.results.length} result{filtered.results.length === 1 ? "" : "s"}
                <span className="font-semibold text-slate-400"> · {categoryLabel(criteria.category === "any" ? "All room types" : criteria.category)}</span>
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Checked {response.checkedHotels} contracted hotels ({response.checkedRooms} room types) · {criteriaSummary}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setFiltersOpen(true)} className="flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 lg:hidden">
                <Filter size={14} /> Filters {activeFilterCount > 0 && `(${activeFilterCount})`}
              </button>
              <div className="relative">
                <ArrowDownWideNarrow size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <select value={filters.sort} onChange={(event) => setFilters((current) => ({ ...current, sort: event.target.value as SortKey }))} className="h-10 appearance-none rounded-xl border border-slate-200 bg-white pl-9 pr-9 text-xs font-bold text-slate-700 outline-none focus:border-teal-700">
                  {SORT_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>{option.label}</option>
                  ))}
                </select>
                <ChevronDown size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              </div>
            </div>
          </div>

          {(filtered.outsidePriceRange > 0 || response.excluded.length > 0) && (
            <div className="mb-4 flex flex-wrap gap-2 text-[11px] font-semibold">
              {filtered.outsidePriceRange > 0 && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-sky-50 px-3 py-1.5 text-sky-700">
                  <Info size={12} /> {filtered.outsidePriceRange} hidden by your rate range
                </span>
              )}
              {response.excluded.length > 0 && (
                <button onClick={() => setShowUnavailable((open) => !open)} className="inline-flex items-center gap-1.5 rounded-full bg-rose-50 px-3 py-1.5 text-rose-700 transition hover:bg-rose-100">
                  <CalendarX2 size={12} /> {response.excluded.length} unavailable for these dates {showUnavailable ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                </button>
              )}
            </div>
          )}

          {showUnavailable && response.excluded.length > 0 && (
            <div className="mb-5 overflow-hidden rounded-2xl border border-rose-100 bg-white">
              <div className="border-b border-rose-100 bg-rose-50/50 px-5 py-3 text-xs font-extrabold text-rose-800">Not bookable for this search</div>
              <div className="divide-y divide-slate-100">
                {response.excluded.map((item) => (
                  <div key={item.key} className="flex flex-wrap items-center gap-3 px-5 py-3">
                    <XCircle size={16} className="shrink-0 text-rose-400" />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-bold text-slate-800">{item.hotelName} <span className="font-medium text-slate-400">· {item.roomName}</span></div>
                      <div className="mt-0.5 text-[11px] text-slate-500">{item.reason}</div>
                    </div>
                    <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${EXCLUDED_STYLE[item.kind].className}`}>{EXCLUDED_STYLE[item.kind].label}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Results */}
          <div className="space-y-4">
            {filtered.results.map((result, index) => {
              const offer = result.offers.find((item) => item.boardType === selectedBoard[result.key]) ?? result.best;
              const rate = comparableRate(offer, filters.rateBasis);
              const isLowest = lowestRate !== null && comparableRate(result.best, filters.rateBasis) === lowestRate;
              const isOpen = expanded === result.key;
              return (
                <article key={result.key} className={`overflow-hidden rounded-2xl border bg-white shadow-[0_2px_10px_rgba(15,23,42,0.03)] transition hover:shadow-lg ${isLowest ? "border-teal-300 ring-1 ring-teal-100" : "border-slate-200/80"}`}>
                  <div className="grid gap-0 md:grid-cols-[minmax(0,1fr)_250px]">
                    <div className="p-5">
                      <div className="flex items-start gap-4">
                        <div className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl text-sm font-extrabold ${isLowest ? "bg-[#174e48] text-white" : "bg-slate-100 text-slate-600"}`}>#{index + 1}</div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-base font-extrabold text-slate-950">{result.hotel.name}</h3>
                            <Stars count={result.hotel.starRating} />
                            {isLowest && <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-extrabold text-emerald-700"><TrendingDown size={11} /> Lowest rate</span>}
                          </div>
                          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                            <span className="flex items-center gap-1"><MapPin size={12} /> {result.hotel.location ? <><b className="font-semibold text-slate-700">{result.hotel.location}</b>, {result.hotel.city}</> : result.hotel.city}</span>
                            <span className="flex items-center gap-1"><Clock3 size={12} /> In {result.hotel.checkInTime} · Out {result.hotel.checkOutTime}</span>
                          </div>
                          {result.hotel.amenities.length > 0 && (
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {result.hotel.amenities.map((slug) => {
                                const option = amenityOptions.find((item) => item.slug === slug);
                                const missing = filters.amenities.includes(slug);
                                return (
                                  <span key={slug} className={`inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[10px] font-bold ${missing ? "bg-teal-50 text-teal-700 ring-1 ring-teal-200" : "bg-slate-50 text-slate-500 ring-1 ring-slate-200"}`}>
                                    <AmenityIcon slug={slug} label={option?.label ?? slug} icon={option?.icon} size={11} />
                                  </span>
                                );
                              })}
                            </div>
                          )}
                          <div className="mt-3 flex flex-wrap items-center gap-2">
                            <span className="inline-flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-xs font-bold text-slate-700 ring-1 ring-slate-200"><BedDouble size={13} /> {result.room.name}</span>
                            {result.room.mediaLink && <a href={result.room.mediaLink} target="_blank" rel="noreferrer" title="Room media on Google Drive" className="rounded-lg bg-slate-50 px-2 py-1.5 text-[10px] font-bold text-slate-600 ring-1 ring-slate-200 transition hover:bg-slate-100 hover:text-slate-900">Media ↗</a>}
                            <span className="rounded-lg bg-teal-50 px-2 py-1.5 text-[10px] font-extrabold uppercase tracking-wide text-teal-700">{categoryLabel(result.room.category)}</span>
                            <span className="rounded-lg bg-slate-50 px-2 py-1.5 text-[10px] font-bold text-slate-600 ring-1 ring-slate-200">Sleeps {result.room.baseSleeps}{result.room.maxChildren > 0 ? ` + ${result.room.maxChildren} ch` : ""}</span>
                            <span className={`rounded-lg px-2 py-1.5 text-[10px] font-bold ${result.roomsLeft <= 2 ? "bg-orange-50 text-orange-700" : "bg-slate-50 text-slate-500"}`}>{result.roomsLeft <= 2 ? `Only ${result.roomsLeft} left` : `${result.roomsLeft} rooms left`}</span>
                            {offer.bedding.map((item) => (
                              <span key={item.kind} className={`rounded-lg px-2 py-1.5 text-[10px] font-bold ${item.free ? "bg-emerald-50 text-emerald-700" : "bg-violet-50 text-violet-700"}`}>
                                {item.count} × {item.label}{item.free ? " · free" : ""}
                              </span>
                            ))}
                            {offer.promoCodes.map((code) => (
                              <span key={code} className="inline-flex items-center gap-1 rounded-lg bg-rose-50 px-2 py-1.5 text-[10px] font-extrabold uppercase tracking-wide text-rose-700">
                                <TicketPercent size={12} /> {code}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Board options */}
                      <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
                        {result.offers.map((item) => {
                          const active = item.boardType === offer.boardType;
                          return (
                            <button key={item.boardType} onClick={() => setSelectedBoard((current) => ({ ...current, [result.key]: item.boardType }))} className={`rounded-xl border px-3 py-2.5 text-left transition ${active ? "border-teal-600 bg-teal-50/60 ring-1 ring-teal-600" : "border-slate-200 hover:border-slate-300"}`}>
                              <div className="flex items-center justify-between">
                                <span className={`text-[10px] font-extrabold uppercase tracking-wide ${active ? "text-teal-800" : "text-slate-400"}`}>{boardShort(item.boardType)}</span>
                                {active && <CheckCircle2 size={13} className="text-teal-700" />}
                              </div>
                              <div className="mt-0.5 truncate text-[11px] font-semibold text-slate-500">{boardLabel(item.boardType)}</div>
                              <div className="mt-1 text-sm font-extrabold text-slate-900">{money(comparableRate(item, filters.rateBasis))}<span className="text-[10px] font-semibold text-slate-400"> /nt</span></div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Price column */}
                    <div className="flex flex-col justify-between border-t border-slate-100 bg-slate-50/60 p-5 md:border-l md:border-t-0">
                      <div className="md:text-right">
                        <div className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Avg per room / night</div>
                        <div className="mt-1 text-[28px] font-extrabold leading-none tracking-tight text-slate-950">{money(rate)}</div>
                        <div className="mt-1 text-[10px] text-slate-400">{filters.rateBasis === "excl_tax" ? "excl. tourism tax" : "incl. tourism tax"} · {boardLabel(offer.boardType)}</div>
                        <div className="mt-4 border-t border-slate-200 pt-3">
                          <div className="text-[11px] text-slate-500">Total {offer.nights} night{offer.nights === 1 ? "" : "s"} · {offer.rooms} room{offer.rooms === 1 ? "" : "s"}</div>
                          <div className="text-lg font-extrabold text-[#174e48]">{money(offer.totalAmount, 0)}</div>
                          <div className="text-[10px] text-slate-400">incl. {money(offer.tourismTaxAmount)} tourism tax</div>
                        </div>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <button onClick={() => setExpanded(isOpen ? null : result.key)} className="flex h-10 flex-1 items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-600 transition hover:bg-slate-50">
                          Breakdown {isOpen ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                        </button>
                        {canBook && <button onClick={() => { setBookingError(""); setBookingTarget({ result, offer }); }} className="flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl bg-[#174e48] text-xs font-extrabold text-white transition hover:bg-[#103f3a]">
                          Book {boardShort(offer.boardType)}
                        </button>}
                      </div>
                      {canQuote && (() => {
                        const inQuote = quoteLegs.some((leg) => leg.key === legKeyFor(result, offer));
                        return (
                          <button
                            onClick={() => addLeg(result, offer)}
                            disabled={inQuote}
                            className={`mt-2 flex h-10 w-full items-center justify-center gap-1.5 rounded-xl border text-xs font-bold transition ${
                              inQuote
                                ? "cursor-default border-emerald-200 bg-emerald-50 text-emerald-700"
                                : "border-teal-200 bg-teal-50 text-teal-800 hover:bg-teal-100"
                            }`}
                          >
                            {inQuote ? <><Check size={14} /> In quotation (stay {quoteLegs.findIndex((leg) => leg.key === legKeyFor(result, offer)) + 1})</> : <><FileText size={14} /> Add to quotation</>}
                          </button>
                        );
                      })()}
                    </div>
                  </div>

                  {isOpen && (
                    <div className="border-t border-slate-100 bg-white p-5">
                      <div className="mb-3 flex flex-wrap gap-2">
                        {result.allocation.map((room, roomIndex) => (
                          <span key={roomIndex} className="inline-flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[11px] font-semibold text-slate-600 ring-1 ring-slate-200">
                            <Users size={12} /> Room {roomIndex + 1}: {room.adults}A{room.children ? ` + ${room.children}C` : ""}{room.infants ? ` + ${room.infants}I` : ""} · {room.rule}{room.bedding.length ? ` · ${room.bedding.map((item) => `${item.count} × ${item.label}${item.free ? " (free)" : ""}`).join(", ")}` : ""}
                          </span>
                        ))}
                      </div>
                      <div className="overflow-x-auto rounded-xl border border-slate-100">
                        <table className="w-full min-w-[640px] text-left text-xs">
                          <thead className="bg-slate-50 text-[10px] uppercase tracking-[0.08em] text-slate-400">
                            <tr>
                              <th className="px-3 py-2.5">Night</th>
                              <th className="px-3 py-2.5">Contract</th>
                              <th className="px-3 py-2.5 text-right">Room</th>
                              <th className="px-3 py-2.5 text-right">Meals</th>
                              <th className="px-3 py-2.5 text-right">Occupancy</th>
                              <th className="px-3 py-2.5 text-right">Extra bed</th>
                              <th className="px-3 py-2.5 text-right">Night total</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {offer.nightly.map((line) => (
                              <tr key={line.date} className="text-slate-600">
                                <td className="px-3 py-2 font-semibold text-slate-800">{shortDate(line.date)}</td>
                                <td className="px-3 py-2 text-slate-500">{line.rateName}</td>
                                <td className="px-3 py-2 text-right">{money(line.roomAmount)}</td>
                                <td className="px-3 py-2 text-right">{line.boardAmount ? money(line.boardAmount) : "—"}</td>
                                <td className="px-3 py-2 text-right">{line.supplementAmount ? money(line.supplementAmount) : "—"}</td>
                                <td className="px-3 py-2 text-right">{line.extraBedAmount ? money(line.extraBedAmount) : "—"}</td>
                                <td className="px-3 py-2 text-right font-bold text-slate-900">{money(line.total)}</td>
                              </tr>
                            ))}
                          </tbody>
                          <tfoot className="bg-slate-50/70 text-slate-700">
                            <tr>
                              <td colSpan={6} className="px-3 py-2 text-right font-semibold">Tourism tax ({money(result.hotel.tourismTax)} per {result.hotel.tourismTaxBasis.replace("_", " / ")})</td>
                              <td className="px-3 py-2 text-right font-bold">{money(offer.tourismTaxAmount)}</td>
                            </tr>
                            <tr>
                              <td colSpan={6} className="px-3 py-2.5 text-right font-extrabold text-slate-900">Total net cost</td>
                              <td className="px-3 py-2.5 text-right text-sm font-extrabold text-[#174e48]">{money(offer.totalAmount, 2)}</td>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                      {offer.minimumNights > 1 && <p className="mt-2 text-[11px] text-amber-700">Minimum stay of {offer.minimumNights} nights applies to this contract.</p>}
                    </div>
                  )}
                </article>
              );
            })}

            {filtered.results.length === 0 && (
              <div className="grid place-items-center rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400"><Hotel size={26} /></div>
                <h3 className="mt-4 text-base font-extrabold text-slate-800">No contracted hotels match</h3>
                <p className="mt-1 max-w-sm text-sm text-slate-500">
                  {filtered.outsidePriceRange > 0 ? `${filtered.outsidePriceRange} hotel(s) are available but outside your nightly rate range. Try widening it.` : "Try different dates, another room category, or fewer guests per room."}
                </p>
                {activeFilterCount > 0 && (
                  <button onClick={() => setFilters((current) => ({ ...DEFAULT_FILTER_STATE, sort: current.sort }))} className="mt-4 rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white">Clear filters</button>
                )}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Mobile filters drawer */}
      {filtersOpen && (
        <div className="fixed inset-0 z-[70] flex justify-end bg-slate-950/40 lg:hidden" onMouseDown={(event) => event.target === event.currentTarget && setFiltersOpen(false)}>
          <div className="h-full w-[320px] max-w-full overflow-y-auto bg-[#f5f7f9] p-4">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-extrabold">Filter results</span>
              <button onClick={() => setFiltersOpen(false)} className="rounded-lg border border-slate-200 bg-white p-1.5"><X size={16} /></button>
            </div>
            {filterPanel}
            <button onClick={() => setFiltersOpen(false)} className="mt-4 h-11 w-full rounded-xl bg-[#174e48] text-sm font-bold text-white">Show {filtered.results.length} results</button>
          </div>
        </div>
      )}

      {/* Booking modal */}
      {bookingTarget && (
        <div data-internal className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px] print:hidden" onMouseDown={(event) => event.target === event.currentTarget && setBookingTarget(null)}>
          <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5">
              <div>
                <h2 className="text-xl font-bold text-slate-950">Confirm booking</h2>
                <p className="mt-1 text-sm text-slate-500">The price is re-checked against the live contract before saving.</p>
              </div>
              <button onClick={() => setBookingTarget(null)} className="rounded-xl border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" aria-label="Close"><X size={18} /></button>
            </div>
            <form onSubmit={confirmBooking} className="grid gap-5 p-6 md:grid-cols-[1fr_280px]">
              <div className="grid content-start gap-4">
                {[
                  { name: "guestName", label: "Lead guest name", type: "text", required: true, placeholder: "Full name as per passport" },
                  { name: "guestEmail", label: "Guest / agent email", type: "email", required: true, placeholder: "guest@email.com" },
                  { name: "guestPhone", label: "Phone", type: "tel", required: false, placeholder: "+971" },
                ].map((field) => (
                  <label key={field.name} className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">{field.label}</span>
                    <input name={field.name} type={field.type} required={field.required} placeholder={field.placeholder} className={inputClass} />
                  </label>
                ))}
                <label className="block">
                  <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Notes for hotel</span>
                  <textarea name="notes" placeholder="Arrival time, bed preference…" className="min-h-24 w-full rounded-xl border border-slate-200 p-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10" />
                </label>
                {bookingError && <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-xs font-semibold text-rose-700"><AlertTriangle size={15} className="shrink-0" /> {bookingError}</div>}
              </div>
              <div className="rounded-2xl bg-slate-50 p-4">
                <div className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-slate-400">Stay summary</div>
                <h3 className="mt-2 text-sm font-extrabold text-slate-900">{bookingTarget.result.hotel.name}</h3>
                <div className="mt-1"><Stars count={bookingTarget.result.hotel.starRating} size={11} /></div>
                <div className="mt-3 space-y-2 text-xs text-slate-600">
                  <div className="flex items-center gap-2"><BedDouble size={13} /> {bookingTarget.result.room.name}{bookingTarget.result.room.mediaLink && <a href={bookingTarget.result.room.mediaLink} target="_blank" rel="noreferrer" className="text-[10px] font-bold text-slate-500 underline">Media ↗</a>}</div>
                  <div className="flex items-center gap-2"><UtensilsCrossed size={13} /> {boardLabel(bookingTarget.offer.boardType)}</div>
                  <div className="flex items-center gap-2"><CalendarDays size={13} /> {shortDate(criteria.checkIn, true)} → {shortDate(criteria.checkOut, true)}</div>
                  <div className="flex items-center gap-2"><Users size={13} /> {criteria.adults}A · {criteria.children}C · {criteria.infants}I · {criteria.rooms} room(s)</div>
                  <div className="flex items-center gap-2"><Globe2 size={13} /> {marketLabel(criteria.market)}</div>
                  {bookingTarget.offer.promoCodes.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5">
                      {bookingTarget.offer.promoCodes.map((code) => (
                        <span key={code} className="inline-flex items-center gap-1 rounded-md bg-rose-50 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-rose-700"><TicketPercent size={11} /> {code}</span>
                      ))}
                    </div>
                  )}
                  {bookingTarget.offer.bedding.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5">
                      {bookingTarget.offer.bedding.map((item) => (
                        <span key={item.kind} className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold ${item.free ? "bg-emerald-50 text-emerald-700" : "bg-violet-50 text-violet-700"}`}>
                          {item.count} × {item.label}{item.free ? " (free)" : ""}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="my-4 border-t border-slate-200" />
                <div className="space-y-1.5 text-xs">
                  {[
                    ["Room", bookingTarget.offer.baseAmount],
                    ["Meal supplements", bookingTarget.offer.boardAmount],
                    ["Occupancy supplements", bookingTarget.offer.occupancyAmount],
                    ["Extra bed", bookingTarget.offer.extraBedAmount],
                    ["Tourism tax", bookingTarget.offer.tourismTaxAmount],
                  ].map(([label, value]) => (
                    <div key={String(label)} className="flex justify-between text-slate-500"><span>{label}</span><span className="font-semibold text-slate-800">{money(value, 2)}</span></div>
                  ))}
                </div>
                <div className="mt-4 rounded-xl bg-[#174e48] p-3 text-white">
                  <div className="text-[10px] text-teal-100">Total net cost</div>
                  <div className="mt-0.5 text-xl font-extrabold">{money(bookingTarget.offer.totalAmount, 2)}</div>
                </div>
              </div>
              <div className="flex justify-end border-t border-slate-100 pt-5 md:col-span-2">
                <button disabled={bookingSaving} className="flex h-11 min-w-40 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white transition hover:bg-[#103f3a] disabled:opacity-60">
                  {bookingSaving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />} {bookingSaving ? "Confirming…" : "Confirm booking"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quotation builder bar */}
      {quoteLegs.length > 0 && !quoteOpen && (
        <div data-internal className="fixed bottom-4 left-1/2 z-[60] w-[calc(100%-2rem)] max-w-2xl -translate-x-1/2 overflow-hidden rounded-2xl border border-teal-900/20 bg-[#173f3b] text-white shadow-2xl print:hidden">
          <div className="flex flex-wrap items-center gap-3 px-5 py-3.5">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/10"><FileText size={18} /></div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-extrabold">
                Quotation · {quoteLegs.length} stay{quoteLegs.length === 1 ? "" : "s"} · {money(quotePreview.proposalTotal, 2)}
              </div>
              <div className="truncate text-[11px] text-teal-100/80">
                {quoteLegs.map((leg) => `${leg.nights}n ${leg.hotelName}`).join("  +  ")}
              </div>
            </div>
            <button onClick={() => setQuoteLegs([])} className="rounded-lg px-2.5 py-2 text-[11px] font-bold text-teal-100/70 transition hover:bg-white/10 hover:text-white">
              Clear
            </button>
            <button onClick={() => { setQuoteError(""); setQuoteOpen(true); }} className="flex h-10 items-center gap-1.5 rounded-xl bg-[#d2a06d] px-4 text-xs font-extrabold text-[#173f3b] transition hover:bg-[#deb17f]">
              Review & save
            </button>
          </div>
        </div>
      )}

      {/* Quotation review & save */}
      {quoteOpen && (
        <div data-internal className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px] print:hidden" onMouseDown={(event) => event.target === event.currentTarget && setQuoteOpen(false)}>
          <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5">
              <div>
                <h2 className="text-xl font-bold text-slate-950">Save quotation</h2>
                <p className="mt-1 text-sm text-slate-500">Combine one or more stays — e.g. 2 nights in one hotel + 2 nights in another — into a single quotation. Prices are re-checked before saving.</p>
              </div>
              <button onClick={() => setQuoteOpen(false)} className="rounded-xl border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" aria-label="Close"><X size={18} /></button>
            </div>
            <form onSubmit={saveQuotation} className="grid gap-5 p-6 md:grid-cols-[1fr_280px]">
              <div className="space-y-3">
                {quoteLegs.map((leg, index) => (
                  <div key={leg.key} className="rounded-2xl border border-slate-200 p-4">
                    <div className="flex items-start gap-3">
                      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-teal-700 text-xs font-extrabold text-white">{index + 1}</div>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-extrabold text-slate-900">{leg.hotelName}</div>
                        <div className="mt-0.5 text-xs text-slate-500">{leg.roomName} · {boardLabel(leg.boardType)}</div>
                        <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-slate-500">
                          <span className="flex items-center gap-1"><CalendarDays size={12} /> {shortDate(leg.checkIn, true)} → {shortDate(leg.checkOut, true)} ({leg.nights}n)</span>
                          <span className="flex items-center gap-1"><Users size={12} /> {leg.adults}A · {leg.children}C · {leg.infants}I · {leg.rooms} room(s)</span>
                        </div>
                        {leg.promoCodes.length > 0 && <div className="mt-1.5 text-[10px] font-extrabold uppercase text-rose-600">Promo: {leg.promoCodes.join(", ")}</div>}
                      </div>
                      <div className="shrink-0 text-right">
                        <div className="text-sm font-extrabold text-slate-900">{money(leg.totalAmount, 2)}</div>
                        <div className="mt-1.5 flex justify-end gap-1">
                          <button type="button" disabled={index === 0} onClick={() => moveLeg(index, -1)} className="rounded-md border border-slate-200 p-1 text-slate-500 hover:bg-slate-50 disabled:opacity-30" aria-label="Move stay up"><ChevronUp size={13} /></button>
                          <button type="button" disabled={index === quoteLegs.length - 1} onClick={() => moveLeg(index, 1)} className="rounded-md border border-slate-200 p-1 text-slate-500 hover:bg-slate-50 disabled:opacity-30" aria-label="Move stay down"><ChevronDown size={13} /></button>
                          <button type="button" onClick={() => removeLeg(leg.key)} className="rounded-md border border-slate-200 p-1 text-slate-500 hover:bg-rose-50 hover:text-rose-600" aria-label="Remove stay"><Trash2 size={13} /></button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {quoteLegs.length === 0 && <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">No stays left. Close this and add stays from the search results.</p>}
                {quoteError && <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-xs font-semibold text-rose-700"><AlertTriangle size={15} className="shrink-0" /> {quoteError}</div>}
              </div>
              <div>
                <div className="grid content-start gap-4">
                  <label className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Client name</span>
                    <input required value={quoteClient.name} onChange={(event) => setQuoteClient((current) => ({ ...current, name: event.target.value }))} placeholder="Full name" className={inputClass} />
                  </label>
                  <label className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Client email</span>
                    <input type="email" value={quoteClient.email} onChange={(event) => setQuoteClient((current) => ({ ...current, email: event.target.value }))} placeholder="client@email.com" className={inputClass} />
                  </label>
                  <label className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Client phone</span>
                    <input value={quoteClient.phone} onChange={(event) => setQuoteClient((current) => ({ ...current, phone: event.target.value }))} placeholder="+971" className={inputClass} />
                  </label>
                  <label className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Valid until</span>
                    <input type="date" value={quoteValidUntil} onChange={(event) => setQuoteValidUntil(event.target.value)} className={inputClass} />
                  </label>
                  <label className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Notes</span>
                    <textarea value={quoteClient.notes} onChange={(event) => setQuoteClient((current) => ({ ...current, notes: event.target.value }))} placeholder="Internal notes shown on the quotation…" className="min-h-20 w-full rounded-xl border border-slate-200 p-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10" />
                  </label>
                </div>
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="text-xs font-extrabold text-slate-900">Proposal pricing</div>
                  <label className="mt-3 flex cursor-pointer items-center justify-between gap-3 rounded-lg bg-slate-50 px-3 py-2.5">
                    <span className="text-xs font-bold text-slate-700">Include tourism tax</span>
                    <input
                      type="checkbox"
                      checked={quoteIncludeTax}
                      onChange={(event) => setQuoteIncludeTax(event.target.checked)}
                      className="h-4 w-4 accent-teal-700"
                    />
                  </label>
                  {!quoteIncludeTax && (
                    <p className="mt-1.5 text-[11px] text-amber-700">
                      {money(quotePreview.excludedTax, 2)} tourism tax will be excluded — the proposal tells the client it is payable at the hotel.
                    </p>
                  )}
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <label className="block">
                      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Markup %</span>
                      <input
                        type="number"
                        min="0"
                        max="500"
                        step="0.5"
                        value={quoteMarkupPct}
                        onChange={(event) => setQuoteMarkupPct(event.target.value)}
                        placeholder="0"
                        className={`${inputClass} h-10`}
                      />
                    </label>
                    <label className="block">
                      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Markup AED</span>
                      <input
                        type="number"
                        min="0"
                        step="1"
                        value={quoteMarkupAmt}
                        onChange={(event) => setQuoteMarkupAmt(event.target.value)}
                        placeholder="0"
                        className={`${inputClass} h-10`}
                      />
                    </label>
                  </div>
                  <p className="mt-1.5 text-[10px] leading-4 text-slate-400">% applies to the net subtotal first, then the fixed amount is added. Both can be combined.</p>
                </div>
                <div className="mt-4 rounded-xl bg-[#174e48] p-3 text-white">
                  <div className="space-y-1 text-[11px] text-teal-100">
                    <div className="flex justify-between"><span>Net cost{quoteIncludeTax ? " (incl. tax)" : " (excl. tax)"}</span><span className="font-bold text-white">{money(quotePreview.subtotal, 2)}</span></div>
                    {(quotePreview.markupPercentAmount > 0 || quotePreview.markupFixedAmount > 0) && (
                      <div className="flex justify-between"><span>Markup</span><span className="font-bold text-white">+{money(quotePreview.margin, 2)}</span></div>
                    )}
                  </div>
                  <div className="mt-2 border-t border-white/15 pt-2">
                    <div className="text-[10px] text-teal-100">Total proposal cost ({quoteLegs.length} stay{quoteLegs.length === 1 ? "" : "s"})</div>
                    <div className="mt-0.5 text-xl font-extrabold">{money(quotePreview.proposalTotal, 2)}</div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-5 md:col-span-2">
                <p className="text-[11px] text-slate-400">Want another hotel in this quotation? Close, change the dates, search again and add another stay.</p>
                <button disabled={quoteSaving || quoteLegs.length === 0} className="flex h-11 min-w-40 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white transition hover:bg-[#103f3a] disabled:opacity-60">
                  {quoteSaving ? <Loader2 size={16} className="animate-spin" /> : <FileText size={16} />} {quoteSaving ? "Saving…" : "Save quotation"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
