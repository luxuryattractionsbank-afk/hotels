import type { Metadata } from "next";
import ResetForm from "./reset-form";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Reset password | Luxury Attractions",
  robots: { index: false, follow: false },
};

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const params = await searchParams;
  return <ResetForm token={typeof params.token === "string" ? params.token : ""} />;
}
