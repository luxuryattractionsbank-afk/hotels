"use client";

import { ArrowLeft, CheckCircle2, Hotel, Loader2, LockKeyhole } from "lucide-react";
import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";

export default function ResetForm({ token }: { token: string }) {
  const [valid, setValid] = useState<boolean | null>(null);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!token) { setValid(false); return; }
    let live = true;
    void fetch(`/api/auth/reset-password?token=${encodeURIComponent(token)}`, { cache: "no-store" })
      .then((response) => response.json())
      .then((value) => { if (live) setValid(value.valid === true); })
      .catch(() => { if (live) setValid(false); });
    return () => { live = false; };
  }, [token]);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password !== confirmPassword) { setError("Passwords do not match."); return; }
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password, confirmPassword }),
      });
      const value = await response.json();
      if (!response.ok) throw new Error(value.error || "Unable to reset password.");
      setPassword("");
      setConfirmPassword("");
      setDone(true);
      // Remove the token from the address bar as soon as it is consumed.
      window.history.replaceState(window.history.state, "", "/reset-password");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to reset password.");
    } finally {
      setBusy(false);
    }
  };
  const input = "h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10";
  return (
    <main className="flex min-h-screen items-center justify-center bg-[#f5f7f9] px-5 py-12">
      <section className="w-full max-w-md rounded-[24px] border border-slate-200 bg-white p-7 shadow-[0_18px_55px_rgba(20,55,50,.08)] sm:p-9">
        <div className="mb-6 flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#174e48] text-white"><Hotel size={21} /></span><div><p className="text-[15px] font-extrabold text-slate-950">Luxury Attractions</p><p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#b27a4b]">Hotel contracts</p></div></div>
        <div className="mb-5 grid h-12 w-12 place-items-center rounded-xl bg-teal-50 text-teal-700">{done ? <CheckCircle2 size={22} /> : <LockKeyhole size={21} />}</div>
        <h1 className="text-[26px] font-extrabold tracking-tight text-slate-950">{done ? "Password changed" : "Choose a new password"}</h1>
        <p className="mt-2 text-sm leading-6 text-slate-500">{done ? "Your old sessions were signed out. Please sign in with your new password." : "Reset links are valid for 30 minutes and can be used once."}</p>
        {!done && valid === null && <p className="mt-5 flex items-center gap-2 text-sm text-slate-500"><Loader2 size={16} className="animate-spin" /> Checking link…</p>}
        {!done && valid === false && <div role="alert" className="mt-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs leading-5 text-amber-900">This reset link is invalid or expired. Request a fresh link using your registered username or email.</div>}
        {error && <div role="alert" className="mt-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-700">{error}</div>}
        {!done && valid && <form onSubmit={submit} className="mt-6 space-y-4">
          <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-[0.07em] text-slate-500">New password</span><input type="password" required minLength={12} maxLength={200} autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 12 characters" className={input} /></label>
          <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-[0.07em] text-slate-500">Confirm new password</span><input type="password" required minLength={12} maxLength={200} autoComplete="new-password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} placeholder="Enter the same password again" className={input} /></label>
          <button disabled={busy} className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#174e48] text-sm font-extrabold text-white transition hover:bg-[#103f3a] disabled:opacity-50">{busy && <Loader2 size={17} className="animate-spin" />}{busy ? "Saving…" : "Reset password"}</button>
        </form>}
        <Link href={done ? "/login" : "/forgot-password"} className="mt-6 inline-flex items-center gap-2 text-xs font-bold text-teal-700 hover:underline"><ArrowLeft size={14} /> {done ? "Sign in" : "Request a new link"}</Link>
      </section>
    </main>
  );
}
