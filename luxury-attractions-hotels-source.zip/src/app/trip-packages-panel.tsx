"use client";

import {
  CarFront,
  ChevronDown,
  FileDown,
  Loader2,
  Pencil,
  Plus,
  Ticket,
  Trash2,
  X,
} from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { boardLabel } from "@/lib/search-engine";
import { computeProposal } from "@/lib/proposal";
import {
  computeTripPackage,
  tourModeLabel,
  tourTotal,
  transferModeLabel,
  transferTotal,
} from "@/lib/trip-package";
import { downloadQuotationPdf, downloadTripPackagePdf, TripPdfTour, TripPdfTransfer } from "@/lib/pdf";
import type { ProposalTextLeg } from "@/lib/proposal";
import type { ServiceRow } from "./services-panel";

export type TripPackageRow = {
  id: number;
  reference: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  quotationId: number | null;
  market: string;
  status: string;
  adults: number;
  children: number;
  infants: number;
  includeTourismTax: boolean;
  markupPercent: string;
  markupAmount: string;
  hotelsNet: string;
  transfersNet: string;
  toursNet: string;
  subtotalNet: string;
  proposalTotal: string;
  currency: string;
  validUntil: string | null;
  notes: string;
  createdAt: string;
};

export type TripTransferRow = {
  id: number;
  packageId: number;
  position: number;
  serviceId: number | null;
  serviceName: string;
  mode: string;
  direction: string;
  vehicle: string;
  transferDate: string;
  transferTime: string;
  pickup: string;
  dropoff: string;
  flightNo: string;
  adults: number;
  children: number;
  vehicles: number;
  unitPrice: string;
  totalNet: string;
  notes: string;
};

export type TripTourRow = {
  id: number;
  packageId: number;
  position: number;
  serviceId: number | null;
  serviceName: string;
  optionMode: string;
  tourDate: string;
  tourTime: string;
  meetingPoint: string;
  adults: number;
  children: number;
  priceAdult: string;
  priceChild: string;
  totalNet: string;
  notes: string;
};

export type QuoteRef = {
  id: number;
  reference: string;
  clientName: string;
  market: string;
  status: string;
  currency: string;
  proposalTotal: string;
};

export type QuoteLegRef = {
  id: number;
  quotationId: number;
  position: number;
  hotelId: number;
  roomTypeId: number;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  totalAmount: string;
  tourismTaxAmount: string;
};

type HotelRef = { id: number; name: string; city: string; locationId: number | null };
type RoomRef = { id: number; name: string };
type LocationRef = { id: number; name: string };

const inputClass =
  "h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10";

const money = (value: number | string, currency = "AED") =>
  `${currency} ${Number(value || 0).toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtDate = (iso: string) =>
  iso
    ? new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(`${iso.slice(0, 10)}T00:00:00Z`))
    : "—";

const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

type TransferDraft = {
  key: string;
  serviceId: number | null;
  serviceName: string;
  mode: "shared" | "private";
  direction: "oneway" | "twoway";
  vehicle: string;
  transferDate: string;
  transferTime: string;
  pickup: string;
  dropoff: string;
  flightNo: string;
  adults: number;
  children: number;
  vehicles: number;
  unitPrice: string;
  totalOverride: string;
  notes: string;
};

type TourDraft = {
  key: string;
  serviceId: number | null;
  serviceName: string;
  optionMode: "ticket_only" | "shared" | "private";
  tourDate: string;
  tourTime: string;
  meetingPoint: string;
  adults: number;
  children: number;
  priceAdult: string;
  priceChild: string;
  totalOverride: string;
  notes: string;
};

const newTransferDraft = (adults: number, children: number): TransferDraft => ({
  key: uid(),
  serviceId: null,
  serviceName: "",
  mode: "shared",
  direction: "oneway",
  vehicle: "",
  transferDate: "",
  transferTime: "",
  pickup: "",
  dropoff: "",
  flightNo: "",
  adults,
  children,
  vehicles: 1,
  unitPrice: "",
  totalOverride: "",
  notes: "",
});

const newTourDraft = (adults: number, children: number): TourDraft => ({
  key: uid(),
  serviceId: null,
  serviceName: "",
  optionMode: "shared",
  tourDate: "",
  tourTime: "",
  meetingPoint: "",
  adults,
  children,
  priceAdult: "",
  priceChild: "",
  totalOverride: "",
  notes: "",
});

function transferUnitFromCatalog(service: ServiceRow, mode: string, direction: string, vehicle: string): string {
  if (mode === "shared") return direction === "twoway" ? service.sharedTwoWayPrice : service.sharedOneWayPrice;
  const two = direction === "twoway";
  if (vehicle === "12 Seater") return two ? service.private12TwoWayPrice : service.private12OneWayPrice;
  return two ? service.private7TwoWayPrice : service.private7OneWayPrice;
}

function tourPricesFromCatalog(service: ServiceRow, option: string): { adult: string; child: string } {
  if (option === "ticket_only") return { adult: service.ticketOnlyAdult, child: service.ticketOnlyChild };
  if (option === "private") return { adult: service.privateAdult, child: service.privateChild };
  return { adult: service.sharedAdult, child: service.sharedChild };
}

const draftTransferTotal = (draft: TransferDraft): number => {
  if (draft.totalOverride !== "") return Math.max(0, Number(draft.totalOverride) || 0);
  return transferTotal({
    mode: draft.mode,
    direction: draft.direction,
    adults: draft.adults,
    children: draft.children,
    vehicles: draft.vehicles,
    unitPrice: draft.unitPrice === "" ? 0 : Number(draft.unitPrice),
  });
};

const draftTourTotal = (draft: TourDraft): number => {
  if (draft.totalOverride !== "") return Math.max(0, Number(draft.totalOverride) || 0);
  return tourTotal({
    adults: draft.adults,
    children: draft.children,
    priceAdult: draft.priceAdult === "" ? 0 : Number(draft.priceAdult),
    priceChild: draft.priceChild === "" ? 0 : Number(draft.priceChild),
  });
};

export function TripStatusBadge({ status }: { status: string }) {
  const tones: Record<string, string> = {
    draft: "bg-slate-100 text-slate-600",
    sent: "bg-sky-50 text-sky-700",
    confirmed: "bg-emerald-50 text-emerald-700",
    expired: "bg-amber-50 text-amber-700",
    cancelled: "bg-rose-50 text-rose-700",
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold capitalize ${tones[status] ?? tones.draft}`}>
      {status}
    </span>
  );
}

export default function TripPackagesPanel({
  packages,
  transfers,
  tours,
  services,
  quotations,
  quotationItems,
  hotels,
  rooms,
  locations,
  onChanged,
}: {
  packages: TripPackageRow[];
  transfers: TripTransferRow[];
  tours: TripTourRow[];
  services: ServiceRow[];
  quotations: QuoteRef[];
  quotationItems: QuoteLegRef[];
  hotels: HotelRef[];
  rooms: RoomRef[];
  locations: LocationRef[];
  onChanged: (message: string) => void;
}) {
  const [expanded, setExpanded] = useState<number | null>(null);
  const [dialog, setDialog] = useState<null | { mode: "add" } | { mode: "edit"; pkg: TripPackageRow }>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [pdfBusy, setPdfBusy] = useState<string | null>(null);

  const hotelName = (id: number) => hotels.find((h) => h.id === id)?.name ?? "Unknown hotel";
  const roomName = (id: number) => rooms.find((r) => r.id === id)?.name ?? "Unknown room";
  const locationName = (id: number | null) => (id ? locations.find((l) => l.id === id)?.name ?? "" : "");
  const itemsForQuote = (quotationId: number | null) =>
    quotationId ? quotationItems.filter((i) => i.quotationId === quotationId).sort((a, b) => a.position - b.position) : [];
  const transfersFor = (packageId: number) => transfers.filter((t) => t.packageId === packageId).sort((a, b) => a.position - b.position);
  const toursFor = (packageId: number) => tours.filter((t) => t.packageId === packageId).sort((a, b) => a.position - b.position);

  // ---- dialog form state ----
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [quotationId, setQuotationId] = useState<number | null>(null);
  const [pax, setPax] = useState({ adults: 2, children: 0, infants: 0 });
  const [includeTax, setIncludeTax] = useState(true);
  const [markupPct, setMarkupPct] = useState("");
  const [markupAmt, setMarkupAmt] = useState("");
  const [validUntil, setValidUntil] = useState("");
  const [notes, setNotes] = useState("");
  const [draftTransfers, setDraftTransfers] = useState<TransferDraft[]>([]);
  const [draftTours, setDraftTours] = useState<TourDraft[]>([]);

  const openAdd = (presetQuotationId?: number) => {
    const qid = presetQuotationId ?? null;
    const quote = quotations.find((q) => q.id === qid);
    setClientName(quote?.clientName ?? "");
    setClientEmail("");
    setClientPhone("");
    setQuotationId(qid);
    setPax({ adults: 2, children: 0, infants: 0 });
    setIncludeTax(true);
    setMarkupPct("");
    setMarkupAmt("");
    setValidUntil("");
    setNotes("");
    setDraftTransfers([]);
    setDraftTours([]);
    setError("");
    setDialog({ mode: "add" });
  };

  const openEdit = (pkg: TripPackageRow) => {
    setClientName(pkg.clientName);
    setClientEmail(pkg.clientEmail);
    setClientPhone(pkg.clientPhone);
    setQuotationId(pkg.quotationId);
    setPax({ adults: pkg.adults, children: pkg.children, infants: pkg.infants });
    setIncludeTax(pkg.includeTourismTax);
    setMarkupPct(Number(pkg.markupPercent) > 0 ? String(Number(pkg.markupPercent)) : "");
    setMarkupAmt(Number(pkg.markupAmount) > 0 ? String(Number(pkg.markupAmount)) : "");
    setValidUntil(pkg.validUntil ?? "");
    setNotes(pkg.notes);
    setDraftTransfers(
      transfersFor(pkg.id).map((t) => ({
        key: `t-${t.id}`,
        serviceId: t.serviceId,
        serviceName: t.serviceName,
        mode: (t.mode === "private" ? "private" : "shared") as "shared" | "private",
        direction: (t.direction === "twoway" ? "twoway" : "oneway") as "oneway" | "twoway",
        vehicle: t.vehicle,
        transferDate: t.transferDate.slice(0, 10),
        transferTime: t.transferTime,
        pickup: t.pickup,
        dropoff: t.dropoff,
        flightNo: t.flightNo,
        adults: t.adults,
        children: t.children,
        vehicles: t.vehicles,
        unitPrice: t.unitPrice,
        totalOverride: "",
        notes: t.notes,
      })),
    );
    setDraftTours(
      toursFor(pkg.id).map((t) => ({
        key: `r-${t.id}`,
        serviceId: t.serviceId,
        serviceName: t.serviceName,
        optionMode: (["ticket_only", "shared", "private"].includes(t.optionMode) ? t.optionMode : "shared") as TourDraft["optionMode"],
        tourDate: t.tourDate.slice(0, 10),
        tourTime: t.tourTime,
        meetingPoint: t.meetingPoint,
        adults: t.adults,
        children: t.children,
        priceAdult: t.priceAdult,
        priceChild: t.priceChild,
        totalOverride: "",
        notes: t.notes,
      })),
    );
    setError("");
    setDialog({ mode: "edit", pkg });
  };

  const preview = useMemo(() => {
    const legs = itemsForQuote(quotationId);
    const tNet = draftTransfers.reduce((s, d) => s + draftTransferTotal(d), 0);
    const rNet = draftTours.reduce((s, d) => s + draftTourTotal(d), 0);
    return computeTripPackage(legs, tNet, rNet, {
      includeTourismTax: includeTax,
      markupPercent: markupPct === "" ? 0 : Number(markupPct),
      markupAmount: markupAmt === "" ? 0 : Number(markupAmt),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quotationId, draftTransfers, draftTours, includeTax, markupPct, markupAmt, quotationItems]);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!dialog) return;
    setSaving(true);
    setError("");
    try {
      const payload: Record<string, unknown> = {
        clientName,
        clientEmail,
        clientPhone,
        quotationId,
        adults: pax.adults,
        children: pax.children,
        infants: pax.infants,
        includeTourismTax: includeTax,
        markupPercent: markupPct === "" ? 0 : Number(markupPct),
        markupAmount: markupAmt === "" ? 0 : Number(markupAmt),
        validUntil: validUntil || null,
        notes,
        transfers: draftTransfers.map((d) => ({
          serviceId: d.serviceId,
          serviceName: d.serviceName,
          mode: d.mode,
          direction: d.direction,
          vehicle: d.vehicle,
          transferDate: d.transferDate,
          transferTime: d.transferTime,
          pickup: d.pickup,
          dropoff: d.dropoff,
          flightNo: d.flightNo,
          adults: d.adults,
          children: d.children,
          vehicles: d.vehicles,
          unitPrice: d.unitPrice === "" ? 0 : Number(d.unitPrice),
          totalNet: d.totalOverride === "" ? undefined : Number(d.totalOverride),
          notes: d.notes,
        })),
        tours: draftTours.map((d) => ({
          serviceId: d.serviceId,
          serviceName: d.serviceName,
          optionMode: d.optionMode,
          tourDate: d.tourDate,
          tourTime: d.tourTime,
          meetingPoint: d.meetingPoint,
          adults: d.adults,
          children: d.children,
          priceAdult: d.priceAdult === "" ? 0 : Number(d.priceAdult),
          priceChild: d.priceChild === "" ? 0 : Number(d.priceChild),
          totalNet: d.totalOverride === "" ? undefined : Number(d.totalOverride),
          notes: d.notes,
        })),
      };
      if (dialog.mode === "edit") payload.id = dialog.pkg.id;
      const response = await fetch("/api/trip-packages", {
        method: dialog.mode === "edit" ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to save trip package.");
      setDialog(null);
      onChanged(dialog.mode === "edit" ? `Trip package ${result.package.reference} updated.` : `Trip package ${result.package.reference} created.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save trip package.");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (pkg: TripPackageRow) => {
    if (!confirm(`Delete trip package ${pkg.reference}? The linked hotel quotation is kept.`)) return;
    setSaving(true);
    try {
      const response = await fetch(`/api/trip-packages?id=${pkg.id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to delete trip package.");
      onChanged(`Trip package ${pkg.reference} deleted.`);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Unable to delete trip package.");
    } finally {
      setSaving(false);
    }
  };

  const downloadPdf = async (pkg: TripPackageRow) => {
    setPdfBusy(`trip-${pkg.id}`);
    try {
      const hotelLegs: ProposalTextLeg[] = itemsForQuote(pkg.quotationId).map((leg) => {
        const hotel = hotels.find((h) => h.id === leg.hotelId);
        return {
          totalAmount: leg.totalAmount,
          tourismTaxAmount: leg.tourismTaxAmount,
          nights: leg.nights,
          rooms: leg.rooms,
          hotelName: hotel?.name ?? "Unknown hotel",
          city: hotel?.city ?? "",
          location: hotel ? locationName(hotel.locationId) : "",
          roomName: roomName(leg.roomTypeId),
          boardType: leg.boardType,
          checkIn: leg.checkIn,
          checkOut: leg.checkOut,
          adults: leg.adults,
          children: leg.children,
          infants: leg.infants,
        };
      });
      const pdfTransfers: TripPdfTransfer[] = transfersFor(pkg.id).map((t) => ({
        serviceName: t.serviceName,
        mode: t.mode,
        direction: t.direction,
        vehicle: t.vehicle,
        transferDate: t.transferDate,
        transferTime: t.transferTime,
        pickup: t.pickup,
        dropoff: t.dropoff,
        adults: t.adults,
        children: t.children,
        vehicles: t.vehicles,
        unitPrice: t.unitPrice,
        totalNet: t.totalNet,
      }));
      const pdfTours: TripPdfTour[] = toursFor(pkg.id).map((t) => ({
        serviceName: t.serviceName,
        optionMode: t.optionMode,
        tourDate: t.tourDate,
        tourTime: t.tourTime,
        meetingPoint: t.meetingPoint,
        adults: t.adults,
        children: t.children,
        priceAdult: t.priceAdult,
        priceChild: t.priceChild,
        totalNet: t.totalNet,
      }));
      downloadTripPackagePdf({
        reference: pkg.reference,
        clientName: pkg.clientName,
        clientEmail: pkg.clientEmail,
        validUntil: pkg.validUntil,
        currency: pkg.currency,
        adults: pkg.adults,
        children: pkg.children,
        infants: pkg.infants,
        notes: pkg.notes,
        hotelLegs,
        transfers: pdfTransfers,
        tours: pdfTours,
        options: { includeTourismTax: pkg.includeTourismTax, markupPercent: pkg.markupPercent, markupAmount: pkg.markupAmount },
      });
    } finally {
      setPdfBusy(null);
    }
  };

  const transferServices = services.filter((s) => s.kind === "transfer" && s.active !== false);
  const tourServices = services.filter((s) => s.kind === "tour" && s.active !== false);

  const applyTransferService = (key: string, serviceId: number | null) => {
    setDraftTransfers((list) =>
      list.map((d) => {
        if (d.key !== key) return d;
        const service = services.find((s) => s.id === serviceId) ?? null;
        if (!service) return { ...d, serviceId: null };
        const vehicle = d.mode === "private" && !d.vehicle ? "7 Seater" : d.vehicle;
        return {
          ...d,
          serviceId: service.id,
          serviceName: service.name,
          vehicle,
          unitPrice: transferUnitFromCatalog(service, d.mode, d.direction, vehicle),
        };
      }),
    );
  };

  const applyTourService = (key: string, serviceId: number | null, option?: TourDraft["optionMode"]) => {
    setDraftTours((list) =>
      list.map((d) => {
        if (d.key !== key) return d;
        const service = services.find((s) => s.id === serviceId) ?? null;
        if (!service) return { ...d, serviceId: null };
        const mode = option ?? d.optionMode;
        const prices = tourPricesFromCatalog(service, mode);
        return { ...d, serviceId: service.id, serviceName: service.name, optionMode: mode, priceAdult: prices.adult, priceChild: prices.child };
      }),
    );
  };

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button onClick={() => openAdd()} className="flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-bold text-white transition hover:bg-[#103f3a]">
          <Plus size={15} /> New trip package
        </button>
      </div>

      {packages.length === 0 ? (
        <div className="grid place-items-center rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
          <div className="text-sm font-bold text-slate-700">No trip packages yet</div>
          <div className="mt-1 max-w-md text-xs text-slate-400">
            Combine a hotel quotation with airport transfers and tours into one client itinerary with a single proposal total and PDF.
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {packages.map((pkg) => {
            const legs = itemsForQuote(pkg.quotationId);
            const pkgTransfers = transfersFor(pkg.id);
            const pkgTours = toursFor(pkg.id);
            const open = expanded === pkg.id;
            const linkedQuote = quotations.find((q) => q.id === pkg.quotationId);
            return (
              <article key={pkg.id} className="overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-[0_2px_10px_rgba(15,23,42,0.03)]">
                <div className="flex flex-wrap items-center gap-4 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-extrabold text-[#175a53]">{pkg.reference}</span>
                      <TripStatusBadge status={pkg.status} />
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">
                        {legs.length} hotel stay{legs.length === 1 ? "" : "s"} · {pkgTransfers.length} transfer{pkgTransfers.length === 1 ? "" : "s"} · {pkgTours.length} tour{pkgTours.length === 1 ? "" : "s"}
                      </span>
                    </div>
                    <div className="mt-1 truncate text-xs font-semibold text-slate-700">
                      {pkg.clientName}
                      {pkg.clientEmail && <span className="font-normal text-slate-400"> · {pkg.clientEmail}</span>}
                    </div>
                    <div className="mt-0.5 truncate text-[11px] text-slate-400">
                      {linkedQuote ? `Hotels from ${linkedQuote.reference}` : "No hotel quotation linked"}
                      {pkg.validUntil ? ` · valid until ${fmtDate(pkg.validUntil)}` : ""}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-extrabold text-[#175a53]">{money(pkg.proposalTotal, pkg.currency)}</div>
                    <div data-internal className="mt-0.5 text-[10px] text-slate-400 print:hidden">Net {money(pkg.subtotalNet, pkg.currency)}</div>
                  </div>
                  <div data-internal className="flex flex-wrap gap-1.5 print:hidden">
                    <button onClick={() => setExpanded(open ? null : pkg.id)} className="flex h-9 items-center gap-1 rounded-lg border border-slate-200 px-3 text-[11px] font-bold text-slate-600 hover:bg-slate-50">
                      Details {open ? <ChevronDown size={13} className="rotate-180" /> : <ChevronDown size={13} />}
                    </button>
                    <button
                      disabled={pdfBusy === `trip-${pkg.id}`}
                      onClick={() => void downloadPdf(pkg)}
                      className="flex h-9 items-center gap-1.5 rounded-lg bg-[#174e48] px-3 text-[11px] font-extrabold text-white hover:bg-[#103f3a] disabled:opacity-60"
                    >
                      {pdfBusy === `trip-${pkg.id}` ? <Loader2 size={13} className="animate-spin" /> : <FileDown size={13} />} PDF
                    </button>
                    <button onClick={() => openEdit(pkg)} className="grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-slate-400 hover:bg-slate-50 hover:text-slate-700" aria-label="Edit trip package">
                      <Pencil size={14} />
                    </button>
                    <button disabled={saving} onClick={() => void remove(pkg)} className="grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-slate-400 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50" aria-label={`Delete ${pkg.reference}`}>
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {open && (
                  <div className="space-y-3 border-t border-slate-100 bg-slate-50/40 px-5 py-4">
                    {legs.length > 0 && (
                      <div>
                        <div className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Hotel stays (from {linkedQuote?.reference})</div>
                        <div className="space-y-2">
                          {legs.map((leg, i) => (
                            <div key={leg.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs">
                              <span className="font-bold text-slate-800">
                                {i + 1}. {hotelName(leg.hotelId)} · {roomName(leg.roomTypeId)}
                              </span>
                              <span className="text-slate-500">
                                {fmtDate(leg.checkIn)} → {fmtDate(leg.checkOut)} ({leg.nights}n) · {leg.adults}A · {leg.children}C · {leg.rooms} room{leg.rooms === 1 ? "" : "s"}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {pkgTransfers.length > 0 && (
                      <div>
                        <div className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Transfers & pick-up</div>
                        <div className="space-y-2">
                          {pkgTransfers.map((t, i) => (
                            <div key={t.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs">
                              <span className="font-bold text-slate-800">
                                {i + 1}. {t.serviceName} · {transferModeLabel(t.mode, t.direction, t.vehicle)}
                              </span>
                              <span className="text-slate-500">
                                {fmtDate(t.transferDate)}{t.transferTime ? ` ${t.transferTime}` : ""} · {t.mode === "private" ? `${t.vehicles} vehicle${t.vehicles === 1 ? "" : "s"}` : `${t.adults + t.children} pax`}<span data-internal className="print:hidden"> · {money(t.totalNet, pkg.currency)} net</span>
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {pkgTours.length > 0 && (
                      <div>
                        <div className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Tours & tickets itinerary</div>
                        <div className="space-y-2">
                          {[...pkgTours]
                            .sort((a, b) => `${a.tourDate}${a.tourTime}`.localeCompare(`${b.tourDate}${b.tourTime}`))
                            .map((t, i) => (
                              <div key={t.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs">
                                <span className="font-bold text-slate-800">
                                  {i + 1}. {t.serviceName} · {tourModeLabel(t.optionMode)}
                                </span>
                                <span className="text-slate-500">
                                  {fmtDate(t.tourDate)}{t.tourTime ? ` ${t.tourTime}` : ""} · {t.adults}A{t.children ? ` ${t.children}C` : ""}<span data-internal className="print:hidden"> · {money(t.totalNet, pkg.currency)} net</span>
                                </span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                    <div className="grid gap-3 rounded-xl border border-slate-200 bg-white p-4 text-xs md:grid-cols-2">
                      <div data-internal className="space-y-1.5 print:hidden">
                        <div className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-400">Package breakdown (internal)</div>
                        <div className="flex justify-between text-slate-500"><span>Hotels net</span><b className="text-slate-800">{money(pkg.hotelsNet, pkg.currency)}</b></div>
                        <div className="flex justify-between text-slate-500"><span>Transfers net</span><b className="text-slate-800">{money(pkg.transfersNet, pkg.currency)}</b></div>
                        <div className="flex justify-between text-slate-500"><span>Tours net</span><b className="text-slate-800">{money(pkg.toursNet, pkg.currency)}</b></div>
                        <div className="flex justify-between border-t border-slate-100 pt-1.5 text-sm font-extrabold text-[#175a53]"><span>Proposal total</span><span>{money(pkg.proposalTotal, pkg.currency)}</span></div>
                      </div>
                      <div className="text-[11px] leading-5 text-slate-500">
                        <p>Travellers: <b className="text-slate-700">{pkg.adults}A · {pkg.children}C · {pkg.infants}I</b></p>
                        <p className="mt-1">Tourism tax: <b className="text-slate-700">{pkg.includeTourismTax ? "included" : "excluded (payable at hotel)"}</b></p>
                        {pkg.notes && <p className="mt-1">Notes: {pkg.notes}</p>}
                      </div>
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}

      {dialog && (
        <div data-internal className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px] print:hidden" onMouseDown={(event) => event.target === event.currentTarget && setDialog(null)}>
          <div className="max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5">
              <div>
                <h2 className="text-xl font-bold text-slate-950">{dialog.mode === "edit" ? "Edit trip package" : "New trip package"}</h2>
                <p className="mt-1 text-sm text-slate-500">Link a hotel quotation, then add transfers and tours with dates and times.</p>
              </div>
              <button onClick={() => setDialog(null)} className="rounded-xl border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" aria-label="Close">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submit} className="space-y-5 p-6">
              <div className="grid gap-4 md:grid-cols-3">
                <label className="block">
                  <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Client name</span>
                  <input required value={clientName} onChange={(e) => setClientName(e.target.value)} className={inputClass} placeholder="Full name" />
                </label>
                <label className="block">
                  <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Client email</span>
                  <input type="email" value={clientEmail} onChange={(e) => setClientEmail(e.target.value)} className={inputClass} placeholder="client@email.com" />
                </label>
                <label className="block">
                  <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Client phone</span>
                  <input value={clientPhone} onChange={(e) => setClientPhone(e.target.value)} className={inputClass} placeholder="+971" />
                </label>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <label className="block">
                  <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Hotel quotation</span>
                  <select value={quotationId ?? ""} onChange={(e) => setQuotationId(e.target.value ? Number(e.target.value) : null)} className={`${inputClass} appearance-none`}>
                    <option value="">No hotels — transfers/tours only</option>
                    {quotations.map((q) => (
                      <option key={q.id} value={q.id}>
                        {q.reference} · {q.clientName} · {money(q.proposalTotal)}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(["adults", "children", "infants"] as const).map((field) => (
                    <label key={field} className="block">
                      <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500 capitalize">{field}</span>
                      <input
                        type="number"
                        min={field === "adults" ? 1 : 0}
                        value={pax[field]}
                        onChange={(e) => setPax((c) => ({ ...c, [field]: Math.max(field === "adults" ? 1 : 0, Number(e.target.value) || 0) }))}
                        className={inputClass}
                      />
                    </label>
                  ))}
                </div>
              </div>

              {quotationId && (
                <div className="rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
                  <b>Hotel stays in this package:</b>{" "}
                  {itemsForQuote(quotationId).map((leg) => `${leg.nights}n ${hotelName(leg.hotelId)}`).join(" + ") || "—"}
                </div>
              )}

              {/* Transfers */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-[0.08em] text-slate-600">
                    <CarFront size={14} /> Airport transfers & pick-up ({draftTransfers.length})
                  </span>
                  <button type="button" onClick={() => setDraftTransfers((l) => [...l, newTransferDraft(pax.adults, pax.children)])} className="flex items-center gap-1 rounded-lg bg-teal-50 px-2.5 py-1.5 text-[11px] font-bold text-teal-700 hover:bg-teal-100">
                    <Plus size={13} /> Add transfer
                  </button>
                </div>
                <div className="space-y-3">
                  {draftTransfers.map((d, idx) => {
                    const total = draftTransferTotal(d);
                    return (
                      <div key={d.key} className="rounded-xl border border-slate-200 p-4">
                        <div className="mb-3 flex items-center justify-between">
                          <span className="text-xs font-extrabold text-slate-800">Transfer {idx + 1}</span>
                          <button type="button" onClick={() => setDraftTransfers((l) => l.filter((x) => x.key !== d.key))} className="rounded p-1 text-slate-300 hover:bg-rose-50 hover:text-rose-600" aria-label="Remove transfer">
                            <Trash2 size={14} />
                          </button>
                        </div>
                        <div className="grid gap-3 md:grid-cols-3">
                          <label className="block md:col-span-2">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Service (from catalog — fills prices)</span>
                            <select
                              value={d.serviceId ?? ""}
                              onChange={(e) => applyTransferService(d.key, e.target.value ? Number(e.target.value) : null)}
                              className={`${inputClass} appearance-none`}
                            >
                              <option value="">Custom (type name below)</option>
                              {transferServices.map((s) => (
                                <option key={s.id} value={s.id}>{s.name}</option>
                              ))}
                            </select>
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Service name</span>
                            <input value={d.serviceName} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, serviceName: e.target.value } : x)))} className={inputClass} placeholder="Airport transfer" />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Shared / private</span>
                            <select
                              value={d.mode}
                              onChange={(e) => {
                                const mode = e.target.value as "shared" | "private";
                                setDraftTransfers((l) =>
                                  l.map((x) => {
                                    if (x.key !== d.key) return x;
                                    const service = services.find((s) => s.id === x.serviceId);
                                    const vehicle = mode === "private" && !x.vehicle ? "7 Seater" : x.vehicle;
                                    return { ...x, mode, vehicle, unitPrice: service ? transferUnitFromCatalog(service, mode, x.direction, vehicle) : x.unitPrice };
                                  }),
                                );
                              }}
                              className={`${inputClass} appearance-none`}
                            >
                              <option value="shared">Shared (per person)</option>
                              <option value="private">Private (per vehicle)</option>
                            </select>
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">One-way / two-way</span>
                            <select
                              value={d.direction}
                              onChange={(e) => {
                                const direction = e.target.value as "oneway" | "twoway";
                                setDraftTransfers((l) =>
                                  l.map((x) => {
                                    if (x.key !== d.key) return x;
                                    const service = services.find((s) => s.id === x.serviceId);
                                    return { ...x, direction, unitPrice: service ? transferUnitFromCatalog(service, x.mode, direction, x.vehicle) : x.unitPrice };
                                  }),
                                );
                              }}
                              className={`${inputClass} appearance-none`}
                            >
                              <option value="oneway">One-way</option>
                              <option value="twoway">Two-way (return)</option>
                            </select>
                          </label>
                          {d.mode === "private" ? (
                            <label className="block">
                              <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Vehicle</span>
                              <select
                                value={d.vehicle}
                                onChange={(e) => {
                                  const vehicle = e.target.value;
                                  setDraftTransfers((l) =>
                                    l.map((x) => {
                                      if (x.key !== d.key) return x;
                                      const service = services.find((s) => s.id === x.serviceId);
                                      return { ...x, vehicle, unitPrice: service ? transferUnitFromCatalog(service, x.mode, x.direction, vehicle) : x.unitPrice };
                                    }),
                                  );
                                }}
                                className={`${inputClass} appearance-none`}
                              >
                                <option value="7 Seater">7 Seater</option>
                                <option value="12 Seater">12 Seater</option>
                              </select>
                            </label>
                          ) : (
                            <div className="grid grid-cols-2 gap-2">
                              <label className="block">
                                <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Adults</span>
                                <input type="number" min="0" value={d.adults} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, adults: Math.max(0, Number(e.target.value) || 0) } : x)))} className={inputClass} />
                              </label>
                              <label className="block">
                                <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Children</span>
                                <input type="number" min="0" value={d.children} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, children: Math.max(0, Number(e.target.value) || 0) } : x)))} className={inputClass} />
                              </label>
                            </div>
                          )}
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Date</span>
                            <input type="date" required value={d.transferDate} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, transferDate: e.target.value } : x)))} className={inputClass} />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Pick-up time</span>
                            <input type="time" value={d.transferTime} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, transferTime: e.target.value } : x)))} className={inputClass} />
                          </label>
                          {d.mode === "private" && (
                            <label className="block">
                              <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Vehicles</span>
                              <input type="number" min="1" value={d.vehicles} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, vehicles: Math.max(1, Number(e.target.value) || 1) } : x)))} className={inputClass} />
                            </label>
                          )}
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Pick-up</span>
                            <input value={d.pickup} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, pickup: e.target.value } : x)))} className={inputClass} placeholder="DXB Terminal 3" />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Drop-off</span>
                            <input value={d.dropoff} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, dropoff: e.target.value } : x)))} className={inputClass} placeholder="Hotel name" />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Unit net (AED {d.mode === "private" ? "/ vehicle" : "/ person"})</span>
                            <input type="number" min="0" step="1" value={d.unitPrice} onChange={(e) => setDraftTransfers((l) => l.map((x) => (x.key === d.key ? { ...x, unitPrice: e.target.value } : x)))} className={inputClass} />
                          </label>
                        </div>
                        <div className="mt-2 flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-xs">
                          <span className="text-slate-500">{transferModeLabel(d.mode, d.direction, d.vehicle)}</span>
                          <b className="text-slate-900">Net total: {money(total, "AED")}</b>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Tours */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-[0.08em] text-slate-600">
                    <Ticket size={14} /> Tours & tickets ({draftTours.length})
                  </span>
                  <button type="button" onClick={() => setDraftTours((l) => [...l, newTourDraft(pax.adults, pax.children)])} className="flex items-center gap-1 rounded-lg bg-teal-50 px-2.5 py-1.5 text-[11px] font-bold text-teal-700 hover:bg-teal-100">
                    <Plus size={13} /> Add tour
                  </button>
                </div>
                <div className="space-y-3">
                  {draftTours.map((d, idx) => {
                    const total = draftTourTotal(d);
                    return (
                      <div key={d.key} className="rounded-xl border border-slate-200 p-4">
                        <div className="mb-3 flex items-center justify-between">
                          <span className="text-xs font-extrabold text-slate-800">Tour {idx + 1}</span>
                          <button type="button" onClick={() => setDraftTours((l) => l.filter((x) => x.key !== d.key))} className="rounded p-1 text-slate-300 hover:bg-rose-50 hover:text-rose-600" aria-label="Remove tour">
                            <Trash2 size={14} />
                          </button>
                        </div>
                        <div className="grid gap-3 md:grid-cols-3">
                          <label className="block md:col-span-2">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Tour (from catalog — fills prices)</span>
                            <select value={d.serviceId ?? ""} onChange={(e) => applyTourService(d.key, e.target.value ? Number(e.target.value) : null)} className={`${inputClass} appearance-none`}>
                              <option value="">Custom (type name below)</option>
                              {tourServices.map((s) => (
                                <option key={s.id} value={s.id}>{s.name}</option>
                              ))}
                            </select>
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Tour name</span>
                            <input value={d.serviceName} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, serviceName: e.target.value } : x)))} className={inputClass} placeholder="Desert Safari" />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Option</span>
                            <select value={d.optionMode} onChange={(e) => applyTourService(d.key, d.serviceId, e.target.value as TourDraft["optionMode"])} className={`${inputClass} appearance-none`}>
                              <option value="ticket_only">Ticket only</option>
                              <option value="shared">Shared transfer</option>
                              <option value="private">Private transfer</option>
                            </select>
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Date</span>
                            <input type="date" required value={d.tourDate} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, tourDate: e.target.value } : x)))} className={inputClass} />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Time</span>
                            <input type="time" value={d.tourTime} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, tourTime: e.target.value } : x)))} className={inputClass} />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Adults</span>
                            <input type="number" min="0" value={d.adults} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, adults: Math.max(0, Number(e.target.value) || 0) } : x)))} className={inputClass} />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Children</span>
                            <input type="number" min="0" value={d.children} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, children: Math.max(0, Number(e.target.value) || 0) } : x)))} className={inputClass} />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Meeting / pick-up point</span>
                            <input value={d.meetingPoint} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, meetingPoint: e.target.value } : x)))} className={inputClass} placeholder="Hotel lobby" />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Adult net (AED / person)</span>
                            <input type="number" min="0" step="1" value={d.priceAdult} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, priceAdult: e.target.value } : x)))} className={inputClass} />
                          </label>
                          <label className="block">
                            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Child net (AED / person)</span>
                            <input type="number" min="0" step="1" value={d.priceChild} onChange={(e) => setDraftTours((l) => l.map((x) => (x.key === d.key ? { ...x, priceChild: e.target.value } : x)))} className={inputClass} />
                          </label>
                          <div className="flex items-end rounded-lg bg-slate-50 px-3 py-2 text-xs">
                            <span className="text-slate-500">{d.adults}A × {money(d.priceAdult || 0)}{d.children ? ` + ${d.children}C × ${money(d.priceChild || 0)}` : ""}</span>
                            <b className="ml-auto text-slate-900">{money(total)}</b>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Pricing */}
              <div className="grid gap-4 rounded-2xl bg-slate-50 p-4 md:grid-cols-2">
                <label className="flex cursor-pointer items-center justify-between gap-3 rounded-xl bg-white px-4 py-3 ring-1 ring-slate-200">
                  <span className="text-xs font-bold text-slate-700">Include tourism tax in proposal</span>
                  <input type="checkbox" checked={includeTax} onChange={(e) => setIncludeTax(e.target.checked)} className="h-4 w-4 accent-teal-700" />
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <label className="block">
                    <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Markup %</span>
                    <input type="number" min="0" max="500" step="0.5" value={markupPct} onChange={(e) => setMarkupPct(e.target.value)} placeholder="0" className={inputClass} />
                  </label>
                  <label className="block">
                    <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Markup AED</span>
                    <input type="number" min="0" step="1" value={markupAmt} onChange={(e) => setMarkupAmt(e.target.value)} placeholder="0" className={inputClass} />
                  </label>
                </div>
                <label className="block">
                  <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Valid until</span>
                  <input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} className={inputClass} />
                </label>
                <label className="block">
                  <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">Notes (shown on PDF)</span>
                  <input value={notes} onChange={(e) => setNotes(e.target.value)} className={inputClass} placeholder="Meeting details, inclusions…" />
                </label>
                <div className="rounded-xl bg-[#174e48] p-4 text-white md:col-span-2">
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-teal-100 sm:grid-cols-4">
                    <span>Hotels net <b className="block text-sm text-white">{money(preview.hotelsNet)}</b></span>
                    <span>Transfers net <b className="block text-sm text-white">{money(preview.transfersNet)}</b></span>
                    <span>Tours net <b className="block text-sm text-white">{money(preview.toursNet)}</b></span>
                    <span>Margin <b className="block text-sm text-white">+{money(preview.margin)}</b></span>
                  </div>
                  <div className="mt-2 border-t border-white/15 pt-2 text-xl font-extrabold">Proposal total: {money(preview.proposalTotal)}</div>
                </div>
              </div>

              {error && <div className="text-sm font-semibold text-rose-600">{error}</div>}
              <div className="flex justify-end gap-2 border-t border-slate-100 pt-5">
                <button type="button" onClick={() => setDialog(null)} className="h-11 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-600">
                  Cancel
                </button>
                <button disabled={saving} className="flex h-11 min-w-40 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white disabled:opacity-60">
                  {saving && <Loader2 size={16} className="animate-spin" />} {dialog.mode === "edit" ? "Save changes" : "Create trip package"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Re-exported so dashboard can open the builder pre-linked to a quotation.
export function tripPanelHelpers() {
  return { newTransferDraft, newTourDraft };
}
