import DashboardClient, { type DashboardData, type View } from "./dashboard-client";
import { requireUser } from "@/lib/auth";
import { getHotelDashboardData } from "@/lib/hotel-data";
import { searchAllHotels } from "@/lib/search-data";
import { addDays, type CoreCriteria, DEFAULT_CRITERIA } from "@/lib/search-engine";

export const dynamic = "force-dynamic";

const knownViews: View[] = ["search", "dashboard", "bookings", "quotations", "trips", "services", "hotels", "rooms", "rates", "blackouts", "users"];

export default async function HomePage({ searchParams }: { searchParams: Promise<{ view?: string }> }) {
  // Checking here as well as in Proxy keeps the data safe even when a page is invoked directly.
  const user = await requireUser();
  const { view } = await searchParams;
  const initialView: View = knownViews.includes(view as View) && (view !== "users" || user.role === "admin") ? (view as View) : "search";
  const data = await getHotelDashboardData();
  const today = new Date().toISOString().slice(0, 10);
  const criteria: CoreCriteria = {
    ...DEFAULT_CRITERIA,
    checkIn: addDays(today, 14),
    checkOut: addDays(today, 17),
    bookingDate: today,
  };
  const { outsidePriceRange: _ignored, ...response } = await searchAllHotels(criteria);
  void _ignored;

  return (
    <DashboardClient
      data={JSON.parse(JSON.stringify(data)) as DashboardData}
      initialSearch={{ criteria, response }}
      today={today}
      user={user}
      initialView={initialView}
    />
  );
}
