"use client";

import { CarFront, Loader2, Pencil, Plus, Ticket, Trash2, X } from "lucide-react";
import { FormEvent, useState } from "react";

export type ServiceRow = {
  id: number;
  kind: string;
  name: string;
  description: string;
  city: string;
  duration: string;
  sharedOneWayPrice: string;
  sharedTwoWayPrice: string;
  private7OneWayPrice: string;
  private7TwoWayPrice: string;
  private12OneWayPrice: string;
  private12TwoWayPrice: string;
  ticketOnlyAdult: string;
  ticketOnlyChild: string;
  sharedAdult: string;
  sharedChild: string;
  privateAdult: string;
  privateChild: string;
  active: boolean;
  sortOrder: number;
};

const inputClass =
  "h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10";

const money = (value: number | string) =>
  `AED ${Number(value || 0).toLocaleString("en-AE", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

const emptyForm = (kind: string) => ({
  kind,
  name: "",
  description: "",
  city: "Dubai",
  duration: "",
  sharedOneWayPrice: "",
  sharedTwoWayPrice: "",
  private7OneWayPrice: "",
  private7TwoWayPrice: "",
  private12OneWayPrice: "",
  private12TwoWayPrice: "",
  ticketOnlyAdult: "",
  ticketOnlyChild: "",
  sharedAdult: "",
  sharedChild: "",
  privateAdult: "",
  privateChild: "",
});

function PriceInput({ label, hint, value, onChange }: { label: string; hint?: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-400">{label}</span>
      <input type="number" min="0" step="1" value={value} onChange={(event) => onChange(event.target.value)} placeholder="0" className={inputClass} />
      {hint && <span className="mt-0.5 block text-[10px] text-slate-400">{hint}</span>}
    </label>
  );
}

export default function ServicesPanel({
  services,
  onChanged,
}: {
  services: ServiceRow[];
  onChanged: (message: string) => void;
}) {
  const [kind, setKind] = useState<"transfer" | "tour">("transfer");
  const [dialog, setDialog] = useState<null | { mode: "add" } | { mode: "edit"; service: ServiceRow }>(null);
  const [form, setForm] = useState(emptyForm("transfer"));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const openAdd = (k: "transfer" | "tour") => {
    setKind(k);
    setForm(emptyForm(k));
    setError("");
    setDialog({ mode: "add" });
  };
  const openEdit = (service: ServiceRow) => {
    setKind(service.kind === "tour" ? "tour" : "transfer");
    setForm({
      kind: service.kind,
      name: service.name,
      description: service.description,
      city: service.city,
      duration: service.duration,
      sharedOneWayPrice: String(Number(service.sharedOneWayPrice) || ""),
      sharedTwoWayPrice: String(Number(service.sharedTwoWayPrice) || ""),
      private7OneWayPrice: String(Number(service.private7OneWayPrice) || ""),
      private7TwoWayPrice: String(Number(service.private7TwoWayPrice) || ""),
      private12OneWayPrice: String(Number(service.private12OneWayPrice) || ""),
      private12TwoWayPrice: String(Number(service.private12TwoWayPrice) || ""),
      ticketOnlyAdult: String(Number(service.ticketOnlyAdult) || ""),
      ticketOnlyChild: String(Number(service.ticketOnlyChild) || ""),
      sharedAdult: String(Number(service.sharedAdult) || ""),
      sharedChild: String(Number(service.sharedChild) || ""),
      privateAdult: String(Number(service.privateAdult) || ""),
      privateChild: String(Number(service.privateChild) || ""),
    });
    setError("");
    setDialog({ mode: "edit", service });
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!dialog) return;
    setSaving(true);
    setError("");
    try {
      const payload: Record<string, unknown> = { ...form };
      if (dialog.mode === "edit") payload.id = dialog.service.id;
      const response = await fetch("/api/services", {
        method: dialog.mode === "edit" ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to save service.");
      setDialog(null);
      onChanged(dialog.mode === "edit" ? `“${result.service.name}” updated.` : `“${result.service.name}” added to your ${form.kind === "tour" ? "tours" : "transfers"}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save service.");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (service: ServiceRow) => {
    if (!confirm(`Delete “${service.name}”? Trip packages keep their saved snapshots.`)) return;
    setSaving(true);
    try {
      const response = await fetch(`/api/services?id=${service.id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to delete service.");
      onChanged(`“${service.name}” deleted.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to delete service.");
    } finally {
      setSaving(false);
    }
  };

  const list = services.filter((service) => service.kind === kind);
  const isTransfer = kind === "transfer";

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="grid grid-cols-2 rounded-xl bg-white p-1 text-xs font-bold ring-1 ring-slate-200">
          <button
            onClick={() => setKind("transfer")}
            className={`flex items-center gap-1.5 rounded-lg px-4 py-2 transition ${isTransfer ? "bg-[#174e48] text-white" : "text-slate-500"}`}
          >
            <CarFront size={14} /> Transfers & pick-up
          </button>
          <button
            onClick={() => setKind("tour")}
            className={`flex items-center gap-1.5 rounded-lg px-4 py-2 transition ${!isTransfer ? "bg-[#174e48] text-white" : "text-slate-500"}`}
          >
            <Ticket size={14} /> Tours & tickets
          </button>
        </div>
        <button
          onClick={() => openAdd(kind)}
          className="flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-bold text-white transition hover:bg-[#103f3a]"
        >
          <Plus size={15} /> Add {isTransfer ? "transfer" : "tour"}
        </button>
      </div>

      {error && !dialog && (
        <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-700">{error}</div>
      )}

      {list.length === 0 ? (
        <div className="grid place-items-center rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
          <div className="text-sm font-bold text-slate-700">No {isTransfer ? "transfers" : "tours"} yet</div>
          <div className="mt-1 max-w-sm text-xs text-slate-400">
            {isTransfer
              ? "Add airport pick-ups with shared per-person and private per-vehicle prices."
              : "Add tours with ticket-only, shared and private per-person prices."}
          </div>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {list.map((service) => (
            <article key={service.id} className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_2px_10px_rgba(15,23,42,0.03)]">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">{service.name}</h3>
                  <p className="mt-0.5 text-[11px] text-slate-400">
                    {service.city}
                    {service.duration ? ` · ${service.duration}` : ""}
                  </p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(service)} className="rounded-lg border border-slate-200 p-2 text-slate-400 hover:bg-slate-50 hover:text-slate-700" aria-label="Edit service">
                    <Pencil size={14} />
                  </button>
                  <button onClick={() => void remove(service)} className="rounded-lg border border-slate-200 p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="Delete service">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              {service.description && <p className="mt-2 text-xs leading-5 text-slate-500">{service.description}</p>}
              {isTransfer ? (
                <div className="mt-3 space-y-1.5 text-xs">
                  <div className="flex justify-between rounded-lg bg-slate-50 px-3 py-2">
                    <span className="font-semibold text-slate-600">Shared · per person · one-way</span>
                    <b>{money(service.sharedOneWayPrice)}</b>
                  </div>
                  <div className="flex justify-between rounded-lg bg-slate-50 px-3 py-2">
                    <span className="font-semibold text-slate-600">Shared · per person · two-way</span>
                    <b>{money(service.sharedTwoWayPrice)}</b>
                  </div>
                  <div className="flex justify-between rounded-lg bg-teal-50 px-3 py-2">
                    <span className="font-semibold text-teal-800">Private 7-seater · per vehicle</span>
                    <b className="text-teal-900">{money(service.private7OneWayPrice)} / {money(service.private7TwoWayPrice)} RT</b>
                  </div>
                  <div className="flex justify-between rounded-lg bg-teal-50 px-3 py-2">
                    <span className="font-semibold text-teal-800">Private 12-seater · per vehicle</span>
                    <b className="text-teal-900">{money(service.private12OneWayPrice)} / {money(service.private12TwoWayPrice)} RT</b>
                  </div>
                </div>
              ) : (
                <div className="mt-3 space-y-1.5 text-xs">
                  <div className="flex justify-between rounded-lg bg-slate-50 px-3 py-2">
                    <span className="font-semibold text-slate-600">Ticket only · adult / child</span>
                    <b>{money(service.ticketOnlyAdult)} / {money(service.ticketOnlyChild)}</b>
                  </div>
                  <div className="flex justify-between rounded-lg bg-teal-50 px-3 py-2">
                    <span className="font-semibold text-teal-800">Shared transfer · adult / child</span>
                    <b className="text-teal-900">{money(service.sharedAdult)} / {money(service.sharedChild)}</b>
                  </div>
                  <div className="flex justify-between rounded-lg bg-violet-50 px-3 py-2">
                    <span className="font-semibold text-violet-800">Private transfer · adult / child</span>
                    <b className="text-violet-900">{money(service.privateAdult)} / {money(service.privateChild)}</b>
                  </div>
                </div>
              )}
            </article>
          ))}
        </div>
      )}

      {dialog && (
        <div data-internal className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px] print:hidden" onMouseDown={(event) => event.target === event.currentTarget && setDialog(null)}>
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5">
              <div>
                <h2 className="text-xl font-bold text-slate-950">{dialog.mode === "edit" ? "Edit service" : isTransfer ? "Add transfer service" : "Add tour / tickets"}</h2>
                <p className="mt-1 text-sm text-slate-500">Net supplier costs in AED — your package markup is added later.</p>
              </div>
              <button onClick={() => setDialog(null)} className="rounded-xl border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" aria-label="Close">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submit} className="grid gap-4 p-6 md:grid-cols-2">
              <label className="block md:col-span-2">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Name</span>
                <input required value={form.name} onChange={(event) => setForm((c) => ({ ...c, name: event.target.value }))} placeholder={isTransfer ? "Airport Pick-up & Drop-back (DXB)" : "Desert Safari with BBQ Dinner"} className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10" />
              </label>
              <label className="block">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">City</span>
                <input value={form.city} onChange={(event) => setForm((c) => ({ ...c, city: event.target.value }))} className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10" />
              </label>
              <label className="block">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Duration</span>
                <input value={form.duration} onChange={(event) => setForm((c) => ({ ...c, duration: event.target.value }))} placeholder="≈45 min each way" className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10" />
              </label>
              <label className="block md:col-span-2">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Description</span>
                <textarea value={form.description} onChange={(event) => setForm((c) => ({ ...c, description: event.target.value }))} placeholder="What's included…" className="min-h-16 w-full rounded-xl border border-slate-200 p-3.5 text-sm outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10" />
              </label>

              {isTransfer ? (
                <>
                  <div className="rounded-xl bg-slate-50 p-3 md:col-span-2">
                    <div className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-slate-500">Shared · per person (AED)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <PriceInput label="One-way" value={form.sharedOneWayPrice} onChange={(v) => setForm((c) => ({ ...c, sharedOneWayPrice: v }))} />
                      <PriceInput label="Two-way" value={form.sharedTwoWayPrice} onChange={(v) => setForm((c) => ({ ...c, sharedTwoWayPrice: v }))} />
                    </div>
                  </div>
                  <div className="rounded-xl bg-teal-50/60 p-3 md:col-span-2">
                    <div className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-teal-800">Private 7-seater · per vehicle (AED)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <PriceInput label="One-way" value={form.private7OneWayPrice} onChange={(v) => setForm((c) => ({ ...c, private7OneWayPrice: v }))} />
                      <PriceInput label="Two-way" value={form.private7TwoWayPrice} onChange={(v) => setForm((c) => ({ ...c, private7TwoWayPrice: v }))} />
                    </div>
                  </div>
                  <div className="rounded-xl bg-teal-50/60 p-3 md:col-span-2">
                    <div className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-teal-800">Private 12-seater · per vehicle (AED)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <PriceInput label="One-way" value={form.private12OneWayPrice} onChange={(v) => setForm((c) => ({ ...c, private12OneWayPrice: v }))} />
                      <PriceInput label="Two-way" value={form.private12TwoWayPrice} onChange={(v) => setForm((c) => ({ ...c, private12TwoWayPrice: v }))} />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="rounded-xl bg-slate-50 p-3 md:col-span-2">
                    <div className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-slate-500">Ticket only · per person (AED)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <PriceInput label="Adult" value={form.ticketOnlyAdult} onChange={(v) => setForm((c) => ({ ...c, ticketOnlyAdult: v }))} />
                      <PriceInput label="Child" value={form.ticketOnlyChild} onChange={(v) => setForm((c) => ({ ...c, ticketOnlyChild: v }))} />
                    </div>
                  </div>
                  <div className="rounded-xl bg-teal-50/60 p-3 md:col-span-2">
                    <div className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-teal-800">Shared transfer · per person (AED)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <PriceInput label="Adult" value={form.sharedAdult} onChange={(v) => setForm((c) => ({ ...c, sharedAdult: v }))} />
                      <PriceInput label="Child" value={form.sharedChild} onChange={(v) => setForm((c) => ({ ...c, sharedChild: v }))} />
                    </div>
                  </div>
                  <div className="rounded-xl bg-violet-50/70 p-3 md:col-span-2">
                    <div className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-violet-800">Private transfer · per person (AED)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <PriceInput label="Adult" value={form.privateAdult} onChange={(v) => setForm((c) => ({ ...c, privateAdult: v }))} />
                      <PriceInput label="Child" value={form.privateChild} onChange={(v) => setForm((c) => ({ ...c, privateChild: v }))} />
                    </div>
                  </div>
                </>
              )}

              {error && <div className="text-sm font-semibold text-rose-600 md:col-span-2">{error}</div>}
              <div className="flex justify-end gap-2 border-t border-slate-100 pt-5 md:col-span-2">
                <button type="button" onClick={() => setDialog(null)} className="h-11 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-600">
                  Cancel
                </button>
                <button disabled={saving} className="flex h-11 min-w-36 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white disabled:opacity-60">
                  {saving && <Loader2 size={16} className="animate-spin" />} {dialog.mode === "edit" ? "Save changes" : "Add service"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
