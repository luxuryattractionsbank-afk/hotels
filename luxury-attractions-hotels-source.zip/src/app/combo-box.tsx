"use client";

import { ChevronDown } from "lucide-react";
import { useEffect, useRef, useState } from "react";

export type ComboOption = { value: number; label: string; meta?: string };

/**
 * Excel-style combo box: type to filter, arrow keys to move, Enter to pick.
 * The field shows the selected label and opens its list as soon as it gets focus.
 */
export default function ComboBox({
  options,
  value,
  onChange,
  placeholder = "Type to search…",
  ariaLabel,
  emptyMessage = "No match found.",
}: {
  options: ComboOption[];
  value: number;
  onChange: (value: number) => void;
  placeholder?: string;
  ariaLabel: string;
  emptyMessage?: string;
}) {
  const selected = options.find((option) => option.value === value);
  const [text, setText] = useState(selected?.label ?? "");
  const [open, setOpen] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Keep the field in step when the selection changes outside the box (e.g. a form reset).
  useEffect(() => {
    if (!open) {
      setText(selected?.label ?? "");
      setDirty(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, open]);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    return () => document.removeEventListener("mousedown", onPointerDown);
  }, [open]);

  // Until the user types, show every option — like opening an Excel dropdown.
  const query = (dirty ? text : "").trim().toLowerCase();
  const visible = options.filter(
    (option) => !query || `${option.label} ${option.meta ?? ""}`.toLowerCase().includes(query),
  );
  const activeIndex = Math.min(highlight, Math.max(visible.length - 1, 0));

  const select = (option: ComboOption) => {
    onChange(option.value);
    setText(option.label);
    setDirty(false);
    setOpen(false);
  };

  return (
    <div ref={rootRef} className="relative">
      <input
        ref={inputRef}
        value={text}
        role="combobox"
        aria-expanded={open}
        aria-controls={`${ariaLabel.replace(/\s+/g, "-").toLowerCase()}-list`}
        aria-label={ariaLabel}
        autoComplete="off"
        spellCheck={false}
        placeholder={placeholder}
        onFocus={(event) => {
          setOpen(true);
          setDirty(false);
          setHighlight(Math.max(0, options.findIndex((option) => option.value === value)));
          requestAnimationFrame(() => event.target.select());
        }}
        onChange={(event) => {
          setText(event.target.value);
          setDirty(true);
          setOpen(true);
          setHighlight(0);
        }}
        onKeyDown={(event) => {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            setOpen(true);
            setHighlight((index) => Math.min(index + 1, visible.length - 1));
          } else if (event.key === "ArrowUp") {
            event.preventDefault();
            setHighlight((index) => Math.max(index - 1, 0));
          } else if (event.key === "Enter") {
            if (open && visible[activeIndex]) {
              event.preventDefault();
              select(visible[activeIndex]);
            }
          } else if (event.key === "Escape") {
            setOpen(false);
            setDirty(false);
            setText(selected?.label ?? "");
          }
        }}
        className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 pr-10 text-sm font-semibold text-slate-800 outline-none transition focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10"
      />
      <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
        <ChevronDown size={15} className={`transition-transform ${open ? "rotate-180" : ""}`} />
      </span>

      {open && (
        <div
          id={`${ariaLabel.replace(/\s+/g, "-").toLowerCase()}-list`}
          role="listbox"
          aria-label={ariaLabel}
          className="absolute left-0 right-0 top-full z-40 mt-1.5 max-h-56 overflow-y-auto rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl"
        >
          {visible.map((option, index) => (
            <button
              key={option.value}
              type="button"
              role="option"
              aria-selected={option.value === value}
              // preventDefault keeps focus in the field so the list stays open until a choice is made.
              onMouseDown={(event) => event.preventDefault()}
              onMouseEnter={() => setHighlight(index)}
              onClick={() => select(option)}
              className={`flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2.5 text-left text-xs font-semibold transition ${
                option.value === value
                  ? "bg-teal-700 text-white"
                  : index === activeIndex
                    ? "bg-teal-50 text-teal-900"
                    : "text-slate-700"
              }`}
            >
              <span className="truncate">{option.label}</span>
              {option.meta && (
                <span className={`shrink-0 text-[10px] ${option.value === value ? "text-teal-100" : "text-slate-400"}`}>
                  {option.meta}
                </span>
              )}
            </button>
          ))}
          {visible.length === 0 && <p className="px-3 py-3 text-[11px] text-slate-400">{emptyMessage}</p>}
          {query && visible.length > 0 && (
            <p className="px-3 pb-1 pt-2 text-[10px] text-slate-400">
              {visible.length} match{visible.length === 1 ? "" : "es"} · ↑ ↓ to move · Enter to select
            </p>
          )}
        </div>
      )}
    </div>
  );
}
