"use client";

import { Check, ChevronDown, KeyRound, Loader2, Plus, ShieldCheck, UserRound, Users, X } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";

type Permission = { value: string; label: string; description: string };
type ManagedUser = { id: number; name: string; username: string | null; email: string; role: string; permissions: string[]; active: boolean; createdAt: string };
const roles = [
  { value: "admin", label: "Administrator", permissions: "All permissions, including user management" },
  { value: "manager", label: "Contract manager", permissions: "Everything except user management" },
  { value: "sales", label: "Sales agent", permissions: "Bookings, quotations, packages and proposal emails" },
  { value: "viewer", label: "Read only", permissions: "Search and view, no changes" },
] as const;
const defaults: Record<string, string[]> = {
  admin: ["manage_hotels", "manage_rates", "manage_bookings", "manage_quotations", "manage_services", "manage_packages", "send_email", "manage_users"],
  manager: ["manage_hotels", "manage_rates", "manage_bookings", "manage_quotations", "manage_services", "manage_packages", "send_email"],
  sales: ["manage_bookings", "manage_quotations", "manage_packages", "send_email"],
  viewer: [],
};
const input = "h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-800 outline-none focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10";

type Form = { name: string; username: string; email: string; password: string; role: string; permissions: string[]; active: boolean };
const blankForm = (): Form => ({ name: "", username: "", email: "", password: "", role: "sales", permissions: defaults.sales, active: true });

export default function UsersPanel({ currentId }: { currentId: number }) {
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [options, setOptions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [editing, setEditing] = useState<ManagedUser | "new" | null>(null);
  const [form, setForm] = useState<Form>(blankForm);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [resetNotice, setResetNotice] = useState("");

  const refresh = async () => {
    const response = await fetch("/api/users", { cache: "no-store" });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Unable to load users.");
    setUsers(result.users ?? []);
    setOptions(result.permissionOptions ?? []);
  };
  useEffect(() => {
    void refresh().catch((cause) => setError(cause instanceof Error ? cause.message : "Unable to load users.")).finally(() => setLoading(false));
  }, []);

  const startAdd = () => { setError(""); setNotice(""); setResetNotice(""); setForm(blankForm()); setEditing("new"); };
  const startEdit = (user: ManagedUser) => {
    setError(""); setNotice(""); setResetNotice("");
    setForm({ name: user.name, username: user.username ?? "", email: user.email, password: "", role: user.role, permissions: user.permissions, active: user.active });
    setEditing(user);
  };
  const emailReset = async (user: ManagedUser) => {
    setResetting(true);
    setError("");
    setResetNotice("");
    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: user.username || user.email }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to request a password reset.");
      setResetNotice(`A single-use password reset email was requested for ${user.email}. The link expires in 30 minutes.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to request a password reset.");
    } finally {
      setResetting(false);
    }
  };
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editing) return;
    setSaving(true);
    setError("");
    try {
      const response = await fetch("/api/users", {
        method: editing === "new" ? "POST" : "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing === "new" ? form : { ...form, id: editing.id, password: form.password || undefined }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to save user.");
      setEditing(null);
      setNotice(editing === "new" ? `${result.user.name} can now sign in.` : `${result.user.name}'s access was updated. Changed permissions take effect immediately.`);
      await refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to save user.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs text-slate-500">{users.length} account{users.length === 1 ? "" : "s"} · deactivate or change permissions without deleting records</p>
        <button onClick={startAdd} className="flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-bold text-white hover:bg-[#103f3a]"><Plus size={15} /> Add user</button>
      </div>
      {notice && <div role="status" className="mb-4 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-800"><Check size={15} /> {notice}</div>}
      {error && !editing && <div role="alert" className="mb-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-700">{error}</div>}
      {loading ? <div className="flex items-center gap-2 rounded-xl bg-white p-6 text-sm text-slate-500"><Loader2 size={18} className="animate-spin" /> Loading users…</div> : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {users.map((user) => (
            <article key={user.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_2px_10px_rgba(15,23,42,.025)]">
              <div className="flex items-start gap-3">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-teal-50 text-teal-700">{user.role === "admin" ? <ShieldCheck size={18} /> : <UserRound size={18} />}</div>
                <div className="min-w-0 flex-1"><div className="truncate text-sm font-extrabold text-slate-900">{user.name} {user.id === currentId && <span className="font-medium text-slate-400">(you)</span>}</div><div className="mt-0.5 truncate text-xs font-semibold text-teal-700">@{user.username ?? "username pending"}</div><div className="mt-0.5 truncate text-xs text-slate-500">{user.email}</div></div>
                <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${user.active ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>{user.active ? "Active" : "Disabled"}</span>
              </div>
              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3"><div><div className="text-[11px] font-bold text-slate-700">{roles.find((r) => r.value === user.role)?.label ?? user.role}</div><div className="mt-0.5 text-[10px] text-slate-400">{user.role === "admin" ? "All permissions" : `${user.permissions.length} permission${user.permissions.length === 1 ? "" : "s"}`}</div></div><button onClick={() => startEdit(user)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-[11px] font-bold text-slate-600 hover:border-teal-300 hover:text-teal-700">Manage</button></div>
            </article>
          ))}
        </div>
      )}

      {editing && (
        <div data-internal className="fixed inset-0 z-[85] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px]" onMouseDown={(event) => event.target === event.currentTarget && setEditing(null)}>
          <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5"><div><h2 className="text-xl font-extrabold text-slate-950">{editing === "new" ? "Add team member" : `Manage ${editing.name}`}</h2><p className="mt-1 text-xs text-slate-500">Set a role and fine-tune the exact actions this user can perform.</p></div><button onClick={() => setEditing(null)} className="rounded-lg border border-slate-200 p-2 text-slate-500"><X size={17} /></button></div>
            <form onSubmit={submit} className="space-y-4 p-6">
              {error && <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-3 text-xs font-semibold text-rose-700">{error}</div>}
              {resetNotice && <div role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-3 text-xs leading-5 text-emerald-800">{resetNotice}</div>}
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block"><span className="mb-1.5 block text-xs font-bold text-slate-500">Full name</span><input required value={form.name} onChange={(e) => setForm((v) => ({ ...v, name: e.target.value }))} className={input} placeholder="Full name" /></label>
                <label className="block"><span className="mb-1.5 block text-xs font-bold text-slate-500">Username</span><input required minLength={3} maxLength={32} autoComplete="off" value={form.username} onChange={(e) => setForm((v) => ({ ...v, username: e.target.value.toLowerCase() }))} className={input} placeholder="e.g. sarah.ahmed" /></label>
              </div>
              <label className="block"><span className="mb-1.5 block text-xs font-bold text-slate-500">Registered email</span><input type="email" required value={form.email} onChange={(e) => setForm((v) => ({ ...v, email: e.target.value }))} className={input} placeholder="name@company.com" /></label>
              <label className="block"><span className="mb-1.5 block text-xs font-bold text-slate-500">{editing === "new" ? "Temporary password" : "New password (leave blank to keep current)"}</span><input type="password" autoComplete="new-password" required={editing === "new"} minLength={12} value={form.password} onChange={(e) => setForm((v) => ({ ...v, password: e.target.value }))} className={input} placeholder="At least 12 characters" /></label>
              {editing !== "new" && editing.active && <button type="button" onClick={() => void emailReset(editing)} disabled={resetting || saving} className="flex h-10 items-center justify-center gap-2 rounded-xl border border-teal-200 bg-teal-50 px-4 text-xs font-bold text-teal-800 transition hover:bg-teal-100 disabled:opacity-50">{resetting ? <Loader2 size={14} className="animate-spin" /> : <KeyRound size={14} />}{resetting ? "Requesting link…" : `Email password reset link to ${editing.email}`}</button>}
              <label className="relative block"><span className="mb-1.5 block text-xs font-bold text-slate-500">Role</span><select value={form.role} onChange={(e) => { const role = e.target.value; setForm((v) => ({ ...v, role, permissions: defaults[role] ?? [] })); }} className={`${input} appearance-none pr-8`}>{roles.map((role) => <option key={role.value} value={role.value}>{role.label} — {role.permissions}</option>)}</select><ChevronDown size={15} className="pointer-events-none absolute bottom-3.5 right-3 text-slate-400" /></label>
              <div><div className="mb-2 text-xs font-bold text-slate-500">Permissions</div><div className="grid gap-2 sm:grid-cols-2">{options.map((permission) => <label key={permission.value} className={`flex cursor-pointer items-start gap-2.5 rounded-xl border p-3 transition ${form.permissions.includes(permission.value) || form.role === "admin" ? "border-teal-200 bg-teal-50/50" : "border-slate-200"}`}><input type="checkbox" disabled={form.role === "admin" || (permission.value === "manage_users" && form.role !== "admin")} checked={form.role === "admin" || form.permissions.includes(permission.value)} onChange={(e) => setForm((v) => ({ ...v, permissions: e.target.checked ? [...v.permissions, permission.value] : v.permissions.filter((p) => p !== permission.value) }))} className="mt-0.5 accent-teal-700" /><span><span className="block text-[11px] font-extrabold text-slate-800">{permission.label}</span><span className="mt-0.5 block text-[10px] leading-4 text-slate-500">{permission.description}</span></span></label>)}</div></div>
              {editing !== "new" && <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 p-3 text-xs font-bold text-slate-700"><input type="checkbox" checked={form.active} disabled={editing.id === currentId} onChange={(e) => setForm((v) => ({ ...v, active: e.target.checked }))} className="accent-teal-700" /> Account active {editing.id === currentId && <span className="font-normal text-slate-400">(you cannot deactivate yourself)</span>}</label>}
              <div className="flex justify-end gap-2 border-t border-slate-100 pt-4"><button type="button" onClick={() => setEditing(null)} className="h-10 rounded-xl border border-slate-200 px-4 text-xs font-bold text-slate-600">Cancel</button><button disabled={saving} className="flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-5 text-xs font-bold text-white disabled:opacity-60">{saving && <Loader2 size={15} className="animate-spin" />} {editing === "new" ? "Create user" : "Save changes"}</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
