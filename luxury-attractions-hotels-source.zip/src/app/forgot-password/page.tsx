import type { Metadata } from "next";
import RecoveryForm from "./recovery-form";

export const metadata: Metadata = {
  title: "Forgot password | Luxury Attractions",
  robots: { index: false, follow: false },
};

export default function ForgotPasswordPage() {
  return <RecoveryForm />;
}
