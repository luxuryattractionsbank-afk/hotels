"use client";

import { ArrowLeft, Hotel, Loader2, Mail, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";

export default function RecoveryForm() {
  const [identifier, setIdentifier] = useState("");
  const [available, setAvailable] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let live = true;
    void fetch("/api/auth/forgot-password", { cache: "no-store" })
      .then((response) => response.json())
      .then((value) => { if (live) setAvailable(value.available === true); })
      .catch(() => { if (live) setAvailable(false); });
    return () => { live = false; };
  }, []);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to request a reset link.");
      setSent(true);
      setIdentifier("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to request a reset link.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#f5f7f9] px-5 py-12">
      <section className="w-full max-w-md rounded-[24px] border border-slate-200 bg-white p-7 shadow-[0_18px_55px_rgba(20,55,50,.08)] sm:p-9">
        <div className="mb-6 flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#174e48] text-white"><Hotel size={21} /></span>
          <div><p className="text-[15px] font-extrabold text-slate-950">Luxury Attractions</p><p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#b27a4b]">Hotel contracts</p></div>
        </div>
        <div className="mb-5 grid h-12 w-12 place-items-center rounded-xl bg-teal-50 text-teal-700"><Mail size={21} /></div>
        <h1 className="text-[26px] font-extrabold tracking-tight text-slate-950">Forgot your password?</h1>
        <p className="mt-2 text-sm leading-6 text-slate-500">Enter the username or email registered to your staff account. If we find an active account, we’ll send a reset link to its registered email address.</p>

        {available === false && <div role="alert" className="mt-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs leading-5 text-amber-900">Email recovery is not configured yet. Please ask your administrator to reset your password in Users & permissions. Once SMTP is configured, email recovery will work here.</div>}
        {error && <div role="alert" className="mt-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold leading-5 text-rose-700">{error}</div>}
        {sent ? (
          <div role="status" className="mt-5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-4 text-sm leading-6 text-emerald-900"><ShieldCheck size={20} className="mb-2" />If an active account matches, you’ll receive a one-time link at its registered email. Check your inbox and spam folder. The link expires in 30 minutes.</div>
        ) : (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-[0.07em] text-slate-500">Username or registered email</span><input autoComplete="username" required value={identifier} onChange={(event) => setIdentifier(event.target.value)} placeholder="e.g. sarah.ahmed or sarah@company.com" className="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10" /></label>
            <button disabled={busy || available !== true} className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#174e48] text-sm font-extrabold text-white transition hover:bg-[#103f3a] disabled:opacity-50">{busy && <Loader2 size={17} className="animate-spin" />}{busy ? "Sending…" : "Email a reset link"}</button>
          </form>
        )}
        <Link href="/login" className="mt-6 inline-flex items-center gap-2 text-xs font-bold text-teal-700 hover:underline"><ArrowLeft size={14} /> Back to sign in</Link>
      </section>
    </main>
  );
}
