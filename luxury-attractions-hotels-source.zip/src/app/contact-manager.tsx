"use client";

import { Building2, Check, ChevronDown, ExternalLink, Mail, Plus, Trash2, UsersRound, X } from "lucide-react";
import { useState } from "react";
import type { DashboardData } from "./dashboard-client";
import { contactIdentity, groupContactCandidates } from "@/lib/contact-sharing";
import { messagingLink } from "@/lib/search-engine";

type Contact = DashboardData["contacts"][number];
type ContactData = Pick<DashboardData, "contacts" | "contactAssignments" | "hotels" | "hotelGroups">;

type Props = {
  data: ContactData;
  mode: "group" | "hotel";
  groupId?: number;
  hotelId?: number;
  onClose: () => void;
  onChanged: (message: string) => void;
  onAddGroupContact: (groupId: number) => void;
  onAddHotelContact: (hotelId: number) => void;
};

function ContactDetails({ contact }: { contact: Contact }) {
  return (
    <div className="min-w-0 flex-1">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-extrabold text-slate-900">{contact.name}</span>
        {contact.groupId && <span className="rounded-full bg-teal-50 px-2 py-0.5 text-[10px] font-bold text-teal-700">Group contact</span>}
      </div>
      <div className="mt-0.5 text-xs text-slate-500">{contact.position || "Position not set"}</div>
      <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[11px]">
        {contact.email && <a href={`mailto:${contact.email}`} className="inline-flex items-center gap-1 text-sky-700 hover:underline"><Mail size={12} /> {contact.email}</a>}
        {contact.phone && <span className="font-semibold text-slate-600">{contact.phone}</span>}
        {contact.whatsapp && contact.phone && <a href={messagingLink("whatsapp", contact.phone)} target="_blank" rel="noreferrer" className="font-bold text-emerald-700">WhatsApp ↗</a>}
        {contact.telegram && contact.phone && <a href={messagingLink("telegram", contact.phone)} target="_blank" rel="noreferrer" className="font-bold text-sky-700">Telegram ↗</a>}
        {contact.viber && contact.phone && <a href={messagingLink("viber", contact.phone)} className="font-bold text-violet-700">Viber ↗</a>}
        {contact.businessCardLink && <a href={contact.businessCardLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-slate-600 hover:underline"><ExternalLink size={11} /> Contact card</a>}
      </div>
      {contact.otherContact && <p className="mt-1.5 text-[11px] text-slate-400">Other: {contact.otherContact}</p>}
    </div>
  );
}

export default function ContactManager({ data, mode, groupId, hotelId, onClose, onChanged, onAddGroupContact, onAddHotelContact }: Props) {
  const [selectedGroupId, setSelectedGroupId] = useState(groupId ?? data.hotelGroups[0]?.id ?? 0);
  const [pending, setPending] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const selectedHotel = data.hotels.find((hotel) => hotel.id === hotelId);
  const group = data.hotelGroups.find((item) => item.id === selectedGroupId);
  const groupHotels = data.hotels.filter((hotel) => hotel.groupId === selectedGroupId);
  const assigned = (contactId: number, targetHotelId: number) => data.contactAssignments.some((item) => item.contactId === contactId && item.hotelId === targetHotelId);
  const candidates = selectedGroupId ? groupContactCandidates(selectedGroupId, data.contacts, data.contactAssignments, data.hotels) : [];
  const shared = data.contacts.filter((contact) => contact.groupId === selectedGroupId && contact.active);
  const fromHotels = candidates.filter((contact) => contact.groupId !== selectedGroupId);
  const hotelContacts = selectedHotel ? data.contacts.filter((contact) => contact.active && assigned(contact.id, selectedHotel.id)) : [];
  const currentIdentities = new Set(hotelContacts.map(contactIdentity));
  const available = selectedHotel?.groupId
    ? groupContactCandidates(selectedHotel.groupId, data.contacts, data.contactAssignments, data.hotels).filter((contact) => !currentIdentities.has(contactIdentity(contact)))
    : [];

  const execute = async (key: string, method: "PATCH" | "DELETE", url: string, body: Record<string, unknown> | undefined, message: string) => {
    setPending(key);
    setError("");
    setNotice("");
    try {
      const response = await fetch(url, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to update this contact.");
      setNotice(message);
      onChanged(message);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Unable to update this contact.");
    } finally {
      setPending(null);
    }
  };

  const attach = (contact: Contact, targetHotelId: number, next: boolean) => execute(
    `${contact.id}-${targetHotelId}`,
    "PATCH",
    "/api/contacts",
    { id: contact.id, hotelId: targetHotelId, attached: next },
    next ? `${contact.name} added to ${data.hotels.find((hotel) => hotel.id === targetHotelId)?.name}.` : `${contact.name} removed from this hotel; other assignments are unchanged.`,
  );

  return (
    <div data-internal className="fixed inset-0 z-[85] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px] print:hidden" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-start justify-between gap-3 border-b border-slate-100 bg-white px-5 py-5 sm:px-6">
          <div>
            <div className="mb-1 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#a66e42]">
              {mode === "group" ? <UsersRound size={13} /> : <Building2 size={13} />}
              {mode === "group" ? "Umbrella company" : "Hotel team"}
            </div>
            <h2 className="text-xl font-extrabold text-slate-950">{mode === "group" ? "Manage group contacts" : `Contacts · ${selectedHotel?.name ?? "Hotel"}`}</h2>
            <p className="mt-1 text-xs leading-5 text-slate-500">
              {mode === "group" ? "Share contacts with the group and choose which hotels use each person." : "Removing a contact here does not remove them from the group or another hotel."}
            </p>
          </div>
          <button onClick={onClose} className="rounded-xl border border-slate-200 p-2 text-slate-500 transition hover:bg-slate-50" aria-label="Close contact manager"><X size={18} /></button>
        </div>

        <div className="space-y-5 p-5 sm:p-6">
          {error && <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-700">{error}</div>}
          {notice && <div role="status" className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-800"><Check size={15} /> {notice}</div>}

          {mode === "group" ? (
            <>
              <div className="flex flex-wrap items-end gap-3 rounded-2xl bg-slate-50 p-4">
                <label className="relative min-w-[230px] flex-1">
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-[0.08em] text-slate-500">Umbrella company</span>
                  <select value={selectedGroupId} onChange={(event) => { setSelectedGroupId(Number(event.target.value)); setNotice(""); setError(""); }} className="h-11 w-full appearance-none rounded-xl border border-slate-200 bg-white px-3 pr-8 text-sm font-bold text-slate-900 outline-none focus:border-teal-600">
                    {data.hotelGroups.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
                  </select>
                  <ChevronDown size={15} className="pointer-events-none absolute bottom-3.5 right-3 text-slate-400" />
                </label>
                {group && <button onClick={() => onAddGroupContact(group.id)} className="flex h-11 items-center gap-2 rounded-xl bg-[#174e48] px-4 text-xs font-bold text-white hover:bg-[#103f3a]"><Plus size={16} /> New group contact</button>}
              </div>

              {group && (
                <>
                  <div className="flex flex-wrap gap-1.5">
                    {groupHotels.map((hotel) => <span key={hotel.id} className="rounded-lg bg-teal-50 px-2.5 py-1.5 text-[11px] font-semibold text-teal-800">{hotel.name}</span>)}
                    {groupHotels.length === 0 && <span className="text-xs text-slate-400">No hotels assigned yet. Add a hotel to this group to start sharing contacts.</span>}
                  </div>
                  <section>
                    <div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-extrabold text-slate-900">Shared with {group.name}</h3><span className="rounded-full bg-teal-50 px-2.5 py-1 text-[10px] font-bold text-teal-700">{shared.length} contacts</span></div>
                    <div className="space-y-3">
                      {shared.map((contact) => (
                        <div key={contact.id} className="rounded-2xl border border-slate-200 p-4">
                          <div className="flex flex-wrap items-start gap-2"><ContactDetails contact={contact} /><button disabled={Boolean(pending)} onClick={() => execute(`remove-group-${contact.id}`, "DELETE", `/api/contacts?id=${contact.id}&groupId=${group.id}`, undefined, `${contact.name} removed from the group. Hotel assignments remain.`)} className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-[10px] font-bold text-slate-500 hover:border-rose-200 hover:bg-rose-50 hover:text-rose-700 disabled:opacity-50">Remove from group</button></div>
                          {groupHotels.length > 0 && <div className="mt-3 border-t border-slate-100 pt-3"><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.08em] text-slate-400">Used at these hotels</p><div className="flex flex-wrap gap-2">{groupHotels.map((hotel) => <label key={hotel.id} className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-[11px] font-semibold text-slate-600 hover:border-teal-300"><input type="checkbox" checked={assigned(contact.id, hotel.id)} disabled={Boolean(pending)} onChange={(event) => void attach(contact, hotel.id, event.target.checked)} className="accent-teal-700" /> {hotel.name}</label>)}</div></div>}
                        </div>
                      ))}
                      {shared.length === 0 && <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-5 text-center text-xs text-slate-500">No group contacts yet. Add a new contact or share one from the hotels below.</div>}
                    </div>
                  </section>
                  {fromHotels.length > 0 && <section><h3 className="mb-1 text-sm font-extrabold text-slate-900">Contacts at group hotels</h3><p className="mb-3 text-xs leading-5 text-slate-500">These people are suggested when adding another hotel because a sibling hotel uses them. Removing someone from the umbrella company keeps their hotel assignments; remove them from individual hotels too if they should no longer be suggested.</p><div className="space-y-2">{fromHotels.map((contact) => <div key={contact.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 p-3"><ContactDetails contact={contact} /><button disabled={Boolean(pending)} onClick={() => execute(`promote-${contact.id}`, "PATCH", "/api/contacts", { id: contact.id, groupId: group.id }, `${contact.name} is now shared with ${group.name}.`)} className="rounded-lg bg-teal-50 px-3 py-2 text-[11px] font-bold text-teal-800 hover:bg-teal-100 disabled:opacity-50">Share with group</button></div>)}</div></section>}
                </>
              )}
            </>
          ) : selectedHotel ? (
            <>
              {selectedHotel.groupId && <div className="rounded-xl border border-teal-100 bg-teal-50 p-3 text-xs text-teal-800">Part of <b>{data.hotelGroups.find((group) => group.id === selectedHotel.groupId)?.name}</b>. You can use contacts at sibling hotels below without duplicating them.</div>}
              <div className="flex items-center justify-between"><h3 className="text-sm font-extrabold text-slate-900">Assigned to this hotel · {hotelContacts.length}</h3><button onClick={() => onAddHotelContact(selectedHotel.id)} className="flex items-center gap-1.5 rounded-lg bg-[#174e48] px-3 py-2 text-[11px] font-bold text-white"><Plus size={14} /> New contact</button></div>
              <div className="space-y-2">
                {hotelContacts.map((contact) => <div key={contact.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 p-3"><ContactDetails contact={contact} /><button disabled={Boolean(pending)} onClick={() => execute(`detach-${contact.id}`, "DELETE", `/api/contacts?id=${contact.id}&hotelId=${selectedHotel.id}`, undefined, `${contact.name} removed from this hotel. Other hotels and the group are unchanged.`)} title="Remove only from this hotel" className="flex items-center gap-1.5 rounded-lg border border-rose-200 px-2.5 py-2 text-[11px] font-bold text-rose-700 hover:bg-rose-50 disabled:opacity-50"><Trash2 size={13} /> Remove</button></div>)}
                {hotelContacts.length === 0 && <p className="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-4 text-xs text-slate-500">No contacts assigned to this hotel yet.</p>}
              </div>
              {available.length > 0 && <section className="border-t border-slate-100 pt-4"><h3 className="text-sm font-extrabold text-slate-900">Available from your umbrella company</h3><p className="mt-1 text-xs text-slate-500">Attach a contact here without changing their assignments at other hotels.</p><div className="mt-3 space-y-2">{available.map((contact) => <div key={contact.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 p-3"><ContactDetails contact={contact} /><button disabled={Boolean(pending)} onClick={() => void attach(contact, selectedHotel.id, true)} className="flex items-center gap-1 rounded-lg bg-teal-50 px-3 py-2 text-[11px] font-bold text-teal-800 hover:bg-teal-100 disabled:opacity-50"><Plus size={13} /> Add to hotel</button></div>)}</div></section>}
            </>
          ) : <p className="text-sm text-slate-500">Hotel not found.</p>}
        </div>
      </div>
    </div>
  );
}
