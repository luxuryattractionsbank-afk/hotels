"use client";

import { Check, Loader2, Mail, Paperclip, X } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";

export type EmailTarget = {
  type: "quotation" | "trip";
  id: number;
  reference: string;
  clientName: string;
  clientEmail: string;
};

export default function EmailProposalDialog({ target, onClose, onSent }: { target: EmailTarget; onClose: () => void; onSent: (message: string) => void }) {
  const [to, setTo] = useState(target.clientEmail);
  const [subject, setSubject] = useState(`Luxury Attractions ${target.type === "quotation" ? "hotel proposal" : "trip package"} — ${target.reference}`);
  const [message, setMessage] = useState(`Dear ${target.clientName},\n\nPlease find your ${target.type === "quotation" ? "hotel proposal" : "trip package and itinerary"} attached as a PDF.\n\nReference: ${target.reference}\n\nKind regards,\nLuxury Attractions`);
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [from, setFrom] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    void fetch("/api/proposals/email", { cache: "no-store" }).then((r) => r.json()).then((data) => {
      if (active) { setConfigured(data.configured === true); setFrom(data.from || ""); }
    }).catch(() => { if (active) setConfigured(false); });
    return () => { active = false; };
  }, []);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/proposals/email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: target.type, id: target.id, to, subject, message }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Email could not be sent.");
      onSent(`Sent ${target.reference} as a PDF attachment to ${result.to}.`);
      onClose();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Email could not be sent.");
    } finally {
      setBusy(false);
    }
  };
  const input = "h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-800 outline-none focus:border-teal-700 focus:ring-4 focus:ring-teal-700/10";
  return (
    <div data-internal className="fixed inset-0 z-[90] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-[3px]" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-[22px] bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-start justify-between border-b border-slate-100 bg-white px-6 py-5"><div><div className="flex items-center gap-2"><Mail size={19} className="text-teal-700" /><h2 className="text-xl font-extrabold text-slate-950">Email PDF proposal</h2></div><p className="mt-1.5 text-xs text-slate-500">The actual client-facing PDF is generated and attached by the server — no link or internal markup details.</p></div><button onClick={onClose} className="rounded-xl border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" aria-label="Close"><X size={18} /></button></div>
        <form onSubmit={submit} className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2 rounded-xl bg-teal-50 px-3.5 py-3 text-xs font-bold text-teal-800"><Paperclip size={14} /> {target.reference}-{target.type === "quotation" ? "hotel-proposal" : "trip-package"}.pdf <span className="ml-auto font-normal text-teal-700">PDF attached automatically</span></div>
          {configured === false && <div className="rounded-xl border border-amber-200 bg-amber-50 px-3.5 py-3 text-xs leading-5 text-amber-900">SMTP is not configured yet. Add SMTP_HOST and SMTP_FROM_EMAIL, plus your provider credentials, to the server environment before sending. You can download the PDF now and attach it manually.</div>}
          {configured && from && <p className="text-[11px] text-slate-500">Sending from: <b className="text-slate-700">{from}</b></p>}
          {error && <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-xs font-semibold text-rose-700">{error}</div>}
          <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">To</span><input value={to} onChange={(e) => setTo(e.target.value)} type="email" required autoComplete="email" placeholder="client@example.com" className={input} /></label>
          <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Subject</span><input value={subject} onChange={(e) => setSubject(e.target.value)} required className={input} /></label>
          <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500">Message</span><textarea value={message} onChange={(e) => setMessage(e.target.value)} required rows={8} className={`${input} h-auto min-h-40 py-3 leading-6`} /></label>
          <div className="flex justify-end gap-2 border-t border-slate-100 pt-4"><button type="button" onClick={onClose} className="h-11 rounded-xl border border-slate-200 px-4 text-xs font-bold text-slate-600">Cancel</button><button disabled={busy || configured !== true} className="flex h-11 items-center gap-2 rounded-xl bg-[#174e48] px-5 text-xs font-extrabold text-white disabled:opacity-50">{busy ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />} {busy ? "Sending…" : "Send PDF email"}</button></div>
        </form>
      </div>
    </div>
  );
}
