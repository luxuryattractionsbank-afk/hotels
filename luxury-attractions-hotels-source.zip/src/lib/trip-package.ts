// Trip package math: hotels (from a quotation) + transfers + tours, then one
// client proposal with tourism-tax choice and markup. Pure + shared server/browser.

import { sanitizeMarkupAmount, sanitizeMarkupPercent } from "./proposal";

export type TripHotelLegNet = {
  totalAmount: number | string;
  tourismTaxAmount: number | string;
  nights: number;
  rooms: number;
};

export type TripPackageOptions = {
  includeTourismTax: boolean;
  markupPercent: number | string;
  markupAmount: number | string;
};

export type TripPackageTotals = {
  hotelsNet: number;
  transfersNet: number;
  toursNet: number;
  subtotal: number;
  markupPercentAmount: number;
  markupFixedAmount: number;
  proposalTotal: number;
  margin: number;
  excludedTax: number;
  hotelsShare: number;
  transfersShare: number;
  toursShare: number;
  factor: number;
};

const num = (value: number | string) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

export function computeTripPackage(
  hotelLegs: TripHotelLegNet[],
  transfersNet: number | string,
  toursNet: number | string,
  options: TripPackageOptions,
): TripPackageTotals {
  const pct = sanitizeMarkupPercent(options.markupPercent);
  const fixed = sanitizeMarkupAmount(options.markupAmount);
  const hotelsNet = round2(
    hotelLegs.reduce((sum, leg) => {
      const total = num(leg.totalAmount);
      const tax = num(leg.tourismTaxAmount);
      return sum + Math.max(0, options.includeTourismTax ? total : total - tax);
    }, 0),
  );
  const transfers = Math.max(0, num(transfersNet));
  const tours = Math.max(0, num(toursNet));
  const excludedTax = options.includeTourismTax
    ? 0
    : round2(
        hotelLegs.reduce((sum, leg) => sum + Math.min(num(leg.tourismTaxAmount), num(leg.totalAmount)), 0),
      );
  const subtotal = round2(hotelsNet + transfers + tours);
  const markupPercentAmount = round2((subtotal * pct) / 100);
  const proposalTotal = round2(subtotal + markupPercentAmount + fixed);
  const factor = subtotal > 0 ? proposalTotal / subtotal : 0;
  let hotelsShare = round2(hotelsNet * factor);
  let transfersShare = round2(transfers * factor);
  let toursShare = round2(tours * factor);
  const drift = round2(proposalTotal - (hotelsShare + transfersShare + toursShare));
  if (drift !== 0) {
    if (tours > 0) toursShare = round2(toursShare + drift);
    else if (transfers > 0) transfersShare = round2(transfersShare + drift);
    else hotelsShare = round2(hotelsShare + drift);
  }
  return {
    hotelsNet,
    transfersNet: round2(transfers),
    toursNet: round2(tours),
    subtotal,
    markupPercentAmount,
    markupFixedAmount: fixed,
    proposalTotal,
    margin: round2(proposalTotal - subtotal),
    excludedTax,
    hotelsShare,
    transfersShare,
    toursShare,
    factor,
  };
}

export function tripReference(): string {
  return `TRP-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 90 + 10)}`;
}

export const transferModeLabel = (mode: string, direction: string, vehicle: string) => {
  const m = mode === "private" ? "Private" : "Shared";
  const d = direction === "twoway" ? "Two-way" : "One-way";
  return vehicle ? `${m} · ${vehicle} · ${d}` : `${m} · ${d}`;
};

export const tourModeLabel = (mode: string) =>
  mode === "ticket_only" ? "Ticket only" : mode === "private" ? "Private transfer" : "Shared transfer";

export function transferTotal(opts: {
  mode: string;
  direction: string;
  adults: number;
  children: number;
  vehicles: number;
  unitPrice: number | string;
}): number {
  const unit = Math.max(0, num(opts.unitPrice));
  if (opts.mode === "private") {
    const ways = opts.direction === "twoway" ? 2 : 1;
    return round2(unit * Math.max(1, opts.vehicles) * ways);
  }
  const pax = Math.max(0, opts.adults + opts.children);
  return round2(unit * pax);
}

export function tourTotal(opts: {
  adults: number;
  children: number;
  priceAdult: number | string;
  priceChild: number | string;
}): number {
  return round2(Math.max(0, opts.adults) * Math.max(0, num(opts.priceAdult)) + Math.max(0, opts.children) * Math.max(0, num(opts.priceChild)));
}
