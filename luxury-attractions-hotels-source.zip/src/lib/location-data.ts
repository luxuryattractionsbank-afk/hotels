import { db } from "@/db";
import { locations } from "@/db/schema";
import { and, sql } from "drizzle-orm";

type Executor = Pick<typeof db, "select" | "insert">;

export const cleanPlace = (value: unknown) => String(value ?? "").trim().replace(/\s+/g, " ").slice(0, 120);

/**
 * Returns the id of `name` inside `city`, creating it if needed.
 * Matching ignores case so "deira" and "Deira" stay one location under Dubai.
 */
export async function findOrCreateLocation(executor: Executor, cityValue: unknown, nameValue: unknown): Promise<number | null> {
  const city = cleanPlace(cityValue);
  const name = cleanPlace(nameValue);
  if (!city || !name) return null;

  const [existing] = await executor
    .select({ id: locations.id })
    .from(locations)
    .where(and(sql`lower(${locations.city}) = lower(${city})`, sql`lower(${locations.name}) = lower(${name})`))
    .limit(1);
  if (existing) return existing.id;

  const [created] = await executor
    .insert(locations)
    .values({ city, name })
    .onConflictDoUpdate({ target: [locations.city, locations.name], set: { active: true } })
    .returning({ id: locations.id });
  return created.id;
}
