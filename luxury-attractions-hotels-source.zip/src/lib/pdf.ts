// Client-facing PDF builders (runs in the browser via jsPDF).
// Quotations: hotel proposal. Trip packages: hotels + transfers + tours itinerary.
// Never includes net costs, margins or markup internals — client totals only.

import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { boardLabel } from "./search-engine";
import { computeProposal, ProposalTextInput } from "./proposal";
import { computeTripPackage, tourModeLabel, transferModeLabel } from "./trip-package";

const TEAL: [number, number, number] = [23, 78, 72];
const GOLD: [number, number, number] = [178, 122, 75];
const SLATE: [number, number, number] = [51, 65, 85];

const money = (value: number, currency: string) =>
  `${currency} ${value.toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

const fmtDate = (iso: string) => {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(
    new Date(`${String(iso).slice(0, 10)}T00:00:00Z`),
  );
};

const todayStr = () =>
  new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date());

function header(doc: jsPDF, title: string, subtitle: string) {
  doc.setFillColor(...TEAL);
  doc.rect(0, 0, 210, 34, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(17);
  doc.text("LUXURY ATTRACTIONS", 14, 13);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(220, 235, 232);
  doc.text("Hotels  •  Transfers  •  Tours & Experiences  •  B2B Proposals", 14, 20);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text(title, 196, 12, { align: "right" });
  doc.setFontSize(8.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(220, 235, 232);
  doc.text(subtitle, 196, 19, { align: "right" });
  doc.setDrawColor(...GOLD);
  doc.setLineWidth(1.2);
  doc.line(0, 34, 210, 34);
}

function footer(doc: jsPDF, reference: string) {
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i += 1) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(140, 150, 165);
    doc.setFont("helvetica", "normal");
    doc.text(`${reference}  •  Generated ${todayStr()} by Luxury Attractions (B2B)`, 14, 290);
    doc.text(`Page ${i} of ${pages}`, 196, 290, { align: "right" });
  }
}

function sectionTitle(doc: jsPDF, y: number, text: string): number {
  doc.setFillColor(240, 246, 245);
  doc.roundedRect(14, y, 182, 9, 2, 2, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10.5);
  doc.setTextColor(...TEAL);
  doc.text(text, 18, y + 6.2);
  return y + 13;
}

function metaBlock(
  doc: jsPDF,
  y: number,
  rows: [string, string][],
): number {
  autoTable(doc, {
    startY: y,
    margin: { left: 14, right: 14 },
    theme: "plain",
    styles: { fontSize: 9, cellPadding: 1.2, textColor: SLATE },
    columnStyles: { 0: { fontStyle: "bold", textColor: [100, 116, 139], cellWidth: 34 }, 1: { cellWidth: 57 }, 2: { fontStyle: "bold", textColor: [100, 116, 139], cellWidth: 34 }, 3: { cellWidth: 57 } },
    body: rows.reduce<string[][]>((acc, _, i, arr) => {
      if (i % 2 === 0) acc.push([arr[i][0], arr[i][1], ...(arr[i + 1] ? arr[i + 1] : ["", ""])]);
      return acc;
    }, []),
  });
  return (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 4;
}

// ---------------------------------------------------------------------------
// Quotation PDF
// ---------------------------------------------------------------------------

export function createQuotationPdf(input: ProposalTextInput): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const proposal = computeProposal(input.legs, input.options);
  const hotels = [...new Set(input.legs.map((leg) => leg.hotelName))];
  const titleName = hotels.length <= 1 ? hotels[0] ?? "Hotel" : `${hotels[0]} + ${hotels.length - 1} more`;

  header(doc, "HOTEL PROPOSAL", input.reference);
  let y = 40;
  y = metaBlock(doc, y, [
    ["Reference", input.reference],
    ["Client", input.clientName],
    ["Date", todayStr()],
    ["Valid until", input.validUntil ? fmtDate(input.validUntil) : "—"],
  ]);

  input.legs.forEach((leg, index) => {
    const share = proposal.legs[index];
    y = sectionTitle(doc, y, `Stay ${index + 1} — ${leg.hotelName}`);
    const place = [leg.location, leg.city].filter(Boolean).join(", ");
    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      theme: "grid",
      styles: { fontSize: 9, cellPadding: 2, textColor: SLATE, lineColor: [226, 232, 240], lineWidth: 0.2 },
      headStyles: { fillColor: TEAL, textColor: 255, fontSize: 8.5 },
      head: [["Detail", ""]],
      body: [
        ["Hotel", leg.hotelName + (place ? `  •  ${place}` : "")],
        ["Room", `${leg.roomName}  •  ${boardLabel(leg.boardType)}`],
        ["Check-in", `${fmtDate(leg.checkIn)}  →  Check-out ${fmtDate(leg.checkOut)}  (${leg.nights} night${leg.nights === 1 ? "" : "s"})`],
        ["Guests", `${leg.adults} Adult${leg.adults === 1 ? "" : "s"}  •  ${leg.children} Child  •  ${leg.infants} Infant  •  ${leg.rooms} Room${leg.rooms === 1 ? "" : "s"}`],
        ["Daily rate", `${money(share.dailyRate, input.currency)} per room / night`],
        ["Stay total", money(share.share, input.currency)],
      ],
      columnStyles: { 0: { fontStyle: "bold", cellWidth: 34, textColor: [100, 116, 139] } },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 5;
    if (y > 250) {
      doc.addPage();
      y = 16;
    }
  });

  y = sectionTitle(doc, y, "Proposal total");
  autoTable(doc, {
    startY: y,
    margin: { left: 14, right: 14 },
    theme: "grid",
    styles: { fontSize: 9.5, cellPadding: 2.5, textColor: SLATE, lineColor: [226, 232, 240], lineWidth: 0.2 },
    body: [
      ...input.legs.map((leg, i) => [`Stay ${i + 1} — ${leg.hotelName} (${leg.nights}n)`, money(proposal.legs[i].share, input.currency)]),
      [{ content: "TOTAL PROPOSAL COST", styles: { fontStyle: "bold", textColor: TEAL } }, { content: money(proposal.proposalTotal, input.currency), styles: { fontStyle: "bold", textColor: TEAL } }],
    ],
    columnStyles: { 0: {}, 1: { halign: "right", cellWidth: 55 } },
  });
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 4;

  doc.setFontSize(9);
  doc.setTextColor(...SLATE);
  const note = input.options.includeTourismTax
    ? "Tourism tax (tourism dirham) is INCLUDED in the totals above."
    : proposal.uniformTaxPerRoomNight !== null
      ? `Tourism tax is EXCLUDED: ${money(proposal.uniformTaxPerRoomNight, input.currency)} per room/night (${money(proposal.excludedTax, input.currency)} total), payable by the guest at the hotel.`
      : `Tourism tax is EXCLUDED: ${money(proposal.excludedTax, input.currency)} total, payable by the guest at the hotel (rates vary per hotel).`;
  const wrapped = doc.splitTextToSize(note, 182);
  doc.text(wrapped, 14, y);
  y += wrapped.length * 5 + 3;
  doc.setFontSize(8.5);
  doc.setTextColor(140, 150, 165);
  const terms = doc.splitTextToSize(
    `Rates are in ${input.currency} and subject to availability at confirmation. Hotel check-in from 15:00, check-out until 12:00 unless stated otherwise. Proposal: ${titleName}.`,
    182,
  );
  doc.text(terms, 14, y);

  footer(doc, input.reference);
  return doc;
}

export function downloadQuotationPdf(input: ProposalTextInput) {
  createQuotationPdf(input).save(`${input.reference}-hotel-proposal.pdf`);
}

// ---------------------------------------------------------------------------
// Trip package PDF
// ---------------------------------------------------------------------------

export type TripPdfTransfer = {
  serviceName: string;
  mode: string;
  direction: string;
  vehicle: string;
  transferDate: string;
  transferTime: string;
  pickup: string;
  dropoff: string;
  adults: number;
  children: number;
  vehicles: number;
  unitPrice: number | string;
  totalNet: number | string;
};

export type TripPdfTour = {
  serviceName: string;
  optionMode: string;
  tourDate: string;
  tourTime: string;
  meetingPoint: string;
  adults: number;
  children: number;
  priceAdult: number | string;
  priceChild: number | string;
  totalNet: number | string;
};

export type TripPdfInput = {
  reference: string;
  clientName: string;
  clientEmail: string;
  validUntil: string | null;
  currency: string;
  adults: number;
  children: number;
  infants: number;
  notes: string;
  hotelLegs: ProposalTextInput["legs"];
  transfers: TripPdfTransfer[];
  tours: TripPdfTour[];
  options: { includeTourismTax: boolean; markupPercent: number | string; markupAmount: number | string };
};

export function createTripPackagePdf(input: TripPdfInput): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const transfersNet = input.transfers.reduce((s, t) => s + Number(t.totalNet || 0), 0);
  const toursNet = input.tours.reduce((s, t) => s + Number(t.totalNet || 0), 0);
  const trip = computeTripPackage(input.hotelLegs, transfersNet, toursNet, input.options);
  const hotelProposal = computeProposal(input.hotelLegs, input.options);
  // Hotel daily rates must reflect the whole-trip markup, not hotel-only markup.
  const hotelFactor = trip.hotelsNet > 0 ? trip.hotelsShare / trip.hotelsNet : 0;

  header(doc, "TRIP PACKAGE", input.reference);
  let y = 40;
  const pax = `${input.adults} Adult${input.adults === 1 ? "" : "s"}${input.children ? ` • ${input.children} Child` : ""}${input.infants ? ` • ${input.infants} Infant` : ""}`;
  y = metaBlock(doc, y, [
    ["Reference", input.reference],
    ["Client", input.clientName],
    ["Travellers", pax],
    ["Valid until", input.validUntil ? fmtDate(input.validUntil) : "—"],
  ]);

  // ---- Part 1: hotel stays (separate) ----
  if (input.hotelLegs.length > 0) {
    y = sectionTitle(doc, y, `Part 1 — Hotel stays (${input.hotelLegs.length})`);
    const hotelRows = input.hotelLegs.map((leg, i) => {
      const legNet = input.options.includeTourismTax
        ? Number(leg.totalAmount)
        : Math.max(0, Number(leg.totalAmount) - Number(leg.tourismTaxAmount));
      const share = Math.round(legNet * hotelFactor * 100) / 100;
      const roomNights = Math.max(1, leg.nights * Math.max(1, leg.rooms));
      const daily = Math.round((share / roomNights) * 100) / 100;
      const place = [leg.location, leg.city].filter(Boolean).join(", ");
      return [
        `Stay ${i + 1}\n${fmtDate(leg.checkIn)} → ${fmtDate(leg.checkOut)} (${leg.nights}n)`,
        `${leg.hotelName}${place ? `\n${place}` : ""}\n${leg.roomName} • ${boardLabel(leg.boardType)}\n${leg.adults}A • ${leg.children}C • ${leg.infants}I • ${leg.rooms} room${leg.rooms === 1 ? "" : "s"}`,
        `${money(daily, input.currency)}/nt`,
        money(share, input.currency),
      ];
    });
    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      theme: "grid",
      styles: { fontSize: 8.5, cellPadding: 2.2, textColor: SLATE, lineColor: [226, 232, 240], lineWidth: 0.2 },
      headStyles: { fillColor: TEAL, textColor: 255, fontSize: 8.5 },
      head: [["Stay", "Hotel & room", "Daily rate", "Stay total"]],
      body: hotelRows,
      columnStyles: { 0: { cellWidth: 38 }, 2: { halign: "right", cellWidth: 32 }, 3: { halign: "right", cellWidth: 32 } },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 2;
    doc.setFontSize(9);
    doc.setTextColor(...TEAL);
    doc.setFont("helvetica", "bold");
    doc.text(`Hotels subtotal: ${money(trip.hotelsShare, input.currency)}`, 196, y, { align: "right" });
    doc.setFont("helvetica", "normal");
    y += 6;
    void hotelProposal;
  }

  // ---- Part 2: transfers ----
  if (input.transfers.length > 0) {
    if (y > 235) {
      doc.addPage();
      y = 16;
    }
    y = sectionTitle(doc, y, `Part 2 — Airport transfers & pick-up services (${input.transfers.length})`);
    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      theme: "grid",
      styles: { fontSize: 8.5, cellPadding: 2.2, textColor: SLATE, lineColor: [226, 232, 240], lineWidth: 0.2 },
      headStyles: { fillColor: [71, 120, 115], textColor: 255, fontSize: 8.5 },
      head: [["Date & time", "Service", "Route", "Pax / vehicles", "Total"]],
      body: input.transfers.map((t) => [
        `${fmtDate(t.transferDate)}${t.transferTime ? `\n${t.transferTime}` : ""}`,
        `${t.serviceName}\n${transferModeLabel(t.mode, t.direction, t.vehicle)}`,
        `${t.pickup || "—"}\n→ ${t.dropoff || "—"}`,
        t.mode === "private"
          ? `${t.vehicles} vehicle${t.vehicles === 1 ? "" : "s"}`
          : `${t.adults + t.children} pax`,
        money(Number(t.totalNet) * trip.factor, input.currency),
      ]),
      columnStyles: { 0: { cellWidth: 30 }, 3: { cellWidth: 28 }, 4: { halign: "right", cellWidth: 28 } },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 2;
    doc.setFontSize(9);
    doc.setTextColor(...TEAL);
    doc.setFont("helvetica", "bold");
    doc.text(`Transfers subtotal: ${money(trip.transfersShare, input.currency)}`, 196, y, { align: "right" });
    doc.setFont("helvetica", "normal");
    y += 6;
  }

  // ---- Part 3: tours itinerary ----
  if (input.tours.length > 0) {
    if (y > 225) {
      doc.addPage();
      y = 16;
    }
    y = sectionTitle(doc, y, `Part 3 — Tours & tickets itinerary (${input.tours.length})`);
    const sorted = [...input.tours].sort((a, b) => `${a.tourDate}${a.tourTime}`.localeCompare(`${b.tourDate}${b.tourTime}`));
    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      theme: "grid",
      styles: { fontSize: 8.5, cellPadding: 2.2, textColor: SLATE, lineColor: [226, 232, 240], lineWidth: 0.2 },
      headStyles: { fillColor: [146, 102, 60], textColor: 255, fontSize: 8.5 },
      head: [["Date & time", "Tour / tickets", "Option", "Pax & price", "Total"]],
      // Per-person prices are marked up like the totals, so the client never sees net rates.
      body: sorted.map((t) => {
        const adult = round2(Number(t.priceAdult) * trip.factor);
        const child = round2(Number(t.priceChild) * trip.factor);
        return [
          `${fmtDate(t.tourDate)}${t.tourTime ? `\n${t.tourTime}` : ""}${t.meetingPoint ? `\nPickup: ${t.meetingPoint}` : ""}`,
          t.serviceName,
          tourModeLabel(t.optionMode),
          `${t.adults}A × ${money(adult, input.currency)}${t.children ? `\n${t.children}C × ${money(child, input.currency)}` : ""}`,
          money(round2(Number(t.totalNet) * trip.factor), input.currency),
        ];
      }),
      columnStyles: { 0: { cellWidth: 36 }, 2: { cellWidth: 28 }, 3: { cellWidth: 42 }, 4: { halign: "right", cellWidth: 28 } },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 2;
    doc.setFontSize(9);
    doc.setTextColor(...TEAL);
    doc.setFont("helvetica", "bold");
    doc.text(`Tours subtotal: ${money(trip.toursShare, input.currency)}`, 196, y, { align: "right" });
    doc.setFont("helvetica", "normal");
    y += 6;
  }

  if (y > 240) {
    doc.addPage();
    y = 16;
  }
  y = sectionTitle(doc, y, "Package total");
  autoTable(doc, {
    startY: y,
    margin: { left: 14, right: 14 },
    theme: "grid",
    styles: { fontSize: 9.5, cellPadding: 2.5, textColor: SLATE, lineColor: [226, 232, 240], lineWidth: 0.2 },
    body: [
      ...(input.hotelLegs.length > 0 ? [["Hotel stays", money(trip.hotelsShare, input.currency)]] : []),
      ...(input.transfers.length > 0 ? [["Transfers & pick-up services", money(trip.transfersShare, input.currency)]] : []),
      ...(input.tours.length > 0 ? [["Tours & tickets", money(trip.toursShare, input.currency)]] : []),
      [
        { content: "TOTAL PACKAGE COST", styles: { fontStyle: "bold", textColor: TEAL } },
        { content: money(trip.proposalTotal, input.currency), styles: { fontStyle: "bold", textColor: TEAL } },
      ],
    ],
    columnStyles: { 0: {}, 1: { halign: "right", cellWidth: 55 } },
  });
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 4;

  doc.setFontSize(9);
  doc.setTextColor(...SLATE);
  const taxNote = input.options.includeTourismTax
    ? "Tourism tax (tourism dirham) is INCLUDED in the hotel totals above."
    : `Tourism tax is EXCLUDED (${money(trip.excludedTax, input.currency)} total), payable by the guest at the hotel.`;
  const wrappedTax = doc.splitTextToSize(input.hotelLegs.length > 0 ? taxNote : "All prices include VAT where applicable.", 182);
  doc.text(wrappedTax, 14, y);
  y += wrappedTax.length * 5 + 2;
  if (input.notes) {
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    const wrappedNotes = doc.splitTextToSize(`Notes: ${input.notes}`, 182);
    doc.text(wrappedNotes, 14, y);
  }

  footer(doc, input.reference);
  return doc;
}

export function downloadTripPackagePdf(input: TripPdfInput) {
  createTripPackagePdf(input).save(`${input.reference}-trip-package.pdf`);
}
