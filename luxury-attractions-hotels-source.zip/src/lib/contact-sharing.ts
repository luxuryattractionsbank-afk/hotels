export type ShareableContact = {
  id: number;
  groupId: number | null;
  name: string;
  email: string;
  phone: string;
};

export type ContactAssignment = { hotelId: number; contactId: number };
export type GroupHotel = { id: number; groupId: number | null };

export function contactIdentity(contact: ShareableContact): string {
  const email = contact.email.trim().toLowerCase();
  if (email) return `email:${email}`;
  const phone = contact.phone.replace(/\D/g, "");
  return `person:${contact.name.trim().toLowerCase()}|${phone}`;
}

/**
 * Contacts owned by a group and contacts used at any of its existing hotels
 * are offered to each new hotel. A group-owned version wins if duplicates exist.
 */
export function groupContactCandidates<T extends ShareableContact>(
  groupId: number,
  contacts: T[],
  assignments: ContactAssignment[],
  hotels: GroupHotel[],
): T[] {
  const groupHotelIds = new Set(hotels.filter((hotel) => hotel.groupId === groupId).map((hotel) => hotel.id));
  const linked = new Set(assignments.filter((item) => groupHotelIds.has(item.hotelId)).map((item) => item.contactId));
  const ordered = contacts
    .filter((contact) => contact.groupId === groupId || (contact.groupId === null && linked.has(contact.id)))
    .sort((a, b) => Number(b.groupId === groupId) - Number(a.groupId === groupId) || a.id - b.id);
  const identities = new Set<string>();
  return ordered.filter((contact) => {
    const identity = contactIdentity(contact);
    if (identities.has(identity)) return false;
    identities.add(identity);
    return true;
  });
}
