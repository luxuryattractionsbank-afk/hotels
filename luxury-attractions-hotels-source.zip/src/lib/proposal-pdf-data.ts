import "server-only";

import { db } from "@/db";
import { hotels, locations, quotationItems, quotations, roomTypes, tripPackages, tripPackageTours, tripPackageTransfers } from "@/db/schema";
import type { TripPdfInput } from "@/lib/pdf";
import type { ProposalTextInput, ProposalTextLeg } from "@/lib/proposal";
import { eq } from "drizzle-orm";

export async function quotationPdfData(id: number): Promise<ProposalTextInput | null> {
  const [quotation] = await db.select().from(quotations).where(eq(quotations.id, id)).limit(1);
  if (!quotation) return null;
  const [items, hotelRows, roomRows, areaRows] = await Promise.all([
    db.select().from(quotationItems).where(eq(quotationItems.quotationId, id)),
    db.select({ id: hotels.id, name: hotels.name, city: hotels.city, locationId: hotels.locationId }).from(hotels),
    db.select({ id: roomTypes.id, name: roomTypes.name }).from(roomTypes),
    db.select({ id: locations.id, name: locations.name }).from(locations),
  ]);
  const legs: ProposalTextLeg[] = items.sort((a, b) => a.position - b.position).map((item) => {
    const hotel = hotelRows.find((h) => h.id === item.hotelId);
    return {
      totalAmount: item.totalAmount,
      tourismTaxAmount: item.tourismTaxAmount,
      nights: item.nights,
      rooms: item.rooms,
      hotelName: hotel?.name ?? "Hotel",
      city: hotel?.city ?? "",
      location: areaRows.find((area) => area.id === hotel?.locationId)?.name ?? "",
      roomName: roomRows.find((room) => room.id === item.roomTypeId)?.name ?? "Room",
      boardType: item.boardType,
      checkIn: item.checkIn,
      checkOut: item.checkOut,
      adults: item.adults,
      children: item.children,
      infants: item.infants,
    };
  });
  return {
    reference: quotation.reference,
    clientName: quotation.clientName,
    validUntil: quotation.validUntil,
    currency: quotation.currency,
    legs,
    options: {
      includeTourismTax: quotation.includeTourismTax,
      markupPercent: quotation.markupPercent,
      markupAmount: quotation.markupAmount,
    },
  };
}

export async function tripPdfData(id: number): Promise<TripPdfInput | null> {
  const [pkg] = await db.select().from(tripPackages).where(eq(tripPackages.id, id)).limit(1);
  if (!pkg) return null;
  const [hotelQuote, transfers, tours] = await Promise.all([
    pkg.quotationId ? quotationPdfData(pkg.quotationId) : Promise.resolve(null),
    db.select().from(tripPackageTransfers).where(eq(tripPackageTransfers.packageId, id)),
    db.select().from(tripPackageTours).where(eq(tripPackageTours.packageId, id)),
  ]);
  return {
    reference: pkg.reference,
    clientName: pkg.clientName,
    clientEmail: pkg.clientEmail,
    validUntil: pkg.validUntil,
    currency: pkg.currency,
    adults: pkg.adults,
    children: pkg.children,
    infants: pkg.infants,
    notes: pkg.notes,
    hotelLegs: hotelQuote?.legs ?? [],
    transfers: transfers.sort((a, b) => a.position - b.position),
    tours: tours.sort((a, b) => a.position - b.position),
    options: {
      includeTourismTax: pkg.includeTourismTax,
      markupPercent: pkg.markupPercent,
      markupAmount: pkg.markupAmount,
    },
  };
}
