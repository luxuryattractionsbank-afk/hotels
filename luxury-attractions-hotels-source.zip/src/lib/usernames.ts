import "server-only";

import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, isNull, or, sql } from "drizzle-orm";

/** Lowercase, case-insensitive staff login name. */
export const normalizeUsername = (input: unknown) => String(input ?? "").trim().toLowerCase();
export const validUsername = (username: string) => /^[a-z][a-z0-9._-]{2,31}$/.test(username);

/**
 * Gives legacy accounts a deterministic unique username without changing their
 * password, email, role or sessions. Never overwrites an assigned username.
 */
export async function ensureUsernames() {
  const missing = await db.select({ id: users.id }).from(users).where(isNull(users.username)).limit(1);
  if (!missing.length) return;

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(786349134)`);
    const all = await tx.select({ id: users.id, email: users.email, username: users.username }).from(users);
    const taken = new Set(all.map((account) => account.username?.toLowerCase()).filter((value): value is string => Boolean(value)));
    for (const account of all.filter((item) => item.username === null)) {
      let stem = normalizeUsername(account.email.split("@")[0])
        .replace(/[^a-z0-9._-]/g, "-")
        .replace(/^[^a-z]+/, "")
        .replace(/[-._]+$/, "")
        .slice(0, 24);
      if (!stem || !/^[a-z]/.test(stem)) stem = "user";
      if (stem.length < 3) stem += "-user";
      let candidate = stem;
      let suffix = 1;
      while (taken.has(candidate)) candidate = `${stem.slice(0, 25)}-${account.id}${suffix++ > 1 ? `-${suffix}` : ""}`.slice(0, 32);
      await tx.update(users).set({ username: candidate }).where(eq(users.id, account.id));
      taken.add(candidate);
    }
  });
}

/** Accept the registered username or email, returning the same user either way. */
export async function findUserByIdentifier(identifier: string) {
  const value = normalizeUsername(identifier);
  if (!value) return null;
  const [user] = await db.select().from(users).where(or(eq(users.email, value), eq(users.username, value))).limit(1);
  return user ?? null;
}
