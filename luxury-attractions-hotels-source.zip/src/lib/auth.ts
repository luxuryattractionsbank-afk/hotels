import "server-only";

import { db } from "@/db";
import { users, type User } from "@/db/schema";
import { sessionSecret } from "@/lib/session-secret";
import { eq } from "drizzle-orm";
import { getIronSession, type SessionOptions } from "iron-session";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

export const PERMISSIONS = [
  { value: "manage_hotels", label: "Hotels, contacts & groups", description: "Create or update hotels, locations, amenities and contacts" },
  { value: "manage_rates", label: "Contracts, rates & closures", description: "Room types, seasonal rates, markets and stop-sales" },
  { value: "manage_bookings", label: "Bookings", description: "Confirm hotel stays and convert quotations to bookings" },
  { value: "manage_quotations", label: "Quotations", description: "Create, price, change and delete hotel quotations" },
  { value: "manage_services", label: "Services & tours", description: "Maintain internal transfer and tour price lists" },
  { value: "manage_packages", label: "Trip packages", description: "Create and manage trip itineraries and prices" },
  { value: "send_email", label: "Send proposal emails", description: "Email customer-facing PDFs via the configured SMTP server" },
  { value: "manage_users", label: "Users & permissions", description: "Create, disable and assign permissions to users" },
] as const;

export type Permission = (typeof PERMISSIONS)[number]["value"];
export type UserRole = "admin" | "manager" | "sales" | "viewer";
export const ROLE_NAMES: Record<UserRole, string> = {
  admin: "Administrator",
  manager: "Contract manager",
  sales: "Sales agent",
  viewer: "Read only",
};

export function defaultPermissions(role: UserRole): Permission[] {
  if (role === "admin") return PERMISSIONS.map((p) => p.value);
  if (role === "manager") return PERMISSIONS.filter((p) => p.value !== "manage_users").map((p) => p.value);
  if (role === "sales") return ["manage_bookings", "manage_quotations", "manage_packages", "send_email"];
  return [];
}

export function normalizePermissions(value: unknown): Permission[] {
  const list = Array.isArray(value) ? value : [];
  return [...new Set(list.map(String).filter((item): item is Permission => PERMISSIONS.some((p) => p.value === item)))];
}

export type SafeUser = Pick<User, "id" | "name" | "username" | "email" | "role" | "active" | "sessionVersion"> & { permissions: Permission[] };
export function toSafeUser(user: User): SafeUser {
  return { id: user.id, name: user.name, username: user.username, email: user.email, role: user.role, active: user.active, sessionVersion: user.sessionVersion, permissions: normalizePermissions(user.permissions) };
}
export function hasPermission(user: SafeUser | null, permission: Permission): boolean {
  return !!user?.active && (user.role === "admin" || user.permissions.includes(permission));
}

export type SessionData = { userId: number; version: number };
export const SESSION_COOKIE = "luxury_attractions_session";

export async function sessionOptions(): Promise<SessionOptions> {
  const secret = await sessionSecret();
  return {
    password: secret,
    cookieName: SESSION_COOKIE,
    ttl: 60 * 60 * 24 * 7,
    cookieOptions: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
    },
  };
}

export async function getSession() {
  return getIronSession<SessionData>(await cookies(), await sessionOptions());
}

export async function findSessionUser(userId?: number, version?: number): Promise<SafeUser | null> {
  if (!userId || !version) return null;
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user || !user.active || user.sessionVersion !== version) return null;
  return toSafeUser(user);
}

export async function currentUser(): Promise<SafeUser | null> {
  const session = await getSession();
  return findSessionUser(session.userId, session.version);
}

export async function requireUser(): Promise<SafeUser> {
  const user = await currentUser();
  if (!user) redirect("/login");
  return user;
}

export async function permissionError(permission: Permission): Promise<Response | null> {
  const user = await currentUser();
  if (!user) return Response.json({ error: "Please sign in to continue." }, { status: 401 });
  if (!hasPermission(user, permission)) return Response.json({ error: "You do not have permission for this action." }, { status: 403 });
  return null;
}

export const isEmail = (value: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim()) && value.length <= 254;
