import "server-only";

import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";

let cachedFallback: string | null = null;

/**
 * A private, cryptographically random, persistent fallback for managed runtimes
 * that do not preserve a developer's local .env between deployments.
 * Production operators should still set SESSION_SECRET explicitly.
 */
export async function sessionSecret(): Promise<string> {
  const configured = process.env.SESSION_SECRET;
  if (configured) {
    if (configured.length < 32) throw new Error("SESSION_SECRET must be at least 32 characters.");
    return configured;
  }
  if (cachedFallback) return cachedFallback;

  const key = "session-encryption-key";
  const generated = randomBytes(48).toString("base64url");
  // Atomic unique-key insert means two simultaneous app instances cannot create
  // different secrets. The one that wins is read back by every other instance.
  await db.insert(appSettings).values({ key, value: generated }).onConflictDoNothing({ target: appSettings.key });
  const [stored] = await db.select({ value: appSettings.value }).from(appSettings).where(eq(appSettings.key, key)).limit(1);
  if (!stored || stored.value.length < 32) throw new Error("Unable to initialize the private session key.");
  cachedFallback = stored.value;
  return stored.value;
}
