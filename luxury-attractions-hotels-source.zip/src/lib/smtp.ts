import "server-only";

import nodemailer, { type SendMailOptions } from "nodemailer";
import { isEmail } from "@/lib/auth";

export const smtpConfigured = () => Boolean(process.env.SMTP_HOST && isEmail(process.env.SMTP_FROM_EMAIL ?? ""));

/** Server-side only: never returns SMTP credentials to browser code. */
export async function sendSmtpMail(options: Pick<SendMailOptions, "to" | "subject" | "text" | "attachments">) {
  if (!smtpConfigured()) throw new Error("SMTP is not configured.");
  const port = Number(process.env.SMTP_PORT || 587);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid SMTP_PORT configuration.");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASSWORD;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: process.env.SMTP_SECURE === "true" || (process.env.SMTP_SECURE !== "false" && port === 465),
    requireTLS: process.env.SMTP_REQUIRE_TLS === "true",
    auth: user && pass ? { user, pass } : undefined,
    connectionTimeout: 12000,
    greetingTimeout: 12000,
    socketTimeout: 20000,
  });
  try {
    const fromName = (process.env.SMTP_FROM_NAME || "Luxury Attractions").replace(/[\r\n"]/g, "");
    const info = await transporter.sendMail({
      from: { name: fromName, address: process.env.SMTP_FROM_EMAIL! },
      ...options,
    });
    if (info.rejected?.length || !info.accepted?.length) throw new Error("SMTP rejected the recipient.");
    return info;
  } finally {
    transporter.close();
  }
}
