// Client proposal math + text builder. Pure and framework-free so the API routes
// (server) and the dashboard (browser) always agree on the numbers.
//
// Net cost = what the hotel charges us (stored on each quotation leg).
// Proposal = what the client pays: net cost, optionally excluding tourism tax,
// plus our markup (a % of the subtotal and/or a fixed AED amount).

import { boardLabel } from "./search-engine";

export type ProposalLegInput = {
  totalAmount: number | string;
  tourismTaxAmount: number | string;
  nights: number;
  rooms: number;
};

export type ProposalOptions = {
  includeTourismTax: boolean;
  markupPercent: number | string;
  markupAmount: number | string;
};

export type ProposalLegShare = {
  /** Leg net after the tourism-tax choice. */
  net: number;
  /** Leg share of the client proposal (markup spread proportionally). */
  share: number;
  /** Client daily rate per room per night, markup included. */
  dailyRate: number;
  /** Tourism tax excluded from the proposal for this leg (0 when included). */
  excludedTax: number;
  /** Tourism tax per room per night for this leg. */
  taxPerRoomNight: number;
};

export type ProposalResult = {
  /** Sum of leg nets after the tourism-tax choice. */
  subtotal: number;
  /** AED value of the % markup. */
  markupPercentAmount: number;
  markupFixedAmount: number;
  /** Client-facing total. */
  proposalTotal: number;
  /** Our margin = proposal total − subtotal. Never shown to the client. */
  margin: number;
  /** Total tourism tax kept out of the proposal (0 when included). */
  excludedTax: number;
  /** Single per-room-night tourism fee when every leg charges the same, else null. */
  uniformTaxPerRoomNight: number | null;
  legs: ProposalLegShare[];
};

const num = (value: number | string) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

export function sanitizeMarkupPercent(value: unknown): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) return 0;
  return Math.min(500, Math.round(parsed * 100) / 100);
}

export function sanitizeMarkupAmount(value: unknown): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) return 0;
  return Math.min(10_000_000, Math.round(parsed * 100) / 100);
}

export function computeProposal(legs: ProposalLegInput[], options: ProposalOptions): ProposalResult {
  const pct = sanitizeMarkupPercent(options.markupPercent);
  const fixed = sanitizeMarkupAmount(options.markupAmount);

  const perLeg = legs.map((leg) => {
    const total = num(leg.totalAmount);
    const tax = num(leg.tourismTaxAmount);
    const roomNights = Math.max(1, Math.round(num(leg.nights)) * Math.max(1, Math.round(num(leg.rooms))));
    const net = Math.max(0, options.includeTourismTax ? total : total - tax);
    return { net, excludedTax: options.includeTourismTax ? 0 : Math.min(tax, total), taxPerRoomNight: tax / roomNights };
  });

  const subtotal = round2(perLeg.reduce((sum, leg) => sum + leg.net, 0));
  const markupPercentAmount = round2((subtotal * pct) / 100);
  const proposalTotal = round2(subtotal + markupPercentAmount + fixed);
  const factor = subtotal > 0 ? proposalTotal / subtotal : 0;

  const shares: ProposalLegShare[] = perLeg.map((leg, index) => {
    const share = round2(leg.net * factor);
    const roomNights = Math.max(1, Math.round(num(legs[index].nights)) * Math.max(1, Math.round(num(legs[index].rooms))));
    return { ...leg, share, dailyRate: round2(share / roomNights) };
  });

  // Fix rounding drift so leg shares always add up to the proposal total.
  const drift = round2(proposalTotal - shares.reduce((sum, leg) => sum + leg.share, 0));
  if (shares.length > 0 && drift !== 0) {
    shares[shares.length - 1] = { ...shares[shares.length - 1], share: round2(shares[shares.length - 1].share + drift) };
    const last = legs[legs.length - 1];
    const roomNights = Math.max(1, Math.round(num(last.nights)) * Math.max(1, Math.round(num(last.rooms))));
    shares[shares.length - 1].dailyRate = round2(shares[shares.length - 1].share / roomNights);
  }

  const excludedTax = round2(perLeg.reduce((sum, leg) => sum + leg.excludedTax, 0));
  const taxRates = perLeg.map((leg) => round2(leg.taxPerRoomNight));
  const uniformTaxPerRoomNight = taxRates.length > 0 && taxRates.every((rate) => rate === taxRates[0]) ? taxRates[0] : null;

  return {
    subtotal,
    markupPercentAmount,
    markupFixedAmount: fixed,
    proposalTotal,
    margin: round2(proposalTotal - subtotal),
    excludedTax,
    uniformTaxPerRoomNight,
    legs: shares,
  };
}

export type ProposalTextLeg = ProposalLegInput & {
  hotelName: string;
  city: string;
  location: string;
  roomName: string;
  boardType: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
};

export type ProposalTextInput = {
  reference: string;
  clientName: string;
  validUntil: string | null;
  currency: string;
  legs: ProposalTextLeg[];
  options: ProposalOptions;
};

const money = (value: number, currency: string) =>
  `${currency} ${value.toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtDate = (iso: string) =>
  new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(`${iso.slice(0, 10)}T00:00:00Z`));

const plural = (count: number, one: string, many: string) => `${count} ${count === 1 ? one : many}`;

const shortHotel = (name: string) => name.replace(/\s+Hotel$/i, "").trim() || name;

function proposalTitle(legs: ProposalTextLeg[]): string {
  const hotels = [...new Set(legs.map((leg) => shortHotel(leg.hotelName)))];
  if (hotels.length <= 1) return `${hotels[0] ?? "Hotel"} Stay`;
  if (hotels.length === 2) return `${hotels[0]} + ${hotels[1]} Stay`;
  return `${hotels[0]} + ${hotels.length - 1} more Stay`;
}

/**
 * Builds the client proposal text. `whatsapp` uses *bold* + emoji;
 * `email` is the same content without asterisks (no markup internals in either).
 */
export function buildProposalText(input: ProposalTextInput, format: "whatsapp" | "email"): string {
  const proposal = computeProposal(input.legs, input.options);
  const bold = (text: string) => (format === "whatsapp" ? `*${text}*` : text);
  const lines: string[] = [
    `🏨 ${bold(`Proposal: ${proposalTitle(input.legs)}`)}`,
    `Ref: ${input.reference} | Client: ${input.clientName}`,
  ];
  if (input.validUntil) lines.push(`Valid until: ${fmtDate(input.validUntil)}`);
  lines.push("");

  input.legs.forEach((leg, index) => {
    const share = proposal.legs[index];
    const place = [leg.location, leg.city].filter(Boolean).join(", ");
    lines.push(
      `📍 ${bold(`Stay ${index + 1}: ${leg.hotelName}`)}`,
      `Hotel Name: ${bold(leg.hotelName)}`,
      ...(place ? [`Location: ${place}`] : []),
      `Room: ${leg.roomName}`,
      `Board: ${boardLabel(leg.boardType)}`,
      `Check In: ${fmtDate(leg.checkIn)}`,
      `Check Out: ${fmtDate(leg.checkOut)}`,
      `Nights: ${plural(leg.nights, "night", "nights")}`,
      `Guests: ${plural(leg.adults, "Adult", "Adults")} · ${plural(leg.children, "Child", "Children")} · ${plural(leg.infants, "Infant", "Infants")}`,
      `Room(s): ${leg.rooms}`,
      `Daily Rate: ${money(share.dailyRate, input.currency)} per room/night`,
      "",
    );
  });

  lines.push(`💰 ${bold(`Total Proposal Cost: ${money(proposal.proposalTotal, input.currency)}`)}`);
  if (input.options.includeTourismTax) {
    lines.push(`✅ ${bold("Tourism tax included")}`);
  } else if (proposal.uniformTaxPerRoomNight !== null) {
    lines.push(
      `⚠️ ${bold(`Excludes daily tourism tax: ${money(proposal.uniformTaxPerRoomNight, input.currency)} per room/night (${money(proposal.excludedTax, input.currency)} total, payable at the hotel)`)}`,
    );
  } else {
    lines.push(`⚠️ ${bold(`Excludes tourism tax: ${money(proposal.excludedTax, input.currency)} total (rates vary per hotel, payable at the hotels)`)}`);
  }
  return lines.join("\n");
}

/** Copies text, falling back to a hidden textarea where the Clipboard API is blocked. */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      document.body.removeChild(area);
      return true;
    } catch {
      return false;
    }
  }
}
