import type { jsPDF } from "jspdf";

export type ShareResult = "shared" | "downloaded" | "cancelled";

/**
 * Share the actual PDF file via the device's native share sheet.
 * WhatsApp/Telegram appear there if installed and accepting PDFs.
 * Web pages cannot silently attach a local file to WhatsApp/Telegram Web.
 */
export async function sharePdf(doc: jsPDF, filename: string, title: string): Promise<ShareResult> {
  if (typeof navigator !== "undefined" && typeof File !== "undefined" && navigator.canShare && navigator.share) {
    const file = new File([doc.output("blob")], filename, { type: "application/pdf" });
    if (navigator.canShare({ files: [file] })) {
      try {
        // Do not pass a URL — the recipient gets the actual PDF file.
        await navigator.share({ files: [file], title });
        return "shared";
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
        throw error;
      }
    }
  }
  // Desktop/unsupported browser: give the PDF itself as a local download.
  doc.save(filename);
  return "downloaded";
}
