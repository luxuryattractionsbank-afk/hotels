// Pure, framework-free availability & pricing engine.
// Used by the search API, the booking API, the seed script and the browser (for instant filtering).

export const ROOM_CATEGORIES = [
  { value: "deluxe_king", label: "Deluxe King" },
  { value: "deluxe_twin", label: "Deluxe Twin" },
  { value: "standard", label: "Standard / Superior" },
  { value: "triple", label: "Triple Room" },
  { value: "family", label: "Family Room" },
  { value: "suite", label: "Suite" },
  { value: "villa", label: "Villa" },
] as const;

/** Bedding kinds a room can offer. Extra beds can be priced by season; the rest use their own rate. */
export const BEDDING_KINDS = [
  { value: "extra_bed", label: "Extra bed", hint: "Rollaway / additional bed" },
  { value: "sofa_bed", label: "Sofa bed", hint: "Pull-out sofa bed" },
  { value: "baby_cot", label: "Baby cot", hint: "Often free of charge" },
] as const;

export type BeddingKind = (typeof BEDDING_KINDS)[number]["value"];

export const beddingLabel = (value: string) => BEDDING_KINDS.find((item) => item.value === value)?.label ?? value;

export const BOARD_TYPES = [
  { value: "room_only", label: "Room only", short: "RO" },
  { value: "breakfast", label: "Bed & breakfast", short: "BB" },
  { value: "half_board", label: "Half board", short: "HB" },
  { value: "full_board", label: "Full board", short: "FB" },
] as const;

export const SORT_OPTIONS = [
  { value: "price_asc", label: "Price: lowest first" },
  { value: "price_desc", label: "Price: highest first" },
  { value: "stars_desc", label: "Star rating" },
  { value: "name_asc", label: "Hotel name (A–Z)" },
] as const;

/** Source markets a contracted rate can target or exclude. "all" means every market. */
export const MARKETS = [
  { value: "all", label: "All markets" },
  { value: "uae", label: "UAE (domestic)" },
  { value: "gcc", label: "GCC" },
  { value: "europe", label: "Europe" },
  { value: "uk", label: "United Kingdom" },
  { value: "asia", label: "Asia" },
  { value: "india", label: "India & subcontinent" },
  { value: "africa", label: "Africa" },
  { value: "americas", label: "Americas" },
  { value: "cis", label: "CIS & Russia" },
] as const;

/** Falls back to a readable version of a custom slug such as "drc_nationals". */
export const marketLabel = (value: string) =>
  MARKETS.find((item) => item.value === value)?.label ?? value.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

export const parseMarketList = (value: string) =>
  value
    .split(",")
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);

export const slugifyLabel = (value: string) =>
  value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 48);

/** Builds a wa.me / t.me link from a stored phone number. */
export function messagingLink(kind: "whatsapp" | "telegram" | "viber", phone: string) {
  const digits = phone.replace(/[^\d]/g, "");
  if (!digits) return "";
  if (kind === "whatsapp") return `https://wa.me/${digits}`;
  if (kind === "telegram") return `https://t.me/+${digits}`;
  return `viber://chat?number=%2B${digits}`;
}

/** True when a rate targeting `market` (with `exclusions`) is sellable to a client from `selected`. */
export function rateAppliesToMarket(rateMarket: string, exclusions: string, selected: string) {
  if (selected === "all") return true; // browsing every market — no market filtering
  const excluded = parseMarketList(exclusions);
  if (excluded.includes(selected)) return false;
  return rateMarket === "all" || rateMarket === selected;
}

/** True when a booking made on `bookingDate` falls inside the rate's booking window (open if unset). */
export function withinBookingWindow(start: string | null, end: string | null, bookingDate: string) {
  if (start && bookingDate < start) return false;
  if (end && bookingDate > end) return false;
  return true;
}

export type SortKey = (typeof SORT_OPTIONS)[number]["value"];

export const categoryLabel = (value: string) =>
  ROOM_CATEGORIES.find((item) => item.value === value)?.label ?? value;
export const boardLabel = (value: string) => BOARD_TYPES.find((item) => item.value === value)?.label ?? value;
export const boardShort = (value: string) => BOARD_TYPES.find((item) => item.value === value)?.short ?? value;

export type EngineHotel = {
  id: number;
  name: string;
  city: string;
  /** Area inside the city/emirate, e.g. "Deira" in Dubai. */
  location?: string;
  address: string;
  starRating: number;
  currency: string;
  checkInTime: string;
  checkOutTime: string;
  tourismTax: string;
  tourismTaxBasis: string;
  amenities: string[];
  active: boolean;
};

export type EngineBedding = {
  roomTypeId: number;
  kind: string;
  label: string;
  maxPerRoom: number;
  free: boolean;
  ratePerNight: string;
  perStay: boolean;
};

export type EngineRoom = {
  id: number;
  hotelId: number;
  name: string;
  code: string;
  category: string;
  description: string;
  mediaLink: string;
  maxAdults: number;
  maxChildren: number;
  maxInfants: number;
  includedAdults: number;
  baseSleeps: number;
  defaultInventory: number;
  extraBedAllowed: boolean;
  active: boolean;
};

export type EngineOccupancy = {
  roomTypeId: number;
  adults: number;
  children: number;
  infants: number;
  extraBeds: number;
  label: string;
};

export type EngineRate = {
  id: number;
  hotelId: number;
  roomTypeId: number;
  name: string;
  boardType: string;
  validFrom: string;
  validTo: string;
  bookingWindowStart: string | null;
  bookingWindowEnd: string | null;
  market: string;
  marketExclusions: string;
  promoCode: string;
  baseRate: string;
  rateBasis: string;
  boardAdultSupplement: string;
  boardChildSupplement: string;
  boardSupplementBasis: string;
  extraAdultRate: string;
  extraChildRate: string;
  extraBedRate: string;
  extraBedBasis: string;
  minimumNights: number;
  active: boolean;
};

export type EngineBlackout = {
  hotelId: number;
  roomTypeId: number | null;
  startDate: string;
  endDate: string;
  reason: string;
};

export type EngineBooking = {
  roomTypeId: number;
  checkIn: string;
  checkOut: string;
  rooms: number;
  status: string;
};

export type SearchContext = {
  hotels: EngineHotel[];
  rooms: EngineRoom[];
  occupancies: EngineOccupancy[];
  bedding: EngineBedding[];
  rates: EngineRate[];
  blackouts: EngineBlackout[];
  bookings: EngineBooking[];
};

export type CoreCriteria = {
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  infants: number;
  rooms: number;
  extraBeds: number;
  sofaBeds: number;
  babyCots: number;
  category: string;
  market: string;
  bookingDate: string;
  hotelId?: number;
  roomTypeId?: number;
};

export const DEFAULT_CRITERIA: Omit<CoreCriteria, "checkIn" | "checkOut" | "bookingDate"> = {
  adults: 2,
  children: 0,
  infants: 0,
  rooms: 1,
  extraBeds: 0,
  sofaBeds: 0,
  babyCots: 0,
  category: "deluxe_king",
  market: "all",
};

export const todayIso = () => new Date().toISOString().slice(0, 10);

export type ResultFilters = {
  boardType: string;
  city: string;
  /** A location inside the chosen city/emirate, or "any". */
  location: string;
  minStars: number;
  minRate: number | null;
  maxRate: number | null;
  rateBasis: "excl_tax" | "incl_tax";
  amenities: string[];
  sort: SortKey;
  query: string;
};

export const DEFAULT_FILTERS: ResultFilters = {
  boardType: "any",
  city: "any",
  location: "any",
  minStars: 0,
  minRate: null,
  maxRate: null,
  rateBasis: "excl_tax",
  amenities: [],
  sort: "price_asc",
  query: "",
};

export type RoomBeddingUse = { kind: string; label: string; count: number; free: boolean; ratePerNight: number; perStay: boolean };

export type RoomAllocation = {
  adults: number;
  children: number;
  infants: number;
  bedding: RoomBeddingUse[];
  rule: string;
};

export type NightLine = {
  date: string;
  rateName: string;
  roomAmount: number;
  boardAmount: number;
  supplementAmount: number;
  extraBedAmount: number;
  total: number;
};

export type Offer = {
  boardType: string;
  rateNames: string[];
  promoCodes: string[];
  primaryRatePeriodId: number;
  minimumNights: number;
  nights: number;
  rooms: number;
  extraBeds: number;
  sofaBeds: number;
  babyCots: number;
  bedding: RoomBeddingUse[];
  baseAmount: number;
  boardAmount: number;
  occupancyAmount: number;
  extraBedAmount: number;
  tourismTaxAmount: number;
  totalAmount: number;
  avgNightlyPerRoom: number;
  avgNightlyPerRoomInclTax: number;
  nightly: NightLine[];
};

export type SearchResult = {
  key: string;
  hotel: Pick<EngineHotel, "id" | "name" | "city" | "address" | "starRating" | "currency" | "checkInTime" | "checkOutTime" | "tourismTax" | "tourismTaxBasis" | "amenities"> & { location: string };
  room: Pick<EngineRoom, "id" | "name" | "code" | "category" | "description" | "mediaLink" | "maxAdults" | "maxChildren" | "maxInfants" | "baseSleeps"> & { bedding: EngineBedding[] };
  roomsLeft: number;
  allocation: RoomAllocation[];
  offers: Offer[];
  best: Offer;
};

export type ExcludedKind = "occupancy" | "blackout" | "sold_out" | "no_rate" | "min_stay";

export type ExcludedResult = {
  key: string;
  hotelId: number;
  hotelName: string;
  city: string;
  starRating: number;
  roomName: string;
  kind: ExcludedKind;
  reason: string;
};

export type AvailabilityResponse = {
  error: string | null;
  nights: number;
  checkedHotels: number;
  checkedRooms: number;
  results: SearchResult[];
  excluded: ExcludedResult[];
};

const DAY = 86_400_000;
const money = (value: number) => Math.round(value * 100) / 100;
const num = (value: string | number) => Number(value) || 0;

export function addDays(date: string, days: number) {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

export function daysBetween(start: string, end: string) {
  return Math.round((new Date(`${end}T00:00:00Z`).getTime() - new Date(`${start}T00:00:00Z`).getTime()) / DAY);
}

export function eachNight(checkIn: string, checkOut: string) {
  const nights: string[] = [];
  let date = checkIn;
  while (date < checkOut && nights.length < 366) {
    nights.push(date);
    date = addDays(date, 1);
  }
  return nights;
}

const isIsoDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));

export function validateCore(criteria: CoreCriteria) {
  if (!isIsoDate(criteria.checkIn) || !isIsoDate(criteria.checkOut)) return "Please enter valid check-in and check-out dates.";
  const nights = daysBetween(criteria.checkIn, criteria.checkOut);
  if (nights < 1) return "Check-out must be at least one night after check-in.";
  if (nights > 60) return "Searches are limited to 60 nights.";
  if (criteria.rooms < 1 || criteria.rooms > 20) return "Choose between 1 and 20 rooms.";
  if (criteria.adults < criteria.rooms) return "Each room needs at least one adult.";
  if (criteria.adults > 80 || criteria.children < 0 || criteria.infants < 0) return "Please check the number of guests.";
  return null;
}

/** Spread guests across rooms. Children & infants are placed from the last room so they share with fewer adults. */
export function allocateGuests(adults: number, children: number, infants: number, rooms: number) {
  const allocation = Array.from({ length: rooms }, () => ({ adults: 0, children: 0, infants: 0 }));
  for (let index = 0; index < adults; index += 1) allocation[index % rooms].adults += 1;
  for (let index = 0; index < children; index += 1) allocation[rooms - 1 - (index % rooms)].children += 1;
  for (let index = 0; index < infants; index += 1) allocation[rooms - 1 - (index % rooms)].infants += 1;
  return allocation;
}

const describeGuests = (guests: { adults: number; children: number; infants: number }) =>
  [`${guests.adults} adult${guests.adults === 1 ? "" : "s"}`, guests.children ? `${guests.children} child${guests.children === 1 ? "" : "ren"}` : "", guests.infants ? `${guests.infants} infant${guests.infants === 1 ? "" : "s"}` : ""]
    .filter(Boolean)
    .join(" + ");

export function matchOccupancy(
  room: EngineRoom,
  rules: EngineOccupancy[],
  guests: { adults: number; children: number; infants: number },
): { ok: true; rule: string } | { ok: false; reason: string } {
  if (guests.adults > room.maxAdults) return { ok: false, reason: `Max ${room.maxAdults} adults per room` };
  if (guests.children > room.maxChildren) return { ok: false, reason: room.maxChildren ? `Max ${room.maxChildren} children per room` : "Children not accepted in this room" };
  if (guests.infants > room.maxInfants) return { ok: false, reason: room.maxInfants ? `Max ${room.maxInfants} infants per room` : "Infants not accepted in this room" };

  const roomRules = rules.filter((rule) => rule.roomTypeId === room.id);
  if (roomRules.length === 0) return { ok: true, rule: describeGuests(guests) };

  const matches = roomRules
    .filter((rule) => guests.adults <= rule.adults && guests.children <= rule.children && guests.infants <= rule.infants)
    .sort((a, b) => a.extraBeds - b.extraBeds || a.adults + a.children - (b.adults + b.children));
  if (matches.length === 0) {
    return { ok: false, reason: `${describeGuests(guests)} is not a permitted occupancy (allowed: ${roomRules.map((rule) => rule.label).join(", ")})` };
  }
  const chosen = matches[0];
  return { ok: true, rule: chosen.label || describeGuests(guests) };
}

/**
 * Works out the bedding needed in one room: guests beyond the room's standard beds need an extra bed or
 * sofa bed, and anything the user asked for is kept as long as the room allows it.
 */
export function assignBedding(
  room: EngineRoom,
  bedding: EngineBedding[],
  guests: { adults: number; children: number },
  requested: { extraBeds: number; sofaBeds: number; babyCots: number },
): { ok: true; bedding: RoomBeddingUse[] } | { ok: false; reason: string } {
  const options = bedding.filter((item) => item.roomTypeId === room.id);
  const option = (kind: string) => options.find((item) => item.kind === kind);
  const capacity = (kind: string) => option(kind)?.maxPerRoom ?? 0;

  if (requested.extraBeds > capacity("extra_bed")) {
    return { ok: false, reason: capacity("extra_bed") === 0 ? "This room does not allow extra beds" : `Max ${capacity("extra_bed")} extra bed(s) per room` };
  }
  if (requested.sofaBeds > capacity("sofa_bed")) {
    return { ok: false, reason: capacity("sofa_bed") === 0 ? "This room has no sofa bed" : `Max ${capacity("sofa_bed")} sofa bed(s) per room` };
  }
  if (requested.babyCots > capacity("baby_cot")) {
    return { ok: false, reason: capacity("baby_cot") === 0 ? "This room has no baby cot" : `Max ${capacity("baby_cot")} baby cot(s) per room` };
  }

  const counts: Record<string, number> = { extra_bed: requested.extraBeds, sofa_bed: requested.sofaBeds, baby_cot: requested.babyCots };
  const bedsNeeded = Math.max(0, guests.adults + guests.children - room.baseSleeps);
  const bedSlots = capacity("extra_bed") + capacity("sofa_bed");

  if (bedsNeeded > bedSlots) {
    return {
      ok: false,
      reason: `Sleeps ${room.baseSleeps} without extra bedding — ${bedsNeeded} extra bed(s) needed but only ${bedSlots} allowed`,
    };
  }

  let deficit = Math.max(0, bedsNeeded - counts.extra_bed - counts.sofa_bed);
  for (const kind of ["extra_bed", "sofa_bed"] as const) {
    if (deficit <= 0) break;
    const add = Math.min(deficit, capacity(kind) - counts[kind]);
    counts[kind] += add;
    deficit -= add;
  }
  if (deficit > 0) return { ok: false, reason: `Not enough extra bedding for ${guests.adults + guests.children} guests` };

  const used = (["extra_bed", "sofa_bed", "baby_cot"] as const)
    .filter((kind) => counts[kind] > 0)
    .map((kind) => {
      const config = option(kind)!;
      return { kind, label: config.label, count: counts[kind], free: config.free, ratePerNight: num(config.ratePerNight), perStay: config.perStay };
    });
  return { ok: true, bedding: used };
}

/** Extra-bed cost for one night in one room. Seasonal contract rate wins over the room default. */
function beddingAmountForNight(bedding: RoomBeddingUse[], seasonalExtraBedRate: number) {
  return bedding.reduce((total, item) => {
    if (item.free) return total;
    const rate = item.kind === "extra_bed" && seasonalExtraBedRate > 0 ? seasonalExtraBedRate : item.ratePerNight;
    return total + item.count * rate;
  }, 0);
}

/**
 * Pick the contract that applies to a night. Only rates whose booking window is open on the booking
 * date and that are sellable to the chosen market qualify. Shorter (more specific) periods such as
 * festive peaks and promo flash sales win.
 */
export function pickRate(rates: EngineRate[], roomTypeId: number, boardType: string, date: string, bookingDate: string, market: string) {
  return rates
    .filter(
      (rate) =>
        rate.active &&
        rate.roomTypeId === roomTypeId &&
        rate.boardType === boardType &&
        rate.validFrom <= date &&
        rate.validTo >= date &&
        withinBookingWindow(rate.bookingWindowStart, rate.bookingWindowEnd, bookingDate) &&
        rateAppliesToMarket(rate.market, rate.marketExclusions, market),
    )
    .sort((a, b) => daysBetween(a.validFrom, a.validTo) - daysBetween(b.validFrom, b.validTo) || b.id - a.id)[0];
}

function priceOffer(
  hotel: EngineHotel,
  room: EngineRoom,
  rates: EngineRate[],
  boardType: string,
  nights: string[],
  allocation: RoomAllocation[],
  bookingDate: string,
  market: string,
): { offer: Offer } | { kind: ExcludedKind; reason: string } {
  const lines: NightLine[] = [];
  const rateNames: string[] = [];
  const promoCodes: string[] = [];
  let primaryRatePeriodId = 0;
  let minimumNights = 1;

  for (const [index, date] of nights.entries()) {
    const rate = pickRate(rates, room.id, boardType, date, bookingDate, market);
    if (!rate) return { kind: "no_rate", reason: `No ${boardLabel(boardType).toLowerCase()} contract for ${date}` };
    if (!primaryRatePeriodId) primaryRatePeriodId = rate.id;
    if (!rateNames.includes(rate.name)) rateNames.push(rate.name);
    if (rate.promoCode && !promoCodes.includes(rate.promoCode)) promoCodes.push(rate.promoCode);
    minimumNights = Math.max(minimumNights, rate.minimumNights);

    let roomAmount = 0;
    let boardAmount = 0;
    let supplementAmount = 0;
    let extraBedAmount = 0;
    for (const guests of allocation) {
      const perPerson = rate.rateBasis === "person_night";
      roomAmount += perPerson ? num(rate.baseRate) * (guests.adults + guests.children) : num(rate.baseRate);
      boardAmount +=
        rate.boardSupplementBasis === "room_night"
          ? num(rate.boardAdultSupplement)
          : num(rate.boardAdultSupplement) * guests.adults + num(rate.boardChildSupplement) * guests.children;
      if (!perPerson) {
        supplementAmount += Math.max(0, guests.adults - room.includedAdults) * num(rate.extraAdultRate);
        supplementAmount += guests.children * num(rate.extraChildRate);
      }
      // Bedding charged per night, unless the hotel charges it once for the whole stay.
      extraBedAmount += beddingAmountForNight(guests.bedding.filter((item) => !item.perStay), num(rate.extraBedRate));
      if (index === 0) extraBedAmount += beddingAmountForNight(guests.bedding.filter((item) => item.perStay), num(rate.extraBedRate));
    }
    lines.push({
      date,
      rateName: rate.name,
      roomAmount: money(roomAmount),
      boardAmount: money(boardAmount),
      supplementAmount: money(supplementAmount),
      extraBedAmount: money(extraBedAmount),
      total: money(roomAmount + boardAmount + supplementAmount + extraBedAmount),
    });
  }

  if (nights.length < minimumNights) {
    return { kind: "min_stay", reason: `Minimum stay of ${minimumNights} nights applies to these dates` };
  }

  const rooms = allocation.length;
  const payingGuests = allocation.reduce((sum, guests) => sum + guests.adults + guests.children, 0);
  const tax = num(hotel.tourismTax);
  const tourismTaxAmount =
    hotel.tourismTaxBasis === "person_night"
      ? tax * payingGuests * nights.length
      : hotel.tourismTaxBasis === "per_stay"
        ? tax * rooms
        : tax * rooms * nights.length;

  const sum = (key: keyof Omit<NightLine, "date" | "rateName">) => money(lines.reduce((total, line) => total + line[key], 0));
  const stayExTax = sum("total");
  const totalAmount = money(stayExTax + tourismTaxAmount);

  return {
    offer: {
      boardType,
      rateNames,
      promoCodes,
      primaryRatePeriodId,
      minimumNights,
      nights: nights.length,
      rooms,
      extraBeds: allocation.reduce((total, guests) => total + (guests.bedding.find((item) => item.kind === "extra_bed")?.count ?? 0), 0),
      sofaBeds: allocation.reduce((total, guests) => total + (guests.bedding.find((item) => item.kind === "sofa_bed")?.count ?? 0), 0),
      babyCots: allocation.reduce((total, guests) => total + (guests.bedding.find((item) => item.kind === "baby_cot")?.count ?? 0), 0),
      bedding: allocation.flatMap((guests) => guests.bedding),
      baseAmount: sum("roomAmount"),
      boardAmount: sum("boardAmount"),
      occupancyAmount: sum("supplementAmount"),
      extraBedAmount: sum("extraBedAmount"),
      tourismTaxAmount: money(tourismTaxAmount),
      totalAmount,
      avgNightlyPerRoom: money(stayExTax / nights.length / rooms),
      avgNightlyPerRoomInclTax: money(totalAmount / nights.length / rooms),
      nightly: lines,
    },
  };
}

/** Checks every contracted hotel & room for the requested stay. */
export function evaluateAvailability(context: SearchContext, criteria: CoreCriteria): AvailabilityResponse {
  const error = validateCore(criteria);
  if (error) return { error, nights: 0, checkedHotels: 0, checkedRooms: 0, results: [], excluded: [] };

  const nights = eachNight(criteria.checkIn, criteria.checkOut);
  const lastNight = nights[nights.length - 1];
  const baseAllocation = allocateGuests(criteria.adults, criteria.children, criteria.infants, criteria.rooms);
  const hotelsById = new Map(context.hotels.map((hotel) => [hotel.id, hotel]));

  const candidates = context.rooms.filter((room) => {
    const hotel = hotelsById.get(room.hotelId);
    return (
      room.active &&
      hotel?.active &&
      (criteria.category === "any" || !criteria.category || room.category === criteria.category) &&
      (!criteria.hotelId || room.hotelId === criteria.hotelId) &&
      (!criteria.roomTypeId || room.id === criteria.roomTypeId)
    );
  });

  const results: SearchResult[] = [];
  const excluded: ExcludedResult[] = [];

  for (const room of candidates) {
    const hotel = hotelsById.get(room.hotelId)!;
    const key = `${hotel.id}-${room.id}`;
    const exclude = (kind: ExcludedKind, reason: string) =>
      excluded.push({ key, hotelId: hotel.id, hotelName: hotel.name, city: hotel.city, starRating: hotel.starRating, roomName: room.name, kind, reason });

    const allocation: RoomAllocation[] = [];
    let occupancyError = "";
    for (const guests of baseAllocation) {
      const match = matchOccupancy(room, context.occupancies, guests);
      if (!match.ok) {
        occupancyError = match.reason;
        break;
      }
      const bedding = assignBedding(room, context.bedding, guests, {
        extraBeds: Math.round(criteria.extraBeds / criteria.rooms),
        sofaBeds: Math.round(criteria.sofaBeds / criteria.rooms),
        babyCots: Math.round(criteria.babyCots / criteria.rooms),
      });
      if (!bedding.ok) {
        occupancyError = bedding.reason;
        break;
      }
      allocation.push({ ...guests, bedding: bedding.bedding, rule: match.rule });
    }
    if (occupancyError) {
      exclude("occupancy", occupancyError);
      continue;
    }

    const closure = context.blackouts.find(
      (item) =>
        item.hotelId === hotel.id &&
        (item.roomTypeId === null || item.roomTypeId === room.id) &&
        item.startDate <= lastNight &&
        item.endDate >= criteria.checkIn,
    );
    if (closure) {
      exclude("blackout", `Fully booked / stop sale ${closure.startDate} → ${closure.endDate}: ${closure.reason}`);
      continue;
    }

    const activeBookings = context.bookings.filter((booking) => booking.roomTypeId === room.id && booking.status !== "cancelled");
    const peakBooked = nights.reduce(
      (peak, date) =>
        Math.max(peak, activeBookings.filter((booking) => booking.checkIn <= date && booking.checkOut > date).reduce((total, booking) => total + booking.rooms, 0)),
      0,
    );
    const roomsLeft = room.defaultInventory - peakBooked;
    if (roomsLeft < criteria.rooms) {
      exclude("sold_out", roomsLeft <= 0 ? "Contracted allocation fully used for these dates" : `Only ${roomsLeft} contracted room(s) left`);
      continue;
    }

    const boards = BOARD_TYPES.map((board) => board.value).filter((board) => context.rates.some((rate) => rate.roomTypeId === room.id && rate.boardType === board));
    const offers: Offer[] = [];
    const failures: { kind: ExcludedKind; reason: string }[] = [];
    for (const board of boards) {
      const priced = priceOffer(hotel, room, context.rates, board, nights, allocation, criteria.bookingDate, criteria.market);
      if ("offer" in priced) offers.push(priced.offer);
      else failures.push(priced);
    }
    if (offers.length === 0) {
      const minStay = failures.find((failure) => failure.kind === "min_stay");
      exclude(minStay ? "min_stay" : "no_rate", minStay?.reason ?? failures[0]?.reason ?? "No contracted rate covers every night of this stay");
      continue;
    }
    offers.sort((a, b) => a.totalAmount - b.totalAmount);

    results.push({
      key,
      hotel: {
        id: hotel.id,
        name: hotel.name,
        city: hotel.city,
        location: hotel.location ?? "",
        address: hotel.address,
        starRating: hotel.starRating,
        currency: hotel.currency,
        checkInTime: hotel.checkInTime,
        checkOutTime: hotel.checkOutTime,
        tourismTax: hotel.tourismTax,
        tourismTaxBasis: hotel.tourismTaxBasis,
        amenities: hotel.amenities ?? [],
      },
      room: {
        id: room.id,
        name: room.name,
        code: room.code,
        category: room.category,
        description: room.description,
        mediaLink: room.mediaLink,
        maxAdults: room.maxAdults,
        maxChildren: room.maxChildren,
        maxInfants: room.maxInfants,
        baseSleeps: room.baseSleeps,
        bedding: context.bedding.filter((item) => item.roomTypeId === room.id),
      },
      roomsLeft,
      allocation,
      offers,
      best: offers[0],
    });
  }

  return {
    error: null,
    nights: nights.length,
    checkedHotels: new Set(candidates.map((room) => room.hotelId)).size,
    checkedRooms: candidates.length,
    results,
    excluded,
  };
}

export const comparableRate = (offer: Offer, basis: ResultFilters["rateBasis"]) =>
  basis === "incl_tax" ? offer.avgNightlyPerRoomInclTax : offer.avgNightlyPerRoom;

/** Applies board, price range, location and sorting filters. Safe to run in the browser. */
export function applyFilters(results: SearchResult[], filters: ResultFilters) {
  const query = filters.query.trim().toLowerCase();
  let outsidePriceRange = 0;
  const filtered: SearchResult[] = [];

  for (const result of results) {
    if (filters.city !== "any" && result.hotel.city !== filters.city) continue;
    // A location only narrows results inside its own city/emirate.
    if (filters.city !== "any" && filters.location !== "any" && result.hotel.location !== filters.location) continue;
    if (result.hotel.starRating < filters.minStars) continue;
    if (filters.amenities.length > 0 && !filters.amenities.every((slug) => result.hotel.amenities.includes(slug))) continue;
    if (query && !`${result.hotel.name} ${result.room.name}`.toLowerCase().includes(query)) continue;
    const boardMatches = result.offers.filter((offer) => filters.boardType === "any" || offer.boardType === filters.boardType);
    if (boardMatches.length === 0) continue;
    const inRange = boardMatches.filter((offer) => {
      const rate = comparableRate(offer, filters.rateBasis);
      return (filters.minRate === null || rate >= filters.minRate) && (filters.maxRate === null || rate <= filters.maxRate);
    });
    if (inRange.length === 0) {
      outsidePriceRange += 1;
      continue;
    }
    filtered.push({ ...result, offers: inRange, best: inRange[0] });
  }

  filtered.sort((a, b) => {
    const priceA = comparableRate(a.best, filters.rateBasis);
    const priceB = comparableRate(b.best, filters.rateBasis);
    if (filters.sort === "price_desc") return priceB - priceA;
    if (filters.sort === "stars_desc") return b.hotel.starRating - a.hotel.starRating || priceA - priceB;
    if (filters.sort === "name_asc") return a.hotel.name.localeCompare(b.hotel.name) || priceA - priceB;
    return priceA - priceB;
  });

  return { results: filtered, outsidePriceRange };
}

export function parseCoreCriteria(body: Record<string, unknown>): CoreCriteria {
  const int = (value: unknown, fallback: number) => {
    const parsed = Math.floor(Number(value));
    return Number.isFinite(parsed) ? parsed : fallback;
  };
  return {
    checkIn: String(body.checkIn ?? ""),
    checkOut: String(body.checkOut ?? ""),
    adults: Math.max(0, int(body.adults, 2)),
    children: Math.max(0, int(body.children, 0)),
    infants: Math.max(0, int(body.infants, 0)),
    rooms: Math.max(1, int(body.rooms, 1)),
    extraBeds: Math.max(0, int(body.extraBeds, 0)),
    sofaBeds: Math.max(0, int(body.sofaBeds, 0)),
    babyCots: Math.max(0, int(body.babyCots, 0)),
    category: String(body.category || "any"),
    // Accept any market slug, including custom nationalities added by the team.
    market: /^[a-z0-9_]+$/.test(String(body.market)) ? String(body.market) : "all",
    bookingDate: /^\d{4}-\d{2}-\d{2}$/.test(String(body.bookingDate)) ? String(body.bookingDate) : todayIso(),
    hotelId: body.hotelId ? int(body.hotelId, 0) || undefined : undefined,
    roomTypeId: body.roomTypeId ? int(body.roomTypeId, 0) || undefined : undefined,
  };
}

export function parseFilters(body: Record<string, unknown>): ResultFilters {
  const rate = (value: unknown) => (value === null || value === undefined || value === "" || !Number.isFinite(Number(value)) ? null : Number(value));
  const sort = SORT_OPTIONS.some((option) => option.value === body.sort) ? (body.sort as SortKey) : "price_asc";
  const rawAmenities = Array.isArray(body.amenities)
    ? body.amenities
    : String(body.amenities ?? "")
        .split(",")
        .map((value) => value.trim());
  const amenities = rawAmenities.map((value) => String(value)).filter(Boolean);
  return {
    boardType: String(body.boardType || "any"),
    city: String(body.city || "any"),
    location: String(body.location || "any"),
    minStars: Number(body.minStars) || 0,
    minRate: rate(body.minRate),
    maxRate: rate(body.maxRate),
    rateBasis: body.rateBasis === "incl_tax" ? "incl_tax" : "excl_tax",
    amenities,
    sort,
    query: String(body.query || ""),
  };
}
