import { getIronSession, nextProxyCookies } from "iron-session";
import { NextResponse, type NextRequest } from "next/server";
import { findSessionUser, hasPermission, sessionOptions, type Permission, type SessionData } from "@/lib/auth";

function requiredPermission(pathname: string): Permission | null {
  if (pathname.startsWith("/api/users")) return "manage_users";
  if (pathname.startsWith("/api/proposals/email")) return "send_email";
  if (pathname.startsWith("/api/quotations/convert")) return "manage_bookings";
  if (pathname.startsWith("/api/quotations")) return "manage_quotations";
  if (pathname.startsWith("/api/trip-packages")) return "manage_packages";
  if (pathname.startsWith("/api/services")) return "manage_services";
  if (pathname.startsWith("/api/bookings")) return "manage_bookings";
  if (pathname.startsWith("/api/rates") || pathname.startsWith("/api/rooms") || pathname.startsWith("/api/blackouts") || pathname.startsWith("/api/markets") || pathname.startsWith("/api/room-categories")) return "manage_rates";
  if (pathname.startsWith("/api/hotels") || pathname.startsWith("/api/hotel-groups") || pathname.startsWith("/api/hotel-amenities") || pathname.startsWith("/api/contacts") || pathname.startsWith("/api/locations") || pathname.startsWith("/api/amenities")) return "manage_hotels";
  return null;
}

export async function proxy(request: NextRequest) {
  const response = NextResponse.next();
  const session = await getIronSession<SessionData>(nextProxyCookies(request, response), await sessionOptions());
  const user = await findSessionUser(session.userId, session.version);
  const path = request.nextUrl.pathname;
  const isApi = path.startsWith("/api/");

  if (!user) {
    if (isApi) return NextResponse.json({ error: "Please sign in to continue." }, { status: 401 });
    const url = new URL("/login", request.url);
    url.searchParams.set("next", request.nextUrl.pathname + request.nextUrl.search);
    return NextResponse.redirect(url);
  }

  if (isApi && !["GET", "HEAD", "OPTIONS"].includes(request.method.toUpperCase())) {
    if (path === "/api/search") return response;
    const permission = requiredPermission(path);
    if (!permission || !hasPermission(user, permission)) {
      return NextResponse.json({ error: "You do not have permission for this action." }, { status: 403 });
    }
  }
  if (path.startsWith("/api/users") && !hasPermission(user, "manage_users")) {
    return NextResponse.json({ error: "You do not have permission to manage users." }, { status: 403 });
  }
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|manifest.webmanifest|downloads|login|forgot-password|reset-password|api/auth|api/health).*)"],
};
