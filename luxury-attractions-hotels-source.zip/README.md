# Luxury Attractions — Hotel Contracts & Trip Packages

Private staff application for contracted B2B hotel rates, availability, quotations, bookings, transfers, tours, PDF proposals and trip packages.

## Stack

**Next.js 16 (App Router), Drizzle ORM, PostgreSQL, jsPDF, encrypted iron-session cookies, bcrypt password hashes and Nodemailer SMTP.** This implementation is **not Laravel/MySQL**. Hosting at `hotels.luxuryattractions.com` requires a Node.js host and PostgreSQL, plus DNS and reverse-proxy setup.

## Local setup

1. Install Node.js **22.13+** and PostgreSQL. Create an empty database.
2. Run `npm ci`.
3. Copy `.env.example` to `.env`. Set `DATABASE_URL`. For production, strongly prefer a long random `SESSION_SECRET` (at least 32 characters) and set a one-time `INITIAL_SETUP_TOKEN` before the first administrator signs up. If `SESSION_SECRET` is omitted, the app creates a random encrypted-session key in a private PostgreSQL settings table; it is never included in API responses or source downloads.
4. Update `dbCredentials.url` in `drizzle.config.json` to point to the **same** database as `DATABASE_URL` (the source archive contains only the sandbox's local address).
5. Run `npx drizzle-kit push` to create the tables.
6. Run `npm run dev` locally, or `npm run build` and `npm run start` on your production Node server.
7. Open `/login`. If there are no users yet, create the **first administrator** with a username, registered email and password (enter the optional one-time setup token if configured). Then use **Users & permissions** to create staff accounts with usernames, email addresses and roles. Remove the setup token after first setup.
8. Existing accounts created before usernames were introduced receive a unique username derived from their registered email on the next login/user-list visit. An administrator can change it in **Users & permissions**.

Existing demo supplier data is seeded on the first dashboard visit if the hotel database is empty. **Demo hotels, contracts, contact details, rates, Google Drive links and service prices are illustrative only.** Replace them with your own before selling or sending real proposals.

## Permissions & sessions

Accounts have administrator, contract-manager, sales-agent or read-only roles. An administrator can fine-tune individual permissions for hotels/contacts, contracts/rates, bookings, quotations, services, trip packages, proposal email and user management. API writes are checked server-side; simply hiding a button is not considered authorization. Accounts can be deactivated and password/permission changes invalidate previous sessions. Login rate limiting locks an account temporarily after repeated failed attempts.

### Password recovery

- Staff can sign in with either their **username or registered email**.
- **Forgot password?** on `/login` opens `/forgot-password`. Enter either identifier; a matching active account receives a one-time link at its **registered email only**. The response does not reveal whether the account exists.
- Reset links expire after **30 minutes**, are single-use, and only their SHA-256 hashes are stored in PostgreSQL. Requests are limited to three per account per hour, no more than one per minute. Resetting the password revokes other reset links and all previous login sessions.
- Recovery email uses the same SMTP settings as proposal delivery. Set `APP_BASE_URL=https://hotels.luxuryattractions.com` on the deployed server so emailed links point to the correct HTTPS origin. Without SMTP, `/forgot-password` says email recovery is unavailable; an administrator can still change the user's password in **Users & permissions** or request a reset email from that screen once SMTP is configured.

## PDFs, file sharing & SMTP

- Quotations and trip packages download as client-facing PDF files. Net supplier costs, internal margins and markup percentages are **not** shown in these PDFs.
- **Share PDF** sends the actual PDF file to the device's native share sheet (`navigator.share({ files: [...] })`); WhatsApp or Telegram can be selected there on supported devices. This is not a link. Web browsers cannot force a file directly into WhatsApp/Telegram Web. On unsupported browsers, the PDF downloads for manual attachment.
- **Email PDF** sends the saved document itself as an SMTP attachment from the server. Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_FROM_EMAIL` and your provider's credentials in `.env`. Port 587 normally uses STARTTLS (`SMTP_SECURE=false`, `SMTP_REQUIRE_TLS=true`); port 465 uses TLS (`SMTP_SECURE=true`). Without configured SMTP, the dialog explains that email cannot yet send; Download/Share continue to work. SMTP settings and passwords never go into the browser bundle.

## Deployment & security

- Use HTTPS on the final subdomain; encrypted session cookies are marked Secure in production.
- Keep configured `SESSION_SECRET`, SMTP credentials and `DATABASE_URL` only in server-side environment variables. If using the auto-generated session key instead, back up PostgreSQL's private `app_settings` table; losing it signs staff out. The real `.env`, build output, installed dependencies and database contents are **excluded** from source downloads.
- Create the initial administrator **before** publishing the subdomain. For public deployments, set `INITIAL_SETUP_TOKEN` during that first setup so nobody else can claim it; remove the token after setup.
- Configure database backups and use real supplier information before production use.
- The `/api/health` route is public for deployment health checks and contains no business data.
