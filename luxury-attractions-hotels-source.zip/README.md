# Luxury Attractions — Hotel Contracts & Booking Platform

Source snapshot for the B2B hotel rates, availability, quotations, PDF proposals, bookings, services, tours, and trip-package application.

## Stack

This implementation uses **Next.js (App Router), Drizzle ORM and PostgreSQL**. It is **not Laravel/MySQL**. Hosting at `hotels.luxuryattractions.com` requires a Node.js host and a PostgreSQL database, plus DNS/reverse-proxy configuration by your hosting provider.

## Local setup

1. Install Node.js 20+ and PostgreSQL, and create a database.
2. Run `npm ci` in this project directory.
3. Copy `.env.example` to `.env` and set `DATABASE_URL` to your PostgreSQL connection string.
4. Set the `dbCredentials.url` in `drizzle.config.json` to **the same database URL**. The downloaded config contains only the sandbox's local database address; change it before pushing the schema on your server.
5. Run `npx drizzle-kit push` to create the tables.
6. Run `npm run dev` for local development, or `npm run build` and `npm run start` for production.

The first dashboard visit inserts **illustrative demo hotels, contacts, services, seasonal rates, and other example records** if the hotel database is empty. Replace these with your real supplier contracts. Demo Google Drive links and contact details are examples, not uploaded files.

## Deployment and security

- The private `.env` file, `node_modules`, build output, and database contents are **not included** in this archive.
- The current app does **not** include user authentication or authorization. **Do not expose it publicly** until access control, backups, and production security settings are in place.
- Client-facing PDFs are generated from quotations and trip packages. Internal net costs and markup details should remain private.
